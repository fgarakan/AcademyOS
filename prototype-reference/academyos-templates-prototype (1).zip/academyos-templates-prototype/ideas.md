# AcademyOS Templates — Design Brainstorm

## Design Brief Summary
Dark premium athletic SaaS for tennis academy directors. Teal/aqua accent, DONNA AI assistant, command-center feel. 10 screens covering class/fitness template workflows.

---

<response>
<text>

## Idea 1: Obsidian Command Layer
**Design Movement:** Dark Brutalism meets Precision Instrument UI
**Core Principles:**
1. Monolithic dark surfaces with surgical teal cuts — every accent earns its place
2. Information density balanced by generous breathing room (no cramped tables)
3. DONNA as a glowing oracle presence — always visible, never intrusive
4. Structural hierarchy through weight contrast, not color noise

**Color Philosophy:** Near-black (#0D0F12) base, deep charcoal card surfaces (#161A1F), teal accent (#00C9B1) for primary actions and active states, amber (#F5A623) for warnings/review states, muted slate for secondary text. The palette reads like a high-end sports analytics platform.

**Layout Paradigm:** Fixed 240px sidebar + fluid content area + collapsible 320px DONNA panel. Content area uses a 12-column grid that breaks into asymmetric 7/5 splits for detail pages. Cards float above the surface with a 1px teal-glow border on hover.

**Signature Elements:**
1. Teal left-border accent on active sidebar items + cards in focus
2. Colored level dots (Red/Orange/Green/Yellow/HP) as consistent visual language
3. Frosted glass DONNA panel with subtle animated gradient border

**Interaction Philosophy:** Every action has a clear affordance. Hover reveals depth. Click confirms with a micro-scale pulse. DONNA suggestions slide in from the right with a gentle blur-fade.

**Animation:** 180ms ease-out for card hovers, 250ms for panel transitions, 300ms for step-flow progression. Cards enter with a 40ms stagger and translateY(8px) → translateY(0) + opacity fade.

**Typography System:** `Space Grotesk` (700/600) for headings — technical yet warm. `Inter` (400/500) for body and labels. Monospaced `JetBrains Mono` for stats, durations, and data points.

</text>
<probability>0.08</probability>
</response>

<response>
<text>

## Idea 2: Athletic Intelligence Dashboard ← SELECTED
**Design Movement:** Premium Sports SaaS / Dark Athletic Command Center
**Core Principles:**
1. Black-to-deep-charcoal depth hierarchy — every layer has purpose
2. Teal/aqua as the single action color — never diluted, always intentional
3. Cards as the primary unit of information — spacious, readable, hover-alive
4. DONNA as a persistent right-rail intelligence partner

**Color Philosophy:** Background #0A0C0F (near-black), card surface #111318, elevated card #161B22, teal accent #0ECFB8 (primary), teal-dim #0A9E8A (hover), amber #F59E0B (review/draft), green #22C55E (ready), slate-400 for secondary text. The palette evokes a high-performance analytics suite used by elite sports organizations.

**Layout Paradigm:** 240px fixed sidebar with icon+label nav, main content with max-w-[calc(100vw-240px-340px)] when DONNA panel is open, collapsible 340px DONNA panel. Step flows use a centered 800px container with a progress stepper at top. Library views use a 3-column responsive card grid.

**Signature Elements:**
1. Level color dots (Red #EF4444, Orange #F97316, Green #22C55E, Yellow #EAB308, HP #A855F7) as consistent visual language across all cards
2. Teal glow box-shadow on primary action buttons and active nav items
3. DONNA panel with animated gradient top border (teal → purple → teal)

**Interaction Philosophy:** Guided flows reduce cognitive load. DONNA suggestions appear contextually. Every destructive action requires explicit review-queue confirmation. Nothing silently overwrites curriculum.

**Animation:** 200ms ease-out card hovers with scale(1.01) + border-color transition. 300ms slide-in for DONNA panel. Step transitions use a 250ms horizontal slide with opacity. Staggered card grid entrance at 50ms intervals.

**Typography System:** `Syne` (700/800) for page titles and hero text — bold, confident, athletic. `Inter` (400/500) for body, labels, metadata. `Space Mono` for durations, counts, and technical data points.

</text>
<probability>0.09</probability>
</response>

<response>
<text>

## Idea 3: Midnight Precision Interface
**Design Movement:** Swiss Grid + Dark Mode SaaS
**Core Principles:**
1. Strict typographic hierarchy — size and weight carry all meaning
2. Minimal color — only teal and status colors, everything else is grayscale
3. Dense information presented through careful spacing, not color coding
4. DONNA as a structured sidebar assistant with clear input/output sections

**Color Philosophy:** Pure #000000 background, #0F0F0F cards, single teal #14B8A6, white text with strict opacity hierarchy (100% / 70% / 40%). Extremely restrained — the discipline of the palette communicates trust.

**Layout Paradigm:** 200px minimal sidebar (icons only on collapse), full-width content area, DONNA as a bottom drawer on mobile / right panel on desktop. Heavy use of horizontal rules and section dividers.

**Signature Elements:**
1. Monochrome level indicators (text labels only, no color dots)
2. Teal underline on active states instead of background fills
3. Minimal card borders (1px #1A1A1A) with no shadows

**Interaction Philosophy:** Keyboard-first. Every action is labeled. No animations except for essential state transitions.

**Animation:** Minimal — 150ms opacity only. No transforms. Respects reduced-motion by default.

**Typography System:** `IBM Plex Mono` throughout — pure technical precision. Single font family with weight variation only.

</text>
<probability>0.05</probability>
</response>

---

## Selected Approach: **Idea 2 — Athletic Intelligence Dashboard**

This approach best matches the "dark premium athletic SaaS" brief and the existing AcademyOS Curriculum Builder style. The Syne + Inter typography pairing gives the interface a confident, modern athletic feel without being generic. The teal glow system and level color dots create a rich visual language that scales across all 10 screens.
