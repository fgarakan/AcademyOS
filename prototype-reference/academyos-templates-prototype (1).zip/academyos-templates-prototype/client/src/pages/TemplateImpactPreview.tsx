/**
 * Screen 9: Template Impact Preview
 * Shows what a template change will affect before anything is applied
 */

import { useLocation } from "wouter";
import Layout from "@/components/Layout";
import {
  ArrowLeft,
  AlertTriangle,
  CalendarDays,
  BookOpen,
  Users,
  ClipboardCheck,
  MessageSquare,
  Dumbbell,
  ListChecks,
  Shield,
  Check,
  X,
  Send,
  Save,
  ChevronRight,
} from "lucide-react";

const IMPACT_CARDS = [
  {
    icon: CalendarDays,
    label: "Future Sessions",
    count: 8,
    desc: "Sessions scheduled to use this template",
    color: "oklch(0.78 0.12 185)",
    items: ["Monday 9:00am — Orange Ball 2 Group A", "Wednesday 4:00pm — Orange Ball 2 Group B", "+6 more sessions"],
  },
  {
    icon: BookOpen,
    label: "Coach Briefings",
    count: 3,
    desc: "Coach briefings that reference this template",
    color: "oklch(0.65 0.20 295)",
    items: ["Coach Sarah — OB2 Monday group", "Coach Mike — OB2 Wednesday group", "Coach Lee — OB2 Friday group"],
  },
  {
    icon: BookOpen,
    label: "Curriculum Connections",
    count: 4,
    desc: "Curriculum skills linked to this template",
    color: "oklch(0.70 0.18 45)",
    items: ["Crosscourt control — Orange Ball 2", "Recovery step — Orange Ball 2", "Wide ball patterns", "Rally consistency gate"],
  },
  {
    icon: Users,
    label: "Player Requirements",
    count: 12,
    desc: "Players currently assigned to this template",
    color: "oklch(0.65 0.17 145)",
    items: ["Orange Ball 2 Group A — 6 players", "Orange Ball 2 Group B — 6 players"],
  },
  {
    icon: ClipboardCheck,
    label: "Assessment Opportunities",
    count: 2,
    desc: "Assessment gates connected to this template",
    color: "oklch(0.78 0.17 90)",
    items: ["Rally consistency gate — OB2", "Recovery step assessment"],
  },
  {
    icon: MessageSquare,
    label: "Parent/Player Summaries",
    count: 12,
    desc: "Summaries that reference this session focus",
    color: "oklch(0.78 0.12 185)",
    items: ["12 player summaries reference this template's focus"],
  },
  {
    icon: Dumbbell,
    label: "Fitness Pathway",
    count: 1,
    desc: "Fitness templates connected to this class template",
    color: "oklch(0.65 0.20 295)",
    items: ["Low Contact Mobility Prep — Orange Ball 2"],
  },
  {
    icon: ListChecks,
    label: "Review Queue",
    count: 0,
    desc: "Items currently in review queue",
    color: "oklch(0.55 0.008 240)",
    items: ["No items currently in review queue"],
  },
];

export default function TemplateImpactPreview() {
  const [, navigate] = useLocation();

  return (
    <Layout
      donnaPrompt="I've mapped everything this template change will affect. Nothing changes until you review and approve."
      donnaActions={[
        "Apply to this template only",
        "Apply to future sessions",
        "Show affected players",
        "Show affected coaches",
        "Save as draft first",
        "Cancel this change",
      ]}
    >
      <div className="px-8 py-7 space-y-6">
        {/* Header */}
        <div className="animate-fade-slide-up">
          <button
            onClick={() => navigate("/templates/class/1")}
            className="flex items-center gap-1.5 text-sm mb-4 transition-colors hover:opacity-80"
            style={{ color: "oklch(0.55 0.008 240)" }}
          >
            <ArrowLeft size={14} />
            Template Editor
          </button>
          <div className="flex items-start justify-between">
            <div>
              <h1 className="font-display text-3xl font-bold" style={{ color: "oklch(0.93 0.005 240)" }}>
                Template Impact Preview
              </h1>
              <p className="mt-1 text-sm" style={{ color: "oklch(0.55 0.008 240)" }}>
                Review what this template change will affect before anything is applied.
              </p>
            </div>
          </div>
        </div>

        {/* Safety Banner */}
        <div
          className="rounded-2xl p-5 animate-fade-slide-up stagger-1"
          style={{
            background: "linear-gradient(135deg, oklch(0.78 0.17 90 / 0.08), oklch(0.62 0.22 25 / 0.05))",
            border: "1px solid oklch(0.78 0.17 90 / 0.25)",
          }}
        >
          <div className="flex items-start gap-4">
            <div
              className="w-10 h-10 rounded-xl flex items-center justify-center shrink-0"
              style={{ background: "oklch(0.78 0.17 90 / 0.15)" }}
            >
              <AlertTriangle size={20} style={{ color: "oklch(0.78 0.17 90)" }} />
            </div>
            <div>
              <h2 className="font-display font-bold text-base mb-1" style={{ color: "oklch(0.78 0.17 90)" }}>
                Nothing changes until you review and approve.
              </h2>
              <p className="text-sm" style={{ color: "oklch(0.70 0.005 240)" }}>
                This is a preview only. Review the impact below, then choose your scope of change. Your master curriculum is never silently overwritten.
              </p>
            </div>
          </div>
        </div>

        {/* Template being changed */}
        <div
          className="rounded-2xl p-4 animate-fade-slide-up stagger-2 flex items-center gap-4"
          style={{ background: "oklch(0.12 0.010 240)", border: "1px solid oklch(1 0 0 / 0.06)" }}
        >
          <div
            className="w-2 h-12 rounded-full"
            style={{ background: "oklch(0.70 0.18 45)" }}
          />
          <div>
            <p className="text-xs mb-0.5" style={{ color: "oklch(0.45 0.008 240)" }}>Template being changed</p>
            <p className="font-display font-bold text-base" style={{ color: "oklch(0.90 0.005 240)" }}>
              Orange Ball 2 — Recovery + Crosscourt Patterns
            </p>
            <p className="text-xs" style={{ color: "oklch(0.55 0.008 240)" }}>
              Class Template · Orange Ball 2 · 80 min · Currently: Ready
            </p>
          </div>
          <div className="ml-auto flex items-center gap-2">
            <span className="badge-review text-xs px-2.5 py-1 rounded-full font-medium">Pending Review</span>
          </div>
        </div>

        {/* Impact Cards Grid */}
        <div className="animate-fade-slide-up stagger-3">
          <h2 className="font-display font-bold text-base mb-4" style={{ color: "oklch(0.85 0.005 240)" }}>
            Impact Summary
          </h2>
          <div className="grid grid-cols-4 gap-4">
            {IMPACT_CARDS.map((card, i) => {
              const Icon = card.icon;
              const hasImpact = card.count > 0;
              return (
                <div
                  key={i}
                  className="rounded-2xl p-4 card-hover"
                  style={{
                    background: "oklch(0.12 0.010 240)",
                    borderLeft: hasImpact ? `3px solid ${card.color}` : "3px solid oklch(0.20 0.008 240)",
                  }}
                >
                  <div className="flex items-start justify-between mb-3">
                    <div
                      className="w-9 h-9 rounded-xl flex items-center justify-center"
                      style={{ background: hasImpact ? `${card.color.replace(")", " / 0.12)")}` : "oklch(0.16 0.010 240)" }}
                    >
                      <Icon size={16} style={{ color: hasImpact ? card.color : "oklch(0.35 0.008 240)" }} />
                    </div>
                    <span
                      className="font-mono-data font-bold text-xl"
                      style={{ color: hasImpact ? card.color : "oklch(0.35 0.008 240)" }}
                    >
                      {card.count}
                    </span>
                  </div>
                  <p className="font-display font-bold text-sm mb-1" style={{ color: hasImpact ? "oklch(0.85 0.005 240)" : "oklch(0.45 0.008 240)" }}>
                    {card.label}
                  </p>
                  <p className="text-xs mb-3" style={{ color: "oklch(0.45 0.008 240)" }}>
                    {card.desc}
                  </p>
                  {hasImpact && (
                    <div className="space-y-1">
                      {card.items.map((item, j) => (
                        <div key={j} className="flex items-center gap-1.5">
                          <ChevronRight size={10} style={{ color: card.color }} />
                          <span className="text-xs" style={{ color: "oklch(0.55 0.008 240)" }}>{item}</span>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>

        {/* Scope Actions */}
        <div
          className="rounded-2xl p-6 animate-fade-slide-up stagger-4"
          style={{ background: "oklch(0.12 0.010 240)", border: "1px solid oklch(1 0 0 / 0.06)" }}
        >
          <h2 className="font-display font-bold text-base mb-2" style={{ color: "oklch(0.85 0.005 240)" }}>
            Choose Scope of Change
          </h2>
          <p className="text-sm mb-5" style={{ color: "oklch(0.55 0.008 240)" }}>
            Select how broadly you want this change to apply.
          </p>

          <div className="grid grid-cols-2 gap-3 mb-5">
            {[
              {
                label: "Apply to this template only",
                desc: "Changes apply only to this template. Existing scheduled sessions are not affected.",
                recommended: false,
              },
              {
                label: "Apply to future sessions using this template",
                desc: "All future sessions using this template will reflect the changes. Past sessions are not affected.",
                recommended: true,
              },
            ].map((option, i) => (
              <div
                key={i}
                className="px-4 py-4 rounded-xl cursor-pointer transition-all hover:border-teal-500/30"
                style={{
                  background: i === 1 ? "oklch(0.78 0.12 185 / 0.06)" : "oklch(0.09 0.008 240)",
                  border: i === 1 ? "1px solid oklch(0.78 0.12 185 / 0.25)" : "1px solid oklch(1 0 0 / 0.08)",
                }}
              >
                <div className="flex items-start gap-3">
                  <div
                    className="w-5 h-5 rounded-full flex items-center justify-center shrink-0 mt-0.5"
                    style={
                      i === 1
                        ? { background: "oklch(0.78 0.12 185)", color: "oklch(0.09 0.008 240)" }
                        : { background: "oklch(0.16 0.010 240)", border: "1px solid oklch(1 0 0 / 0.15)" }
                    }
                  >
                    {i === 1 && <Check size={11} />}
                  </div>
                  <div>
                    <p className="font-display font-bold text-sm mb-1" style={{ color: i === 1 ? "oklch(0.78 0.12 185)" : "oklch(0.75 0.005 240)" }}>
                      {option.label}
                      {option.recommended && (
                        <span className="ml-2 text-xs px-1.5 py-0.5 rounded" style={{ background: "oklch(0.78 0.12 185 / 0.15)", color: "oklch(0.78 0.12 185)" }}>
                          Recommended
                        </span>
                      )}
                    </p>
                    <p className="text-xs" style={{ color: "oklch(0.50 0.008 240)" }}>
                      {option.desc}
                    </p>
                  </div>
                </div>
              </div>
            ))}
          </div>

          <div className="flex items-center gap-3">
            <button
              className="flex items-center gap-2 px-5 py-2.5 rounded-xl text-sm font-medium transition-all hover:bg-white/[0.05]"
              style={{ background: "oklch(0.09 0.008 240)", border: "1px solid oklch(1 0 0 / 0.08)", color: "oklch(0.75 0.005 240)" }}
            >
              <Save size={15} />
              Save as Draft
            </button>
            <button
              className="flex items-center gap-2 px-5 py-2.5 rounded-xl text-sm font-medium transition-all hover:bg-white/[0.05]"
              style={{ background: "oklch(0.78 0.17 90 / 0.10)", border: "1px solid oklch(0.78 0.17 90 / 0.30)", color: "oklch(0.78 0.17 90)" }}
            >
              <Send size={15} />
              Send to Review Queue
            </button>
            <button
              className="flex items-center gap-2 px-5 py-2.5 rounded-xl text-sm font-medium transition-all hover:bg-white/[0.05]"
              style={{ background: "oklch(0.12 0.010 240)", border: "1px solid oklch(1 0 0 / 0.08)", color: "oklch(0.55 0.008 240)" }}
              onClick={() => navigate("/templates/class/1")}
            >
              <X size={15} />
              Cancel
            </button>
            <button
              className="btn-teal flex items-center gap-2 px-6 py-2.5 rounded-xl text-sm ml-auto"
            >
              <Shield size={15} />
              Apply &amp; Send to Review
            </button>
          </div>
        </div>
      </div>
    </Layout>
  );
}
