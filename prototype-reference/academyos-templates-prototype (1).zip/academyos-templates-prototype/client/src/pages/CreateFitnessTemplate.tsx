/**
 * Screen 6: Create Fitness Template — DONNA Guided Setup
 * Block-based flow: Level → Build Blocks → Configure Blocks → Review
 * Design: Athletic Intelligence Dashboard — DM Sans, dark near-black, teal accent
 */

import { useState } from "react";
import { useLocation } from "wouter";
import Layout from "@/components/Layout";
import {
  ArrowLeft,
  ArrowRight,
  Check,
  Sparkles,
  Plus,
  X,
  Save,
  Eye,
  Send,
  GripVertical,
  Activity,
  Zap,
  Dumbbell,
  Wind,
  RotateCcw,
  Shield,
  Flame,
  Layers,
  ChevronDown,
  ChevronUp,
} from "lucide-react";

const STEPS = [
  { id: 1, label: "Choose Level" },
  { id: 2, label: "Build Blocks" },
  { id: 3, label: "Configure Blocks" },
  { id: 4, label: "Review" },
];

const LEVEL_GROUPS = [
  { group: "Red Ball", items: ["Red Ball 1", "Red Ball 2", "Red Ball 3"], color: "oklch(0.62 0.22 25)" },
  { group: "Orange Ball", items: ["Orange Ball 1", "Orange Ball 2", "Orange Ball 3"], color: "oklch(0.70 0.18 45)" },
  { group: "Green Ball", items: ["Green Ball 1", "Green Ball 2", "Green Ball 3"], color: "oklch(0.65 0.17 145)" },
  { group: "Yellow Ball", items: ["Yellow Ball 1", "Yellow Ball 2", "Yellow Ball 3"], color: "oklch(0.78 0.17 90)" },
  { group: "High Performance", items: ["High Performance 1", "High Performance 2", "High Performance 3"], color: "oklch(0.65 0.20 295)" },
];

const FITNESS_GOALS = [
  { label: "Mobility", icon: Activity, color: "oklch(0.78 0.12 185)", desc: "Joint range, flexibility, movement quality" },
  { label: "Coordination", icon: Wind, color: "oklch(0.65 0.20 295)", desc: "Multi-limb coordination and body awareness" },
  { label: "Speed", icon: Zap, color: "oklch(0.78 0.17 90)", desc: "First-step speed and acceleration" },
  { label: "Agility", icon: Activity, color: "oklch(0.70 0.18 45)", desc: "Change of direction and reactive movement" },
  { label: "Strength", icon: Dumbbell, color: "oklch(0.62 0.22 25)", desc: "Functional strength for tennis performance" },
  { label: "Recovery", icon: RotateCcw, color: "oklch(0.65 0.17 145)", desc: "Active recovery and regeneration" },
  { label: "Plyometrics", icon: Flame, color: "oklch(0.70 0.18 45)", desc: "Explosive power and reactive strength" },
  { label: "Pre-tournament", icon: Shield, color: "oklch(0.65 0.20 295)", desc: "Activation and mental readiness" },
  { label: "Post-tournament", icon: RotateCcw, color: "oklch(0.65 0.17 145)", desc: "Recovery and regeneration after competition" },
  { label: "Injury prevention", icon: Shield, color: "oklch(0.78 0.17 90)", desc: "Prehab and movement screening" },
];

// Fitness block palette — each block type has a set of default exercises
const BLOCK_PALETTE = [
  {
    type: "Movement Prep",
    icon: Activity,
    color: "oklch(0.78 0.12 185)",
    desc: "Dynamic warm-up activating movement patterns",
    defaultDuration: 8,
    tennisTransfer: "Court movement, split step timing",
    exercises: ["Hip 90/90 Stretch", "Ankle Circles + Calf Raises", "Arm Circles", "Leg Swings", "High Knees"],
    cue: "Full range of motion, controlled tempo, breathe through each movement",
    progression: "Add resistance band to hip stretch",
    regression: "Reduce range, focus on pain-free movement",
  },
  {
    type: "Speed",
    icon: Zap,
    color: "oklch(0.78 0.17 90)",
    desc: "First-step speed and linear acceleration",
    defaultDuration: 12,
    tennisTransfer: "First step to the ball, explosive push-off",
    exercises: ["10m Sprint Starts", "Resisted Sprint Runs", "Wall Drive Drill", "A-Skip + Sprint", "Acceleration Ladder"],
    cue: "Drive knees high, stay low on first step, full arm drive",
    progression: "Add reaction signal to sprint start",
    regression: "Reduce distance, focus on mechanics",
  },
  {
    type: "Agility",
    icon: Activity,
    color: "oklch(0.70 0.18 45)",
    desc: "Change of direction and reactive movement",
    defaultDuration: 12,
    tennisTransfer: "Court coverage, recovery after wide balls",
    exercises: ["Lateral Shuffle + Stick", "5-10-5 Drill", "T-Drill", "Cone Touch Sequence", "Reactive Shuffle"],
    cue: "Low center of gravity, stick on landing, soft knees",
    progression: "Add visual cue for direction change",
    regression: "Slow tempo, focus on landing mechanics",
  },
  {
    type: "Plyometrics",
    icon: Flame,
    color: "oklch(0.62 0.22 25)",
    desc: "Explosive power and reactive strength",
    defaultDuration: 10,
    tennisTransfer: "Serve power, split step reactivity",
    exercises: ["Box Jumps", "Broad Jumps", "Lateral Bounds", "Depth Drops", "Hurdle Hops"],
    cue: "Land softly, absorb force through hips and knees, reset before next rep",
    progression: "Increase box height or add consecutive reps",
    regression: "Remove box, use floor-level jumps only",
  },
  {
    type: "Strength",
    icon: Dumbbell,
    color: "oklch(0.62 0.22 25)",
    desc: "Functional strength for tennis performance",
    defaultDuration: 15,
    tennisTransfer: "Lateral stability, serve power, groundstroke force",
    exercises: ["Resistance Band Hip Abduction", "Single-Leg Squat", "Romanian Deadlift", "Push-Up Variations", "Pallof Press"],
    cue: "Controlled movement, no compensation, full range",
    progression: "Add load or reduce base of support",
    regression: "Bodyweight only, reduce range of motion",
  },
  {
    type: "Coordination",
    icon: Wind,
    color: "oklch(0.65 0.20 295)",
    desc: "Multi-limb coordination and body awareness",
    defaultDuration: 10,
    tennisTransfer: "Split step stability, racket-body coordination",
    exercises: ["Single-Leg Balance Reach", "Ladder Footwork Patterns", "Ball Toss + Footwork", "Mirror Drill", "Cone Touch Sequence"],
    cue: "Soft knees, eyes forward, controlled movement throughout",
    progression: "Add visual distraction (ball toss)",
    regression: "Use wall support for balance exercises",
  },
  {
    type: "Mobility",
    icon: Activity,
    color: "oklch(0.78 0.12 185)",
    desc: "Joint range, flexibility, movement quality",
    defaultDuration: 10,
    tennisTransfer: "Hip rotation for groundstrokes, shoulder turn for serve",
    exercises: ["Thoracic Rotation Drill", "Hip Flexor Stretch", "Shoulder Circles", "World's Greatest Stretch", "Pigeon Pose"],
    cue: "Breathe into each stretch, hold 2–3 seconds at end range, no bouncing",
    progression: "Add movement between stretches",
    regression: "Static holds only, reduce duration",
  },
  {
    type: "Recovery",
    icon: RotateCcw,
    color: "oklch(0.65 0.17 145)",
    desc: "Active recovery and regeneration",
    defaultDuration: 8,
    tennisTransfer: "Post-match recovery, next-day readiness",
    exercises: ["Foam Rolling — Quads + IT Band", "Light Walking", "Breathing Exercises", "Gentle Stretching", "Cold/Heat Protocol"],
    cue: "Low intensity, focus on breath, no pain — discomfort only",
    progression: "Add contrast therapy",
    regression: "Passive rest only",
  },
  {
    type: "Tennis Transfer Finisher",
    icon: Layers,
    color: "oklch(0.78 0.12 185)",
    desc: "Connect fitness work to on-court movement",
    defaultDuration: 5,
    tennisTransfer: "Direct transfer to court movement patterns",
    exercises: ["Shadow Footwork", "Split Step Practice", "Quick Feet Ladder", "Court Sprint Patterns"],
    cue: "Light and quick, replicate on-court movement patterns",
    progression: "Add ball tracking with footwork",
    regression: "Slow down tempo, focus on pattern",
  },
];

const donnaMessages: Record<number, string> = {
  1: "Choose the level or age group this fitness template is built for. I'll match blocks and exercises to their physical development stage.",
  2: "Select the blocks that make up this fitness template. Each block is a focused training unit. Drag to reorder, or add multiple blocks of the same type.",
  3: "Configure each block — adjust duration, exercises, cues, and progressions. I've pre-populated based on the selected level.",
  4: "Review your complete fitness template before saving. Nothing changes in your curriculum until you approve.",
};

interface FitnessBlock {
  id: number;
  type: string;
  duration: number;
  exercises: string[];
  cue: string;
  tennisTransfer: string;
  progression: string;
  regression: string;
  color: string;
  icon: React.ElementType;
}

export default function CreateFitnessTemplate() {
  const [, navigate] = useLocation();
  const [step, setStep] = useState(1);
  const [selectedLevel, setSelectedLevel] = useState("");

  const [blocks, setBlocks] = useState<FitnessBlock[]>([]);
  const [expandedBlock, setExpandedBlock] = useState<number | null>(null);
  const [templateName, setTemplateName] = useState("");
  let blockIdCounter = 100;

  const canProceed = () => {
    if (step === 1) return !!selectedLevel;
    if (step === 2) return blocks.length > 0;
    return true;
  };

  const addBlock = (palette: typeof BLOCK_PALETTE[0]) => {
    const newBlock: FitnessBlock = {
      id: Date.now(),
      type: palette.type,
      duration: palette.defaultDuration,
      exercises: [...palette.exercises.slice(0, 3)],
      cue: palette.cue,
      tennisTransfer: palette.tennisTransfer,
      progression: palette.progression,
      regression: palette.regression,
      color: palette.color,
      icon: palette.icon,
    };
    setBlocks((prev) => [...prev, newBlock]);
  };

  const removeBlock = (id: number) => {
    setBlocks((prev) => prev.filter((b) => b.id !== id));
    if (expandedBlock === id) setExpandedBlock(null);
  };

  const updateBlockDuration = (id: number, duration: number) => {
    setBlocks((prev) => prev.map((b) => (b.id === id ? { ...b, duration } : b)));
  };

  const totalDuration = blocks.reduce((a, b) => a + b.duration, 0);

  const levelColor =
    LEVEL_GROUPS.find((g) => g.items.includes(selectedLevel))?.color || "oklch(0.78 0.12 185)";

  return (
    <Layout
      donnaPrompt={donnaMessages[step]}
      donnaActions={[
        "Suggest blocks for this level",
        "Add a mobility block",
        "Add a speed block",
        "Make this session lower load",
        "Make this session more intense",
        "Add tennis transfer finisher",
      ]}
    >
      <div className="px-8 py-7">
        {/* Header */}
        <div className="mb-6 animate-fade-slide-up">
          <button
            onClick={() => navigate("/templates/fitness")}
            className="flex items-center gap-1.5 text-sm mb-4 transition-colors hover:opacity-80"
            style={{ color: "oklch(0.55 0.008 240)" }}
          >
            <ArrowLeft size={14} />
            Fitness Templates
          </button>
          <h1 className="font-display text-3xl font-bold" style={{ color: "oklch(0.93 0.005 240)" }}>
            Create Fitness Template
          </h1>
          <p className="mt-1 text-sm" style={{ color: "oklch(0.55 0.008 240)" }}>
            Build a block-based fitness template connected to your tennis curriculum.
          </p>
        </div>

        {/* Step Progress */}
        <div
          className="rounded-2xl p-5 mb-6 animate-fade-slide-up stagger-1"
          style={{ background: "oklch(0.12 0.010 240)", border: "1px solid oklch(1 0 0 / 0.06)" }}
        >
          <div className="flex items-center gap-0">
            {STEPS.map((s, i) => (
              <div key={s.id} className="flex items-center flex-1">
                <div className="flex flex-col items-center gap-1.5">
                  <button
                    onClick={() => s.id < step && setStep(s.id)}
                    className={`step-dot ${s.id < step ? "completed" : s.id === step ? "active" : "pending"}`}
                  >
                    {s.id < step ? <Check size={14} /> : s.id}
                  </button>
                  <span
                    className="text-xs whitespace-nowrap"
                    style={{
                      color:
                        s.id === step
                          ? "oklch(0.78 0.12 185)"
                          : s.id < step
                          ? "oklch(0.65 0.17 145)"
                          : "oklch(0.40 0.008 240)",
                      fontWeight: s.id === step ? 600 : 400,
                    }}
                  >
                    {s.label}
                  </span>
                </div>
                {i < STEPS.length - 1 && (
                  <div
                    className="flex-1 h-px mx-2 mb-5"
                    style={{
                      background:
                        s.id < step
                          ? "oklch(0.78 0.12 185 / 0.40)"
                          : "oklch(1 0 0 / 0.08)",
                    }}
                  />
                )}
              </div>
            ))}
          </div>
        </div>

        {/* DONNA Hint */}
        <div
          className="rounded-xl px-4 py-3 mb-5 flex items-start gap-3 animate-fade-slide-up stagger-2"
          style={{ background: "oklch(0.78 0.12 185 / 0.06)", border: "1px solid oklch(0.78 0.12 185 / 0.15)" }}
        >
          <Sparkles size={15} className="shrink-0 mt-0.5" style={{ color: "oklch(0.78 0.12 185)" }} />
          <p className="text-sm" style={{ color: "oklch(0.75 0.005 240)" }}>
            {donnaMessages[step]}
          </p>
        </div>

        {/* Step Content */}
        <div className="animate-fade-slide-up stagger-3">

          {/* Step 1: Choose Level */}
          {step === 1 && (
            <div className="space-y-4">
              {LEVEL_GROUPS.map((group) => (
                <div key={group.group}>
                  <div className="flex items-center gap-2 mb-2">
                    <div className="w-2 h-2 rounded-full" style={{ background: group.color }} />
                    <span className="text-xs font-medium" style={{ color: "oklch(0.55 0.008 240)" }}>
                      {group.group}
                    </span>
                  </div>
                  <div className="grid grid-cols-3 gap-2">
                    {group.items.map((level) => (
                      <button
                        key={level}
                        onClick={() => setSelectedLevel(level)}
                        className="px-4 py-3 rounded-xl text-sm font-medium text-left transition-all"
                        style={
                          selectedLevel === level
                            ? {
                                background: `${group.color.replace(")", " / 0.12)")}`,
                                color: group.color,
                                border: `1px solid ${group.color.replace(")", " / 0.35)")}`,
                                boxShadow: `0 0 12px ${group.color.replace(")", " / 0.15)")}`,
                              }
                            : {
                                background: "oklch(0.12 0.010 240)",
                                color: "oklch(0.65 0.008 240)",
                                border: "1px solid oklch(1 0 0 / 0.08)",
                              }
                        }
                      >
                        {level}
                      </button>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          )}

          {/* Step 2: Build Blocks */}
          {step === 2 && (
            <div className="space-y-5">
              {/* Current blocks */}
              {blocks.length > 0 && (
                <div
                  className="rounded-2xl p-4"
                  style={{ background: "oklch(0.12 0.010 240)", border: "1px solid oklch(1 0 0 / 0.06)" }}
                >
                  <div className="flex items-center justify-between mb-3">
                    <h3 className="font-display font-bold text-sm" style={{ color: "oklch(0.85 0.005 240)" }}>
                      Your Template — {blocks.length} block{blocks.length !== 1 ? "s" : ""} · {totalDuration} min total
                    </h3>
                  </div>
                  <div className="space-y-2">
                    {blocks.map((block, i) => {
                      const Icon = block.icon;
                      return (
                        <div
                          key={block.id}
                          className="flex items-center gap-3 px-3 py-2.5 rounded-xl"
                          style={{ background: "oklch(0.09 0.008 240)", borderLeft: `3px solid ${block.color}` }}
                        >
                          <GripVertical size={14} style={{ color: "oklch(0.35 0.008 240)" }} />
                          <div
                            className="w-7 h-7 rounded-lg flex items-center justify-center shrink-0"
                            style={{ background: `${block.color.replace(")", " / 0.12)")}` }}
                          >
                            <Icon size={13} style={{ color: block.color }} />
                          </div>
                          <div className="flex-1 min-w-0">
                            <p className="text-sm font-medium truncate" style={{ color: "oklch(0.85 0.005 240)" }}>
                              {block.type}
                            </p>
                            <p className="text-xs" style={{ color: "oklch(0.50 0.008 240)" }}>
                              {block.duration} min · {block.exercises.length} exercises
                            </p>
                          </div>
                          <span
                            className="text-xs font-medium px-2 py-1 rounded-lg"
                            style={{ background: `${block.color.replace(")", " / 0.10)")}`, color: block.color }}
                          >
                            {block.duration}m
                          </span>
                          <button
                            onClick={() => removeBlock(block.id)}
                            className="p-1 rounded-lg transition-colors hover:bg-white/5"
                            style={{ color: "oklch(0.45 0.008 240)" }}
                          >
                            <X size={13} />
                          </button>
                        </div>
                      );
                    })}
                  </div>
                </div>
              )}

              {/* Block palette */}
              <div>
                <p className="text-xs font-medium mb-3" style={{ color: "oklch(0.45 0.008 240)", letterSpacing: "0.06em", textTransform: "uppercase" }}>
                  Block Palette — click to add
                </p>
                <div className="grid grid-cols-3 gap-3">
                  {BLOCK_PALETTE.map((palette) => {
                    const Icon = palette.icon;
                    const alreadyAdded = blocks.filter((b) => b.type === palette.type).length;
                    return (
                      <button
                        key={palette.type}
                        onClick={() => addBlock(palette)}
                        className="flex items-start gap-3 p-4 rounded-xl text-left transition-all group"
                        style={{
                          background: "oklch(0.12 0.010 240)",
                          border: `1px solid ${alreadyAdded > 0 ? palette.color.replace(")", " / 0.25)") : "oklch(1 0 0 / 0.08)"}`,
                        }}
                      >
                        <div
                          className="w-9 h-9 rounded-xl flex items-center justify-center shrink-0"
                          style={{ background: `${palette.color.replace(")", " / 0.12)")}` }}
                        >
                          <Icon size={16} style={{ color: palette.color }} />
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-1.5">
                            <p className="font-display font-bold text-sm" style={{ color: "oklch(0.85 0.005 240)" }}>
                              {palette.type}
                            </p>
                            {alreadyAdded > 0 && (
                              <span
                                className="text-xs px-1.5 py-0.5 rounded-full font-medium"
                                style={{ background: `${palette.color.replace(")", " / 0.15)")}`, color: palette.color }}
                              >
                                ×{alreadyAdded}
                              </span>
                            )}
                          </div>
                          <p className="text-xs mt-0.5 leading-snug" style={{ color: "oklch(0.50 0.008 240)" }}>
                            {palette.desc}
                          </p>
                          <p className="text-xs mt-1" style={{ color: "oklch(0.40 0.008 240)" }}>
                            {palette.defaultDuration} min default
                          </p>
                        </div>
                        <div
                          className="w-6 h-6 rounded-full flex items-center justify-center shrink-0 transition-all group-hover:scale-110"
                          style={{ background: `${palette.color.replace(")", " / 0.15)")}`, color: palette.color }}
                        >
                          <Plus size={12} />
                        </div>
                      </button>
                    );
                  })}
                </div>
              </div>

              {blocks.length === 0 && (
                <div
                  className="rounded-xl px-4 py-3 flex items-center gap-2"
                  style={{ background: "oklch(0.78 0.17 90 / 0.06)", border: "1px solid oklch(0.78 0.17 90 / 0.15)" }}
                >
                  <Sparkles size={14} style={{ color: "oklch(0.78 0.17 90)" }} />
                  <p className="text-sm" style={{ color: "oklch(0.65 0.005 240)" }}>
                    Select blocks from the palette above to build your fitness template. You can add multiple blocks of the same type.
                  </p>
                </div>
              )}
            </div>
          )}

          {/* Step 3: Configure Blocks */}
          {step === 3 && (
            <div className="space-y-3">
              <div
                className="rounded-xl px-4 py-3 flex items-center gap-2 mb-2"
                style={{ background: "oklch(0.65 0.20 295 / 0.06)", border: "1px solid oklch(0.65 0.20 295 / 0.15)" }}
              >
                <Sparkles size={14} style={{ color: "oklch(0.65 0.20 295)" }} />
                <p className="text-sm" style={{ color: "oklch(0.75 0.005 240)" }}>
                  Configuring <strong style={{ color: "oklch(0.65 0.20 295)" }}>{blocks.length} blocks</strong> for{" "}
                  <strong style={{ color: levelColor }}>{selectedLevel || "your level"}</strong>
                </p>
              </div>

              {blocks.map((block, i) => {
                const Icon = block.icon;
                const isExpanded = expandedBlock === block.id;
                return (
                  <div
                    key={block.id}
                    className="rounded-2xl overflow-hidden"
                    style={{ background: "oklch(0.12 0.010 240)", border: `1px solid ${block.color.replace(")", " / 0.20)")}`, borderLeft: `4px solid ${block.color}` }}
                  >
                    {/* Block header */}
                    <button
                      className="w-full flex items-center gap-3 px-5 py-4 text-left transition-colors hover:bg-white/[0.02]"
                      onClick={() => setExpandedBlock(isExpanded ? null : block.id)}
                    >
                      <div
                        className="w-8 h-8 rounded-xl flex items-center justify-center shrink-0 text-sm font-bold font-display"
                        style={{ background: `${block.color.replace(")", " / 0.12)")}`, color: block.color }}
                      >
                        {i + 1}
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="font-display font-bold text-base" style={{ color: "oklch(0.90 0.005 240)" }}>
                          {block.type}
                        </p>
                        <p className="text-xs" style={{ color: "oklch(0.55 0.008 240)" }}>
                          {block.duration} min · {block.exercises.length} exercises · {block.tennisTransfer}
                        </p>
                      </div>
                      {/* Duration quick-edit */}
                      <div className="flex items-center gap-1 mr-2" onClick={(e) => e.stopPropagation()}>
                        {[5, 8, 10, 12, 15, 20].map((d) => (
                          <button
                            key={d}
                            onClick={() => updateBlockDuration(block.id, d)}
                            className="text-xs px-2 py-1 rounded-lg transition-all"
                            style={
                              block.duration === d
                                ? { background: block.color.replace(")", " / 0.20)"), color: block.color, border: `1px solid ${block.color.replace(")", " / 0.35)")}` }
                                : { background: "oklch(0.09 0.008 240)", color: "oklch(0.45 0.008 240)", border: "1px solid oklch(1 0 0 / 0.08)" }
                            }
                          >
                            {d}m
                          </button>
                        ))}
                      </div>
                      {isExpanded ? (
                        <ChevronUp size={16} style={{ color: "oklch(0.45 0.008 240)" }} />
                      ) : (
                        <ChevronDown size={16} style={{ color: "oklch(0.45 0.008 240)" }} />
                      )}
                    </button>

                    {/* Expanded details */}
                    {isExpanded && (
                      <div
                        className="px-5 pb-5 space-y-4 border-t"
                        style={{ borderColor: "oklch(1 0 0 / 0.06)" }}
                      >
                        {/* Exercises */}
                        <div className="pt-4">
                          <p className="text-xs font-medium mb-2" style={{ color: "oklch(0.45 0.008 240)", letterSpacing: "0.05em", textTransform: "uppercase" }}>
                            Exercises
                          </p>
                          <div className="space-y-1.5">
                            {block.exercises.map((ex, j) => (
                              <div key={j} className="flex items-center gap-2 px-3 py-2 rounded-lg" style={{ background: "oklch(0.09 0.008 240)" }}>
                                <div className="w-1.5 h-1.5 rounded-full shrink-0" style={{ background: block.color }} />
                                <span className="text-sm flex-1" style={{ color: "oklch(0.78 0.005 240)" }}>{ex}</span>
                                <button
                                  onClick={() => setBlocks((prev) => prev.map((b) => b.id === block.id ? { ...b, exercises: b.exercises.filter((_, k) => k !== j) } : b))}
                                  className="p-0.5 rounded transition-colors hover:bg-white/5"
                                  style={{ color: "oklch(0.40 0.008 240)" }}
                                >
                                  <X size={11} />
                                </button>
                              </div>
                            ))}
                          </div>
                        </div>

                        {/* Cue */}
                        <div>
                          <p className="text-xs font-medium mb-1.5" style={{ color: "oklch(0.45 0.008 240)", letterSpacing: "0.05em", textTransform: "uppercase" }}>
                            Coach Cue
                          </p>
                          <p className="text-sm italic px-3 py-2 rounded-lg" style={{ background: "oklch(0.09 0.008 240)", color: "oklch(0.65 0.005 240)" }}>
                            "{block.cue}"
                          </p>
                        </div>

                        {/* Tennis Transfer */}
                        <div>
                          <p className="text-xs font-medium mb-1.5" style={{ color: "oklch(0.45 0.008 240)", letterSpacing: "0.05em", textTransform: "uppercase" }}>
                            Tennis Transfer
                          </p>
                          <p className="text-sm px-3 py-2 rounded-lg" style={{ background: "oklch(0.09 0.008 240)", color: "oklch(0.65 0.005 240)" }}>
                            {block.tennisTransfer}
                          </p>
                        </div>

                        {/* Progression / Regression */}
                        <div className="grid grid-cols-2 gap-3">
                          <div>
                            <p className="text-xs font-medium mb-1.5" style={{ color: "oklch(0.65 0.17 145)", letterSpacing: "0.05em", textTransform: "uppercase" }}>
                              Progression
                            </p>
                            <p className="text-xs px-3 py-2 rounded-lg" style={{ background: "oklch(0.65 0.17 145 / 0.06)", border: "1px solid oklch(0.65 0.17 145 / 0.15)", color: "oklch(0.65 0.005 240)" }}>
                              {block.progression}
                            </p>
                          </div>
                          <div>
                            <p className="text-xs font-medium mb-1.5" style={{ color: "oklch(0.62 0.22 25)", letterSpacing: "0.05em", textTransform: "uppercase" }}>
                              Regression
                            </p>
                            <p className="text-xs px-3 py-2 rounded-lg" style={{ background: "oklch(0.62 0.22 25 / 0.06)", border: "1px solid oklch(0.62 0.22 25 / 0.15)", color: "oklch(0.65 0.005 240)" }}>
                              {block.regression}
                            </p>
                          </div>
                        </div>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          )}

          {/* Step 4: Review */}
          {step === 4 && (
            <div className="space-y-4">
              {/* Template name */}
              <div
                className="rounded-2xl p-5"
                style={{ background: "oklch(0.12 0.010 240)", border: "1px solid oklch(1 0 0 / 0.06)" }}
              >
                <label className="text-xs font-medium block mb-2" style={{ color: "oklch(0.55 0.008 240)" }}>
                  Template Name
                </label>
                <input
                  type="text"
                  value={templateName}
                  onChange={(e) => setTemplateName(e.target.value)}
                    placeholder={`${selectedLevel} — Fitness Template`}
                  className="w-full bg-transparent text-base font-display font-bold outline-none"
                  style={{ color: "oklch(0.90 0.005 240)" }}
                />
              </div>

              {/* Summary */}
              <div
                className="rounded-2xl p-5 space-y-4"
                style={{ background: "oklch(0.12 0.010 240)", border: "1px solid oklch(1 0 0 / 0.06)" }}
              >
                <h3 className="font-display font-bold text-base" style={{ color: "oklch(0.85 0.005 240)" }}>
                  Template Summary
                </h3>
                <div className="grid grid-cols-3 gap-3">
                  {[
                    { label: "Level", value: selectedLevel || "Not selected", color: levelColor },
                    { label: "Total Duration", value: `${totalDuration} min` },
                    { label: "Blocks", value: `${blocks.length} blocks` },
                    { label: "Block Types", value: Array.from(new Set(blocks.map((b) => b.type))).length + " types" },
                    { label: "Status", value: "Draft" },
                  ].map((item, i) => (
                    <div key={i} className="px-3 py-2.5 rounded-xl" style={{ background: "oklch(0.09 0.008 240)" }}>
                      <p className="text-xs mb-1" style={{ color: "oklch(0.45 0.008 240)" }}>{item.label}</p>
                      <p className="text-sm font-medium" style={{ color: (item as any).color || "oklch(0.85 0.005 240)" }}>
                        {item.value}
                      </p>
                    </div>
                  ))}
                </div>
              </div>

              {/* Block list */}
              <div
                className="rounded-2xl p-5"
                style={{ background: "oklch(0.12 0.010 240)", border: "1px solid oklch(1 0 0 / 0.06)" }}
              >
                <h3 className="font-display font-bold text-sm mb-3" style={{ color: "oklch(0.75 0.005 240)" }}>
                  Block Sequence
                </h3>
                <div className="space-y-2">
                  {blocks.map((block, i) => {
                    const Icon = block.icon;
                    return (
                      <div key={block.id} className="flex items-center gap-3 px-3 py-2.5 rounded-xl" style={{ background: "oklch(0.09 0.008 240)", borderLeft: `3px solid ${block.color}` }}>
                        <span className="text-xs font-bold font-display w-5 text-center" style={{ color: block.color }}>{i + 1}</span>
                        <Icon size={13} style={{ color: block.color }} />
                        <span className="text-sm font-medium flex-1" style={{ color: "oklch(0.80 0.005 240)" }}>{block.type}</span>
                        <span className="text-xs font-medium" style={{ color: "oklch(0.50 0.008 240)" }}>{block.duration} min</span>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Tennis Transfer chain */}
              <div className="rounded-2xl p-5" style={{ background: "oklch(0.12 0.010 240)", border: "1px solid oklch(1 0 0 / 0.06)" }}>
                <h3 className="font-display font-bold text-sm mb-3" style={{ color: "oklch(0.75 0.005 240)" }}>Tennis Transfer Connections</h3>
                <div className="space-y-1.5">
                  {blocks.map((block, i) => (
                    <div key={block.id} className="flex items-center gap-2">
                      <div className="w-1.5 h-1.5 rounded-full shrink-0" style={{ background: block.color }} />
                      <span className="text-xs font-medium" style={{ color: block.color }}>{block.type}</span>
                      <span className="text-xs" style={{ color: "oklch(0.35 0.008 240)" }}>→</span>
                      <span className="text-xs" style={{ color: "oklch(0.60 0.005 240)" }}>{block.tennisTransfer}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Safety notice */}
              <div
                className="rounded-xl px-4 py-3 flex items-start gap-3"
                style={{ background: "oklch(0.65 0.17 145 / 0.06)", border: "1px solid oklch(0.65 0.17 145 / 0.20)" }}
              >
                <Check size={15} className="shrink-0 mt-0.5" style={{ color: "oklch(0.65 0.17 145)" }} />
                <div>
                  <p className="text-sm font-medium" style={{ color: "oklch(0.65 0.17 145)" }}>Review-safe</p>
                  <p className="text-xs mt-0.5" style={{ color: "oklch(0.55 0.008 240)" }}>
                    Saved as draft. Does not affect master curriculum. Director approval required before use.
                  </p>
                </div>
              </div>

              {/* Action buttons */}
              <div className="flex items-center gap-3 flex-wrap">
                <button
                  className="flex items-center gap-2 px-5 py-2.5 rounded-xl text-sm font-medium transition-all hover:bg-white/[0.05]"
                  style={{ background: "oklch(0.12 0.010 240)", border: "1px solid oklch(1 0 0 / 0.08)", color: "oklch(0.75 0.005 240)" }}
                >
                  <Save size={15} />
                  Save as Draft
                </button>
                <button
                  className="flex items-center gap-2 px-5 py-2.5 rounded-xl text-sm font-medium transition-all hover:bg-white/[0.05]"
                  style={{ background: "oklch(0.12 0.010 240)", border: "1px solid oklch(1 0 0 / 0.08)", color: "oklch(0.75 0.005 240)" }}
                  onClick={() => navigate("/templates/coach-preview")}
                >
                  <Eye size={15} />
                  Preview Coach View
                </button>
                <button
                  className="flex items-center gap-2 px-5 py-2.5 rounded-xl text-sm font-medium transition-all hover:bg-white/[0.05]"
                  style={{ background: "oklch(0.12 0.010 240)", border: "1px solid oklch(0.78 0.17 90 / 0.30)", color: "oklch(0.78 0.17 90)" }}
                >
                  <Send size={15} />
                  Send to Review Queue
                </button>
                <button
                  className="flex items-center gap-2 px-5 py-2.5 rounded-xl text-sm font-medium transition-all hover:bg-white/[0.05] ml-auto"
                  style={{ background: "oklch(0.12 0.010 240)", border: "1px solid oklch(1 0 0 / 0.08)", color: "oklch(0.55 0.008 240)" }}
                  onClick={() => navigate("/templates/fitness")}
                >
                  <X size={15} />
                  Cancel
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Navigation */}
        {step < 5 && (
          <div className="flex items-center justify-between mt-8 pt-6 border-t" style={{ borderColor: "oklch(1 0 0 / 0.06)" }}>
            <button
              onClick={() => step > 1 && setStep(step - 1)}
              className="flex items-center gap-2 px-5 py-2.5 rounded-xl text-sm font-medium transition-all"
              style={{
                background: "oklch(0.12 0.010 240)",
                border: "1px solid oklch(1 0 0 / 0.08)",
                color: step === 1 ? "oklch(0.35 0.008 240)" : "oklch(0.75 0.005 240)",
                opacity: step === 1 ? 0.5 : 1,
              }}
              disabled={step === 1}
            >
              <ArrowLeft size={15} />
              Back
            </button>
            <button
              onClick={() => canProceed() && setStep(step + 1)}
              className="btn-teal flex items-center gap-2 px-6 py-2.5 rounded-xl text-sm"
              style={{ opacity: canProceed() ? 1 : 0.5, cursor: canProceed() ? "pointer" : "not-allowed" }}
            >
              Continue
              <ArrowRight size={15} />
            </button>
          </div>
        )}
      </div>
    </Layout>
  );
}
