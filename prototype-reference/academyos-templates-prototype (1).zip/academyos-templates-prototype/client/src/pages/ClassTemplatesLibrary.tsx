/**
 * Screen 2: Class Templates Library
 * Design: Card grid with level dots, filter bar, spacious cards
 */

import { useState } from "react";
import { useLocation } from "wouter";
import Layout from "@/components/Layout";
import {
  Plus,
  Sparkles,
  Filter,
  Search,
  Clock,
  Layers,
  BookOpen,
  Target,
  ChevronRight,
  ArrowLeft,
} from "lucide-react";

const LEVELS = ["All", "Red", "Orange", "Green", "Yellow", "High Performance"];
const PATHWAYS = ["All", "Skill", "Competition", "Mixed"];
const STATUSES = ["All", "Ready", "Draft", "Needs Review"];
const DURATIONS = ["All", "30 min", "60 min", "90 min", "120 min"];

const levelColors: Record<string, string> = {
  Red: "oklch(0.62 0.22 25)",
  Orange: "oklch(0.70 0.18 45)",
  Green: "oklch(0.65 0.17 145)",
  Yellow: "oklch(0.78 0.17 90)",
  "High Performance": "oklch(0.65 0.20 295)",
};

const templates = [
  {
    id: "1",
    name: "Orange Ball 2 — Recovery + Crosscourt Patterns",
    level: "Orange",
    duration: "60 min",
    curriculum: "Orange Ball 2",
    skillFocus: "Crosscourt control under movement",
    compFocus: "Rally consistency patterns",
    blocks: 5,
    drills: 8,
    status: "ready",
    updated: "2 days ago",
    sessions: 14,
  },
  {
    id: "2",
    name: "Green Ball 1 — Serve + First Ball Development",
    level: "Green",
    duration: "60 min",
    curriculum: "Green Ball 1",
    skillFocus: "Serve mechanics + first ball attack",
    compFocus: "Serve + 1 patterns",
    blocks: 5,
    drills: 7,
    status: "draft",
    updated: "4 days ago",
    sessions: 7,
  },
  {
    id: "3",
    name: "Red Ball 1 — Movement + Rally Foundations",
    level: "Red",
    duration: "45 min",
    curriculum: "Red Ball 1",
    skillFocus: "Split step + recovery movement",
    compFocus: "Rally consistency",
    blocks: 4,
    drills: 6,
    status: "ready",
    updated: "1 week ago",
    sessions: 21,
  },
  {
    id: "4",
    name: "High Performance — Live Ball Pressure Session",
    level: "High Performance",
    duration: "90 min",
    curriculum: "High Performance 1",
    skillFocus: "Decision-making under pressure",
    compFocus: "Live ball competition patterns",
    blocks: 6,
    drills: 10,
    status: "review",
    updated: "3 days ago",
    sessions: 22,
  },
  {
    id: "5",
    name: "Yellow Ball 2 — Baseline Consistency",
    level: "Yellow",
    duration: "60 min",
    curriculum: "Yellow Ball 2",
    skillFocus: "Topspin depth + direction",
    compFocus: "Baseline rally patterns",
    blocks: 5,
    drills: 8,
    status: "ready",
    updated: "5 days ago",
    sessions: 11,
  },
  {
    id: "6",
    name: "Orange Ball 1 — Footwork + Ball Control",
    level: "Orange",
    duration: "45 min",
    curriculum: "Orange Ball 1",
    skillFocus: "Footwork patterns + ball control",
    compFocus: "Short court consistency",
    blocks: 4,
    drills: 6,
    status: "draft",
    updated: "1 week ago",
    sessions: 5,
  },
];

const statusBadge = (status: string) => {
  if (status === "ready") return <span className="badge-ready text-xs px-2 py-0.5 rounded-full font-medium">Ready</span>;
  if (status === "draft") return <span className="badge-draft text-xs px-2 py-0.5 rounded-full font-medium">Draft</span>;
  if (status === "review") return <span className="badge-review text-xs px-2 py-0.5 rounded-full font-medium">Needs Review</span>;
  return null;
};

export default function ClassTemplatesLibrary() {
  const [, navigate] = useLocation();
  const [activeLevel, setActiveLevel] = useState("All");
  const [activePathway, setActivePathway] = useState("All");
  const [activeStatus, setActiveStatus] = useState("All");
  const [search, setSearch] = useState("");

  const filtered = templates.filter((t) => {
    if (activeLevel !== "All" && t.level !== activeLevel) return false;
    if (activeStatus !== "All") {
      const statusMap: Record<string, string> = { Ready: "ready", Draft: "draft", "Needs Review": "review" };
      if (t.status !== statusMap[activeStatus]) return false;
    }
    if (search && !t.name.toLowerCase().includes(search.toLowerCase())) return false;
    return true;
  });

  return (
    <Layout
      donnaPrompt="Which class template do you want to build or improve?"
      donnaActions={[
        "Build from Orange Ball 2 curriculum",
        "Find missing level templates",
        "Improve a draft template",
        "Create assessment session",
        "Create live-ball session",
      ]}
    >
      <div className="px-8 py-7 space-y-6">
        {/* Header */}
        <div className="animate-fade-slide-up">
          <button
            onClick={() => navigate("/templates")}
            className="flex items-center gap-1.5 text-sm mb-4 transition-colors hover:opacity-80"
            style={{ color: "oklch(0.55 0.008 240)" }}
          >
            <ArrowLeft size={14} />
            Templates
          </button>
          <div className="flex items-start justify-between">
            <div>
              <h1 className="font-display text-3xl font-bold" style={{ color: "oklch(0.93 0.005 240)" }}>
                Class Templates
              </h1>
              <p className="mt-1 text-sm" style={{ color: "oklch(0.55 0.008 240)" }}>
                Reusable session structures connected to your curriculum.
              </p>
            </div>
            <div className="flex items-center gap-3">
              <button
                onClick={() => navigate("/templates/donna-suggestions")}
                className="flex items-center gap-2 px-4 py-2.5 rounded-xl text-sm font-medium transition-all hover:bg-white/[0.05]"
                style={{
                  background: "oklch(0.12 0.010 240)",
                  border: "1px solid oklch(1 0 0 / 0.08)",
                  color: "oklch(0.78 0.12 185)",
                }}
              >
                <Sparkles size={15} />
                Ask DONNA to Suggest
              </button>
              <button
                onClick={() => navigate("/templates/class/create")}
                className="btn-teal flex items-center gap-2 px-4 py-2.5 rounded-xl text-sm"
              >
                <Plus size={15} />
                New Class Template
              </button>
            </div>
          </div>
        </div>

        {/* Filters */}
        <div
          className="rounded-2xl p-4 space-y-3 animate-fade-slide-up stagger-1"
          style={{ background: "oklch(0.12 0.010 240)", border: "1px solid oklch(1 0 0 / 0.06)" }}
        >
          {/* Search */}
          <div
            className="flex items-center gap-2 px-3 py-2.5 rounded-xl"
            style={{ background: "oklch(0.09 0.008 240)", border: "1px solid oklch(1 0 0 / 0.08)" }}
          >
            <Search size={15} style={{ color: "oklch(0.45 0.008 240)" }} />
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search templates..."
              className="flex-1 bg-transparent text-sm outline-none"
              style={{ color: "oklch(0.85 0.005 240)" }}
            />
          </div>

          {/* Filter rows */}
          <div className="flex flex-wrap gap-4">
            {/* Level */}
            <div className="flex items-center gap-2">
              <span className="text-xs font-medium" style={{ color: "oklch(0.45 0.008 240)" }}>
                Level:
              </span>
              <div className="flex gap-1.5">
                {LEVELS.map((l) => (
                  <button
                    key={l}
                    onClick={() => setActiveLevel(l)}
                    className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-xs font-medium transition-all"
                    style={
                      activeLevel === l
                        ? { background: "oklch(0.78 0.12 185 / 0.15)", color: "oklch(0.78 0.12 185)", border: "1px solid oklch(0.78 0.12 185 / 0.30)" }
                        : { background: "oklch(0.09 0.008 240)", color: "oklch(0.55 0.008 240)", border: "1px solid oklch(1 0 0 / 0.08)" }
                    }
                  >
                    {l !== "All" && (
                      <span
                        className="w-1.5 h-1.5 rounded-full"
                        style={{ background: levelColors[l] }}
                      />
                    )}
                    {l}
                  </button>
                ))}
              </div>
            </div>

            {/* Status */}
            <div className="flex items-center gap-2">
              <span className="text-xs font-medium" style={{ color: "oklch(0.45 0.008 240)" }}>
                Status:
              </span>
              <div className="flex gap-1.5">
                {STATUSES.map((s) => (
                  <button
                    key={s}
                    onClick={() => setActiveStatus(s)}
                    className="px-2.5 py-1 rounded-lg text-xs font-medium transition-all"
                    style={
                      activeStatus === s
                        ? { background: "oklch(0.78 0.12 185 / 0.15)", color: "oklch(0.78 0.12 185)", border: "1px solid oklch(0.78 0.12 185 / 0.30)" }
                        : { background: "oklch(0.09 0.008 240)", color: "oklch(0.55 0.008 240)", border: "1px solid oklch(1 0 0 / 0.08)" }
                    }
                  >
                    {s}
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Template Grid */}
        <div className="grid grid-cols-2 gap-4 animate-fade-slide-up stagger-2">
          {filtered.map((t, i) => (
            <div
              key={t.id}
              className="rounded-2xl p-5 card-hover cursor-pointer"
              style={{ background: "oklch(0.12 0.010 240)", animationDelay: `${i * 50}ms` }}
              onClick={() => navigate(`/templates/class/${t.id}`)}
            >
              {/* Card header */}
              <div className="flex items-start justify-between mb-3">
                <div className="flex items-center gap-2">
                  <div
                    className="w-2.5 h-2.5 rounded-full"
                    style={{ background: levelColors[t.level] }}
                  />
                  <span className="text-xs font-medium" style={{ color: "oklch(0.55 0.008 240)" }}>
                    {t.level} Ball · {t.curriculum}
                  </span>
                </div>
                {statusBadge(t.status)}
              </div>

              {/* Name */}
              <h3 className="font-display font-bold text-base mb-3 leading-snug" style={{ color: "oklch(0.90 0.005 240)" }}>
                {t.name}
              </h3>

              {/* Meta grid */}
              <div className="grid grid-cols-2 gap-2 mb-4">
                <div
                  className="flex items-center gap-2 px-3 py-2 rounded-lg"
                  style={{ background: "oklch(0.09 0.008 240)" }}
                >
                  <Target size={13} style={{ color: "oklch(0.78 0.12 185)" }} />
                  <div>
                    <p className="text-xs" style={{ color: "oklch(0.45 0.008 240)" }}>Skill Focus</p>
                    <p className="text-xs font-medium truncate" style={{ color: "oklch(0.75 0.005 240)" }}>
                      {t.skillFocus}
                    </p>
                  </div>
                </div>
                <div
                  className="flex items-center gap-2 px-3 py-2 rounded-lg"
                  style={{ background: "oklch(0.09 0.008 240)" }}
                >
                  <BookOpen size={13} style={{ color: "oklch(0.65 0.20 295)" }} />
                  <div>
                    <p className="text-xs" style={{ color: "oklch(0.45 0.008 240)" }}>Competition</p>
                    <p className="text-xs font-medium truncate" style={{ color: "oklch(0.75 0.005 240)" }}>
                      {t.compFocus}
                    </p>
                  </div>
                </div>
              </div>

              {/* Stats row */}
              <div className="flex items-center gap-4 mb-4">
                <div className="flex items-center gap-1.5">
                  <Layers size={13} style={{ color: "oklch(0.45 0.008 240)" }} />
                  <span className="text-xs font-mono-data" style={{ color: "oklch(0.65 0.008 240)" }}>
                    {t.blocks} blocks
                  </span>
                </div>
                <div className="flex items-center gap-1.5">
                  <Target size={13} style={{ color: "oklch(0.45 0.008 240)" }} />
                  <span className="text-xs font-mono-data" style={{ color: "oklch(0.65 0.008 240)" }}>
                    {t.drills} drills
                  </span>
                </div>
                <div className="flex items-center gap-1.5">
                  <Clock size={13} style={{ color: "oklch(0.45 0.008 240)" }} />
                  <span className="text-xs font-mono-data" style={{ color: "oklch(0.65 0.008 240)" }}>
                    {t.duration}
                  </span>
                </div>
                <div className="ml-auto flex items-center gap-1.5">
                  <span className="text-xs" style={{ color: "oklch(0.45 0.008 240)" }}>
                    Used {t.sessions}×
                  </span>
                </div>
              </div>

              {/* Footer */}
              <div className="flex items-center justify-between">
                <span className="text-xs" style={{ color: "oklch(0.40 0.008 240)" }}>
                  Updated {t.updated}
                </span>
                <button
                  className="flex items-center gap-1 text-xs font-medium transition-colors"
                  style={{ color: "oklch(0.78 0.12 185)" }}
                >
                  Open <ChevronRight size={12} />
                </button>
              </div>
            </div>
          ))}
        </div>

        {filtered.length === 0 && (
          <div className="text-center py-16 animate-fade-in">
            <div
              className="w-16 h-16 rounded-2xl flex items-center justify-center mx-auto mb-4"
              style={{ background: "oklch(0.12 0.010 240)" }}
            >
              <Filter size={24} style={{ color: "oklch(0.35 0.008 240)" }} />
            </div>
            <p className="font-display font-bold text-lg mb-2" style={{ color: "oklch(0.65 0.008 240)" }}>
              No templates found
            </p>
            <p className="text-sm mb-4" style={{ color: "oklch(0.45 0.008 240)" }}>
              Try adjusting your filters or create a new template.
            </p>
            <button
              onClick={() => navigate("/templates/class/create")}
              className="btn-teal inline-flex items-center gap-2 px-5 py-2.5 rounded-xl text-sm"
            >
              <Plus size={15} />
              Create Class Template
            </button>
          </div>
        )}
      </div>
    </Layout>
  );
}
