/**
 * Screen 5: Fitness Templates Library
 * Design: Card grid with fitness-specific metadata and level dots
 */

import { useState } from "react";
import { useLocation } from "wouter";
import Layout from "@/components/Layout";
import {
  Plus,
  Sparkles,
  Search,
  Clock,
  ChevronRight,
  ArrowLeft,
  Dumbbell,
  Zap,
  Activity,
  Wind,
  Shield,
  RotateCcw,
} from "lucide-react";

const levelColors: Record<string, string> = {
  Red: "oklch(0.62 0.22 25)",
  Orange: "oklch(0.70 0.18 45)",
  Green: "oklch(0.65 0.17 145)",
  Yellow: "oklch(0.78 0.17 90)",
  "High Performance": "oklch(0.65 0.20 295)",
};

const loadColors: Record<string, string> = {
  Low: "oklch(0.65 0.17 145)",
  Medium: "oklch(0.78 0.17 90)",
  High: "oklch(0.62 0.22 25)",
};

const fitnessGoalIcons: Record<string, React.ElementType> = {
  Mobility: Activity,
  Speed: Zap,
  Coordination: Wind,
  Strength: Dumbbell,
  Agility: Activity,
  Recovery: RotateCcw,
  "Pre-Tournament": Shield,
};

const templates = [
  {
    id: "1",
    name: "Low Contact Mobility Prep",
    level: "Red",
    levelFit: "Red Ball 1–3",
    duration: "25 min",
    focus: "Mobility",
    tennisTransfer: "Forehand/backhand stability",
    load: "Low",
    equipment: "Bands, mat",
    status: "ready",
    lastUsed: "3 days ago",
    blocks: ["Movement Prep", "Mobility", "Recovery"],
  },
  {
    id: "2",
    name: "Orange Ball Coordination + Balance",
    level: "Orange",
    levelFit: "Orange Ball 1–3",
    duration: "30 min",
    focus: "Coordination",
    tennisTransfer: "Split step + first step",
    load: "Low",
    equipment: "Cones, balance pads",
    status: "ready",
    lastUsed: "1 week ago",
    blocks: ["Movement Prep", "Coordination", "Tennis Transfer Finisher"],
  },
  {
    id: "3",
    name: "Green Ball First-Step Speed",
    level: "Green",
    levelFit: "Green Ball 1–3",
    duration: "35 min",
    focus: "Speed",
    tennisTransfer: "Court coverage + recovery",
    load: "Medium",
    equipment: "Cones, ladder",
    status: "draft",
    lastUsed: "Never",
    blocks: ["Movement Prep", "Speed", "Agility", "Tennis Transfer Finisher"],
  },
  {
    id: "4",
    name: "Yellow Ball Strength Foundation",
    level: "Yellow",
    levelFit: "Yellow Ball 1–3",
    duration: "40 min",
    focus: "Strength",
    tennisTransfer: "Groundstroke power + stability",
    load: "Medium",
    equipment: "Resistance bands, bodyweight",
    status: "ready",
    lastUsed: "5 days ago",
    blocks: ["Movement Prep", "Strength", "Plyometrics", "Recovery"],
  },
  {
    id: "5",
    name: "High Performance Pre-Tournament Primer",
    level: "High Performance",
    levelFit: "HP 1–3",
    duration: "45 min",
    focus: "Pre-Tournament",
    tennisTransfer: "Activation + readiness",
    load: "Low",
    equipment: "Minimal",
    status: "ready",
    lastUsed: "2 days ago",
    blocks: ["Movement Prep", "Speed", "Coordination", "Tennis Transfer Finisher"],
  },
  {
    id: "6",
    name: "Red Ball Agility + Reaction",
    level: "Red",
    levelFit: "Red Ball 2–3",
    duration: "20 min",
    focus: "Agility",
    tennisTransfer: "Court movement patterns",
    load: "Low",
    equipment: "Cones, markers",
    status: "review",
    lastUsed: "1 week ago",
    blocks: ["Movement Prep", "Agility", "Speed"],
  },
];

const FOCUS_FILTERS = ["All", "Mobility", "Speed", "Coordination", "Strength", "Agility", "Recovery", "Pre-Tournament"];
const LOAD_FILTERS = ["All", "Low", "Medium", "High"];
const LEVELS = ["All", "Red", "Orange", "Green", "Yellow", "High Performance"];

const statusBadge = (status: string) => {
  if (status === "ready") return <span className="badge-ready text-xs px-2 py-0.5 rounded-full font-medium">Ready</span>;
  if (status === "draft") return <span className="badge-draft text-xs px-2 py-0.5 rounded-full font-medium">Draft</span>;
  if (status === "review") return <span className="badge-review text-xs px-2 py-0.5 rounded-full font-medium">Review</span>;
  return null;
};

export default function FitnessTemplatesLibrary() {
  const [, navigate] = useLocation();
  const [activeLevel, setActiveLevel] = useState("All");
  const [activeFocus, setActiveFocus] = useState("All");
  const [activeLoad, setActiveLoad] = useState("All");
  const [search, setSearch] = useState("");

  const filtered = templates.filter((t) => {
    if (activeLevel !== "All" && t.level !== activeLevel) return false;
    if (activeFocus !== "All" && t.focus !== activeFocus) return false;
    if (activeLoad !== "All" && t.load !== activeLoad) return false;
    if (search && !t.name.toLowerCase().includes(search.toLowerCase())) return false;
    return true;
  });

  return (
    <Layout
      donnaPrompt="What physical quality should this template support?"
      donnaActions={[
        "Build mobility template",
        "Build speed template",
        "Build coordination template",
        "Build recovery template",
        "Suggest missing fitness templates",
      ]}
    >
      <div className="px-8 py-7 space-y-6">
        {/* Header */}
        <div className="animate-fade-slide-up">
          <button
            onClick={() => navigate("/templates")}
            className="flex items-center gap-1.5 text-sm mb-4 transition-colors hover:opacity-80"
            style={{ color: "oklch(0.55 0.008 240)" }}
          >
            <ArrowLeft size={14} />
            Templates
          </button>
          <div className="flex items-start justify-between">
            <div>
              <h1 className="font-display text-3xl font-bold" style={{ color: "oklch(0.93 0.005 240)" }}>
                Fitness Templates
              </h1>
              <p className="mt-1 text-sm" style={{ color: "oklch(0.55 0.008 240)" }}>
                Reusable fitness blocks connected to tennis development.
              </p>
            </div>
            <div className="flex items-center gap-3">
              <button
                onClick={() => navigate("/templates/donna-suggestions")}
                className="flex items-center gap-2 px-4 py-2.5 rounded-xl text-sm font-medium transition-all hover:bg-white/[0.05]"
                style={{
                  background: "oklch(0.12 0.010 240)",
                  border: "1px solid oklch(1 0 0 / 0.08)",
                  color: "oklch(0.78 0.12 185)",
                }}
              >
                <Sparkles size={15} />
                Ask DONNA to Suggest
              </button>
              <button
                onClick={() => navigate("/templates/fitness/create")}
                className="btn-teal flex items-center gap-2 px-4 py-2.5 rounded-xl text-sm"
              >
                <Plus size={15} />
                New Fitness Template
              </button>
            </div>
          </div>
        </div>

        {/* Filters */}
        <div
          className="rounded-2xl p-4 space-y-3 animate-fade-slide-up stagger-1"
          style={{ background: "oklch(0.12 0.010 240)", border: "1px solid oklch(1 0 0 / 0.06)" }}
        >
          <div
            className="flex items-center gap-2 px-3 py-2.5 rounded-xl"
            style={{ background: "oklch(0.09 0.008 240)", border: "1px solid oklch(1 0 0 / 0.08)" }}
          >
            <Search size={15} style={{ color: "oklch(0.45 0.008 240)" }} />
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search fitness templates..."
              className="flex-1 bg-transparent text-sm outline-none"
              style={{ color: "oklch(0.85 0.005 240)" }}
            />
          </div>

          <div className="flex flex-wrap gap-4">
            {/* Level */}
            <div className="flex items-center gap-2">
              <span className="text-xs font-medium" style={{ color: "oklch(0.45 0.008 240)" }}>Level:</span>
              <div className="flex gap-1.5">
                {LEVELS.map((l) => (
                  <button
                    key={l}
                    onClick={() => setActiveLevel(l)}
                    className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-xs font-medium transition-all"
                    style={
                      activeLevel === l
                        ? { background: "oklch(0.78 0.12 185 / 0.15)", color: "oklch(0.78 0.12 185)", border: "1px solid oklch(0.78 0.12 185 / 0.30)" }
                        : { background: "oklch(0.09 0.008 240)", color: "oklch(0.55 0.008 240)", border: "1px solid oklch(1 0 0 / 0.08)" }
                    }
                  >
                    {l !== "All" && <span className="w-1.5 h-1.5 rounded-full" style={{ background: levelColors[l] }} />}
                    {l === "High Performance" ? "HP" : l}
                  </button>
                ))}
              </div>
            </div>

            {/* Load */}
            <div className="flex items-center gap-2">
              <span className="text-xs font-medium" style={{ color: "oklch(0.45 0.008 240)" }}>Load:</span>
              <div className="flex gap-1.5">
                {LOAD_FILTERS.map((l) => (
                  <button
                    key={l}
                    onClick={() => setActiveLoad(l)}
                    className="px-2.5 py-1 rounded-lg text-xs font-medium transition-all"
                    style={
                      activeLoad === l
                        ? { background: "oklch(0.78 0.12 185 / 0.15)", color: "oklch(0.78 0.12 185)", border: "1px solid oklch(0.78 0.12 185 / 0.30)" }
                        : { background: "oklch(0.09 0.008 240)", color: "oklch(0.55 0.008 240)", border: "1px solid oklch(1 0 0 / 0.08)" }
                    }
                  >
                    {l}
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Focus filter */}
          <div className="flex items-center gap-2 flex-wrap">
            <span className="text-xs font-medium" style={{ color: "oklch(0.45 0.008 240)" }}>Focus:</span>
            {FOCUS_FILTERS.map((f) => (
              <button
                key={f}
                onClick={() => setActiveFocus(f)}
                className="px-2.5 py-1 rounded-lg text-xs font-medium transition-all"
                style={
                  activeFocus === f
                    ? { background: "oklch(0.65 0.20 295 / 0.15)", color: "oklch(0.65 0.20 295)", border: "1px solid oklch(0.65 0.20 295 / 0.30)" }
                    : { background: "oklch(0.09 0.008 240)", color: "oklch(0.55 0.008 240)", border: "1px solid oklch(1 0 0 / 0.08)" }
                }
              >
                {f}
              </button>
            ))}
          </div>
        </div>

        {/* Template Grid */}
        <div className="grid grid-cols-2 gap-4 animate-fade-slide-up stagger-2">
          {filtered.map((t, i) => {
            const FocusIcon = fitnessGoalIcons[t.focus] || Activity;
            return (
              <div
                key={t.id}
                className="rounded-2xl p-5 card-hover cursor-pointer"
                style={{ background: "oklch(0.12 0.010 240)", animationDelay: `${i * 50}ms` }}
                onClick={() => navigate(`/templates/fitness/${t.id}`)}
              >
                {/* Header */}
                <div className="flex items-start justify-between mb-3">
                  <div className="flex items-center gap-2">
                    <div
                      className="w-2.5 h-2.5 rounded-full"
                      style={{ background: levelColors[t.level] }}
                    />
                    <span className="text-xs font-medium" style={{ color: "oklch(0.55 0.008 240)" }}>
                      {t.levelFit}
                    </span>
                  </div>
                  {statusBadge(t.status)}
                </div>

                {/* Name + Focus */}
                <div className="flex items-start gap-3 mb-3">
                  <div
                    className="w-10 h-10 rounded-xl flex items-center justify-center shrink-0"
                    style={{ background: "oklch(0.65 0.20 295 / 0.10)" }}
                  >
                    <FocusIcon size={18} style={{ color: "oklch(0.65 0.20 295)" }} />
                  </div>
                  <div>
                    <h3 className="font-display font-bold text-base leading-snug" style={{ color: "oklch(0.90 0.005 240)" }}>
                      {t.name}
                    </h3>
                    <p className="text-xs mt-0.5" style={{ color: "oklch(0.55 0.008 240)" }}>
                      Tennis transfer: {t.tennisTransfer}
                    </p>
                  </div>
                </div>

                {/* Blocks */}
                <div className="flex flex-wrap gap-1.5 mb-3">
                  {(t as any).blocks?.map((block: string) => (
                    <span
                      key={block}
                      className="text-xs px-2 py-0.5 rounded-md font-medium"
                      style={{ background: "oklch(0.78 0.12 185 / 0.08)", color: "oklch(0.78 0.12 185)", border: "1px solid oklch(0.78 0.12 185 / 0.18)" }}
                    >
                      {block}
                    </span>
                  ))}
                </div>

                {/* Meta */}
                <div className="grid grid-cols-3 gap-2 mb-4">
                  <div className="px-2.5 py-2 rounded-lg" style={{ background: "oklch(0.09 0.008 240)" }}>
                    <p className="text-xs mb-0.5" style={{ color: "oklch(0.40 0.008 240)" }}>Duration</p>
                    <p className="text-xs font-mono-data font-medium" style={{ color: "oklch(0.75 0.005 240)" }}>
                      {t.duration}
                    </p>
                  </div>
                  <div className="px-2.5 py-2 rounded-lg" style={{ background: "oklch(0.09 0.008 240)" }}>
                    <p className="text-xs mb-0.5" style={{ color: "oklch(0.40 0.008 240)" }}>Load</p>
                    <p className="text-xs font-medium" style={{ color: loadColors[t.load] }}>
                      {t.load}
                    </p>
                  </div>
                  <div className="px-2.5 py-2 rounded-lg" style={{ background: "oklch(0.09 0.008 240)" }}>
                    <p className="text-xs mb-0.5" style={{ color: "oklch(0.40 0.008 240)" }}>Equipment</p>
                    <p className="text-xs font-medium truncate" style={{ color: "oklch(0.75 0.005 240)" }}>
                      {t.equipment}
                    </p>
                  </div>
                </div>

                {/* Footer */}
                <div className="flex items-center justify-between">
                  <span className="text-xs" style={{ color: "oklch(0.40 0.008 240)" }}>
                    Last used: {t.lastUsed}
                  </span>
                  <button
                    className="flex items-center gap-1 text-xs font-medium transition-colors"
                    style={{ color: "oklch(0.78 0.12 185)" }}
                  >
                    Open <ChevronRight size={12} />
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </Layout>
  );
}
