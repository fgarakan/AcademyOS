/**
 * Screen 10: DONNA Template Suggestions
 * AI-powered suggestions based on curriculum gaps
 */

import { useState } from "react";
import { useLocation } from "wouter";
import Layout from "@/components/Layout";
import {
  ArrowLeft,
  Sparkles,
  Plus,
  X,
  ChevronRight,
  AlertCircle,
  Dumbbell,
  FileStack,
  Users,
  BookOpen,
  TrendingUp,
  Clock,
} from "lucide-react";

const SUGGESTIONS = [
  {
    id: 1,
    title: "Missing Orange Ball 2 Recovery Template",
    type: "Class",
    priority: "high",
    why: "Your Orange Ball 2 players have 3 upcoming sessions with no recovery-focused template. After tournament play, recovery sessions are critical for this level.",
    curriculumConnection: "Orange Ball 2 — Post-competition recovery protocol",
    playersAffected: "12 players (Orange Ball 2 Group A + B)",
    usefulness: 94,
    estimatedTime: "45 min to build",
    levelColor: "oklch(0.70 0.18 45)",
    level: "Orange",
  },
  {
    id: 2,
    title: "Green Ball Serve + First Ball Template Recommended",
    type: "Class",
    priority: "high",
    why: "Green Ball 1 players are approaching the serve assessment gate but have no serve-focused template in the library. DONNA detected this gap from curriculum progress data.",
    curriculumConnection: "Green Ball 1 — Serve mechanics + first ball attack gate",
    playersAffected: "8 players (Green Ball 1 Group)",
    usefulness: 91,
    estimatedTime: "60 min to build",
    levelColor: "oklch(0.65 0.17 145)",
    level: "Green",
  },
  {
    id: 3,
    title: "Fitness Mobility Template Missing for Red/Orange Groups",
    type: "Fitness",
    priority: "medium",
    why: "Red and Orange Ball groups have no dedicated mobility fitness template. Research shows mobility work at this age significantly reduces injury risk and improves tennis transfer.",
    curriculumConnection: "Red Ball 1–3 + Orange Ball 1–3 — Physical development pathway",
    playersAffected: "24 players (Red + Orange groups)",
    usefulness: 88,
    estimatedTime: "30 min to build",
    levelColor: "oklch(0.62 0.22 25)",
    level: "Red",
  },
  {
    id: 4,
    title: "High Performance Pre-Tournament Primer Suggested",
    type: "Class",
    priority: "medium",
    why: "HP players have a tournament in 3 weeks. A pre-tournament template helps coaches deliver consistent preparation sessions across all HP groups.",
    curriculumConnection: "High Performance 1–3 — Competition preparation pathway",
    playersAffected: "6 players (HP Group)",
    usefulness: 85,
    estimatedTime: "75 min to build",
    levelColor: "oklch(0.65 0.20 295)",
    level: "HP",
  },
  {
    id: 5,
    title: "Yellow Ball Baseline Consistency Template",
    type: "Class",
    priority: "low",
    why: "Yellow Ball 2 players are working on baseline consistency but the current template library has no dedicated baseline rally template for this level.",
    curriculumConnection: "Yellow Ball 2 — Topspin depth + direction skill need",
    playersAffected: "10 players (Yellow Ball 2 Group)",
    usefulness: 78,
    estimatedTime: "50 min to build",
    levelColor: "oklch(0.78 0.17 90)",
    level: "Yellow",
  },
];

const priorityColors: Record<string, string> = {
  high: "oklch(0.62 0.22 25)",
  medium: "oklch(0.78 0.17 90)",
  low: "oklch(0.65 0.17 145)",
};

const priorityLabels: Record<string, string> = {
  high: "High Priority",
  medium: "Medium Priority",
  low: "Low Priority",
};

export default function DonnaSuggestions() {
  const [, navigate] = useLocation();
  const [dismissed, setDismissed] = useState<number[]>([]);

  const visible = SUGGESTIONS.filter((s) => !dismissed.includes(s.id));

  const handleCreate = (suggestion: typeof SUGGESTIONS[0]) => {
    if (suggestion.type === "Class") {
      navigate("/templates/class/create");
    } else {
      navigate("/templates/fitness/create");
    }
  };

  return (
    <Layout
      donnaPrompt="I've analyzed your curriculum, player progress, and upcoming sessions. Here are the templates your academy is missing. Want me to build the highest priority one first?"
      donnaActions={[
        "Build highest priority template",
        "Show level gaps",
        "Build all Orange Ball templates",
        "Find fitness gaps",
        "Show tournament prep gaps",
      ]}
    >
      <div className="px-8 py-7 space-y-6">
        {/* Header */}
        <div className="animate-fade-slide-up">
          <button
            onClick={() => navigate("/templates")}
            className="flex items-center gap-1.5 text-sm mb-4 transition-colors hover:opacity-80"
            style={{ color: "oklch(0.55 0.008 240)" }}
          >
            <ArrowLeft size={14} />
            Templates
          </button>
          <div className="flex items-start justify-between">
            <div>
              <h1 className="font-display text-3xl font-bold" style={{ color: "oklch(0.93 0.005 240)" }}>
                DONNA Template Suggestions
              </h1>
              <p className="mt-1 text-sm" style={{ color: "oklch(0.55 0.008 240)" }}>
                Suggested templates based on your curriculum gaps and academy needs.
              </p>
            </div>
            <div className="flex items-center gap-2">
              <span
                className="text-sm px-3 py-1.5 rounded-xl font-medium"
                style={{ background: "oklch(0.78 0.12 185 / 0.10)", color: "oklch(0.78 0.12 185)", border: "1px solid oklch(0.78 0.12 185 / 0.20)" }}
              >
                {visible.length} suggestions
              </span>
            </div>
          </div>
        </div>

        {/* DONNA Intro Card */}
        <div
          className="rounded-2xl p-5 animate-fade-slide-up stagger-1 relative overflow-hidden"
          style={{
            background: "linear-gradient(135deg, oklch(0.78 0.12 185 / 0.08), oklch(0.65 0.20 295 / 0.06))",
            border: "1px solid oklch(0.78 0.12 185 / 0.20)",
          }}
        >
          <div className="flex items-start gap-4">
            <div
              className="w-10 h-10 rounded-xl flex items-center justify-center shrink-0"
              style={{ background: "oklch(0.78 0.12 185 / 0.15)" }}
            >
              <Sparkles size={20} style={{ color: "oklch(0.78 0.12 185)" }} />
            </div>
            <div>
              <p className="font-display font-bold text-sm mb-1" style={{ color: "oklch(0.78 0.12 185)" }}>
                DONNA Analysis
              </p>
              <p className="text-sm leading-relaxed" style={{ color: "oklch(0.78 0.005 240)" }}>
                I analyzed your curriculum progress, upcoming sessions, and template library. I found <strong style={{ color: "oklch(0.78 0.12 185)" }}>{SUGGESTIONS.length} template gaps</strong> that could improve your coaching consistency and player development. I can build any of these from your curriculum — nothing changes until you approve.
              </p>
            </div>
          </div>
          <div
            className="absolute top-0 right-0 w-64 h-64 rounded-full pointer-events-none"
            style={{
              background: "radial-gradient(circle, oklch(0.78 0.12 185 / 0.05) 0%, transparent 70%)",
              transform: "translate(30%, -30%)",
            }}
          />
        </div>

        {/* Suggestion Cards */}
        <div className="space-y-4 animate-fade-slide-up stagger-2">
          {visible.map((suggestion, i) => (
            <div
              key={suggestion.id}
              className="rounded-2xl p-5 card-hover"
              style={{
                background: "oklch(0.12 0.010 240)",
                borderLeft: `3px solid ${priorityColors[suggestion.priority]}`,
                animationDelay: `${i * 60}ms`,
              }}
            >
              <div className="flex items-start gap-4">
                {/* Icon */}
                <div
                  className="w-10 h-10 rounded-xl flex items-center justify-center shrink-0"
                  style={{ background: `${suggestion.levelColor.replace(")", " / 0.12)")}` }}
                >
                  {suggestion.type === "Class" ? (
                    <FileStack size={18} style={{ color: suggestion.levelColor }} />
                  ) : (
                    <Dumbbell size={18} style={{ color: suggestion.levelColor }} />
                  )}
                </div>

                {/* Content */}
                <div className="flex-1 min-w-0">
                  <div className="flex items-start justify-between mb-2">
                    <div>
                      <div className="flex items-center gap-2 mb-1">
                        <span
                          className="text-xs px-2 py-0.5 rounded-full font-medium"
                          style={{
                            background: `${priorityColors[suggestion.priority].replace(")", " / 0.12)")}`,
                            color: priorityColors[suggestion.priority],
                            border: `1px solid ${priorityColors[suggestion.priority].replace(")", " / 0.25)")}`,
                          }}
                        >
                          {priorityLabels[suggestion.priority]}
                        </span>
                        <span
                          className="text-xs px-2 py-0.5 rounded-full font-medium"
                          style={{ background: "oklch(0.09 0.008 240)", color: "oklch(0.55 0.008 240)", border: "1px solid oklch(1 0 0 / 0.08)" }}
                        >
                          {suggestion.type} Template
                        </span>
                      </div>
                      <h3 className="font-display font-bold text-base" style={{ color: "oklch(0.90 0.005 240)" }}>
                        {suggestion.title}
                      </h3>
                    </div>
                    <button
                      onClick={() => setDismissed((prev) => [...prev, suggestion.id])}
                      className="p-1.5 rounded-lg hover:bg-white/5 transition-colors shrink-0 ml-3"
                      style={{ color: "oklch(0.40 0.008 240)" }}
                    >
                      <X size={14} />
                    </button>
                  </div>

                  {/* Why DONNA suggests it */}
                  <div
                    className="rounded-xl px-3 py-2.5 mb-3"
                    style={{ background: "oklch(0.09 0.008 240)" }}
                  >
                    <div className="flex items-start gap-2">
                      <AlertCircle size={13} className="shrink-0 mt-0.5" style={{ color: "oklch(0.78 0.12 185)" }} />
                      <p className="text-sm" style={{ color: "oklch(0.70 0.005 240)" }}>
                        {suggestion.why}
                      </p>
                    </div>
                  </div>

                  {/* Meta */}
                  <div className="grid grid-cols-4 gap-3 mb-4">
                    <div>
                      <p className="text-xs mb-0.5" style={{ color: "oklch(0.40 0.008 240)" }}>Curriculum</p>
                      <div className="flex items-start gap-1">
                        <BookOpen size={11} className="shrink-0 mt-0.5" style={{ color: "oklch(0.78 0.12 185)" }} />
                        <p className="text-xs" style={{ color: "oklch(0.65 0.008 240)" }}>{suggestion.curriculumConnection}</p>
                      </div>
                    </div>
                    <div>
                      <p className="text-xs mb-0.5" style={{ color: "oklch(0.40 0.008 240)" }}>Players Affected</p>
                      <div className="flex items-center gap-1">
                        <Users size={11} style={{ color: "oklch(0.65 0.20 295)" }} />
                        <p className="text-xs" style={{ color: "oklch(0.65 0.008 240)" }}>{suggestion.playersAffected}</p>
                      </div>
                    </div>
                    <div>
                      <p className="text-xs mb-0.5" style={{ color: "oklch(0.40 0.008 240)" }}>Estimated Usefulness</p>
                      <div className="flex items-center gap-2">
                        <div
                          className="flex-1 h-1.5 rounded-full overflow-hidden"
                          style={{ background: "oklch(1 0 0 / 0.06)" }}
                        >
                          <div
                            className="h-full rounded-full"
                            style={{
                              width: `${suggestion.usefulness}%`,
                              background: suggestion.usefulness > 90 ? "oklch(0.65 0.17 145)" : "oklch(0.78 0.12 185)",
                            }}
                          />
                        </div>
                        <span className="text-xs font-mono-data" style={{ color: "oklch(0.65 0.008 240)" }}>
                          {suggestion.usefulness}%
                        </span>
                      </div>
                    </div>
                    <div>
                      <p className="text-xs mb-0.5" style={{ color: "oklch(0.40 0.008 240)" }}>Build Time</p>
                      <div className="flex items-center gap-1">
                        <Clock size={11} style={{ color: "oklch(0.55 0.008 240)" }} />
                        <p className="text-xs" style={{ color: "oklch(0.65 0.008 240)" }}>{suggestion.estimatedTime}</p>
                      </div>
                    </div>
                  </div>

                  {/* Actions */}
                  <div className="flex items-center gap-3">
                    <button
                      onClick={() => handleCreate(suggestion)}
                      className="btn-teal flex items-center gap-2 px-4 py-2 rounded-xl text-sm"
                    >
                      <Plus size={14} />
                      Create Draft
                    </button>
                    <button
                      className="flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-medium transition-all hover:bg-white/[0.05]"
                      style={{ background: "oklch(0.09 0.008 240)", border: "1px solid oklch(1 0 0 / 0.08)", color: "oklch(0.65 0.008 240)" }}
                    >
                      <Sparkles size={14} style={{ color: "oklch(0.78 0.12 185)" }} />
                      Let DONNA Build It
                    </button>
                    <button
                      className="flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-medium transition-all hover:bg-white/[0.05] ml-auto"
                      style={{ color: "oklch(0.45 0.008 240)" }}
                      onClick={() => setDismissed((prev) => [...prev, suggestion.id])}
                    >
                      Dismiss
                    </button>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Empty state */}
        {visible.length === 0 && (
          <div className="text-center py-16 animate-fade-in">
            <div
              className="w-16 h-16 rounded-2xl flex items-center justify-center mx-auto mb-4"
              style={{ background: "oklch(0.12 0.010 240)" }}
            >
              <Sparkles size={24} style={{ color: "oklch(0.78 0.12 185)" }} />
            </div>
            <p className="font-display font-bold text-lg mb-2" style={{ color: "oklch(0.65 0.008 240)" }}>
              All suggestions reviewed
            </p>
            <p className="text-sm mb-4" style={{ color: "oklch(0.45 0.008 240)" }}>
              DONNA will continue monitoring your curriculum for new gaps.
            </p>
            <button
              onClick={() => navigate("/templates")}
              className="btn-teal inline-flex items-center gap-2 px-5 py-2.5 rounded-xl text-sm"
            >
              Back to Templates
              <ChevronRight size={15} />
            </button>
          </div>
        )}
      </div>
    </Layout>
  );
}
