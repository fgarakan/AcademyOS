/**
 * Screen 3: Create Class Template — DONNA Guided Setup
 * 5-step flow: Level → Goal → Build Blocks → Add Drills → Review
 */

import { useState } from "react";
import { useLocation } from "wouter";
import Layout from "@/components/Layout";
import {
  ArrowLeft,
  ArrowRight,
  Check,
  Sparkles,
  GripVertical,
  Edit3,
  Plus,
  X,
  Clock,
  Target,
  BookOpen,
  Eye,
  Save,
  Send,
} from "lucide-react";

const STEPS = [
  { id: 1, label: "Choose Level" },
  { id: 2, label: "Choose Goal" },
  { id: 3, label: "Build Blocks" },
  { id: 4, label: "Add Drills" },
  { id: 5, label: "Review Template" },
];

const LEVELS = [
  { group: "Red Ball", items: ["Red Ball 1", "Red Ball 2", "Red Ball 3"], color: "oklch(0.62 0.22 25)" },
  { group: "Orange Ball", items: ["Orange Ball 1", "Orange Ball 2", "Orange Ball 3"], color: "oklch(0.70 0.18 45)" },
  { group: "Green Ball", items: ["Green Ball 1", "Green Ball 2", "Green Ball 3"], color: "oklch(0.65 0.17 145)" },
  { group: "Yellow Ball", items: ["Yellow Ball 1", "Yellow Ball 2", "Yellow Ball 3"], color: "oklch(0.78 0.17 90)" },
  { group: "High Performance", items: ["High Performance 1", "High Performance 2", "High Performance 3"], color: "oklch(0.65 0.20 295)" },
];

const GOALS = [
  { label: "Skill Development", desc: "Focus on technical skill building and repetition" },
  { label: "Competition Pattern", desc: "Build tactical patterns for match play" },
  { label: "Assessment Session", desc: "Evaluate player progress against curriculum gates" },
  { label: "Live Ball Session", desc: "Open play with coaching interventions" },
  { label: "Mixed Development", desc: "Blend skill, fitness, and competition elements" },
  { label: "Pre-Tournament", desc: "Sharpen patterns and mental readiness" },
  { label: "Recovery / Lower Load", desc: "Active recovery with reduced intensity" },
];

const DEFAULT_BLOCKS = [
  { id: 1, name: "Warm-Up / Athletic Prep", duration: 10, intent: "Activate movement patterns and prepare the body", skill: "Dynamic movement", watchFor: "Split step timing, ready position" },
  { id: 2, name: "Technical Skill Block", duration: 20, intent: "Build the primary technical skill for this session", skill: "Crosscourt forehand control", watchFor: "Contact point, swing path, follow-through" },
  { id: 3, name: "Pattern / Decision Block", duration: 20, intent: "Apply skill in pattern play with decision-making", skill: "Rally direction control", watchFor: "Target selection, recovery after each shot" },
  { id: 4, name: "Live Ball / Competition Block", duration: 25, intent: "Test skills under competitive pressure", skill: "Point play", watchFor: "Pattern execution under pressure" },
  { id: 5, name: "Review / Challenge", duration: 5, intent: "Consolidate learning and set next challenge", skill: "Self-assessment", watchFor: "Player awareness of own performance" },
];

const DRILLS = [
  { id: 1, name: "Crosscourt Rally Consistency", skill: "Groundstrokes", domain: "Technical", recommended: true },
  { id: 2, name: "Wide Ball Recovery Drill", skill: "Movement", domain: "Athletic", recommended: true },
  { id: 3, name: "Serve + 1 Pattern", skill: "Serve", domain: "Tactical", recommended: false },
  { id: 4, name: "Short Court Control", skill: "Touch", domain: "Technical", recommended: true },
  { id: 5, name: "Live Ball Points", skill: "Competition", domain: "Match Play", recommended: false },
  { id: 6, name: "Target Feeding — Crosscourt", skill: "Direction", domain: "Technical", recommended: true },
];

const donnaMessages: Record<number, string> = {
  1: "Choose the level this template is built for. I will pull the right skills, drills, gates, and coach watch-fors from your curriculum.",
  2: "What is the main goal for this session? I'll structure the blocks and drill selection to match your intent.",
  3: "These blocks are pre-built from your curriculum for this level. Drag to reorder, edit to customize, or ask me to adjust.",
  4: "Here are drills recommended from your curriculum for this level and goal. Add the ones that fit your session.",
  5: "Review your complete template before saving. Nothing changes in your curriculum until you approve.",
};

export default function CreateClassTemplate() {
  const [, navigate] = useLocation();
  const [step, setStep] = useState(1);
  const [selectedLevel, setSelectedLevel] = useState("");
  const [selectedGoal, setSelectedGoal] = useState("");
  const [blocks, setBlocks] = useState(DEFAULT_BLOCKS);
  const [selectedDrills, setSelectedDrills] = useState<number[]>([1, 2, 4, 6]);
  const [templateName, setTemplateName] = useState("");

  const canProceed = () => {
    if (step === 1) return !!selectedLevel;
    if (step === 2) return !!selectedGoal;
    return true;
  };

  const levelColor = LEVELS.find((g) => g.items.includes(selectedLevel))?.color || "oklch(0.78 0.12 185)";

  return (
    <Layout
      donnaPrompt={donnaMessages[step]}
      donnaActions={[
        "Suggest blocks for this level",
        "Add a warm-up block",
        "Make this session easier",
        "Make this session harder",
        "Add competition scoring",
        "Preview impact on curriculum",
      ]}
    >
      <div className="px-8 py-7">
        {/* Header */}
        <div className="mb-6 animate-fade-slide-up">
          <button
            onClick={() => navigate("/templates/class")}
            className="flex items-center gap-1.5 text-sm mb-4 transition-colors hover:opacity-80"
            style={{ color: "oklch(0.55 0.008 240)" }}
          >
            <ArrowLeft size={14} />
            Class Templates
          </button>
          <h1 className="font-display text-3xl font-bold" style={{ color: "oklch(0.93 0.005 240)" }}>
            Create Class Template
          </h1>
          <p className="mt-1 text-sm" style={{ color: "oklch(0.55 0.008 240)" }}>
            DONNA will help you turn curriculum into a reusable coaching template.
          </p>
        </div>

        {/* Step Progress */}
        <div
          className="rounded-2xl p-5 mb-6 animate-fade-slide-up stagger-1"
          style={{ background: "oklch(0.12 0.010 240)", border: "1px solid oklch(1 0 0 / 0.06)" }}
        >
          <div className="flex items-center gap-0">
            {STEPS.map((s, i) => (
              <div key={s.id} className="flex items-center flex-1">
                <div className="flex flex-col items-center gap-1.5">
                  <button
                    onClick={() => s.id < step && setStep(s.id)}
                    className={`step-dot ${s.id < step ? "completed" : s.id === step ? "active" : "pending"}`}
                  >
                    {s.id < step ? <Check size={14} /> : s.id}
                  </button>
                  <span
                    className="text-xs whitespace-nowrap"
                    style={{
                      color: s.id === step ? "oklch(0.78 0.12 185)" : s.id < step ? "oklch(0.65 0.17 145)" : "oklch(0.40 0.008 240)",
                      fontWeight: s.id === step ? 600 : 400,
                    }}
                  >
                    {s.label}
                  </span>
                </div>
                {i < STEPS.length - 1 && (
                  <div
                    className="flex-1 h-px mx-2 mb-5"
                    style={{
                      background: s.id < step ? "oklch(0.78 0.12 185 / 0.40)" : "oklch(1 0 0 / 0.08)",
                    }}
                  />
                )}
              </div>
            ))}
          </div>
        </div>

        {/* DONNA Hint */}
        <div
          className="rounded-xl px-4 py-3 mb-5 flex items-start gap-3 animate-fade-slide-up stagger-2"
          style={{ background: "oklch(0.78 0.12 185 / 0.06)", border: "1px solid oklch(0.78 0.12 185 / 0.15)" }}
        >
          <Sparkles size={15} className="shrink-0 mt-0.5" style={{ color: "oklch(0.78 0.12 185)" }} />
          <p className="text-sm" style={{ color: "oklch(0.75 0.005 240)" }}>
            {donnaMessages[step]}
          </p>
        </div>

        {/* Step Content */}
        <div className="animate-fade-slide-up stagger-3">
          {/* Step 1: Choose Level */}
          {step === 1 && (
            <div className="space-y-4">
              {LEVELS.map((group) => (
                <div key={group.group}>
                  <div className="flex items-center gap-2 mb-2">
                    <div className="w-2 h-2 rounded-full" style={{ background: group.color }} />
                    <span className="text-xs font-medium" style={{ color: "oklch(0.55 0.008 240)" }}>
                      {group.group}
                    </span>
                  </div>
                  <div className="grid grid-cols-3 gap-2">
                    {group.items.map((level) => (
                      <button
                        key={level}
                        onClick={() => setSelectedLevel(level)}
                        className="px-4 py-3 rounded-xl text-sm font-medium text-left transition-all"
                        style={
                          selectedLevel === level
                            ? {
                                background: `${group.color.replace(")", " / 0.12)")}`,
                                color: group.color,
                                border: `1px solid ${group.color.replace(")", " / 0.35)")}`,
                                boxShadow: `0 0 12px ${group.color.replace(")", " / 0.15)")}`,
                              }
                            : {
                                background: "oklch(0.12 0.010 240)",
                                color: "oklch(0.65 0.008 240)",
                                border: "1px solid oklch(1 0 0 / 0.08)",
                              }
                        }
                      >
                        {level}
                      </button>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          )}

          {/* Step 2: Choose Goal */}
          {step === 2 && (
            <div className="grid grid-cols-2 gap-3">
              {GOALS.map((goal) => (
                <button
                  key={goal.label}
                  onClick={() => setSelectedGoal(goal.label)}
                  className="px-5 py-4 rounded-xl text-left transition-all"
                  style={
                    selectedGoal === goal.label
                      ? {
                          background: "oklch(0.78 0.12 185 / 0.10)",
                          border: "1px solid oklch(0.78 0.12 185 / 0.35)",
                          boxShadow: "0 0 16px oklch(0.78 0.12 185 / 0.12)",
                        }
                      : {
                          background: "oklch(0.12 0.010 240)",
                          border: "1px solid oklch(1 0 0 / 0.08)",
                        }
                  }
                >
                  <p
                    className="font-display font-bold text-sm mb-1"
                    style={{ color: selectedGoal === goal.label ? "oklch(0.78 0.12 185)" : "oklch(0.85 0.005 240)" }}
                  >
                    {goal.label}
                  </p>
                  <p className="text-xs" style={{ color: "oklch(0.50 0.008 240)" }}>
                    {goal.desc}
                  </p>
                </button>
              ))}
            </div>
          )}

          {/* Step 3: Build Blocks */}
          {step === 3 && (
            <div className="space-y-3">
              {blocks.map((block) => (
                <div
                  key={block.id}
                  className="rounded-2xl p-4"
                  style={{ background: "oklch(0.12 0.010 240)", border: "1px solid oklch(1 0 0 / 0.08)" }}
                >
                  <div className="flex items-start gap-3">
                    <div className="drag-handle mt-1">
                      <GripVertical size={16} />
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center justify-between mb-2">
                        <h4 className="font-display font-bold text-sm" style={{ color: "oklch(0.90 0.005 240)" }}>
                          {block.name}
                        </h4>
                        <div className="flex items-center gap-2">
                          <span
                            className="text-xs font-mono-data px-2 py-0.5 rounded-lg"
                            style={{ background: "oklch(0.78 0.12 185 / 0.10)", color: "oklch(0.78 0.12 185)" }}
                          >
                            {block.duration} min
                          </span>
                          <button className="p-1 rounded-lg hover:bg-white/5 transition-colors" style={{ color: "oklch(0.55 0.008 240)" }}>
                            <Edit3 size={13} />
                          </button>
                          <button className="p-1 rounded-lg hover:bg-white/5 transition-colors" style={{ color: "oklch(0.78 0.12 185)" }}>
                            <Sparkles size={13} />
                          </button>
                        </div>
                      </div>
                      <p className="text-xs mb-2" style={{ color: "oklch(0.55 0.008 240)" }}>
                        {block.intent}
                      </p>
                      <div className="grid grid-cols-2 gap-2">
                        <div className="flex items-center gap-1.5">
                          <Target size={11} style={{ color: "oklch(0.78 0.12 185)" }} />
                          <span className="text-xs" style={{ color: "oklch(0.55 0.008 240)" }}>
                            {block.skill}
                          </span>
                        </div>
                        <div className="flex items-center gap-1.5">
                          <Eye size={11} style={{ color: "oklch(0.65 0.20 295)" }} />
                          <span className="text-xs" style={{ color: "oklch(0.55 0.008 240)" }}>
                            {block.watchFor}
                          </span>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
              <button
                className="w-full flex items-center justify-center gap-2 px-4 py-3 rounded-xl text-sm transition-all hover:bg-white/[0.03]"
                style={{ border: "1px dashed oklch(0.78 0.12 185 / 0.25)", color: "oklch(0.78 0.12 185)" }}
              >
                <Plus size={15} />
                Add Block
              </button>
            </div>
          )}

          {/* Step 4: Add Drills */}
          {step === 4 && (
            <div className="space-y-4">
              <div
                className="rounded-xl px-4 py-3 flex items-center gap-2"
                style={{ background: "oklch(0.78 0.12 185 / 0.06)", border: "1px solid oklch(0.78 0.12 185 / 0.15)" }}
              >
                <Sparkles size={14} style={{ color: "oklch(0.78 0.12 185)" }} />
                <p className="text-sm" style={{ color: "oklch(0.75 0.005 240)" }}>
                  Showing recommended drills for <strong style={{ color: "oklch(0.78 0.12 185)" }}>{selectedLevel || "your selected level"}</strong>
                </p>
              </div>
              <div className="grid grid-cols-2 gap-3">
                {DRILLS.map((drill) => {
                  const selected = selectedDrills.includes(drill.id);
                  return (
                    <div
                      key={drill.id}
                      className="rounded-xl p-4 transition-all cursor-pointer"
                      style={
                        selected
                          ? {
                              background: "oklch(0.78 0.12 185 / 0.08)",
                              border: "1px solid oklch(0.78 0.12 185 / 0.30)",
                            }
                          : {
                              background: "oklch(0.12 0.010 240)",
                              border: "1px solid oklch(1 0 0 / 0.08)",
                            }
                      }
                      onClick={() =>
                        setSelectedDrills((prev) =>
                          prev.includes(drill.id) ? prev.filter((d) => d !== drill.id) : [...prev, drill.id]
                        )
                      }
                    >
                      <div className="flex items-start justify-between mb-2">
                        <div>
                          {drill.recommended && (
                            <span className="badge-teal text-xs px-2 py-0.5 rounded-full font-medium mb-1.5 inline-block">
                              DONNA Suggested
                            </span>
                          )}
                          <p className="font-display font-bold text-sm" style={{ color: "oklch(0.88 0.005 240)" }}>
                            {drill.name}
                          </p>
                        </div>
                        <div
                          className="w-5 h-5 rounded-full flex items-center justify-center"
                          style={
                            selected
                              ? { background: "oklch(0.78 0.12 185)", color: "oklch(0.09 0.008 240)" }
                              : { background: "oklch(0.09 0.008 240)", border: "1px solid oklch(1 0 0 / 0.15)" }
                          }
                        >
                          {selected && <Check size={11} />}
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="text-xs px-2 py-0.5 rounded-lg" style={{ background: "oklch(0.09 0.008 240)", color: "oklch(0.55 0.008 240)" }}>
                          {drill.skill}
                        </span>
                        <span className="text-xs px-2 py-0.5 rounded-lg" style={{ background: "oklch(0.09 0.008 240)", color: "oklch(0.55 0.008 240)" }}>
                          {drill.domain}
                        </span>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* Step 5: Review */}
          {step === 5 && (
            <div className="space-y-4">
              {/* Template name */}
              <div
                className="rounded-2xl p-5"
                style={{ background: "oklch(0.12 0.010 240)", border: "1px solid oklch(1 0 0 / 0.06)" }}
              >
                <label className="text-xs font-medium block mb-2" style={{ color: "oklch(0.55 0.008 240)" }}>
                  Template Name
                </label>
                <input
                  type="text"
                  value={templateName}
                  onChange={(e) => setTemplateName(e.target.value)}
                  placeholder={`${selectedLevel} — ${selectedGoal || "Session Template"}`}
                  className="w-full bg-transparent text-base font-display font-bold outline-none"
                  style={{ color: "oklch(0.90 0.005 240)" }}
                />
              </div>

              {/* Summary */}
              <div
                className="rounded-2xl p-5 space-y-4"
                style={{ background: "oklch(0.12 0.010 240)", border: "1px solid oklch(1 0 0 / 0.06)" }}
              >
                <h3 className="font-display font-bold text-base" style={{ color: "oklch(0.85 0.005 240)" }}>
                  Template Summary
                </h3>
                <div className="grid grid-cols-3 gap-3">
                  {[
                    { label: "Level", value: selectedLevel || "Not selected", color: levelColor },
                    { label: "Goal", value: selectedGoal || "Not selected" },
                    { label: "Duration", value: `${blocks.reduce((a, b) => a + b.duration, 0)} min` },
                    { label: "Blocks", value: `${blocks.length} blocks` },
                    { label: "Drills", value: `${selectedDrills.length} drills` },
                    { label: "Status", value: "Draft" },
                  ].map((item, i) => (
                    <div key={i} className="px-3 py-2.5 rounded-xl" style={{ background: "oklch(0.09 0.008 240)" }}>
                      <p className="text-xs mb-1" style={{ color: "oklch(0.45 0.008 240)" }}>{item.label}</p>
                      <p className="text-sm font-medium" style={{ color: item.color || "oklch(0.85 0.005 240)" }}>
                        {item.value}
                      </p>
                    </div>
                  ))}
                </div>
              </div>

              {/* Curriculum Connections */}
              <div className="rounded-2xl p-5" style={{ background: "oklch(0.12 0.010 240)", border: "1px solid oklch(1 0 0 / 0.06)" }}>
                <h3 className="font-display font-bold text-sm mb-3" style={{ color: "oklch(0.75 0.005 240)" }}>Curriculum Connections</h3>
                <div className="flex items-center gap-2 flex-wrap">
                  {["Curriculum Level", "Skill Need", "Drill", "Template Block", "Coach Watch-For", "Assessment Gate"].map((node, i, arr) => (
                    <div key={i} className="flex items-center gap-2">
                      <span className="text-xs px-3 py-1.5 rounded-full font-medium" style={{ background: "oklch(0.78 0.12 185 / 0.10)", color: "oklch(0.78 0.12 185)", border: "1px solid oklch(0.78 0.12 185 / 0.20)" }}>{node}</span>
                      {i < arr.length - 1 && <span className="text-xs" style={{ color: "oklch(0.35 0.008 240)" }}>→</span>}
                    </div>
                  ))}
                </div>
              </div>

              {/* Coach Briefing */}
              <div className="rounded-2xl p-5" style={{ background: "oklch(0.12 0.010 240)", border: "1px solid oklch(1 0 0 / 0.06)" }}>
                <h3 className="font-display font-bold text-sm mb-2" style={{ color: "oklch(0.75 0.005 240)" }}>Coach Briefing</h3>
                <p className="text-sm leading-relaxed" style={{ color: "oklch(0.65 0.005 240)" }}>
                  Today's focus is building {selectedGoal?.toLowerCase() || "session skills"} for {selectedLevel || "this level"}. Coaches should watch for clean contact points and recovery position after each ball.
                </p>
              </div>

              {/* Player Outcomes */}
              <div className="rounded-2xl p-5" style={{ background: "oklch(0.12 0.010 240)", border: "1px solid oklch(1 0 0 / 0.06)" }}>
                <h3 className="font-display font-bold text-sm mb-3" style={{ color: "oklch(0.75 0.005 240)" }}>Player Outcomes</h3>
                <div className="space-y-2">
                  {["Improved consistency in target skill", "Awareness of own performance patterns", "Readiness for next curriculum gate"].map((outcome, i) => (
                    <div key={i} className="flex items-center gap-2">
                      <div className="w-1.5 h-1.5 rounded-full" style={{ background: "oklch(0.65 0.17 145)" }} />
                      <span className="text-xs" style={{ color: "oklch(0.65 0.005 240)" }}>{outcome}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Safety notice */}
              <div
                className="rounded-xl px-4 py-3 flex items-start gap-3"
                style={{ background: "oklch(0.65 0.17 145 / 0.06)", border: "1px solid oklch(0.65 0.17 145 / 0.20)" }}
              >
                <Check size={15} className="shrink-0 mt-0.5" style={{ color: "oklch(0.65 0.17 145)" }} />
                <div>
                  <p className="text-sm font-medium" style={{ color: "oklch(0.65 0.17 145)" }}>
                    Review-safe
                  </p>
                  <p className="text-xs mt-0.5" style={{ color: "oklch(0.55 0.008 240)" }}>
                    This template is saved as a draft. It does not change your master curriculum. Director approval required before use.
                  </p>
                </div>
              </div>

              {/* Action buttons */}
              <div className="flex items-center gap-3 flex-wrap">
                <button
                  className="flex items-center gap-2 px-5 py-2.5 rounded-xl text-sm font-medium transition-all hover:bg-white/[0.05]"
                  style={{ background: "oklch(0.12 0.010 240)", border: "1px solid oklch(1 0 0 / 0.08)", color: "oklch(0.75 0.005 240)" }}
                >
                  <Save size={15} />
                  Save as Draft
                </button>
                <button
                  className="flex items-center gap-2 px-5 py-2.5 rounded-xl text-sm font-medium transition-all hover:bg-white/[0.05]"
                  style={{ background: "oklch(0.12 0.010 240)", border: "1px solid oklch(1 0 0 / 0.08)", color: "oklch(0.75 0.005 240)" }}
                  onClick={() => navigate("/templates/coach-preview")}
                >
                  <Eye size={15} />
                  Preview Coach View
                </button>
                <button
                  className="flex items-center gap-2 px-5 py-2.5 rounded-xl text-sm font-medium transition-all hover:bg-white/[0.05]"
                  style={{ background: "oklch(0.12 0.010 240)", border: "1px solid oklch(0.78 0.17 90 / 0.30)", color: "oklch(0.78 0.17 90)" }}
                >
                  <Send size={15} />
                  Send to Review Queue
                </button>
                <button
                  className="flex items-center gap-2 px-5 py-2.5 rounded-xl text-sm font-medium transition-all hover:bg-white/[0.05] ml-auto"
                  style={{ background: "oklch(0.12 0.010 240)", border: "1px solid oklch(1 0 0 / 0.08)", color: "oklch(0.55 0.008 240)" }}
                  onClick={() => navigate("/templates/class")}
                >
                  <X size={15} />
                  Cancel
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Navigation */}
        {step < 5 && (
          <div className="flex items-center justify-between mt-8 pt-6 border-t" style={{ borderColor: "oklch(1 0 0 / 0.06)" }}>
            <button
              onClick={() => step > 1 && setStep(step - 1)}
              className="flex items-center gap-2 px-5 py-2.5 rounded-xl text-sm font-medium transition-all"
              style={{
                background: "oklch(0.12 0.010 240)",
                border: "1px solid oklch(1 0 0 / 0.08)",
                color: step === 1 ? "oklch(0.35 0.008 240)" : "oklch(0.75 0.005 240)",
                opacity: step === 1 ? 0.5 : 1,
                cursor: step === 1 ? "not-allowed" : "pointer",
              }}
              disabled={step === 1}
            >
              <ArrowLeft size={15} />
              Back
            </button>
            <button
              onClick={() => canProceed() && setStep(step + 1)}
              className="btn-teal flex items-center gap-2 px-6 py-2.5 rounded-xl text-sm"
              style={{ opacity: canProceed() ? 1 : 0.5, cursor: canProceed() ? "pointer" : "not-allowed" }}
            >
              Continue
              <ArrowRight size={15} />
            </button>
          </div>
        )}
      </div>
    </Layout>
  );
}
