// Redirect root to Templates
import { Redirect } from "wouter";
export default function Home() {
  return <Redirect to="/templates" />;
}
