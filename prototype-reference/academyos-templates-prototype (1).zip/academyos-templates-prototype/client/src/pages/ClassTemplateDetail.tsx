/**
 * Screen 4: Class Template Detail / Editor
 * Full editor with blocks, curriculum connections, coach briefing
 */

import { useLocation } from "wouter";
import Layout from "@/components/Layout";
import {
  ArrowLeft,
  Eye,
  Sparkles,
  Save,
  Send,
  GripVertical,
  Edit3,
  Target,
  BookOpen,
  ChevronRight,
  Clock,
  Layers,
  Shield,
  Info,
  ArrowRight,
} from "lucide-react";

const BLOCKS = [
  {
    id: 1,
    name: "Warm-Up / Athletic Prep",
    duration: 10,
    description: "Dynamic movement activation, split step practice, and court awareness exercises.",
    skills: ["Split step timing", "Ready position", "Court movement"],
    competition: "N/A",
    drills: ["Ladder footwork", "Shadow movement"],
    watchFor: "Split step timing, ready position before each ball",
    progression: "Add directional change on coach signal",
    regression: "Reduce speed, focus on form only",
  },
  {
    id: 2,
    name: "Technical Skill Block",
    duration: 20,
    description: "Crosscourt forehand control with movement pressure and recovery.",
    skills: ["Crosscourt control", "Contact point", "Swing path"],
    competition: "Crosscourt rally patterns",
    drills: ["Target feeding — crosscourt", "Crosscourt rally consistency"],
    watchFor: "Contact point in front, full follow-through, recovery step after each shot",
    progression: "Add movement before each ball",
    regression: "Feed from shorter distance, reduce pace",
  },
  {
    id: 3,
    name: "Pattern / Decision Block",
    duration: 20,
    description: "Apply crosscourt skill in structured patterns with directional decisions.",
    skills: ["Rally direction", "Decision-making", "Pattern execution"],
    competition: "Crosscourt → down-the-line patterns",
    drills: ["Wide ball recovery drill", "Direction change rally"],
    watchFor: "Target selection before hitting, recovery after wide balls",
    progression: "Add scoring to patterns",
    regression: "Remove movement, feed from basket",
  },
  {
    id: 4,
    name: "Live Ball / Competition Block",
    duration: 25,
    description: "Open point play with crosscourt pattern emphasis and coach interventions.",
    skills: ["Point construction", "Pattern under pressure"],
    competition: "Live ball points — crosscourt bias",
    drills: ["Live ball points", "Mini-tournament format"],
    watchFor: "Pattern execution under pressure, emotional response to errors",
    progression: "Add serve to start each point",
    regression: "Reduce court size, use shorter scoring",
  },
  {
    id: 5,
    name: "Review / Challenge",
    duration: 5,
    description: "Player self-assessment and coach challenge for next session.",
    skills: ["Self-awareness", "Goal-setting"],
    competition: "N/A",
    drills: ["Player reflection", "Challenge card"],
    watchFor: "Player awareness of own performance patterns",
    progression: "Player sets own challenge",
    regression: "Coach sets specific focus for next session",
  },
];

const CURRICULUM_CONNECTIONS = [
  { from: "Orange Ball 2 Curriculum", to: "Crosscourt Control Skill Need", color: "oklch(0.70 0.18 45)" },
  { from: "Crosscourt Control Skill Need", to: "Wide Ball Recovery Drill", color: "oklch(0.78 0.12 185)" },
  { from: "Wide Ball Recovery Drill", to: "Pattern Block", color: "oklch(0.78 0.12 185)" },
  { from: "Pattern Block", to: "Coach Watch-For: Recovery Step", color: "oklch(0.65 0.20 295)" },
  { from: "Coach Watch-For: Recovery Step", to: "Assessment Gate: Rally Consistency", color: "oklch(0.65 0.17 145)" },
];

export default function ClassTemplateDetail() {
  const [, navigate] = useLocation();

  return (
    <Layout
      donnaPrompt="You're editing this class template. What would you like to change?"
      donnaActions={[
        "Add a block",
        "Add a drill",
        "Adjust duration",
        "Make it easier",
        "Make it harder",
        "Add competition scoring",
        "Add coach watch-fors",
        "Preview impact",
      ]}
    >
      <div className="px-8 py-7 space-y-6">
        {/* Header */}
        <div className="animate-fade-slide-up">
          <button
            onClick={() => navigate("/templates/class")}
            className="flex items-center gap-1.5 text-sm mb-4 transition-colors hover:opacity-80"
            style={{ color: "oklch(0.55 0.008 240)" }}
          >
            <ArrowLeft size={14} />
            Class Templates
          </button>
          <div className="flex items-start justify-between">
            <div>
              <div className="flex items-center gap-2 mb-1">
                <div className="w-2.5 h-2.5 rounded-full" style={{ background: "oklch(0.70 0.18 45)" }} />
                <span className="text-xs font-medium" style={{ color: "oklch(0.55 0.008 240)" }}>
                  Class Template · Connected to Orange Ball 2 curriculum
                </span>
              </div>
              <h1 className="font-display text-2xl font-bold" style={{ color: "oklch(0.93 0.005 240)" }}>
                Orange Ball 2 — Recovery + Crosscourt Patterns
              </h1>
            </div>
            <div className="flex items-center gap-2">
              <button
                onClick={() => navigate("/templates/coach-preview")}
                className="flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-medium transition-all hover:bg-white/[0.05]"
                style={{ background: "oklch(0.12 0.010 240)", border: "1px solid oklch(1 0 0 / 0.08)", color: "oklch(0.75 0.005 240)" }}
              >
                <Eye size={14} />
                Coach Preview
              </button>
              <button
                className="flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-medium transition-all hover:bg-white/[0.05]"
                style={{ background: "oklch(0.12 0.010 240)", border: "1px solid oklch(0.78 0.12 185 / 0.25)", color: "oklch(0.78 0.12 185)" }}
              >
                <Sparkles size={14} />
                Ask DONNA to Improve
              </button>
              <button
                className="flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-medium transition-all hover:bg-white/[0.05]"
                style={{ background: "oklch(0.12 0.010 240)", border: "1px solid oklch(1 0 0 / 0.08)", color: "oklch(0.75 0.005 240)" }}
              >
                <Save size={14} />
                Save Draft
              </button>
              <button
                onClick={() => navigate("/templates/impact-preview")}
                className="flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-medium transition-all"
                style={{ background: "oklch(0.78 0.17 90 / 0.10)", border: "1px solid oklch(0.78 0.17 90 / 0.30)", color: "oklch(0.78 0.17 90)" }}
              >
                <Send size={14} />
                Send to Review Queue
              </button>
            </div>
          </div>
        </div>

        {/* Overview */}
        <div
          className="rounded-2xl p-5 animate-fade-slide-up stagger-1"
          style={{ background: "oklch(0.12 0.010 240)", border: "1px solid oklch(1 0 0 / 0.06)" }}
        >
          <h2 className="font-display font-bold text-base mb-4" style={{ color: "oklch(0.85 0.005 240)" }}>
            Template Overview
          </h2>
          <div className="grid grid-cols-6 gap-3">
            {[
              { label: "Level", value: "Orange Ball 2", color: "oklch(0.70 0.18 45)" },
              { label: "Duration", value: "80 min", mono: true },
              { label: "Main Goal", value: "Skill Development" },
              { label: "Pathway", value: "Skill + Competition" },
              { label: "Curriculum", value: "Orange Ball 2" },
              { label: "Status", value: "Ready", badge: "ready" },
            ].map((item, i) => (
              <div key={i} className="px-3 py-2.5 rounded-xl" style={{ background: "oklch(0.09 0.008 240)" }}>
                <p className="text-xs mb-1" style={{ color: "oklch(0.45 0.008 240)" }}>{item.label}</p>
                {item.badge ? (
                  <span className={`badge-${item.badge} text-xs px-2 py-0.5 rounded-full font-medium`}>{item.value}</span>
                ) : (
                  <p
                    className={`text-sm font-medium ${item.mono ? "font-mono-data" : ""}`}
                    style={{ color: item.color || "oklch(0.85 0.005 240)" }}
                  >
                    {item.value}
                  </p>
                )}
              </div>
            ))}
          </div>
        </div>

        {/* Session Blocks */}
        <div className="animate-fade-slide-up stagger-2">
          <h2 className="font-display font-bold text-base mb-4" style={{ color: "oklch(0.85 0.005 240)" }}>
            Session Blocks
          </h2>
          <div className="space-y-3">
            {BLOCKS.map((block, i) => (
              <div
                key={block.id}
                className="rounded-2xl overflow-hidden"
                style={{ background: "oklch(0.12 0.010 240)", border: "1px solid oklch(1 0 0 / 0.06)" }}
              >
                {/* Block header */}
                <div className="flex items-center gap-3 px-5 py-4">
                  <div className="drag-handle">
                    <GripVertical size={16} />
                  </div>
                  <div
                    className="w-7 h-7 rounded-lg flex items-center justify-center text-xs font-bold font-display"
                    style={{ background: "oklch(0.78 0.12 185 / 0.12)", color: "oklch(0.78 0.12 185)" }}
                  >
                    {i + 1}
                  </div>
                  <div className="flex-1">
                    <h3 className="font-display font-bold text-sm" style={{ color: "oklch(0.90 0.005 240)" }}>
                      {block.name}
                    </h3>
                    <p className="text-xs mt-0.5" style={{ color: "oklch(0.55 0.008 240)" }}>
                      {block.description}
                    </p>
                  </div>
                  <div className="flex items-center gap-2">
                    <span
                      className="text-xs font-mono-data px-2.5 py-1 rounded-lg"
                      style={{ background: "oklch(0.78 0.12 185 / 0.10)", color: "oklch(0.78 0.12 185)" }}
                    >
                      <Clock size={11} className="inline mr-1" />
                      {block.duration} min
                    </span>
                    <button className="p-1.5 rounded-lg hover:bg-white/5 transition-colors" style={{ color: "oklch(0.55 0.008 240)" }}>
                      <Edit3 size={13} />
                    </button>
                    <button className="p-1.5 rounded-lg hover:bg-white/5 transition-colors" style={{ color: "oklch(0.78 0.12 185)" }}>
                      <Sparkles size={13} />
                    </button>
                  </div>
                </div>

                {/* Block details */}
                <div
                  className="px-5 pb-4 grid grid-cols-4 gap-3"
                  style={{ borderTop: "1px solid oklch(1 0 0 / 0.05)" }}
                >
                  <div className="pt-3">
                    <p className="text-xs font-medium mb-1.5" style={{ color: "oklch(0.45 0.008 240)" }}>Connected Skills</p>
                    <div className="space-y-1">
                      {block.skills.map((s, j) => (
                        <div key={j} className="flex items-center gap-1.5">
                          <Target size={10} style={{ color: "oklch(0.78 0.12 185)" }} />
                          <span className="text-xs" style={{ color: "oklch(0.65 0.008 240)" }}>{s}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                  <div className="pt-3">
                    <p className="text-xs font-medium mb-1.5" style={{ color: "oklch(0.45 0.008 240)" }}>Drills</p>
                    <div className="space-y-1">
                      {block.drills.map((d, j) => (
                        <div key={j} className="flex items-center gap-1.5">
                          <Layers size={10} style={{ color: "oklch(0.65 0.20 295)" }} />
                          <span className="text-xs" style={{ color: "oklch(0.65 0.008 240)" }}>{d}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                  <div className="pt-3">
                    <p className="text-xs font-medium mb-1.5" style={{ color: "oklch(0.45 0.008 240)" }}>Coach Watch-For</p>
                    <p className="text-xs" style={{ color: "oklch(0.65 0.008 240)" }}>{block.watchFor}</p>
                  </div>
                  <div className="pt-3">
                    <p className="text-xs font-medium mb-1.5" style={{ color: "oklch(0.45 0.008 240)" }}>Progression / Regression</p>
                    <div className="space-y-1">
                      <div className="flex items-center gap-1.5">
                        <span className="text-xs px-1.5 py-0.5 rounded" style={{ background: "oklch(0.65 0.17 145 / 0.15)", color: "oklch(0.65 0.17 145)" }}>+</span>
                        <span className="text-xs" style={{ color: "oklch(0.65 0.008 240)" }}>{block.progression}</span>
                      </div>
                      <div className="flex items-center gap-1.5">
                        <span className="text-xs px-1.5 py-0.5 rounded" style={{ background: "oklch(0.62 0.22 25 / 0.15)", color: "oklch(0.62 0.22 25)" }}>−</span>
                        <span className="text-xs" style={{ color: "oklch(0.65 0.008 240)" }}>{block.regression}</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Curriculum Connections */}
        <div
          className="rounded-2xl p-5 animate-fade-slide-up stagger-3"
          style={{ background: "oklch(0.12 0.010 240)", border: "1px solid oklch(1 0 0 / 0.06)" }}
        >
          <h2 className="font-display font-bold text-base mb-4" style={{ color: "oklch(0.85 0.005 240)" }}>
            Curriculum Connections
          </h2>
          <div className="flex items-center gap-2 overflow-x-auto pb-2">
            {CURRICULUM_CONNECTIONS.map((conn, i) => (
              <div key={i} className="flex items-center gap-2 shrink-0">
                <div
                  className="px-3 py-2 rounded-xl text-xs font-medium whitespace-nowrap"
                  style={{
                    background: `${conn.color.replace(")", " / 0.10)")}`,
                    color: conn.color,
                    border: `1px solid ${conn.color.replace(")", " / 0.25)")}`,
                  }}
                >
                  {conn.from}
                </div>
                {i < CURRICULUM_CONNECTIONS.length - 1 && (
                  <ArrowRight size={14} style={{ color: "oklch(0.35 0.008 240)" }} />
                )}
              </div>
            ))}
            <div
              className="px-3 py-2 rounded-xl text-xs font-medium whitespace-nowrap shrink-0"
              style={{
                background: "oklch(0.65 0.17 145 / 0.10)",
                color: "oklch(0.65 0.17 145)",
                border: "1px solid oklch(0.65 0.17 145 / 0.25)",
              }}
            >
              Assessment Gate: Rally Consistency
            </div>
          </div>
        </div>

        {/* Coach Briefing */}
        <div
          className="rounded-2xl p-5 animate-fade-slide-up stagger-4"
          style={{ background: "oklch(0.12 0.010 240)", border: "1px solid oklch(1 0 0 / 0.06)" }}
        >
          <div className="flex items-center gap-2 mb-3">
            <BookOpen size={16} style={{ color: "oklch(0.78 0.12 185)" }} />
            <h2 className="font-display font-bold text-base" style={{ color: "oklch(0.85 0.005 240)" }}>
              Coach Briefing
            </h2>
          </div>
          <div
            className="rounded-xl px-4 py-4"
            style={{ background: "oklch(0.09 0.008 240)", border: "1px solid oklch(1 0 0 / 0.06)" }}
          >
            <p className="text-sm leading-relaxed italic" style={{ color: "oklch(0.75 0.005 240)" }}>
              "Today's focus is recovery after wide balls and building crosscourt control under movement pressure. Players should feel the connection between their recovery step and their ability to control direction. Watch for players who skip the recovery step — this is the key technical habit for this level."
            </p>
          </div>
        </div>

        {/* Review Safety */}
        <div
          className="rounded-2xl p-5 animate-fade-slide-up stagger-5"
          style={{ background: "oklch(0.65 0.17 145 / 0.05)", border: "1px solid oklch(0.65 0.17 145 / 0.15)" }}
        >
          <div className="flex items-center gap-2 mb-3">
            <Shield size={16} style={{ color: "oklch(0.65 0.17 145)" }} />
            <h2 className="font-display font-bold text-base" style={{ color: "oklch(0.65 0.17 145)" }}>
              Review &amp; Draft Safety
            </h2>
          </div>
          <div className="grid grid-cols-3 gap-3">
            {[
              "Draft only — not yet active",
              "Director approval required before use",
              "Does not change master curriculum",
            ].map((note, i) => (
              <div key={i} className="flex items-center gap-2">
                <Info size={13} style={{ color: "oklch(0.65 0.17 145)" }} />
                <span className="text-sm" style={{ color: "oklch(0.65 0.008 240)" }}>{note}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </Layout>
  );
}
