/**
 * Screen 8: Template Coach Preview
 * Low cognitive load, big readable blocks, on-court use view
 */

import { useLocation } from "wouter";
import Layout from "@/components/Layout";
import {
  ArrowLeft,
  Clock,
  Eye,
  Sparkles,
  ChevronRight,
  CheckCircle2,
  Users,
  MessageSquare,
  Play,
  Edit3,
  TrendingUp,
  TrendingDown,
  Flag,
} from "lucide-react";

const BLOCKS = [
  {
    id: 1,
    name: "Warm-Up / Athletic Prep",
    duration: 10,
    focus: "Movement activation",
    drills: ["Ladder footwork", "Shadow movement", "Split step practice"],
    watchFor: "Split step timing and ready position",
    color: "oklch(0.78 0.12 185)",
  },
  {
    id: 2,
    name: "Technical Skill Block",
    duration: 20,
    focus: "Crosscourt forehand control",
    drills: ["Target feeding — crosscourt", "Crosscourt rally consistency"],
    watchFor: "Contact point in front, full follow-through, recovery step",
    color: "oklch(0.65 0.20 295)",
  },
  {
    id: 3,
    name: "Pattern / Decision Block",
    duration: 20,
    focus: "Direction control under movement",
    drills: ["Wide ball recovery drill", "Direction change rally"],
    watchFor: "Target selection before hitting, recovery after wide balls",
    color: "oklch(0.70 0.18 45)",
  },
  {
    id: 4,
    name: "Live Ball / Competition Block",
    duration: 25,
    focus: "Point play with crosscourt bias",
    drills: ["Live ball points", "Mini-tournament format"],
    watchFor: "Pattern execution under pressure, emotional response",
    color: "oklch(0.62 0.22 25)",
  },
  {
    id: 5,
    name: "Review / Challenge",
    duration: 5,
    focus: "Self-assessment and next challenge",
    drills: ["Player reflection", "Challenge card"],
    watchFor: "Player awareness of own performance patterns",
    color: "oklch(0.65 0.17 145)",
  },
];

export default function CoachPreview() {
  const [, navigate] = useLocation();

  return (
    <Layout
      donnaPrompt="Want me to help you run or adapt this session? I can modify blocks in real time, capture notes, or suggest progressions."
      donnaActions={[
        "Modify for today's group",
        "Make it easier",
        "Make it harder",
        "Add progression to block 2",
        "Capture session note",
        "Wrap up this session",
      ]}
    >
      <div className="px-8 py-7 space-y-6">
        {/* Header */}
        <div className="animate-fade-slide-up">
          <button
            onClick={() => navigate("/templates/class/1")}
            className="flex items-center gap-1.5 text-sm mb-4 transition-colors hover:opacity-80"
            style={{ color: "oklch(0.55 0.008 240)" }}
          >
            <ArrowLeft size={14} />
            Template Editor
          </button>
          <div className="flex items-start justify-between">
            <div>
              <div className="flex items-center gap-2 mb-1">
                <Eye size={14} style={{ color: "oklch(0.78 0.12 185)" }} />
                <span className="text-xs font-medium" style={{ color: "oklch(0.55 0.008 240)" }}>
                  Coach Preview · Simple execution view for on-court use
                </span>
              </div>
              <h1 className="font-display text-2xl font-bold" style={{ color: "oklch(0.93 0.005 240)" }}>
                Orange Ball 2 — Recovery + Crosscourt Patterns
              </h1>
            </div>
            <div className="flex items-center gap-2">
              <span className="badge-teal text-xs px-3 py-1 rounded-full font-medium">Coach View</span>
              <button
                className="flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-medium"
                style={{ background: "oklch(0.12 0.010 240)", border: "1px solid oklch(1 0 0 / 0.08)", color: "oklch(0.75 0.005 240)" }}
                onClick={() => navigate("/templates/class/1")}
              >
                <Edit3 size={14} />
                Back to Editor
              </button>
            </div>
          </div>
        </div>

        {/* Today's Focus */}
        <div
          className="rounded-2xl p-5 animate-fade-slide-up stagger-1"
          style={{
            background: "linear-gradient(135deg, oklch(0.78 0.12 185 / 0.08), oklch(0.65 0.20 295 / 0.06))",
            border: "1px solid oklch(0.78 0.12 185 / 0.20)",
          }}
        >
          <div className="flex items-center gap-2 mb-2">
            <Flag size={16} style={{ color: "oklch(0.78 0.12 185)" }} />
            <h2 className="font-display font-bold text-base" style={{ color: "oklch(0.78 0.12 185)" }}>
              Today's Focus
            </h2>
          </div>
          <p className="text-base leading-relaxed" style={{ color: "oklch(0.85 0.005 240)" }}>
            Recovery after wide balls and building crosscourt control under movement pressure. Players should feel the connection between their recovery step and their ability to control direction.
          </p>
          <div className="flex items-center gap-4 mt-3">
            <div className="flex items-center gap-1.5">
              <Clock size={13} style={{ color: "oklch(0.55 0.008 240)" }} />
              <span className="text-sm font-mono-data" style={{ color: "oklch(0.65 0.008 240)" }}>80 min total</span>
            </div>
            <div className="flex items-center gap-1.5">
              <Users size={13} style={{ color: "oklch(0.55 0.008 240)" }} />
              <span className="text-sm" style={{ color: "oklch(0.65 0.008 240)" }}>Orange Ball 2 · 6–8 players</span>
            </div>
          </div>
        </div>

        {/* Block Timeline */}
        <div className="animate-fade-slide-up stagger-2">
          <h2 className="font-display font-bold text-base mb-4" style={{ color: "oklch(0.85 0.005 240)" }}>
            Block Timeline
          </h2>
          <div className="space-y-3">
            {BLOCKS.map((block, i) => (
              <div
                key={block.id}
                className="rounded-2xl p-5"
                style={{
                  background: "oklch(0.12 0.010 240)",
                  border: `1px solid ${block.color.replace(")", " / 0.15)")}`,
                  borderLeft: `4px solid ${block.color}`,
                }}
              >
                <div className="flex items-start justify-between mb-3">
                  <div className="flex items-center gap-3">
                    <div
                      className="w-8 h-8 rounded-xl flex items-center justify-center text-sm font-bold font-display"
                      style={{ background: `${block.color.replace(")", " / 0.12)")}`, color: block.color }}
                    >
                      {i + 1}
                    </div>
                    <div>
                      <h3 className="font-display font-bold text-base" style={{ color: "oklch(0.90 0.005 240)" }}>
                        {block.name}
                      </h3>
                      <p className="text-sm" style={{ color: "oklch(0.60 0.008 240)" }}>
                        {block.focus}
                      </p>
                    </div>
                  </div>
                  <span
                    className="text-sm font-mono-data font-bold px-3 py-1 rounded-xl"
                    style={{ background: `${block.color.replace(")", " / 0.10)")}`, color: block.color }}
                  >
                    {block.duration} min
                  </span>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <p className="text-xs font-medium mb-2" style={{ color: "oklch(0.45 0.008 240)" }}>
                      Drills
                    </p>
                    <div className="space-y-1.5">
                      {block.drills.map((drill, j) => (
                        <div key={j} className="flex items-center gap-2">
                          <ChevronRight size={12} style={{ color: block.color }} />
                          <span className="text-sm" style={{ color: "oklch(0.75 0.005 240)" }}>{drill}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                  <div>
                    <p className="text-xs font-medium mb-2" style={{ color: "oklch(0.45 0.008 240)" }}>
                      Watch For
                    </p>
                    <p className="text-sm" style={{ color: "oklch(0.75 0.005 240)" }}>
                      {block.watchFor}
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-3 mt-3 pt-3" style={{ borderTop: "1px solid oklch(1 0 0 / 0.06)" }}>
                  <button
                    className="flex items-center gap-1.5 text-xs px-2.5 py-1.5 rounded-lg transition-all hover:bg-white/[0.05]"
                    style={{ color: "oklch(0.65 0.17 145)", border: "1px solid oklch(0.65 0.17 145 / 0.20)" }}
                  >
                    <TrendingUp size={11} />
                    Progression
                  </button>
                  <button
                    className="flex items-center gap-1.5 text-xs px-2.5 py-1.5 rounded-lg transition-all hover:bg-white/[0.05]"
                    style={{ color: "oklch(0.62 0.22 25)", border: "1px solid oklch(0.62 0.22 25 / 0.20)" }}
                  >
                    <TrendingDown size={11} />
                    Regression
                  </button>
                  <button
                    className="flex items-center gap-1.5 text-xs px-2.5 py-1.5 rounded-lg transition-all hover:bg-white/[0.05] ml-auto"
                    style={{ color: "oklch(0.78 0.12 185)", border: "1px solid oklch(0.78 0.12 185 / 0.20)" }}
                  >
                    <Sparkles size={11} />
                    Ask DONNA
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Key Watch-Fors */}
        <div
          className="rounded-2xl p-5 animate-fade-slide-up stagger-3"
          style={{ background: "oklch(0.12 0.010 240)", border: "1px solid oklch(1 0 0 / 0.06)" }}
        >
          <h2 className="font-display font-bold text-base mb-4" style={{ color: "oklch(0.85 0.005 240)" }}>
            Key Watch-Fors
          </h2>
          <div className="grid grid-cols-2 gap-3">
            {[
              "Recovery step after every wide ball",
              "Contact point in front of the body",
              "Full follow-through on crosscourt shots",
              "Emotional response to errors — stay calm",
              "Target selection before swinging",
              "Ready position before each ball",
            ].map((wf, i) => (
              <div key={i} className="flex items-start gap-2.5 px-3 py-2.5 rounded-xl" style={{ background: "oklch(0.09 0.008 240)" }}>
                <CheckCircle2 size={14} className="shrink-0 mt-0.5" style={{ color: "oklch(0.78 0.12 185)" }} />
                <span className="text-sm" style={{ color: "oklch(0.75 0.005 240)" }}>{wf}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Player Notes */}
        <div
          className="rounded-2xl p-5 animate-fade-slide-up stagger-4"
          style={{ background: "oklch(0.12 0.010 240)", border: "1px solid oklch(1 0 0 / 0.06)" }}
        >
          <div className="flex items-center gap-2 mb-4">
            <Users size={16} style={{ color: "oklch(0.65 0.20 295)" }} />
            <h2 className="font-display font-bold text-base" style={{ color: "oklch(0.85 0.005 240)" }}>
              Player Notes to Consider
            </h2>
          </div>
          <div className="grid grid-cols-3 gap-3">
            {[
              { player: "Alex M.", note: "Tends to skip recovery step — emphasize this today" },
              { player: "Sam K.", note: "Strong crosscourt, challenge with down-the-line variation" },
              { player: "Jordan T.", note: "Emotional after errors — use calm cues during live ball" },
            ].map((p, i) => (
              <div key={i} className="px-3 py-3 rounded-xl" style={{ background: "oklch(0.09 0.008 240)" }}>
                <p className="text-sm font-medium mb-1" style={{ color: "oklch(0.78 0.12 185)" }}>{p.player}</p>
                <p className="text-xs" style={{ color: "oklch(0.60 0.008 240)" }}>{p.note}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Wrap-Up Prompt */}
        <div
          className="rounded-2xl p-5 animate-fade-slide-up stagger-5"
          style={{ background: "oklch(0.78 0.12 185 / 0.06)", border: "1px solid oklch(0.78 0.12 185 / 0.15)" }}
        >
          <div className="flex items-center gap-2 mb-3">
            <MessageSquare size={16} style={{ color: "oklch(0.78 0.12 185)" }} />
            <h2 className="font-display font-bold text-base" style={{ color: "oklch(0.78 0.12 185)" }}>
              Wrap-Up Prompt
            </h2>
          </div>
          <p className="text-sm mb-4" style={{ color: "oklch(0.75 0.005 240)" }}>
            Ask players: "What was the one thing you focused on most today? Did your recovery step help you control direction?"
          </p>
          <div className="flex items-center gap-3">
            <button
              className="btn-teal flex items-center gap-2 px-4 py-2.5 rounded-xl text-sm"
            >
              <Play size={14} />
              Start Session
            </button>
            <button
              className="flex items-center gap-2 px-4 py-2.5 rounded-xl text-sm font-medium transition-all hover:bg-white/[0.05]"
              style={{ background: "oklch(0.12 0.010 240)", border: "1px solid oklch(1 0 0 / 0.08)", color: "oklch(0.75 0.005 240)" }}
            >
              <MessageSquare size={14} />
              Capture Note
            </button>
          </div>
        </div>
      </div>
    </Layout>
  );
}
