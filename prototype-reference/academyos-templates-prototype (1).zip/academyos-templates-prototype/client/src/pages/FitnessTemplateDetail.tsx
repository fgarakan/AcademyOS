/**
 * Screen 7: Fitness Template Detail / Editor
 * Block-based editor — each block is a focused training unit with exercises, cues,
 * progressions/regressions, and tennis-transfer metadata.
 * Design: Athletic Intelligence Dashboard — DM Sans, dark near-black, teal accent
 */

import { useState } from "react";
import { useLocation } from "wouter";
import Layout from "@/components/Layout";
import {
  ArrowLeft,
  ArrowRight,
  Plus,
  X,
  Save,
  Eye,
  Send,
  Sparkles,
  GripVertical,
  Activity,
  Zap,
  Dumbbell,
  Wind,
  RotateCcw,
  Shield,
  Flame,
  Layers,
  ChevronDown,
  ChevronUp,
  TrendingUp,
  TrendingDown,
  Clock,
  Users,
  BookOpen,
  Edit2,
} from "lucide-react";

const BLOCK_TYPES = [
  { type: "Movement Prep", icon: Activity, color: "oklch(0.78 0.12 185)" },
  { type: "Speed", icon: Zap, color: "oklch(0.78 0.17 90)" },
  { type: "Agility", icon: Activity, color: "oklch(0.70 0.18 45)" },
  { type: "Plyometrics", icon: Flame, color: "oklch(0.62 0.22 25)" },
  { type: "Strength", icon: Dumbbell, color: "oklch(0.62 0.22 25)" },
  { type: "Coordination", icon: Wind, color: "oklch(0.65 0.20 295)" },
  { type: "Mobility", icon: Activity, color: "oklch(0.78 0.12 185)" },
  { type: "Recovery", icon: RotateCcw, color: "oklch(0.65 0.17 145)" },
  { type: "Tennis Transfer Finisher", icon: Layers, color: "oklch(0.78 0.12 185)" },
];

const EXERCISE_SUGGESTIONS: Record<string, string[]> = {
  "Movement Prep": ["Hip 90/90 Stretch", "Ankle Circles + Calf Raises", "Arm Circles", "Leg Swings", "High Knees", "Butt Kicks", "Inchworm"],
  "Speed": ["10m Sprint Starts", "Resisted Sprint Runs", "Wall Drive Drill", "A-Skip + Sprint", "Acceleration Ladder"],
  "Agility": ["Lateral Shuffle + Stick", "5-10-5 Drill", "T-Drill", "Cone Touch Sequence", "Reactive Shuffle", "Pro Agility"],
  "Plyometrics": ["Box Jumps", "Broad Jumps", "Lateral Bounds", "Depth Drops", "Hurdle Hops", "Tuck Jumps"],
  "Strength": ["Resistance Band Hip Abduction", "Single-Leg Squat", "Romanian Deadlift", "Push-Up Variations", "Pallof Press", "Glute Bridge"],
  "Coordination": ["Single-Leg Balance Reach", "Ladder Footwork Patterns", "Ball Toss + Footwork", "Mirror Drill", "Cone Touch Sequence"],
  "Mobility": ["Thoracic Rotation Drill", "Hip Flexor Stretch", "Shoulder Circles", "World's Greatest Stretch", "Pigeon Pose"],
  "Recovery": ["Foam Rolling — Quads + IT Band", "Light Walking", "Breathing Exercises", "Gentle Stretching"],
  "Tennis Transfer Finisher": ["Shadow Footwork", "Split Step Practice", "Quick Feet Ladder", "Court Sprint Patterns"],
};

interface FitnessBlock {
  id: number;
  type: string;
  duration: number;
  exercises: string[];
  cue: string;
  tennisTransfer: string;
  progression: string;
  regression: string;
  color: string;
  icon: React.ElementType;
}

const INITIAL_BLOCKS: FitnessBlock[] = [
  {
    id: 1,
    type: "Movement Prep",
    duration: 8,
    exercises: ["Hip 90/90 Stretch", "Ankle Circles + Calf Raises", "Arm Circles", "Leg Swings"],
    cue: "Full range of motion, controlled tempo, breathe through each movement",
    tennisTransfer: "Court movement, split step timing",
    progression: "Add resistance band to hip stretch",
    regression: "Reduce range, focus on pain-free movement",
    color: "oklch(0.78 0.12 185)",
    icon: Activity,
  },
  {
    id: 2,
    type: "Agility",
    duration: 12,
    exercises: ["Lateral Shuffle + Stick", "5-10-5 Drill", "T-Drill", "Reactive Shuffle"],
    cue: "Low center of gravity, stick on landing, soft knees",
    tennisTransfer: "Court coverage, recovery after wide balls",
    progression: "Add visual cue for direction change",
    regression: "Slow tempo, focus on landing mechanics",
    color: "oklch(0.70 0.18 45)",
    icon: Activity,
  },
  {
    id: 3,
    type: "Strength",
    duration: 15,
    exercises: ["Resistance Band Hip Abduction", "Single-Leg Squat", "Romanian Deadlift", "Pallof Press"],
    cue: "Controlled movement, no compensation, full range",
    tennisTransfer: "Lateral stability, serve power, groundstroke force",
    progression: "Add load or reduce base of support",
    regression: "Bodyweight only, reduce range of motion",
    color: "oklch(0.62 0.22 25)",
    icon: Dumbbell,
  },
  {
    id: 4,
    type: "Tennis Transfer Finisher",
    duration: 5,
    exercises: ["Shadow Footwork", "Split Step Practice", "Quick Feet Ladder"],
    cue: "Light and quick, replicate on-court movement patterns",
    tennisTransfer: "Direct transfer to court movement patterns",
    progression: "Add ball tracking with footwork",
    regression: "Slow down tempo, focus on pattern",
    color: "oklch(0.78 0.12 185)",
    icon: Layers,
  },
];

export default function FitnessTemplateDetail() {
  const [, navigate] = useLocation();
  const [blocks, setBlocks] = useState<FitnessBlock[]>(INITIAL_BLOCKS);
  const [expandedBlock, setExpandedBlock] = useState<number | null>(null);
  const [showAddBlock, setShowAddBlock] = useState(false);
  const [editingName, setEditingName] = useState(false);
  const [templateName, setTemplateName] = useState("Orange Ball 2 — Agility + Strength Block");

  const totalDuration = blocks.reduce((a, b) => a + b.duration, 0);

  const removeBlock = (id: number) => {
    setBlocks((prev) => prev.filter((b) => b.id !== id));
    if (expandedBlock === id) setExpandedBlock(null);
  };

  const updateBlockDuration = (id: number, duration: number) => {
    setBlocks((prev) => prev.map((b) => (b.id === id ? { ...b, duration } : b)));
  };

  const addExercise = (blockId: number, exercise: string) => {
    setBlocks((prev) =>
      prev.map((b) =>
        b.id === blockId && !b.exercises.includes(exercise)
          ? { ...b, exercises: [...b.exercises, exercise] }
          : b
      )
    );
  };

  const removeExercise = (blockId: number, index: number) => {
    setBlocks((prev) =>
      prev.map((b) =>
        b.id === blockId ? { ...b, exercises: b.exercises.filter((_, i) => i !== index) } : b
      )
    );
  };

  const addBlock = (blockType: typeof BLOCK_TYPES[0]) => {
    const suggestions = EXERCISE_SUGGESTIONS[blockType.type] || [];
    const newBlock: FitnessBlock = {
      id: Date.now(),
      type: blockType.type,
      duration: 10,
      exercises: suggestions.slice(0, 3),
      cue: "Coach cue — edit to match your session focus",
      tennisTransfer: "Tennis transfer — connect to on-court skill",
      progression: "Increase difficulty or load",
      regression: "Reduce intensity or range",
      color: blockType.color,
      icon: blockType.icon,
    };
    setBlocks((prev) => [...prev, newBlock]);
    setShowAddBlock(false);
    setExpandedBlock(newBlock.id);
  };

  return (
    <Layout
      donnaPrompt="I can improve this fitness template based on your players' current physical development stage. Want me to suggest block adjustments or add a missing block type?"
      donnaActions={[
        "Ask DONNA to Improve",
        "Add a mobility block",
        "Adjust for post-tournament recovery",
        "Make session shorter",
        "Add tennis transfer finisher",
        "Send to Review Queue",
      ]}
    >
      <div className="px-8 py-7">
        {/* Header */}
        <div className="mb-6 animate-fade-slide-up">
          <button
            onClick={() => navigate("/templates/fitness")}
            className="flex items-center gap-1.5 text-sm mb-4 transition-colors hover:opacity-80"
            style={{ color: "oklch(0.55 0.008 240)" }}
          >
            <ArrowLeft size={14} />
            Fitness Templates
          </button>

          <div className="flex items-start justify-between gap-4">
            <div className="flex-1 min-w-0">
              {editingName ? (
                <input
                  autoFocus
                  type="text"
                  value={templateName}
                  onChange={(e) => setTemplateName(e.target.value)}
                  onBlur={() => setEditingName(false)}
                  onKeyDown={(e) => e.key === "Enter" && setEditingName(false)}
                  className="font-display text-3xl font-bold bg-transparent outline-none w-full"
                  style={{ color: "oklch(0.93 0.005 240)", borderBottom: "1px solid oklch(0.78 0.12 185 / 0.40)" }}
                />
              ) : (
                <div className="flex items-center gap-3 group">
                  <h1 className="font-display text-3xl font-bold" style={{ color: "oklch(0.93 0.005 240)" }}>
                    {templateName}
                  </h1>
                  <button
                    onClick={() => setEditingName(true)}
                    className="opacity-0 group-hover:opacity-100 transition-opacity p-1.5 rounded-lg hover:bg-white/5"
                    style={{ color: "oklch(0.55 0.008 240)" }}
                  >
                    <Edit2 size={14} />
                  </button>
                </div>
              )}
              <div className="flex items-center gap-3 mt-2">
                <span
                  className="text-xs px-2.5 py-1 rounded-full font-medium"
                  style={{ background: "oklch(0.70 0.18 45 / 0.12)", color: "oklch(0.70 0.18 45)", border: "1px solid oklch(0.70 0.18 45 / 0.25)" }}
                >
                  Orange Ball 2
                </span>
                <span
                  className="text-xs px-2.5 py-1 rounded-full font-medium"
                  style={{ background: "oklch(0.78 0.17 90 / 0.12)", color: "oklch(0.78 0.17 90)", border: "1px solid oklch(0.78 0.17 90 / 0.25)" }}
                >
                  Needs Review
                </span>
                <span className="text-xs flex items-center gap-1" style={{ color: "oklch(0.45 0.008 240)" }}>
                  <Clock size={11} />
                  Updated 2d ago
                </span>
                <span className="text-xs flex items-center gap-1" style={{ color: "oklch(0.45 0.008 240)" }}>
                  <Users size={11} />
                  12 players
                </span>
              </div>
            </div>

            <div className="flex items-center gap-2 shrink-0 flex-wrap justify-end">
              <button
                onClick={() => navigate("/templates/impact-preview")}
                className="flex items-center gap-2 px-4 py-2.5 rounded-xl text-sm font-medium transition-all hover:bg-white/[0.05]"
                style={{ background: "oklch(0.12 0.010 240)", border: "1px solid oklch(1 0 0 / 0.08)", color: "oklch(0.75 0.005 240)" }}
              >
                <Eye size={14} />
                Impact Preview
              </button>
              <button
                onClick={() => navigate("/templates/coach-preview")}
                className="flex items-center gap-2 px-4 py-2.5 rounded-xl text-sm font-medium transition-all hover:bg-white/[0.05]"
                style={{ background: "oklch(0.12 0.010 240)", border: "1px solid oklch(1 0 0 / 0.08)", color: "oklch(0.75 0.005 240)" }}
              >
                <Eye size={14} />
                Coach Preview
              </button>
              <button
                className="flex items-center gap-2 px-4 py-2.5 rounded-xl text-sm font-medium transition-all"
                style={{ background: "oklch(0.78 0.12 185 / 0.10)", border: "1px solid oklch(0.78 0.12 185 / 0.25)", color: "oklch(0.78 0.12 185)" }}
              >
                <Sparkles size={14} />
                Ask DONNA to Improve
              </button>
              <button
                className="flex items-center gap-2 px-4 py-2.5 rounded-xl text-sm font-medium transition-all"
                style={{ background: "oklch(0.65 0.20 295 / 0.10)", border: "1px solid oklch(0.65 0.20 295 / 0.25)", color: "oklch(0.65 0.20 295)" }}
              >
                <Send size={14} />
                Send to Review Queue
              </button>
            </div>
          </div>
        </div>

        {/* Stats bar */}
        <div className="grid grid-cols-4 gap-3 mb-6 animate-fade-slide-up stagger-1">
          {[
            { label: "Total Duration", value: `${totalDuration} min`, icon: Clock, color: "oklch(0.78 0.12 185)" },
            { label: "Blocks", value: `${blocks.length} blocks`, icon: Layers, color: "oklch(0.65 0.20 295)" },
            { label: "Exercises", value: `${blocks.reduce((a, b) => a + b.exercises.length, 0)} total`, icon: Dumbbell, color: "oklch(0.70 0.18 45)" },
            { label: "Players", value: "12 assigned", icon: Users, color: "oklch(0.65 0.17 145)" },
          ].map((stat, i) => {
            const Icon = stat.icon;
            return (
              <div
                key={i}
                className="rounded-xl px-4 py-3 flex items-center gap-3"
                style={{ background: "oklch(0.12 0.010 240)", border: "1px solid oklch(1 0 0 / 0.06)" }}
              >
                <Icon size={16} style={{ color: stat.color }} />
                <div>
                  <p className="text-xs" style={{ color: "oklch(0.45 0.008 240)" }}>{stat.label}</p>
                  <p className="font-display font-bold text-sm" style={{ color: "oklch(0.85 0.005 240)" }}>{stat.value}</p>
                </div>
              </div>
            );
          })}
        </div>

        {/* Block Editor */}
        <div className="space-y-3 animate-fade-slide-up stagger-2">
          <div className="flex items-center justify-between mb-1">
            <h2 className="font-display font-bold text-base" style={{ color: "oklch(0.85 0.005 240)" }}>
              Block Sequence
            </h2>
            <button
              onClick={() => setShowAddBlock(!showAddBlock)}
              className="flex items-center gap-1.5 text-sm px-3 py-1.5 rounded-lg transition-all"
              style={{
                background: showAddBlock ? "oklch(0.78 0.12 185 / 0.12)" : "oklch(0.12 0.010 240)",
                border: `1px solid ${showAddBlock ? "oklch(0.78 0.12 185 / 0.30)" : "oklch(1 0 0 / 0.08)"}`,
                color: showAddBlock ? "oklch(0.78 0.12 185)" : "oklch(0.65 0.008 240)",
              }}
            >
              <Plus size={13} />
              Add Block
            </button>
          </div>

          {/* Add block palette */}
          {showAddBlock && (
            <div
              className="rounded-2xl p-4 mb-2"
              style={{ background: "oklch(0.12 0.010 240)", border: "1px solid oklch(0.78 0.12 185 / 0.20)" }}
            >
              <p className="text-xs font-medium mb-3" style={{ color: "oklch(0.45 0.008 240)", letterSpacing: "0.06em", textTransform: "uppercase" }}>
                Select Block Type
              </p>
              <div className="grid grid-cols-3 gap-2">
                {BLOCK_TYPES.map((bt) => {
                  const Icon = bt.icon;
                  return (
                    <button
                      key={bt.type}
                      onClick={() => addBlock(bt)}
                      className="flex items-center gap-2.5 px-3 py-2.5 rounded-xl text-left transition-all hover:bg-white/[0.04]"
                      style={{ background: "oklch(0.09 0.008 240)", border: `1px solid ${bt.color.replace(")", " / 0.15)")}` }}
                    >
                      <div
                        className="w-7 h-7 rounded-lg flex items-center justify-center shrink-0"
                        style={{ background: `${bt.color.replace(")", " / 0.12)")}` }}
                      >
                        <Icon size={13} style={{ color: bt.color }} />
                      </div>
                      <span className="text-sm font-medium" style={{ color: "oklch(0.80 0.005 240)" }}>{bt.type}</span>
                    </button>
                  );
                })}
              </div>
            </div>
          )}

          {/* Block cards */}
          {blocks.map((block, i) => {
            const Icon = block.icon;
            const isExpanded = expandedBlock === block.id;
            const suggestions = (EXERCISE_SUGGESTIONS[block.type] || []).filter(
              (ex) => !block.exercises.includes(ex)
            );

            return (
              <div
                key={block.id}
                className="rounded-2xl overflow-hidden transition-all"
                style={{
                  background: "oklch(0.12 0.010 240)",
                  border: `1px solid ${block.color.replace(")", " / 0.18)")}`,
                  borderLeft: `4px solid ${block.color}`,
                }}
              >
                {/* Block header */}
                <div className="flex items-center gap-3 px-5 py-4">
                  <GripVertical size={15} style={{ color: "oklch(0.30 0.008 240)" }} className="cursor-grab" />
                  <div
                    className="w-8 h-8 rounded-xl flex items-center justify-center shrink-0 font-display font-bold text-sm"
                    style={{ background: `${block.color.replace(")", " / 0.12)")}`, color: block.color }}
                  >
                    {i + 1}
                  </div>
                  <button
                    className="flex-1 text-left"
                    onClick={() => setExpandedBlock(isExpanded ? null : block.id)}
                  >
                    <p className="font-display font-bold text-base" style={{ color: "oklch(0.90 0.005 240)" }}>
                      {block.type}
                    </p>
                    <p className="text-xs mt-0.5" style={{ color: "oklch(0.50 0.008 240)" }}>
                      {block.exercises.length} exercises · {block.tennisTransfer}
                    </p>
                  </button>

                  {/* Duration chips */}
                  <div className="flex items-center gap-1">
                    {[5, 8, 10, 12, 15, 20].map((d) => (
                      <button
                        key={d}
                        onClick={() => updateBlockDuration(block.id, d)}
                        className="text-xs px-2 py-1 rounded-lg transition-all"
                        style={
                          block.duration === d
                            ? { background: block.color.replace(")", " / 0.18)"), color: block.color, border: `1px solid ${block.color.replace(")", " / 0.35)")}` }
                            : { background: "oklch(0.09 0.008 240)", color: "oklch(0.40 0.008 240)", border: "1px solid oklch(1 0 0 / 0.08)" }
                        }
                      >
                        {d}m
                      </button>
                    ))}
                  </div>

                  <button
                    onClick={() => setExpandedBlock(isExpanded ? null : block.id)}
                    className="p-1.5 rounded-lg transition-colors hover:bg-white/5"
                    style={{ color: "oklch(0.45 0.008 240)" }}
                  >
                    {isExpanded ? <ChevronUp size={15} /> : <ChevronDown size={15} />}
                  </button>
                  <button
                    onClick={() => removeBlock(block.id)}
                    className="p-1.5 rounded-lg transition-colors hover:bg-white/5"
                    style={{ color: "oklch(0.45 0.008 240)" }}
                  >
                    <X size={15} />
                  </button>
                </div>

                {/* Expanded block content */}
                {isExpanded && (
                  <div
                    className="px-5 pb-5 space-y-4 border-t"
                    style={{ borderColor: "oklch(1 0 0 / 0.06)" }}
                  >
                    <div className="pt-4 grid grid-cols-2 gap-5">
                      {/* Exercises column */}
                      <div>
                        <p className="text-xs font-medium mb-2" style={{ color: "oklch(0.45 0.008 240)", letterSpacing: "0.05em", textTransform: "uppercase" }}>
                          Exercises
                        </p>
                        <div className="space-y-1.5 mb-3">
                          {block.exercises.map((ex, j) => (
                            <div
                              key={j}
                              className="flex items-center gap-2 px-3 py-2 rounded-lg"
                              style={{ background: "oklch(0.09 0.008 240)" }}
                            >
                              <div className="w-1.5 h-1.5 rounded-full shrink-0" style={{ background: block.color }} />
                              <span className="text-sm flex-1" style={{ color: "oklch(0.78 0.005 240)" }}>{ex}</span>
                              <button
                                onClick={() => removeExercise(block.id, j)}
                                className="p-0.5 rounded transition-colors hover:bg-white/5"
                                style={{ color: "oklch(0.38 0.008 240)" }}
                              >
                                <X size={11} />
                              </button>
                            </div>
                          ))}
                        </div>
                        {suggestions.length > 0 && (
                          <div>
                            <p className="text-xs mb-1.5" style={{ color: "oklch(0.38 0.008 240)" }}>
                              + Add exercise
                            </p>
                            <div className="flex flex-wrap gap-1.5">
                              {suggestions.slice(0, 4).map((ex) => (
                                <button
                                  key={ex}
                                  onClick={() => addExercise(block.id, ex)}
                                  className="text-xs px-2.5 py-1 rounded-lg transition-all hover:bg-white/[0.05]"
                                  style={{
                                    background: `${block.color.replace(")", " / 0.06)")}`,
                                    border: `1px solid ${block.color.replace(")", " / 0.20)")}`,
                                    color: block.color,
                                  }}
                                >
                                  + {ex}
                                </button>
                              ))}
                            </div>
                          </div>
                        )}
                      </div>

                      {/* Metadata column */}
                      <div className="space-y-3">
                        <div>
                          <p className="text-xs font-medium mb-1.5" style={{ color: "oklch(0.45 0.008 240)", letterSpacing: "0.05em", textTransform: "uppercase" }}>
                            Coach Cue
                          </p>
                          <p
                            className="text-sm italic px-3 py-2.5 rounded-lg"
                            style={{ background: "oklch(0.09 0.008 240)", color: "oklch(0.65 0.005 240)", border: "1px solid oklch(1 0 0 / 0.06)" }}
                          >
                            "{block.cue}"
                          </p>
                        </div>

                        <div>
                          <p className="text-xs font-medium mb-1.5" style={{ color: "oklch(0.45 0.008 240)", letterSpacing: "0.05em", textTransform: "uppercase" }}>
                            Tennis Transfer
                          </p>
                          <div
                            className="flex items-start gap-2 px-3 py-2.5 rounded-lg"
                            style={{ background: "oklch(0.78 0.12 185 / 0.06)", border: "1px solid oklch(0.78 0.12 185 / 0.15)" }}
                          >
                            <BookOpen size={13} className="shrink-0 mt-0.5" style={{ color: "oklch(0.78 0.12 185)" }} />
                            <p className="text-sm" style={{ color: "oklch(0.70 0.005 240)" }}>{block.tennisTransfer}</p>
                          </div>
                        </div>

                        <div className="grid grid-cols-2 gap-2">
                          <div>
                            <p className="text-xs font-medium mb-1" style={{ color: "oklch(0.65 0.17 145)", letterSpacing: "0.04em", textTransform: "uppercase" }}>
                              Progression
                            </p>
                            <div
                              className="flex items-start gap-1.5 px-2.5 py-2 rounded-lg"
                              style={{ background: "oklch(0.65 0.17 145 / 0.06)", border: "1px solid oklch(0.65 0.17 145 / 0.15)" }}
                            >
                              <TrendingUp size={11} className="shrink-0 mt-0.5" style={{ color: "oklch(0.65 0.17 145)" }} />
                              <p className="text-xs" style={{ color: "oklch(0.60 0.005 240)" }}>{block.progression}</p>
                            </div>
                          </div>
                          <div>
                            <p className="text-xs font-medium mb-1" style={{ color: "oklch(0.62 0.22 25)", letterSpacing: "0.04em", textTransform: "uppercase" }}>
                              Regression
                            </p>
                            <div
                              className="flex items-start gap-1.5 px-2.5 py-2 rounded-lg"
                              style={{ background: "oklch(0.62 0.22 25 / 0.06)", border: "1px solid oklch(0.62 0.22 25 / 0.15)" }}
                            >
                              <TrendingDown size={11} className="shrink-0 mt-0.5" style={{ color: "oklch(0.62 0.22 25)" }} />
                              <p className="text-xs" style={{ color: "oklch(0.60 0.005 240)" }}>{block.regression}</p>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>

                    {/* DONNA suggestion row */}
                    <div
                      className="flex items-center gap-3 pt-3 border-t"
                      style={{ borderColor: "oklch(1 0 0 / 0.06)" }}
                    >
                      <button
                        className="flex items-center gap-1.5 text-xs px-3 py-1.5 rounded-lg transition-all hover:bg-white/[0.05]"
                        style={{ color: "oklch(0.78 0.12 185)", border: "1px solid oklch(0.78 0.12 185 / 0.20)" }}
                      >
                        <Sparkles size={11} />
                        Ask DONNA to improve this block
                      </button>
                      <button
                        className="flex items-center gap-1.5 text-xs px-3 py-1.5 rounded-lg transition-all hover:bg-white/[0.05]"
                        style={{ color: "oklch(0.65 0.17 145)", border: "1px solid oklch(0.65 0.17 145 / 0.20)" }}
                      >
                        <TrendingUp size={11} />
                        Apply Progression
                      </button>
                      <button
                        className="flex items-center gap-1.5 text-xs px-3 py-1.5 rounded-lg transition-all hover:bg-white/[0.05]"
                        style={{ color: "oklch(0.62 0.22 25)", border: "1px solid oklch(0.62 0.22 25 / 0.20)" }}
                      >
                        <TrendingDown size={11} />
                        Apply Regression
                      </button>
                    </div>
                  </div>
                )}
              </div>
            );
          })}

          {/* Add block CTA */}
          <button
            onClick={() => setShowAddBlock(true)}
            className="w-full flex items-center justify-center gap-2 py-3.5 rounded-2xl text-sm font-medium transition-all hover:bg-white/[0.03]"
            style={{
              background: "oklch(0.12 0.010 240)",
              border: "1px dashed oklch(1 0 0 / 0.12)",
              color: "oklch(0.50 0.008 240)",
            }}
          >
            <Plus size={14} />
            Add Another Block
          </button>
        </div>

        {/* Curriculum pathway chain */}
        <div
          className="rounded-2xl p-5 mt-6 animate-fade-slide-up stagger-3"
          style={{ background: "oklch(0.12 0.010 240)", border: "1px solid oklch(1 0 0 / 0.06)" }}
        >
          <h3 className="font-display font-bold text-sm mb-3" style={{ color: "oklch(0.75 0.005 240)" }}>
            Tennis Transfer Chain
          </h3>
          <div className="flex items-center gap-2 overflow-x-auto pb-1">
            {blocks.map((block, i) => (
              <div key={block.id} className="flex items-center gap-2 shrink-0">
                <div
                  className="px-3 py-1.5 rounded-lg text-xs font-medium whitespace-nowrap"
                  style={{ background: `${block.color.replace(")", " / 0.10)")}`, color: block.color, border: `1px solid ${block.color.replace(")", " / 0.22)")}` }}
                >
                  {block.type}
                </div>
                {i < blocks.length - 1 && (
                  <ArrowRight size={13} style={{ color: "oklch(0.35 0.008 240)" }} />
                )}
              </div>
            ))}
            <ArrowRight size={13} style={{ color: "oklch(0.35 0.008 240)" }} />
            <div
              className="px-3 py-1.5 rounded-lg text-xs font-medium whitespace-nowrap shrink-0"
              style={{ background: "oklch(0.65 0.17 145 / 0.10)", color: "oklch(0.65 0.17 145)", border: "1px solid oklch(0.65 0.17 145 / 0.25)" }}
            >
              On-Court Performance
            </div>
          </div>
        </div>

        {/* Bottom actions */}
        <div
          className="flex items-center gap-3 mt-6 pt-6 border-t animate-fade-slide-up stagger-4"
          style={{ borderColor: "oklch(1 0 0 / 0.06)" }}
        >
          <button
            className="flex items-center gap-2 px-5 py-2.5 rounded-xl text-sm font-medium transition-all hover:bg-white/[0.05]"
            style={{ background: "oklch(0.12 0.010 240)", border: "1px solid oklch(1 0 0 / 0.08)", color: "oklch(0.75 0.005 240)" }}
          >
            <Save size={15} />
            Save Draft
          </button>
          <button
            onClick={() => navigate("/templates/coach-preview")}
            className="flex items-center gap-2 px-5 py-2.5 rounded-xl text-sm font-medium transition-all hover:bg-white/[0.05]"
            style={{ background: "oklch(0.12 0.010 240)", border: "1px solid oklch(1 0 0 / 0.08)", color: "oklch(0.75 0.005 240)" }}
          >
            <Eye size={15} />
            Coach Preview
          </button>
          <button
            className="flex items-center gap-2 px-5 py-2.5 rounded-xl text-sm font-medium transition-all"
            style={{ background: "oklch(0.78 0.12 185 / 0.10)", border: "1px solid oklch(0.78 0.12 185 / 0.25)", color: "oklch(0.78 0.12 185)" }}
          >
            <Sparkles size={15} />
            Ask DONNA to Improve
          </button>
          <button
            className="flex items-center gap-2 px-5 py-2.5 rounded-xl text-sm font-medium transition-all"
            style={{ background: "oklch(0.65 0.20 295 / 0.10)", border: "1px solid oklch(0.65 0.20 295 / 0.25)", color: "oklch(0.65 0.20 295)" }}
          >
            <Send size={15} />
            Send to Review Queue
          </button>
        </div>
      </div>
    </Layout>
  );
}
