/**
 * Screen 1: Templates Home
 * Brief: Templates landing with DONNA hero card, 4 action cards, 4 stat cards, 2 category cards
 */

import { useLocation } from "wouter";
import Layout from "@/components/Layout";
import {
  FileStack,
  Dumbbell,
  ClipboardCheck,
  RefreshCw,
  Plus,
  Sparkles,
  ArrowRight,
  Clock,
  ChevronRight,
} from "lucide-react";

const dashboardCards = [
  {
    label: "Class Templates",
    value: "12",
    sub: "4 ready · 6 draft · 2 review",
    icon: FileStack,
    color: "oklch(0.78 0.12 185)",
    bg: "oklch(0.78 0.12 185 / 0.10)",
  },
  {
    label: "Fitness Templates",
    value: "8",
    sub: "5 ready · 2 draft · 1 review",
    icon: Dumbbell,
    color: "oklch(0.65 0.20 295)",
    bg: "oklch(0.65 0.20 295 / 0.10)",
  },
  {
    label: "Needs Review",
    value: "3",
    sub: "Awaiting director approval",
    icon: ClipboardCheck,
    color: "oklch(0.78 0.17 90)",
    bg: "oklch(0.78 0.17 90 / 0.10)",
  },
  {
    label: "Recently Updated",
    value: "5",
    sub: "In the last 7 days",
    icon: RefreshCw,
    color: "oklch(0.65 0.17 145)",
    bg: "oklch(0.65 0.17 145 / 0.10)",
  },
];

const recentTemplates = [
  { name: "Orange Ball 2 — Recovery + Crosscourt", type: "Class", level: "Orange", levelColor: "oklch(0.70 0.18 45)", status: "ready", updated: "2 days ago", sessions: 14 },
  { name: "Green Ball 1 — Serve + First Ball", type: "Class", level: "Green", levelColor: "oklch(0.65 0.17 145)", status: "draft", updated: "4 days ago", sessions: 7 },
  { name: "Orange Ball Coordination + Balance", type: "Fitness", level: "Orange", levelColor: "oklch(0.70 0.18 45)", status: "ready", updated: "5 days ago", sessions: 9 },
  { name: "High Performance — Live Ball Pressure", type: "Class", level: "HP", levelColor: "oklch(0.65 0.20 295)", status: "review", updated: "1 week ago", sessions: 22 },
];

const draftTemplates = [
  { name: "Red Ball 1 — Movement + Rally Foundations", type: "Class", level: "Red", levelColor: "oklch(0.62 0.22 25)", progress: 60 },
  { name: "Green Ball First-Step Speed", type: "Fitness", level: "Green", levelColor: "oklch(0.65 0.17 145)", progress: 35 },
  { name: "Yellow Ball Strength Foundation", type: "Fitness", level: "Yellow", levelColor: "oklch(0.78 0.17 90)", progress: 80 },
];

const statusBadge = (status: string) => {
  if (status === "ready") return <span className="badge-ready text-xs px-2 py-0.5 rounded-full font-medium">Ready</span>;
  if (status === "draft") return <span className="badge-draft text-xs px-2 py-0.5 rounded-full font-medium">Draft</span>;
  if (status === "review") return <span className="badge-review text-xs px-2 py-0.5 rounded-full font-medium">Review</span>;
  return null;
};

const DONNA_ACTIONS = [
  "Build a class template from curriculum",
  "Build a fitness template",
  "Improve an existing template",
  "Find missing templates",
  "Create templates for a level",
];

export default function TemplatesHome() {
  const [, navigate] = useLocation();

  return (
    <Layout
      donnaPrompt="What are you trying to build?"
      donnaActions={DONNA_ACTIONS}
    >
      <div className="px-8 py-7 space-y-8">
        {/* Page Header */}
        <div className="animate-fade-slide-up">
          <h1 className="font-display text-3xl font-bold" style={{ color: "oklch(0.93 0.005 240)" }}>
            Templates
          </h1>
          <p className="mt-1 text-sm" style={{ color: "oklch(0.55 0.008 240)" }}>
            Build reusable class and fitness templates powered by your curriculum.
          </p>
        </div>

        {/* DONNA Hero Card */}
        <div
          className="rounded-2xl p-5 animate-fade-slide-up stagger-1 relative overflow-hidden"
          style={{
            background: "linear-gradient(135deg, oklch(0.78 0.12 185 / 0.08), oklch(0.65 0.20 295 / 0.06))",
            border: "1px solid oklch(0.78 0.12 185 / 0.20)",
          }}
        >
          <div className="flex items-start gap-4">
            <div
              className="w-10 h-10 rounded-xl flex items-center justify-center shrink-0"
              style={{ background: "oklch(0.78 0.12 185 / 0.15)" }}
            >
              <Sparkles size={20} style={{ color: "oklch(0.78 0.12 185)" }} />
            </div>
            <div className="flex-1">
              <div className="flex items-center gap-2 mb-1">
                <span className="font-display font-bold text-sm" style={{ color: "oklch(0.78 0.12 185)" }}>DONNA</span>
                <span className="text-xs px-2 py-0.5 rounded-full" style={{ background: "oklch(0.65 0.17 145 / 0.15)", color: "oklch(0.65 0.17 145)", border: "1px solid oklch(0.65 0.17 145 / 0.25)" }}>
                  AI Assistant
                </span>
              </div>
              <p className="text-sm" style={{ color: "oklch(0.78 0.005 240)" }}>
                Your templates turn curriculum into repeatable coaching systems. What would you like to build today?
              </p>
            </div>
          </div>
          <div className="absolute top-0 right-0 w-64 h-64 rounded-full pointer-events-none" style={{ background: "radial-gradient(circle, oklch(0.78 0.12 185 / 0.06) 0%, transparent 70%)", transform: "translate(30%, -30%)" }} />
        </div>

        {/* Four Action Cards */}
        <div className="grid grid-cols-4 gap-3 animate-fade-slide-up stagger-2">
          {[
            { label: "Create Class Template", icon: Plus, action: () => navigate("/templates/class/create") },
            { label: "Create Fitness Template", icon: Dumbbell, action: () => navigate("/templates/fitness/create") },
            { label: "Review Existing Templates", icon: ClipboardCheck, action: () => navigate("/templates/class") },
            { label: "Ask DONNA to Suggest", icon: Sparkles, action: () => navigate("/templates/donna-suggestions") },
          ].map((btn, i) => {
            const Icon = btn.icon;
            return (
              <button
                key={i}
                onClick={btn.action}
                className="flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-medium transition-all hover:scale-[1.02] active:scale-[0.98]"
                style={{ background: "oklch(0.12 0.010 240)", border: "1px solid oklch(1 0 0 / 0.08)", color: "oklch(0.75 0.005 240)" }}
                onMouseEnter={(e) => { (e.currentTarget as HTMLElement).style.borderColor = "oklch(0.78 0.12 185 / 0.30)"; (e.currentTarget as HTMLElement).style.color = "oklch(0.93 0.005 240)"; }}
                onMouseLeave={(e) => { (e.currentTarget as HTMLElement).style.borderColor = "oklch(1 0 0 / 0.08)"; (e.currentTarget as HTMLElement).style.color = "oklch(0.75 0.005 240)"; }}
              >
                <Icon size={16} style={{ color: "oklch(0.78 0.12 185)" }} />
                {btn.label}
              </button>
            );
          })}
        </div>

        {/* Four Stat Cards */}
        <div className="grid grid-cols-4 gap-4 animate-fade-slide-up stagger-3">
          {dashboardCards.map((card, i) => {
            const Icon = card.icon;
            return (
              <div key={i} className="rounded-2xl p-5 card-hover" style={{ background: "oklch(0.12 0.010 240)" }}>
                <div className="flex items-start justify-between mb-4">
                  <div className="w-10 h-10 rounded-xl flex items-center justify-center" style={{ background: card.bg }}>
                    <Icon size={18} style={{ color: card.color }} />
                  </div>
                </div>
                <p className="font-display text-3xl font-bold mb-1" style={{ color: "oklch(0.93 0.005 240)" }}>{card.value}</p>
                <p className="text-sm font-medium mb-1" style={{ color: "oklch(0.75 0.005 240)" }}>{card.label}</p>
                <p className="text-xs" style={{ color: "oklch(0.45 0.008 240)" }}>{card.sub}</p>
              </div>
            );
          })}
        </div>

        {/* Two Large Category Cards */}
        <div className="grid grid-cols-2 gap-5 animate-fade-slide-up stagger-4">
          <div className="rounded-2xl p-6 card-hover relative overflow-hidden" style={{ background: "oklch(0.12 0.010 240)" }}>
            <div className="w-12 h-12 rounded-2xl flex items-center justify-center mb-4" style={{ background: "oklch(0.78 0.12 185 / 0.12)" }}>
              <FileStack size={22} style={{ color: "oklch(0.78 0.12 185)" }} />
            </div>
            <h3 className="font-display text-xl font-bold mb-2" style={{ color: "oklch(0.93 0.005 240)" }}>Class Templates</h3>
            <p className="text-sm mb-5 leading-relaxed" style={{ color: "oklch(0.55 0.008 240)" }}>
              Build tennis session structures from your curriculum, drills, skills, and level goals.
            </p>
            <button onClick={() => navigate("/templates/class")} className="btn-teal flex items-center gap-2 px-5 py-2.5 rounded-xl text-sm font-semibold">
              Open Class Templates <ArrowRight size={15} />
            </button>
            <div className="absolute bottom-0 right-0 w-32 h-32 rounded-full pointer-events-none" style={{ background: "radial-gradient(circle, oklch(0.78 0.12 185 / 0.06) 0%, transparent 70%)", transform: "translate(30%, 30%)" }} />
          </div>

          <div className="rounded-2xl p-6 card-hover relative overflow-hidden" style={{ background: "oklch(0.12 0.010 240)" }}>
            <div className="w-12 h-12 rounded-2xl flex items-center justify-center mb-4" style={{ background: "oklch(0.65 0.20 295 / 0.12)" }}>
              <Dumbbell size={22} style={{ color: "oklch(0.65 0.20 295)" }} />
            </div>
            <h3 className="font-display text-xl font-bold mb-2" style={{ color: "oklch(0.93 0.005 240)" }}>Fitness Templates</h3>
            <p className="text-sm mb-5 leading-relaxed" style={{ color: "oklch(0.55 0.008 240)" }}>
              Build physical training blocks that support mobility, speed, strength, coordination, and tennis transfer.
            </p>
            <button
              onClick={() => navigate("/templates/fitness")}
              className="flex items-center gap-2 px-5 py-2.5 rounded-xl text-sm font-semibold transition-all hover:scale-[1.02] active:scale-[0.98]"
              style={{ background: "oklch(0.65 0.20 295 / 0.12)", color: "oklch(0.65 0.20 295)", border: "1px solid oklch(0.65 0.20 295 / 0.25)" }}
            >
              Open Fitness Templates <ArrowRight size={15} />
            </button>
            <div className="absolute bottom-0 right-0 w-32 h-32 rounded-full pointer-events-none" style={{ background: "radial-gradient(circle, oklch(0.65 0.20 295 / 0.06) 0%, transparent 70%)", transform: "translate(30%, 30%)" }} />
          </div>
        </div>

        {/* Recent + Draft Templates */}
        <div className="grid grid-cols-2 gap-6 animate-fade-slide-up stagger-5">
          <div className="rounded-2xl p-5" style={{ background: "oklch(0.12 0.010 240)", border: "1px solid oklch(1 0 0 / 0.06)" }}>
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-display font-bold text-base" style={{ color: "oklch(0.85 0.005 240)" }}>Recent Templates</h3>
              <button className="text-xs flex items-center gap-1 transition-colors" style={{ color: "oklch(0.78 0.12 185)" }} onClick={() => navigate("/templates/class")}>
                View all <ChevronRight size={12} />
              </button>
            </div>
            <div className="space-y-2.5">
              {recentTemplates.map((t, i) => (
                <div key={i} className="flex items-center gap-3 px-3 py-2.5 rounded-xl cursor-pointer transition-all hover:bg-white/[0.03]" onClick={() => navigate(t.type === "Class" ? "/templates/class/1" : "/templates/fitness/1")}>
                  <div className="w-2 h-2 rounded-full shrink-0" style={{ background: t.levelColor }} />
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium truncate" style={{ color: "oklch(0.80 0.005 240)" }}>{t.name}</p>
                    <div className="flex items-center gap-2 mt-0.5">
                      <span className="text-xs" style={{ color: "oklch(0.45 0.008 240)" }}>{t.type}</span>
                      <span className="text-xs" style={{ color: "oklch(0.35 0.008 240)" }}>·</span>
                      <span className="text-xs flex items-center gap-1" style={{ color: "oklch(0.45 0.008 240)" }}><Clock size={10} />{t.updated}</span>
                    </div>
                  </div>
                  {statusBadge(t.status)}
                </div>
              ))}
            </div>
          </div>

          <div className="rounded-2xl p-5" style={{ background: "oklch(0.12 0.010 240)", border: "1px solid oklch(1 0 0 / 0.06)" }}>
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-display font-bold text-base" style={{ color: "oklch(0.85 0.005 240)" }}>In Progress</h3>
              <span className="badge-draft text-xs px-2 py-0.5 rounded-full font-medium">{draftTemplates.length} drafts</span>
            </div>
            <div className="space-y-3">
              {draftTemplates.map((t, i) => (
                <div key={i} className="px-3 py-3 rounded-xl cursor-pointer transition-all hover:bg-white/[0.03]" onClick={() => navigate(t.type === "Class" ? "/templates/class/1" : "/templates/fitness/1")}>
                  <div className="flex items-center gap-2 mb-2">
                    <div className="w-2 h-2 rounded-full shrink-0" style={{ background: t.levelColor }} />
                    <p className="text-sm font-medium flex-1 truncate" style={{ color: "oklch(0.80 0.005 240)" }}>{t.name}</p>
                    <span className="text-xs font-mono-data" style={{ color: "oklch(0.55 0.008 240)" }}>{t.progress}%</span>
                  </div>
                  <div className="h-1.5 rounded-full overflow-hidden" style={{ background: "oklch(1 0 0 / 0.06)" }}>
                    <div className="h-full rounded-full transition-all" style={{ width: `${t.progress}%`, background: t.levelColor }} />
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </Layout>
  );
}
