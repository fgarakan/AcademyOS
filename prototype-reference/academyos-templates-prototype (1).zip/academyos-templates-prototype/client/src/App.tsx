import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/NotFound";
import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";

// Page imports
import TemplatesHome from "./pages/TemplatesHome";
import ClassTemplatesLibrary from "./pages/ClassTemplatesLibrary";
import CreateClassTemplate from "./pages/CreateClassTemplate";
import ClassTemplateDetail from "./pages/ClassTemplateDetail";
import FitnessTemplatesLibrary from "./pages/FitnessTemplatesLibrary";
import CreateFitnessTemplate from "./pages/CreateFitnessTemplate";
import FitnessTemplateDetail from "./pages/FitnessTemplateDetail";
import CoachPreview from "./pages/CoachPreview";
import TemplateImpactPreview from "./pages/TemplateImpactPreview";
import DonnaSuggestions from "./pages/DonnaSuggestions";

function Router() {
  return (
    <Switch>
      <Route path="/" component={TemplatesHome} />
      <Route path="/templates" component={TemplatesHome} />
      <Route path="/templates/class" component={ClassTemplatesLibrary} />
      <Route path="/templates/class/create" component={CreateClassTemplate} />
      <Route path="/templates/class/:id" component={ClassTemplateDetail} />
      <Route path="/templates/fitness" component={FitnessTemplatesLibrary} />
      <Route path="/templates/fitness/create" component={CreateFitnessTemplate} />
      <Route path="/templates/fitness/:id" component={FitnessTemplateDetail} />
      <Route path="/templates/coach-preview" component={CoachPreview} />
      <Route path="/templates/impact-preview" component={TemplateImpactPreview} />
      <Route path="/templates/donna-suggestions" component={DonnaSuggestions} />
      <Route path="/404" component={NotFound} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider defaultTheme="dark">
        <TooltipProvider>
          <Toaster />
          <Router />
        </TooltipProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;
