/**
 * AcademyOS Layout — Athletic Intelligence Dashboard
 * Fixed 240px sidebar + fluid content + collapsible 340px DONNA panel
 * Design: Dark near-black, teal accent, Syne headings, Inter body
 */

import { useState } from "react";
import { Link, useLocation } from "wouter";
import { toast } from "sonner";
import {
  LayoutDashboard,
  Calendar,
  Users,
  UserCheck,
  CalendarDays,
  ClipboardList,
  Zap,
  BarChart3,
  BookOpen,
  FileStack,
  Settings,
  Rocket,
  Terminal,
  ChevronRight,
  X,
  Send,
  Sparkles,
  Bot,
} from "lucide-react";

const navItems = [
  { label: "Dashboard", icon: LayoutDashboard, path: "/dashboard" },
  { label: "Today's Academy", icon: Calendar, path: "/today" },
  { label: "Players", icon: Users, path: "/players" },
  { label: "Coaches", icon: UserCheck, path: "/coaches" },
  { label: "Sessions", icon: CalendarDays, path: "/sessions" },
  { label: "Review Queue", icon: ClipboardList, path: "/review" },
  { label: "Signals", icon: Zap, path: "/signals" },
  { label: "KPI", icon: BarChart3, path: "/kpi" },
  { label: "Curriculum", icon: BookOpen, path: "/curriculum" },
  { label: "Templates", icon: FileStack, path: "/templates" },
  { label: "Settings", icon: Settings, path: "/settings" },
  { label: "Onboarding", icon: Rocket, path: "/onboarding" },
  { label: "Command Center", icon: Terminal, path: "/command" },
];

const donnaActions = [
  "Build a class template from curriculum",
  "Build a fitness template",
  "Improve an existing template",
  "Find missing templates",
  "Create templates for a level",
];

interface DonnaPanelProps {
  open: boolean;
  onClose: () => void;
  context?: string;
  contextActions?: string[];
  contextPrompt?: string;
}

export function DonnaPanel({
  open,
  onClose,
  context,
  contextActions,
  contextPrompt,
}: DonnaPanelProps) {
  const [input, setInput] = useState("");
  const [messages, setMessages] = useState<{ role: "donna" | "user"; text: string }[]>([
    {
      role: "donna",
      text: contextPrompt || "What are you trying to build?",
    },
  ]);

  const actions = contextActions || donnaActions;

  const handleSend = () => {
    if (!input.trim()) return;
    const userMsg = input.trim();
    setMessages((prev) => [...prev, { role: "user", text: userMsg }]);
    setInput("");
    setTimeout(() => {
      setMessages((prev) => [
        ...prev,
        {
          role: "donna",
          text: "I can build this from your curriculum. Nothing changes until you approve. Let me pull the right skills, drills, and coach watch-fors for you.",
        },
      ]);
    }, 800);
  };

  const handleAction = (action: string) => {
    setMessages((prev) => [
      ...prev,
      { role: "user", text: action },
      {
        role: "donna",
        text: "I can help with that. I'll suggest drills that match this level and connect everything to your curriculum pathways. Nothing changes until you approve.",
      },
    ]);
  };

  if (!open) return null;

  return (
    <div
      className="w-[340px] shrink-0 flex flex-col h-full border-l animate-slide-in-right"
      style={{
        background: "oklch(0.10 0.010 240)",
        borderColor: "oklch(1 0 0 / 0.08)",
      }}
    >
      {/* Header */}
      <div
        className="flex items-center justify-between px-5 py-4 border-b"
        style={{ borderColor: "oklch(1 0 0 / 0.08)" }}
      >
        <div className="flex items-center gap-3">
          <div
            className="w-9 h-9 rounded-xl flex items-center justify-center"
            style={{ background: "oklch(0.78 0.12 185 / 0.15)" }}
          >
            <Bot size={18} style={{ color: "oklch(0.78 0.12 185)" }} />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="font-display font-700 text-sm" style={{ color: "oklch(0.93 0.005 240)" }}>
                DONNA
              </span>
              <span
                className="text-xs px-2 py-0.5 rounded-full font-medium"
                style={{
                  background: "oklch(0.65 0.17 145 / 0.15)",
                  color: "oklch(0.65 0.17 145)",
                  border: "1px solid oklch(0.65 0.17 145 / 0.25)",
                }}
              >
                Active
              </span>
            </div>
            <p className="text-xs" style={{ color: "oklch(0.55 0.008 240)" }}>
              AI Curriculum Assistant
            </p>
          </div>
        </div>
        <button
          onClick={onClose}
          className="p-1.5 rounded-lg transition-colors hover:bg-white/5"
          style={{ color: "oklch(0.55 0.008 240)" }}
        >
          <X size={16} />
        </button>
      </div>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto px-4 py-4 space-y-3">
        {messages.map((msg, i) => (
          <div
            key={i}
            className={`flex gap-2 ${msg.role === "user" ? "flex-row-reverse" : ""}`}
          >
            {msg.role === "donna" && (
              <div
                className="w-7 h-7 rounded-lg flex items-center justify-center shrink-0 mt-0.5"
                style={{ background: "oklch(0.78 0.12 185 / 0.15)" }}
              >
                <Sparkles size={13} style={{ color: "oklch(0.78 0.12 185)" }} />
              </div>
            )}
            <div
              className="rounded-xl px-3 py-2.5 text-sm max-w-[240px]"
              style={
                msg.role === "donna"
                  ? {
                      background: "oklch(0.14 0.010 240)",
                      color: "oklch(0.85 0.005 240)",
                      border: "1px solid oklch(1 0 0 / 0.08)",
                    }
                  : {
                      background: "oklch(0.78 0.12 185 / 0.15)",
                      color: "oklch(0.78 0.12 185)",
                      border: "1px solid oklch(0.78 0.12 185 / 0.20)",
                    }
              }
            >
              {msg.text}
            </div>
          </div>
        ))}
      </div>

      {/* Quick Actions */}
      <div
        className="px-4 py-3 border-t space-y-1.5"
        style={{ borderColor: "oklch(1 0 0 / 0.08)" }}
      >
        <p className="text-xs font-medium mb-2" style={{ color: "oklch(0.45 0.008 240)" }}>
          Quick Actions
        </p>
        {actions.map((action, i) => (
          <button
            key={i}
            onClick={() => handleAction(action)}
            className="w-full text-left text-xs px-3 py-2 rounded-lg transition-all hover:bg-white/5 flex items-center gap-2 group"
            style={{ color: "oklch(0.65 0.008 240)" }}
          >
            <ChevronRight
              size={12}
              className="shrink-0 transition-transform group-hover:translate-x-0.5"
              style={{ color: "oklch(0.78 0.12 185)" }}
            />
            {action}
          </button>
        ))}
      </div>

      {/* Input */}
      <div
        className="px-4 py-3 border-t"
        style={{ borderColor: "oklch(1 0 0 / 0.08)" }}
      >
        <div
          className="flex items-center gap-2 rounded-xl px-3 py-2.5"
          style={{
            background: "oklch(0.14 0.010 240)",
            border: "1px solid oklch(1 0 0 / 0.10)",
          }}
        >
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && handleSend()}
            placeholder="Ask DONNA anything..."
            className="flex-1 bg-transparent text-sm outline-none placeholder:text-[oklch(0.35_0.008_240)]"
            style={{ color: "oklch(0.85 0.005 240)" }}
          />
          <button
            onClick={handleSend}
            className="p-1 rounded-lg transition-all hover:scale-110"
            style={{ color: "oklch(0.78 0.12 185)" }}
          >
            <Send size={14} />
          </button>
        </div>
      </div>
    </div>
  );
}

interface LayoutProps {
  children: React.ReactNode;
  donnaOpen?: boolean;
  onDonnaToggle?: () => void;
  donnaContext?: string;
  donnaActions?: string[];
  donnaPrompt?: string;
}

export default function Layout({
  children,
  donnaOpen: externalDonnaOpen,
  onDonnaToggle,
  donnaContext,
  donnaActions: customDonnaActions,
  donnaPrompt,
}: LayoutProps) {
  const [location] = useLocation();
  const [internalDonnaOpen, setInternalDonnaOpen] = useState(true);

  const donnaOpen = externalDonnaOpen !== undefined ? externalDonnaOpen : internalDonnaOpen;
  const toggleDonna = onDonnaToggle || (() => setInternalDonnaOpen((v) => !v));

  const isActive = (path: string) => {
    if (path === "/templates") return location.startsWith("/templates") || location === "/";
    return location === path;
  };

  const handleNavClick = (path: string) => {
    if (path !== "/templates" && !path.startsWith("/templates")) {
      toast("Feature coming soon", {
        description: "This section is not yet implemented in this prototype.",
      });
    }
  };

  return (
    <div
      className="flex h-screen overflow-hidden"
      style={{ background: "oklch(0.09 0.008 240)" }}
    >
      {/* Sidebar */}
      <aside
        className="w-[240px] shrink-0 flex flex-col h-full border-r"
        style={{
          background: "oklch(0.10 0.010 240)",
          borderColor: "oklch(1 0 0 / 0.06)",
        }}
      >
        {/* Logo */}
        <div
          className="flex items-center gap-3 px-5 py-5 border-b"
          style={{ borderColor: "oklch(1 0 0 / 0.06)" }}
        >
          <div
            className="w-8 h-8 rounded-lg flex items-center justify-center"
            style={{ background: "oklch(0.78 0.12 185)" }}
          >
            <span className="font-display font-bold text-sm" style={{ color: "oklch(0.09 0.008 240)" }}>
              A
            </span>
          </div>
          <div>
            <p className="font-display font-bold text-sm leading-tight" style={{ color: "oklch(0.93 0.005 240)" }}>
              AcademyOS
            </p>
            <p className="text-xs" style={{ color: "oklch(0.45 0.008 240)" }}>
              Director View
            </p>
          </div>
        </div>

        {/* Nav */}
        <nav className="flex-1 px-3 py-4 overflow-y-auto">
          <p className="text-xs font-medium px-2 mb-2 mt-1" style={{ color: "oklch(0.38 0.008 240)", letterSpacing: "0.08em", textTransform: "uppercase" }}>Screens</p>
          <div className="space-y-0.5">
          {navItems.map((item) => {
            const Icon = item.icon;
            const active = isActive(item.path);
            return (
              <Link key={item.path} href={item.path}>
                <a
                  className={`nav-item ${active ? "active" : ""}`}
                  onClick={(e) => {
                    if (!item.path.startsWith("/templates")) {
                      e.preventDefault();
                      handleNavClick(item.path);
                    }
                  }}
                >
                  <Icon size={16} />
                  <span>{item.label}</span>
                </a>
              </Link>
            );
          })}
          </div>
        </nav>

        {/* User */}
        <div
          className="px-3 py-4 border-t"
          style={{ borderColor: "oklch(1 0 0 / 0.06)" }}
        >
          <div className="flex items-center gap-3 px-2 py-2 rounded-lg">
            <div
              className="w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold"
              style={{
                background: "oklch(0.78 0.12 185 / 0.15)",
                color: "oklch(0.78 0.12 185)",
                border: "1px solid oklch(0.78 0.12 185 / 0.25)",
              }}
            >
              AD
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-medium truncate" style={{ color: "oklch(0.85 0.005 240)" }}>
                Academy Director
              </p>
              <p className="text-xs truncate" style={{ color: "oklch(0.45 0.008 240)" }}>
                admin@academy.com
              </p>
            </div>
          </div>
        </div>
      </aside>

      {/* Main content */}
      <div className="flex-1 flex flex-col min-w-0 overflow-hidden">
        {/* Top bar */}
        <header
          className="h-14 flex items-center justify-between px-6 border-b shrink-0"
          style={{
            background: "oklch(0.10 0.010 240)",
            borderColor: "oklch(1 0 0 / 0.06)",
          }}
        >
          <div className="flex items-center gap-2 text-sm" style={{ color: "oklch(0.45 0.008 240)" }}>
            <span>AcademyOS</span>
            <ChevronRight size={14} />
            <span style={{ color: "oklch(0.78 0.12 185)" }}>Templates</span>
          </div>
          <button
            onClick={toggleDonna}
            className="flex items-center gap-2 px-3 py-1.5 rounded-lg text-sm font-medium transition-all"
            style={{
              background: donnaOpen ? "oklch(0.78 0.12 185 / 0.12)" : "oklch(0.16 0.010 240)",
              color: donnaOpen ? "oklch(0.78 0.12 185)" : "oklch(0.65 0.008 240)",
              border: `1px solid ${donnaOpen ? "oklch(0.78 0.12 185 / 0.25)" : "oklch(1 0 0 / 0.08)"}`,
            }}
          >
            <Sparkles size={14} />
            DONNA
          </button>
        </header>

        {/* Content area + DONNA panel */}
        <div className="flex-1 flex overflow-hidden">
          <main className="flex-1 overflow-y-auto">
            {children}
          </main>
          <DonnaPanel
            open={donnaOpen}
            onClose={() => setInternalDonnaOpen(false)}
            context={donnaContext}
            contextActions={customDonnaActions}
            contextPrompt={donnaPrompt}
          />
        </div>
      </div>
    </div>
  );
}
