# Player Portal — Design Brainstorm

<response>
<probability>0.07</probability>
<text>
## Idea A — "Tactical HUD" / Cyberpunk Sports Dashboard

**Design Movement:** Military-grade HUD meets premium athletic SaaS

**Core Principles:**
- Dark command-center aesthetic with neon teal data overlays
- Information is mission-critical — every element earns its place
- Gamification through data density, not decoration
- Asymmetric grid inspired by sports analytics dashboards

**Color Philosophy:**
- Background: near-black `#0a0f0e` with very subtle green tint
- Primary accent: electric teal `#00d4aa`
- Secondary accent: amber/gold `#f5a623` for level/reward highlights
- Danger/locked: muted red `#ff4d4d`
- Text: cold white `#e8f4f1` with muted slate for secondary

**Layout Paradigm:**
- Left sidebar navigation (icon + label) — persistent across all screens
- Main content area uses asymmetric 2-column grid
- Hero cards use full-bleed with diagonal clip-paths
- Progress elements use horizontal bars with glowing fill

**Signature Elements:**
- Glowing teal borders on active cards (box-shadow: 0 0 12px #00d4aa40)
- Hexagonal badge/level icons
- Subtle scanline texture on hero sections

**Interaction Philosophy:**
- Hover states reveal hidden data layers
- Button presses trigger brief scale + glow pulse
- Screen transitions: slide-in from right with fade

**Animation:**
- Card entrance: staggered fade-up (30ms delay each)
- Progress bars: fill animation on mount (600ms ease-out)
- Level badge: brief scale pulse on unlock
- Reduced motion: all animations disabled

**Typography System:**
- Display: "Barlow Condensed" Bold — mission titles, level names
- Body: "Inter" 400/500 — readable data, descriptions
- Mono: "JetBrains Mono" — stats, numbers, rep counts
</text>
</response>

<response>
<probability>0.06</probability>
<text>
## Idea B — "Mission Journal" / Tactical Field Notes

**Design Movement:** Premium sports notebook meets digital-first UI

**Core Principles:**
- Warm dark paper texture with ink-style typography
- Missions feel like coach's handwritten field notes, digitized
- Progress is a journey, not a score — narrative-first
- Generous whitespace with editorial layout rhythm

**Color Philosophy:**
- Background: deep charcoal `#1a1a1a` with warm undertone
- Accent: bright teal `#0ff4c6` for highlights and CTAs
- Warm gold `#e8b84b` for achievements and streaks
- Muted sage for secondary text
- Cream white `#f5f0e8` for primary text

**Layout Paradigm:**
- Full-width single column with editorial card stacking
- Mission cards use left-border accent stripe (4px teal)
- Progress shown as vertical timeline/path
- No sidebar — bottom tab navigation for mobile-first feel

**Signature Elements:**
- Left-accent border stripe on mission cards
- Dotted path line connecting mission nodes
- Subtle paper grain texture on card backgrounds

**Interaction Philosophy:**
- Tap/click reveals expanded detail inline (accordion-style)
- Smooth vertical scroll between sections
- Celebration screen uses confetti burst

**Animation:**
- Cards slide in from left (200ms ease-out)
- Path dots pulse gently to indicate current position
- Achievement badge spins once on unlock

**Typography System:**
- Display: "Syne" ExtraBold — section headers
- Body: "DM Sans" — clean, friendly, readable
- Numbers: "Space Mono" — rep counts, percentages
</text>
</response>

<response>
<probability>0.05</probability>
<text>
## Idea C — "Mission Control" / Dark Athletic SaaS (CHOSEN)

**Design Movement:** Premium dark athletic SaaS — same visual family as AnglesOS marketing site

**Core Principles:**
- Deep dark backgrounds with layered card depth (not flat)
- Teal/aqua as the single dominant accent — used sparingly for maximum impact
- Gamification through visual hierarchy and progress metaphors, not gimmicks
- Sidebar navigation with persistent player identity header

**Color Philosophy:**
- Background: `#0d1117` (near-black with blue-green tint) — matches AnglesOS brand
- Card surface: `#141c22` with `#1e2a33` for elevated cards
- Primary accent: `#00c9a7` (teal) — CTAs, active states, progress fills
- Secondary accent: `#f0c040` (amber) — level badges, streaks, rewards
- Muted: `#4a6070` — secondary text, locked states
- Text: `#e2eef4` primary, `#7a9aaa` secondary

**Layout Paradigm:**
- Left sidebar (64px collapsed / 240px expanded) with player avatar at top
- Main content: responsive grid with hero card spanning full width
- Mission map: horizontal scrollable node path
- Progress screens: 2-column card grid

**Signature Elements:**
- Teal glow on active/hover cards: `box-shadow: 0 0 0 1px #00c9a730, 0 4px 20px #00c9a720`
- Circular progress rings for skill/path indicators
- Hexagonal level badge with gradient fill

**Interaction Philosophy:**
- Sidebar items highlight with teal left-border indicator
- Cards scale up 1.02 on hover with glow intensification
- DONNA panel slides in from right as a drawer

**Animation:**
- Page transitions: fade + slight upward translate (150ms)
- Progress bars and rings animate on mount (800ms ease-out)
- Mission unlock: scale from 0.95 + opacity 0 → 1 (250ms)
- Staggered card entrance: 40ms delay per card

**Typography System:**
- Display: "Barlow Condensed" SemiBold/Bold — screen titles, mission names
- Body: "DM Sans" 400/500 — descriptions, labels, body copy
- Numbers/Stats: "Space Grotesk" — level numbers, percentages, rep counts
</text>
</response>

---

## Selected Approach: **Idea C — "Mission Control"**

Dark athletic SaaS with teal accent, sidebar navigation, layered card depth, and gamified progress metaphors that match the AnglesOS brand family.
