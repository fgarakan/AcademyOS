/* AcademyOS Player Portal — App Router
   Design: Mission Control · Dark Athletic SaaS · Teal accent */

import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/NotFound";
import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";

// Pages
import PlayerHome from "./pages/PlayerHome";
import MissionMap from "./pages/MissionMap";
import MissionDetail from "./pages/MissionDetail";
import SkillPath from "./pages/SkillPath";
import CompetitionPath from "./pages/CompetitionPath";
import FitnessPath from "./pages/FitnessPath";
import LevelUp from "./pages/LevelUp";
import PracticeHome from "./pages/PracticeHome";
import Celebration from "./pages/Celebration";
import AskDonna from "./pages/AskDonna";

function Router() {
  return (
    <Switch>
      <Route path="/" component={PlayerHome} />
      <Route path="/mission-map" component={MissionMap} />
      <Route path="/mission-detail" component={MissionDetail} />
      <Route path="/skill-path" component={SkillPath} />
      <Route path="/competition-path" component={CompetitionPath} />
      <Route path="/fitness-path" component={FitnessPath} />
      <Route path="/level-up" component={LevelUp} />
      <Route path="/practice" component={PracticeHome} />
      <Route path="/celebration" component={Celebration} />
      <Route path="/ask-donna" component={AskDonna} />
      <Route path="/404" component={NotFound} />
      <Route component={NotFound} />
    </Switch>
  );
}

export default function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider defaultTheme="dark">
        <TooltipProvider>
          <Toaster />
          <Router />
        </TooltipProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}
