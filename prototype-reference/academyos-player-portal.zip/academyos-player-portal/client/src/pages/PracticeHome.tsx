/* Screen 8 — Practice / At-Home Work
   Design: Mission Control · Dark Athletic SaaS · Teal accent */

import AppLayout from "@/components/AppLayout";
import { Link } from "wouter";
import { Dumbbell, Clock, CheckCircle2, Play, Smartphone } from "lucide-react";
import { useState } from "react";

interface PracticeItem {
  id: string;
  label: string;
  reps: string;
  time: string;
  quality: number | null;
  category: "movement" | "skill" | "fitness";
  done: boolean;
}

const initialItems: PracticeItem[] = [
  { id: "1", label: "Wide-ball shadow movement",  reps: "3 rounds",   time: "5 min",  quality: null, category: "movement", done: false },
  { id: "2", label: "Quality shadow reps",         reps: "40 reps",    time: "4 min",  quality: null, category: "skill",    done: false },
  { id: "3", label: "Serve toss reps",             reps: "10 reps",    time: "3 min",  quality: null, category: "skill",    done: false },
  { id: "4", label: "Mobility warm-up",            reps: "1 round",    time: "5 min",  quality: null, category: "fitness",  done: false },
  { id: "5", label: "Movement recovery rounds",    reps: "3 rounds",   time: "4 min",  quality: null, category: "movement", done: true  },
];

const categoryColors: Record<PracticeItem["category"], { bg: string; text: string; label: string }> = {
  movement: { bg: "oklch(0.76 0.14 175 / 0.12)", text: "oklch(0.76 0.14 175)", label: "Movement" },
  skill:    { bg: "oklch(0.83 0.16 80 / 0.12)",  text: "oklch(0.83 0.16 80)",  label: "Skill"    },
  fitness:  { bg: "oklch(0.72 0.15 140 / 0.12)", text: "oklch(0.72 0.15 140)", label: "Fitness"  },
};

export default function PracticeHome() {
  const [items, setItems] = useState(initialItems);

  const toggle = (id: string) => {
    setItems((prev) => prev.map((item) => item.id === id ? { ...item, done: !item.done } : item));
  };

  const doneCount = items.filter((i) => i.done).length;
  const totalTime = "21 min";

  return (
    <AppLayout>
      <div className="px-6 py-8 max-w-3xl">
        {/* Header */}
        <div className="mb-8 animate-fade-up">
          <div
            className="text-xs font-semibold tracking-widest uppercase mb-2"
            style={{ color: "oklch(0.60 0.20 30)", fontFamily: "'Barlow Condensed', sans-serif", letterSpacing: "0.14em" }}
          >
            Practice
          </div>
          <h1
            className="text-4xl font-bold leading-tight mb-1"
            style={{ color: "oklch(0.95 0.01 200)", fontFamily: "'Barlow Condensed', sans-serif" }}
          >
            At-Home Practice
          </h1>
          <p className="text-sm" style={{ color: "oklch(0.55 0.02 210)" }}>
            Short, focused missions. Quality over quantity.
          </p>
        </div>

        {/* Session summary */}
        <div
          className="rounded-2xl p-5 mb-6 animate-fade-up"
          style={{
            background: "linear-gradient(135deg, oklch(0.16 0.02 175), oklch(0.18 0.015 210))",
            border: "1px solid oklch(0.76 0.14 175 / 0.2)",
            animationDelay: "60ms",
          }}
        >
          <div className="flex items-center justify-between mb-4">
            <div>
              <div
                className="text-sm font-semibold mb-0.5"
                style={{ color: "oklch(0.76 0.14 175)", fontFamily: "'Barlow Condensed', sans-serif", letterSpacing: "0.06em" }}
              >
                Today's Practice Session
              </div>
              <div className="text-xs" style={{ color: "oklch(0.55 0.02 210)" }}>
                Linked to: Wide Ball Recovery Mission
              </div>
            </div>
            <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg" style={{ background: "oklch(0.76 0.14 175 / 0.10)", border: "1px solid oklch(0.76 0.14 175 / 0.2)" }}>
              <Clock size={13} style={{ color: "oklch(0.76 0.14 175)" }} />
              <span className="text-sm font-semibold" style={{ color: "oklch(0.76 0.14 175)", fontFamily: "'Space Grotesk', sans-serif" }}>
                {totalTime}
              </span>
            </div>
          </div>

          {/* Progress */}
          <div className="mb-3">
            <div className="flex justify-between mb-1.5">
              <span className="text-xs" style={{ color: "oklch(0.55 0.02 210)" }}>
                {doneCount}/{items.length} exercises done
              </span>
              <span className="text-xs font-semibold" style={{ color: "oklch(0.76 0.14 175)", fontFamily: "'Space Grotesk', sans-serif" }}>
                {Math.round((doneCount / items.length) * 100)}%
              </span>
            </div>
            <div className="h-2 rounded-full overflow-hidden" style={{ background: "oklch(1 0 0 / 0.08)" }}>
              <div
                className="h-full rounded-full progress-teal"
                style={{
                  width: `${(doneCount / items.length) * 100}%`,
                  transition: "width 400ms cubic-bezier(0.23,1,0.32,1)",
                }}
              />
            </div>
          </div>

          <div className="text-xs" style={{ color: "oklch(0.50 0.02 210)" }}>
            Suggested time: <span style={{ color: "oklch(0.76 0.14 175)", fontWeight: 600 }}>5–10 minutes</span> — short and focused
          </div>
        </div>

        {/* Practice list */}
        <div
          className="rounded-xl overflow-hidden mb-6 animate-fade-up"
          style={{ border: "1px solid oklch(1 0 0 / 0.07)", animationDelay: "100ms" }}
        >
          <div
            className="px-5 py-3 border-b"
            style={{ background: "oklch(0.18 0.015 210)", borderColor: "oklch(1 0 0 / 0.07)" }}
          >
            <h2
              className="text-sm font-semibold uppercase tracking-widest"
              style={{ color: "oklch(0.75 0.01 200)", fontFamily: "'Barlow Condensed', sans-serif", letterSpacing: "0.10em" }}
            >
              Exercises
            </h2>
          </div>
          <div style={{ background: "oklch(0.16 0.015 210)" }}>
            {items.map((item, i) => {
              const cat = categoryColors[item.category];
              return (
                <div
                  key={item.id}
                  className="flex items-center gap-4 px-5 py-4 cursor-pointer transition-all duration-150 animate-fade-up"
                  style={{
                    borderBottom: i < items.length - 1 ? "1px solid oklch(1 0 0 / 0.05)" : "none",
                    background: item.done ? "oklch(0.72 0.15 140 / 0.04)" : "transparent",
                    animationDelay: `${140 + i * 40}ms`,
                  }}
                  onClick={() => toggle(item.id)}
                >
                  <div>
                    {item.done ? (
                      <CheckCircle2 size={20} style={{ color: "oklch(0.72 0.15 140)" }} />
                    ) : (
                      <div
                        className="w-5 h-5 rounded-full border-2"
                        style={{ borderColor: "oklch(0.35 0.02 210)" }}
                      />
                    )}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div
                      className="text-sm font-semibold mb-0.5"
                      style={{
                        color: item.done ? "oklch(0.55 0.02 210)" : "oklch(0.88 0.01 200)",
                        textDecoration: item.done ? "line-through" : "none",
                        textDecorationColor: "oklch(0.55 0.02 210 / 0.5)",
                      }}
                    >
                      {item.label}
                    </div>
                    <div className="flex items-center gap-3">
                      <span className="text-xs" style={{ color: "oklch(0.50 0.02 210)" }}>
                        {item.reps}
                      </span>
                      <span className="text-xs flex items-center gap-1" style={{ color: "oklch(0.50 0.02 210)" }}>
                        <Clock size={10} /> {item.time}
                      </span>
                    </div>
                  </div>
                  <span
                    className="text-xs px-2 py-0.5 rounded-full font-semibold shrink-0"
                    style={{ background: cat.bg, color: cat.text, fontFamily: "'Barlow Condensed', sans-serif", letterSpacing: "0.06em" }}
                  >
                    {cat.label}
                  </span>
                </div>
              );
            })}
          </div>
        </div>

        {/* Angles App connection */}
        <div
          className="rounded-xl p-5 mb-4 animate-fade-up"
          style={{
            background: "oklch(0.16 0.015 210)",
            border: "1px dashed oklch(0.76 0.14 175 / 0.3)",
            animationDelay: "360ms",
          }}
        >
          <div className="flex items-center gap-3 mb-2">
            <div
              className="w-9 h-9 rounded-xl flex items-center justify-center"
              style={{ background: "oklch(0.76 0.14 175 / 0.12)", border: "1px solid oklch(0.76 0.14 175 / 0.2)" }}
            >
              <Smartphone size={16} style={{ color: "oklch(0.76 0.14 175)" }} />
            </div>
            <div>
              <div
                className="text-sm font-semibold"
                style={{ color: "oklch(0.76 0.14 175)", fontFamily: "'Barlow Condensed', sans-serif", letterSpacing: "0.04em" }}
              >
                Angles App — Coming Soon
              </div>
              <div className="text-xs" style={{ color: "oklch(0.50 0.02 210)" }}>
                Track reps, quality scores, and streaks automatically
              </div>
            </div>
          </div>
          <div className="flex gap-3 mt-3">
            <div className="stat-badge flex-1 text-center">
              <div className="text-xs mb-0.5" style={{ color: "oklch(0.50 0.02 210)" }}>Rep Count</div>
              <div className="text-lg font-bold" style={{ color: "oklch(0.55 0.02 210)", fontFamily: "'Space Grotesk', sans-serif" }}>—</div>
            </div>
            <div className="stat-badge flex-1 text-center">
              <div className="text-xs mb-0.5" style={{ color: "oklch(0.50 0.02 210)" }}>Quality Score</div>
              <div className="text-lg font-bold" style={{ color: "oklch(0.55 0.02 210)", fontFamily: "'Space Grotesk', sans-serif" }}>—</div>
            </div>
            <div className="stat-badge flex-1 text-center">
              <div className="text-xs mb-0.5" style={{ color: "oklch(0.50 0.02 210)" }}>Streak</div>
              <div className="text-lg font-bold" style={{ color: "oklch(0.55 0.02 210)", fontFamily: "'Space Grotesk', sans-serif" }}>—</div>
            </div>
          </div>
        </div>

        {/* Homework focus */}
        <div
          className="rounded-xl p-5 animate-fade-up"
          style={{
            background: "oklch(0.16 0.015 210)",
            border: "1px solid oklch(1 0 0 / 0.07)",
            animationDelay: "400ms",
          }}
        >
          <div className="flex items-center gap-2 mb-2">
            <Dumbbell size={14} style={{ color: "oklch(0.60 0.20 30)" }} />
            <span
              className="text-xs font-semibold uppercase tracking-widest"
              style={{ color: "oklch(0.60 0.20 30)", fontFamily: "'Barlow Condensed', sans-serif", letterSpacing: "0.10em" }}
            >
              Homework Focus
            </span>
          </div>
          <p className="text-sm leading-relaxed" style={{ color: "oklch(0.70 0.02 210)" }}>
            This week: <span style={{ color: "oklch(0.88 0.01 200)", fontWeight: 600 }}>wide-ball shadow movement and recovery step</span>. 
            Do 3 short sessions before your next lesson. Focus on quality — not speed.
          </p>
          <Link href="/mission-detail">
            <button
              className="mt-3 flex items-center gap-2 text-sm font-semibold"
              style={{ color: "oklch(0.76 0.14 175)", fontFamily: "'Barlow Condensed', sans-serif", letterSpacing: "0.04em" }}
            >
              <Play size={13} /> View mission details
            </button>
          </Link>
        </div>
      </div>
    </AppLayout>
  );
}
