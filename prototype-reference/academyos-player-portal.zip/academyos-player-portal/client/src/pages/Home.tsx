// Redirect root to PlayerHome
export { default } from "./PlayerHome";
