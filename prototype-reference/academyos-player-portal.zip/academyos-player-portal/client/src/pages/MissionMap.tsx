/* Screen 2 — Mission Map: Gamified visual mission path
   Design: Mission Control · Dark Athletic SaaS · Teal accent */

import { Link } from "wouter";
import AppLayout from "@/components/AppLayout";
import { Lock, CheckCircle2, ChevronRight, Star, Zap, Trophy, Activity, ArrowRight } from "lucide-react";

type MissionStatus = "completed" | "active" | "next" | "locked";

interface Mission {
  id: string;
  name: string;
  subtitle: string;
  status: MissionStatus;
  progress?: number;
  badge: string;
  evidence: string;
  reward: string;
  icon: React.ElementType;
  iconColor: string;
}

const missions: Mission[] = [
  {
    id: "early-prep",
    name: "Early Prep Mission",
    subtitle: "Prepare your racket before the ball arrives",
    status: "completed",
    progress: 100,
    badge: "⚡",
    evidence: "3 sessions logged",
    reward: "Prep Badge earned",
    icon: Zap,
    iconColor: "oklch(0.83 0.16 80)",
  },
  {
    id: "wide-ball",
    name: "Wide Ball Recovery",
    subtitle: "Recover to balance after moving wide",
    status: "active",
    progress: 62,
    badge: "🎯",
    evidence: "Coach observation needed",
    reward: "Recovery Badge",
    icon: Activity,
    iconColor: "oklch(0.76 0.14 175)",
  },
  {
    id: "crosscourt",
    name: "Crosscourt Control",
    subtitle: "Play safer crosscourt targets under pressure",
    status: "next",
    progress: 0,
    badge: "🏆",
    evidence: "2 match observations",
    reward: "Control Badge",
    icon: Trophy,
    iconColor: "oklch(0.65 0.18 250)",
  },
  {
    id: "serve-first",
    name: "Serve + First Ball",
    subtitle: "Win the first ball after your serve",
    status: "locked",
    progress: 0,
    badge: "🔒",
    evidence: "Complete Crosscourt first",
    reward: "Serve Badge",
    icon: Star,
    iconColor: "oklch(0.40 0.02 210)",
  },
  {
    id: "split-step",
    name: "Split-Step Timing",
    subtitle: "Land your split-step as the opponent hits",
    status: "locked",
    progress: 0,
    badge: "🔒",
    evidence: "Complete Serve + First Ball",
    reward: "Footwork Badge",
    icon: Zap,
    iconColor: "oklch(0.40 0.02 210)",
  },
  {
    id: "match-reset",
    name: "Match Reset Mission",
    subtitle: "Reset mentally after losing a point",
    status: "locked",
    progress: 0,
    badge: "🔒",
    evidence: "Complete Split-Step first",
    reward: "Mental Badge",
    icon: Trophy,
    iconColor: "oklch(0.40 0.02 210)",
  },
];

function MissionCard({ mission }: { mission: Mission }) {
  const Icon = mission.icon;
  const isActive = mission.status === "active";
  const isCompleted = mission.status === "completed";
  const isNext = mission.status === "next";
  const isLocked = mission.status === "locked";

  const borderStyle = isActive
    ? "1px solid oklch(0.76 0.14 175 / 0.4)"
    : isCompleted
    ? "1px solid oklch(0.83 0.16 80 / 0.3)"
    : isNext
    ? "1px solid oklch(0.65 0.18 250 / 0.3)"
    : "1px solid oklch(1 0 0 / 0.06)";

  const glowStyle = isActive
    ? "0 0 0 1px oklch(0.76 0.14 175 / 0.15), 0 4px 24px oklch(0.76 0.14 175 / 0.10)"
    : isCompleted
    ? "0 0 0 1px oklch(0.83 0.16 80 / 0.10)"
    : "none";

  return (
    <div
      className="rounded-xl p-5 transition-all duration-200"
      style={{
        background: isLocked ? "oklch(0.14 0.015 210)" : "oklch(0.16 0.015 210)",
        border: borderStyle,
        boxShadow: glowStyle,
        opacity: isLocked ? 0.55 : 1,
      }}
    >
      {/* Status badge */}
      <div className="flex items-start justify-between mb-3">
        <div
          className="flex items-center gap-2 px-2.5 py-1 rounded-full text-xs font-semibold"
          style={{
            background: isActive
              ? "oklch(0.76 0.14 175 / 0.12)"
              : isCompleted
              ? "oklch(0.83 0.16 80 / 0.12)"
              : isNext
              ? "oklch(0.65 0.18 250 / 0.12)"
              : "oklch(1 0 0 / 0.05)",
            color: isActive
              ? "oklch(0.76 0.14 175)"
              : isCompleted
              ? "oklch(0.83 0.16 80)"
              : isNext
              ? "oklch(0.65 0.18 250)"
              : "oklch(0.40 0.02 210)",
            fontFamily: "'Barlow Condensed', sans-serif",
            letterSpacing: "0.08em",
          }}
        >
          {isCompleted && <CheckCircle2 size={11} />}
          {isLocked && <Lock size={11} />}
          {isActive ? "ACTIVE" : isCompleted ? "COMPLETE" : isNext ? "NEXT UP" : "LOCKED"}
        </div>
        <div
          className="w-9 h-9 rounded-lg flex items-center justify-center"
          style={{ background: `${mission.iconColor}18` }}
        >
          <Icon size={16} style={{ color: mission.iconColor }} />
        </div>
      </div>

      {/* Name */}
      <h3
        className="text-lg font-bold mb-1 leading-tight"
        style={{
          color: isLocked ? "oklch(0.45 0.02 210)" : "oklch(0.92 0.01 200)",
          fontFamily: "'Barlow Condensed', sans-serif",
        }}
      >
        {mission.name}
      </h3>
      <p className="text-xs mb-3" style={{ color: "oklch(0.50 0.02 210)" }}>
        {mission.subtitle}
      </p>

      {/* Progress */}
      {!isLocked && (
        <div className="mb-3">
          <div className="h-1.5 rounded-full overflow-hidden" style={{ background: "oklch(1 0 0 / 0.08)" }}>
            <div
              className="h-full rounded-full"
              style={{
                width: `${mission.progress}%`,
                background: isCompleted
                  ? "oklch(0.83 0.16 80)"
                  : "oklch(0.76 0.14 175)",
                boxShadow: isActive ? "0 0 6px oklch(0.76 0.14 175 / 0.5)" : "none",
                transition: "width 800ms cubic-bezier(0.23,1,0.32,1)",
              }}
            />
          </div>
          {isActive && (
            <div className="text-xs mt-1" style={{ color: "oklch(0.76 0.14 175)", fontFamily: "'Space Grotesk', sans-serif" }}>
              {mission.progress}% complete
            </div>
          )}
        </div>
      )}

      {/* Evidence + reward */}
      <div className="flex items-center justify-between text-xs mb-4">
        <span style={{ color: "oklch(0.45 0.02 210)" }}>
          Evidence: {mission.evidence}
        </span>
        <span style={{ color: isCompleted ? "oklch(0.83 0.16 80)" : "oklch(0.45 0.02 210)" }}>
          {mission.reward}
        </span>
      </div>

      {/* Action */}
      {isActive && (
        <Link href="/mission-detail">
          <button
            className="btn-teal w-full flex items-center justify-center gap-2 py-2 rounded-lg text-sm"
          >
            Continue Mission <ArrowRight size={14} />
          </button>
        </Link>
      )}
      {isNext && (
        <button
          className="w-full flex items-center justify-center gap-2 py-2 rounded-lg text-sm font-semibold"
          style={{
            background: "oklch(0.65 0.18 250 / 0.12)",
            border: "1px solid oklch(0.65 0.18 250 / 0.3)",
            color: "oklch(0.65 0.18 250)",
            fontFamily: "'Barlow Condensed', sans-serif",
            letterSpacing: "0.04em",
          }}
        >
          Coming Up Next <ChevronRight size={14} />
        </button>
      )}
      {isCompleted && (
        <div
          className="flex items-center gap-2 text-sm font-semibold"
          style={{ color: "oklch(0.83 0.16 80)", fontFamily: "'Barlow Condensed', sans-serif" }}
        >
          <CheckCircle2 size={15} />
          Mission Complete!
        </div>
      )}
    </div>
  );
}

export default function MissionMap() {
  const completed = missions.filter((m) => m.status === "completed");
  const active = missions.filter((m) => m.status === "active");
  const next = missions.filter((m) => m.status === "next");
  const locked = missions.filter((m) => m.status === "locked");

  return (
    <AppLayout>
      <div className="px-6 py-8 max-w-4xl">
        {/* Header */}
        <div className="mb-8 animate-fade-up">
          <div
            className="text-xs font-semibold tracking-widest uppercase mb-2"
            style={{ color: "oklch(0.76 0.14 175)", fontFamily: "'Barlow Condensed', sans-serif", letterSpacing: "0.14em" }}
          >
            Mission Map
          </div>
          <h1
            className="text-4xl font-bold leading-tight mb-1"
            style={{ color: "oklch(0.95 0.01 200)", fontFamily: "'Barlow Condensed', sans-serif" }}
          >
            Your Development Journey
          </h1>
          <p className="text-sm" style={{ color: "oklch(0.55 0.02 210)" }}>
            Complete missions to unlock your next level. Every step builds on the last.
          </p>
        </div>

        {/* Active */}
        {active.length > 0 && (
          <section className="mb-8 animate-fade-up" style={{ animationDelay: "60ms" }}>
            <h2
              className="text-sm font-semibold uppercase tracking-widest mb-3"
              style={{ color: "oklch(0.76 0.14 175)", fontFamily: "'Barlow Condensed', sans-serif", letterSpacing: "0.12em" }}
            >
              Current Mission
            </h2>
            <div className="grid gap-3">
              {active.map((m) => <MissionCard key={m.id} mission={m} />)}
            </div>
          </section>
        )}

        {/* Next */}
        {next.length > 0 && (
          <section className="mb-8 animate-fade-up" style={{ animationDelay: "120ms" }}>
            <h2
              className="text-sm font-semibold uppercase tracking-widest mb-3"
              style={{ color: "oklch(0.65 0.18 250)", fontFamily: "'Barlow Condensed', sans-serif", letterSpacing: "0.12em" }}
            >
              Next Mission
            </h2>
            <div className="grid gap-3">
              {next.map((m) => <MissionCard key={m.id} mission={m} />)}
            </div>
          </section>
        )}

        {/* Locked */}
        {locked.length > 0 && (
          <section className="mb-8 animate-fade-up" style={{ animationDelay: "180ms" }}>
            <h2
              className="text-sm font-semibold uppercase tracking-widest mb-3"
              style={{ color: "oklch(0.40 0.02 210)", fontFamily: "'Barlow Condensed', sans-serif", letterSpacing: "0.12em" }}
            >
              Future Missions — Locked
            </h2>
            <div className="grid sm:grid-cols-2 gap-3">
              {locked.map((m) => <MissionCard key={m.id} mission={m} />)}
            </div>
          </section>
        )}

        {/* Completed */}
        {completed.length > 0 && (
          <section className="animate-fade-up" style={{ animationDelay: "240ms" }}>
            <h2
              className="text-sm font-semibold uppercase tracking-widest mb-3"
              style={{ color: "oklch(0.83 0.16 80)", fontFamily: "'Barlow Condensed', sans-serif", letterSpacing: "0.12em" }}
            >
              Completed Missions
            </h2>
            <div className="grid sm:grid-cols-2 gap-3">
              {completed.map((m) => <MissionCard key={m.id} mission={m} />)}
            </div>
          </section>
        )}
      </div>
    </AppLayout>
  );
}
