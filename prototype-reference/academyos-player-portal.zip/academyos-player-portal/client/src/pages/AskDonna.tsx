/* Screen 10 — Ask DONNA: Player-safe AI assistant
   Design: Mission Control · Dark Athletic SaaS · Teal accent */

import AppLayout from "@/components/AppLayout";
import { MessageCircle, Send, Shield, ChevronRight } from "lucide-react";
import { useState, useRef, useEffect } from "react";

interface Message {
  id: string;
  role: "user" | "donna";
  text: string;
}

const quickQuestions = [
  "What should I practice?",
  "What does my mission mean?",
  "How do I get to the next level?",
  "How do I prepare for a match?",
  "What did my coach say I should focus on?",
];

const donnaResponses: Record<string, string> = {
  "What should I practice?":
    "Right now your best practice is the **wide-ball shadow movement** — 3 rounds of moving wide and recovering back to the T. Keep it short and focused. 5–10 minutes of quality reps is better than 30 minutes of sloppy ones. Check your Practice screen for today's full session.",
  "What does my mission mean?":
    "Your current mission — **Wide Ball Recovery** — is about staying in control when you're pulled wide. Instead of going for a risky winner, the goal is to recover your balance first, then play a safe crosscourt ball. It's a high-percentage habit that will help you win more points.",
  "How do I get to the next level?":
    "To unlock **Orange Ball 3**, you need to: (1) keep preparing earlier, (2) recover after wide balls consistently, (3) choose crosscourt targets under pressure, (4) complete your mission evidence (3 sessions + coach observation), and (5) get coach approval. You've already done step 1 — great work!",
  "How do I prepare for a match?":
    "Before a match: warm up your movement with a few split-step drills, do some shadow swings to get your preparation timing sharp, and remind yourself of your one focus — **recover after wide balls and play crosscourt**. Keep it simple. One focus is better than ten.",
  "What did my coach say I should focus on?":
    "Coach Martinez wants you to focus on your **recovery step** after wide balls. The goal is to stop, reset, and play a controlled crosscourt ball — not go for a winner when you're off-balance. Your coach will be watching for this in your next session.",
};

const defaultResponse =
  "That's a great question! I'm here to help you understand your training. Try one of the quick questions below, or ask me about your mission, practice, or how to prepare for a match.";

export default function AskDonna() {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: "0",
      role: "donna",
      text: "Hi! I'm DONNA — your training guide. I can help you understand your missions, practice plans, and what to focus on. What would you like to know?",
    },
  ]);
  const [input, setInput] = useState("");
  const [typing, setTyping] = useState(false);
  const bottomRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, typing]);

  const sendMessage = (text: string) => {
    if (!text.trim()) return;
    const userMsg: Message = { id: Date.now().toString(), role: "user", text: text.trim() };
    setMessages((prev) => [...prev, userMsg]);
    setInput("");
    setTyping(true);

    setTimeout(() => {
      const response = donnaResponses[text.trim()] || defaultResponse;
      const donnaMsg: Message = {
        id: (Date.now() + 1).toString(),
        role: "donna",
        text: response,
      };
      setMessages((prev) => [...prev, donnaMsg]);
      setTyping(false);
    }, 900 + Math.random() * 400);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    sendMessage(input);
  };

  function renderText(text: string) {
    // Bold markdown
    return text.split(/\*\*(.*?)\*\*/g).map((part, i) =>
      i % 2 === 1 ? (
        <strong key={i} style={{ color: "oklch(0.88 0.01 200)", fontWeight: 600 }}>
          {part}
        </strong>
      ) : (
        part
      )
    );
  }

  return (
    <AppLayout>
      <div className="flex flex-col h-[calc(100vh-0px)] lg:h-screen max-w-2xl">
        {/* Header */}
        <div
          className="px-6 py-5 border-b shrink-0"
          style={{ borderColor: "oklch(1 0 0 / 0.07)", background: "oklch(0.13 0.015 210)" }}
        >
          <div className="flex items-center gap-3">
            <div
              className="w-10 h-10 rounded-xl flex items-center justify-center"
              style={{
                background: "linear-gradient(135deg, oklch(0.76 0.14 175 / 0.2), oklch(0.65 0.16 175 / 0.15))",
                border: "1px solid oklch(0.76 0.14 175 / 0.3)",
              }}
            >
              <MessageCircle size={18} style={{ color: "oklch(0.76 0.14 175)" }} />
            </div>
            <div>
              <h1
                className="text-lg font-bold leading-tight"
                style={{ color: "oklch(0.95 0.01 200)", fontFamily: "'Barlow Condensed', sans-serif" }}
              >
                Ask DONNA
              </h1>
              <div className="flex items-center gap-1.5">
                <div
                  className="w-1.5 h-1.5 rounded-full animate-pulse"
                  style={{ background: "oklch(0.72 0.15 140)" }}
                />
                <span className="text-xs" style={{ color: "oklch(0.55 0.02 210)" }}>
                  Your training guide — always here
                </span>
              </div>
            </div>
          </div>

          {/* Guardrails notice */}
          <div
            className="flex items-center gap-2 mt-3 px-3 py-2 rounded-lg"
            style={{ background: "oklch(0.76 0.14 175 / 0.06)", border: "1px solid oklch(0.76 0.14 175 / 0.12)" }}
          >
            <Shield size={12} style={{ color: "oklch(0.76 0.14 175)", flexShrink: 0 }} />
            <p className="text-xs" style={{ color: "oklch(0.55 0.02 210)" }}>
              DONNA shares coach-approved summaries only. No rankings, no pressure, no private notes.
            </p>
          </div>
        </div>

        {/* Messages */}
        <div className="flex-1 overflow-y-auto px-6 py-4 space-y-4">
          {messages.map((msg) => (
            <div
              key={msg.id}
              className={`flex ${msg.role === "user" ? "justify-end" : "justify-start"} animate-fade-up`}
            >
              {msg.role === "donna" && (
                <div
                  className="w-7 h-7 rounded-lg flex items-center justify-center mr-2.5 mt-0.5 shrink-0"
                  style={{
                    background: "oklch(0.76 0.14 175 / 0.12)",
                    border: "1px solid oklch(0.76 0.14 175 / 0.2)",
                  }}
                >
                  <MessageCircle size={13} style={{ color: "oklch(0.76 0.14 175)" }} />
                </div>
              )}
              <div
                className="max-w-[80%] px-4 py-3 rounded-2xl text-sm leading-relaxed"
                style={
                  msg.role === "donna"
                    ? {
                        background: "oklch(0.18 0.015 210)",
                        border: "1px solid oklch(1 0 0 / 0.08)",
                        color: "oklch(0.75 0.01 200)",
                        borderRadius: "0 1rem 1rem 1rem",
                      }
                    : {
                        background: "oklch(0.76 0.14 175)",
                        color: "oklch(0.10 0.01 175)",
                        fontWeight: 500,
                        borderRadius: "1rem 1rem 0 1rem",
                      }
                }
              >
                {msg.role === "donna" ? renderText(msg.text) : msg.text}
              </div>
            </div>
          ))}

          {typing && (
            <div className="flex justify-start animate-fade-in">
              <div
                className="w-7 h-7 rounded-lg flex items-center justify-center mr-2.5 mt-0.5 shrink-0"
                style={{
                  background: "oklch(0.76 0.14 175 / 0.12)",
                  border: "1px solid oklch(0.76 0.14 175 / 0.2)",
                }}
              >
                <MessageCircle size={13} style={{ color: "oklch(0.76 0.14 175)" }} />
              </div>
              <div
                className="px-4 py-3 rounded-2xl"
                style={{
                  background: "oklch(0.18 0.015 210)",
                  border: "1px solid oklch(1 0 0 / 0.08)",
                  borderRadius: "0 1rem 1rem 1rem",
                }}
              >
                <div className="flex gap-1.5 items-center h-4">
                  {[0, 1, 2].map((i) => (
                    <div
                      key={i}
                      className="w-1.5 h-1.5 rounded-full"
                      style={{
                        background: "oklch(0.76 0.14 175)",
                        animation: `pulse 1.2s ${i * 0.2}s ease-in-out infinite`,
                      }}
                    />
                  ))}
                </div>
              </div>
            </div>
          )}
          <div ref={bottomRef} />
        </div>

        {/* Quick questions */}
        <div
          className="px-6 py-3 border-t shrink-0"
          style={{ borderColor: "oklch(1 0 0 / 0.07)", background: "oklch(0.13 0.015 210)" }}
        >
          <div className="text-xs mb-2" style={{ color: "oklch(0.45 0.02 210)" }}>
            Quick questions:
          </div>
          <div className="flex flex-wrap gap-2">
            {quickQuestions.map((q) => (
              <button
                key={q}
                onClick={() => sendMessage(q)}
                className="flex items-center gap-1 text-xs px-3 py-1.5 rounded-lg font-medium transition-all duration-150"
                style={{
                  background: "oklch(0.76 0.14 175 / 0.08)",
                  border: "1px solid oklch(0.76 0.14 175 / 0.18)",
                  color: "oklch(0.76 0.14 175)",
                }}
                onMouseEnter={(e) => {
                  (e.currentTarget as HTMLButtonElement).style.background = "oklch(0.76 0.14 175 / 0.16)";
                }}
                onMouseLeave={(e) => {
                  (e.currentTarget as HTMLButtonElement).style.background = "oklch(0.76 0.14 175 / 0.08)";
                }}
              >
                <ChevronRight size={10} /> {q}
              </button>
            ))}
          </div>
        </div>

        {/* Input */}
        <form
          onSubmit={handleSubmit}
          className="px-6 py-4 border-t shrink-0"
          style={{ borderColor: "oklch(1 0 0 / 0.07)", background: "oklch(0.13 0.015 210)" }}
        >
          <div
            className="flex items-center gap-3 rounded-xl px-4 py-2.5"
            style={{
              background: "oklch(0.18 0.015 210)",
              border: "1px solid oklch(1 0 0 / 0.10)",
            }}
          >
            <input
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder="Ask DONNA anything about your training..."
              className="flex-1 bg-transparent text-sm outline-none"
              style={{ color: "oklch(0.85 0.01 200)" }}
            />
            <button
              type="submit"
              disabled={!input.trim() || typing}
              className="w-8 h-8 rounded-lg flex items-center justify-center shrink-0 transition-all duration-150"
              style={{
                background: input.trim() && !typing ? "oklch(0.76 0.14 175)" : "oklch(0.25 0.015 210)",
                color: input.trim() && !typing ? "oklch(0.10 0.01 175)" : "oklch(0.40 0.02 210)",
              }}
            >
              <Send size={14} />
            </button>
          </div>
        </form>
      </div>
    </AppLayout>
  );
}
