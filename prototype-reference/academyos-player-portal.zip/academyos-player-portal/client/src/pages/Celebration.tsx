/* Screen 9 — Progress Celebration
   Design: Mission Control · Dark Athletic SaaS · Teal accent */

import AppLayout from "@/components/AppLayout";
import { Link } from "wouter";
import { Star, ArrowRight, Share2, MessageCircle } from "lucide-react";
import { useEffect, useState } from "react";

function Confetti() {
  const [particles, setParticles] = useState<{ x: number; y: number; color: string; size: number; delay: number }[]>([]);

  useEffect(() => {
    const colors = [
      "oklch(0.76 0.14 175)",
      "oklch(0.83 0.16 80)",
      "oklch(0.72 0.15 140)",
      "oklch(0.65 0.18 250)",
    ];
    setParticles(
      Array.from({ length: 24 }, (_, i) => ({
        x: Math.random() * 100,
        y: Math.random() * 60,
        color: colors[i % colors.length],
        size: 4 + Math.random() * 6,
        delay: Math.random() * 600,
      }))
    );
  }, []);

  return (
    <div className="absolute inset-0 pointer-events-none overflow-hidden rounded-2xl">
      {particles.map((p, i) => (
        <div
          key={i}
          className="absolute rounded-sm"
          style={{
            left: `${p.x}%`,
            top: `${p.y}%`,
            width: p.size,
            height: p.size,
            background: p.color,
            opacity: 0.7,
            animation: `fadeIn 400ms ${p.delay}ms both`,
          }}
        />
      ))}
    </div>
  );
}

export default function Celebration() {
  return (
    <AppLayout>
      <div className="px-6 py-8 max-w-2xl">
        {/* Header */}
        <div className="mb-8 animate-fade-up">
          <div
            className="text-xs font-semibold tracking-widest uppercase mb-2"
            style={{ color: "oklch(0.83 0.16 80)", fontFamily: "'Barlow Condensed', sans-serif", letterSpacing: "0.14em" }}
          >
            Achievements
          </div>
          <h1
            className="text-4xl font-bold leading-tight mb-1"
            style={{ color: "oklch(0.95 0.01 200)", fontFamily: "'Barlow Condensed', sans-serif" }}
          >
            Mission Complete!
          </h1>
          <p className="text-sm" style={{ color: "oklch(0.55 0.02 210)" }}>
            You did the work. Here's what you unlocked.
          </p>
        </div>

        {/* Celebration hero card */}
        <div
          className="relative rounded-2xl p-8 mb-6 text-center overflow-hidden animate-celebration"
          style={{
            background: "linear-gradient(135deg, oklch(0.18 0.03 80), oklch(0.17 0.02 175), oklch(0.16 0.015 210))",
            border: "1px solid oklch(0.83 0.16 80 / 0.4)",
            boxShadow: "0 0 60px oklch(0.83 0.16 80 / 0.12)",
          }}
        >
          <Confetti />

          {/* Badge */}
          <div
            className="w-20 h-20 rounded-2xl flex items-center justify-center text-4xl mx-auto mb-4"
            style={{
              background: "linear-gradient(135deg, oklch(0.83 0.16 80), oklch(0.76 0.18 60))",
              boxShadow: "0 0 30px oklch(0.83 0.16 80 / 0.4)",
            }}
          >
            ⚡
          </div>

          <div
            className="text-xs font-semibold uppercase tracking-widest mb-2"
            style={{ color: "oklch(0.83 0.16 80)", fontFamily: "'Barlow Condensed', sans-serif", letterSpacing: "0.14em" }}
          >
            Badge Earned
          </div>
          <h2
            className="text-3xl font-bold mb-1"
            style={{ color: "oklch(0.95 0.01 200)", fontFamily: "'Barlow Condensed', sans-serif" }}
          >
            Early Prep Badge
          </h2>
          <p className="text-sm mb-4" style={{ color: "oklch(0.65 0.02 210)" }}>
            You completed the Early Prep Mission — racket back before the ball bounces.
          </p>

          {/* Stats */}
          <div className="flex justify-center gap-4 mb-5">
            {[
              { label: "Sessions", value: "3" },
              { label: "Quality Reps", value: "120" },
              { label: "Days", value: "7" },
            ].map((stat) => (
              <div key={stat.label} className="text-center">
                <div
                  className="text-2xl font-bold"
                  style={{ color: "oklch(0.83 0.16 80)", fontFamily: "'Space Grotesk', sans-serif" }}
                >
                  {stat.value}
                </div>
                <div className="text-xs" style={{ color: "oklch(0.55 0.02 210)" }}>
                  {stat.label}
                </div>
              </div>
            ))}
          </div>

          {/* Share placeholder */}
          <button
            className="flex items-center gap-2 mx-auto px-4 py-2 rounded-lg text-sm font-semibold"
            style={{
              background: "oklch(0.83 0.16 80 / 0.12)",
              border: "1px solid oklch(0.83 0.16 80 / 0.3)",
              color: "oklch(0.83 0.16 80)",
              fontFamily: "'Barlow Condensed', sans-serif",
              letterSpacing: "0.04em",
            }}
          >
            <Share2 size={14} /> Share with Family
          </button>
        </div>

        {/* Coach note */}
        <div
          className="rounded-xl p-5 mb-4 animate-fade-up"
          style={{
            background: "oklch(0.16 0.015 210)",
            border: "1px solid oklch(0.76 0.14 175 / 0.15)",
            animationDelay: "200ms",
          }}
        >
          <div className="flex items-center gap-2 mb-2">
            <MessageCircle size={14} style={{ color: "oklch(0.76 0.14 175)" }} />
            <span
              className="text-xs font-semibold uppercase tracking-widest"
              style={{ color: "oklch(0.76 0.14 175)", fontFamily: "'Barlow Condensed', sans-serif", letterSpacing: "0.10em" }}
            >
              Coach Note
            </span>
          </div>
          <p className="text-sm leading-relaxed" style={{ color: "oklch(0.70 0.02 210)" }}>
            "Alex showed real improvement in preparation timing this week. The early racket work is making a visible difference in contact quality. Ready to move to the next challenge."
          </p>
          <div className="text-xs mt-2" style={{ color: "oklch(0.45 0.02 210)" }}>
            — Coach Martinez
          </div>
        </div>

        {/* Next mission unlocked */}
        <div
          className="rounded-xl p-5 animate-fade-up"
          style={{
            background: "linear-gradient(135deg, oklch(0.16 0.02 175), oklch(0.17 0.015 210))",
            border: "1px solid oklch(0.76 0.14 175 / 0.25)",
            animationDelay: "280ms",
          }}
        >
          <div className="flex items-center gap-2 mb-2">
            <Star size={14} style={{ color: "oklch(0.76 0.14 175)" }} />
            <span
              className="text-xs font-semibold uppercase tracking-widest"
              style={{ color: "oklch(0.76 0.14 175)", fontFamily: "'Barlow Condensed', sans-serif", letterSpacing: "0.10em" }}
            >
              Next Mission Unlocked
            </span>
          </div>
          <h3
            className="text-xl font-bold mb-1"
            style={{ color: "oklch(0.92 0.01 200)", fontFamily: "'Barlow Condensed', sans-serif" }}
          >
            Wide Ball Recovery
          </h3>
          <p className="text-sm mb-3" style={{ color: "oklch(0.60 0.02 210)" }}>
            Recover to balance after moving wide and play a safer crosscourt ball.
          </p>
          <Link href="/mission-detail">
            <button className="btn-teal flex items-center gap-2 px-5 py-2.5 rounded-lg text-sm">
              Start Next Mission <ArrowRight size={14} />
            </button>
          </Link>
        </div>
      </div>
    </AppLayout>
  );
}
