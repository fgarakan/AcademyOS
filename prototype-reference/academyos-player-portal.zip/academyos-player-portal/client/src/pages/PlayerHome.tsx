/* Screen 1 — Player Home: My Training Path
   Design: Mission Control · Dark Athletic SaaS · Teal accent */

import { Link } from "wouter";
import AppLayout from "@/components/AppLayout";
import {
  ChevronRight, Flame, Zap, Trophy, Activity,
  Dumbbell, Map, MessageCircle, ArrowRight, Target
} from "lucide-react";

function ProgressBar({ value, max = 100, label }: { value: number; max?: number; label?: string }) {
  const pct = Math.round((value / max) * 100);
  return (
    <div>
      {label && (
        <div className="flex justify-between mb-1.5">
          <span className="text-xs" style={{ color: "oklch(0.55 0.02 210)" }}>{label}</span>
          <span className="text-xs font-semibold" style={{ color: "oklch(0.76 0.14 175)", fontFamily: "'Space Grotesk', sans-serif" }}>
            {pct}%
          </span>
        </div>
      )}
      <div className="h-1.5 rounded-full overflow-hidden" style={{ background: "oklch(1 0 0 / 0.08)" }}>
        <div
          className="h-full rounded-full progress-teal"
          style={{ width: `${pct}%`, transition: "width 800ms cubic-bezier(0.23,1,0.32,1)" }}
        />
      </div>
    </div>
  );
}

function PathCard({
  href, icon: Icon, label, progress, color, delay
}: {
  href: string; icon: React.ElementType; label: string; progress: number; color: string; delay: number;
}) {
  return (
    <Link href={href}>
      <div
        className="card-glow rounded-xl p-4 cursor-pointer"
        style={{
          background: "oklch(0.16 0.015 210)",
          animationDelay: `${delay}ms`,
        }}
      >
        <div className="flex items-center justify-between mb-3">
          <div
            className="w-8 h-8 rounded-lg flex items-center justify-center"
            style={{ background: `${color}20` }}
          >
            <Icon size={16} style={{ color }} />
          </div>
          <ChevronRight size={14} style={{ color: "oklch(0.40 0.02 210)" }} />
        </div>
        <div className="text-sm font-semibold mb-2" style={{ color: "oklch(0.90 0.01 200)" }}>
          {label}
        </div>
        <ProgressBar value={progress} />
      </div>
    </Link>
  );
}

export default function PlayerHome() {
  return (
    <AppLayout>
      <div className="px-6 py-8 max-w-4xl">
        {/* Header */}
        <div className="mb-8 animate-fade-up">
          <div
            className="text-xs font-semibold tracking-widest uppercase mb-2"
            style={{ color: "oklch(0.76 0.14 175)", fontFamily: "'Barlow Condensed', sans-serif", letterSpacing: "0.14em" }}
          >
            Player Development Operating System
          </div>
          <h1
            className="text-4xl font-bold leading-tight mb-1"
            style={{ color: "oklch(0.95 0.01 200)", fontFamily: "'Barlow Condensed', sans-serif" }}
          >
            My Training Path
          </h1>
          <p className="text-sm" style={{ color: "oklch(0.55 0.02 210)" }}>
            Your current mission, progress, and next step. Welcome back, Alex.
          </p>
        </div>

        {/* Hero Mission Card */}
        <div
          className="rounded-2xl p-6 mb-6 animate-fade-up"
          style={{
            background: "linear-gradient(135deg, oklch(0.16 0.02 175), oklch(0.18 0.015 210))",
            border: "1px solid oklch(0.76 0.14 175 / 0.25)",
            boxShadow: "0 0 40px oklch(0.76 0.14 175 / 0.08)",
            animationDelay: "60ms",
          }}
        >
          <div className="flex items-start justify-between mb-4">
            <div>
              <div
                className="text-xs font-semibold tracking-widest uppercase mb-1"
                style={{ color: "oklch(0.76 0.14 175)", fontFamily: "'Barlow Condensed', sans-serif", letterSpacing: "0.12em" }}
              >
                Current Mission
              </div>
              <h2
                className="text-2xl font-bold leading-snug"
                style={{ color: "oklch(0.95 0.01 200)", fontFamily: "'Barlow Condensed', sans-serif", maxWidth: "420px" }}
              >
                "Recover after wide balls and control the crosscourt."
              </h2>
            </div>
            <div
              className="level-badge rounded-xl px-3 py-2 text-center shrink-0 ml-4"
              style={{ minWidth: "80px" }}
            >
              <div className="text-xs font-semibold uppercase tracking-wide" style={{ fontSize: "9px", letterSpacing: "0.1em" }}>
                Level
              </div>
              <div className="text-lg font-bold leading-tight" style={{ fontFamily: "'Space Grotesk', sans-serif" }}>
                OB2
              </div>
            </div>
          </div>

          {/* Level progress */}
          <div className="mb-5">
            <div className="flex justify-between mb-2">
              <span className="text-xs font-medium" style={{ color: "oklch(0.55 0.02 210)" }}>
                Orange Ball 2
              </span>
              <span className="text-xs font-medium" style={{ color: "oklch(0.55 0.02 210)" }}>
                Orange Ball 3
              </span>
            </div>
            <div className="h-2 rounded-full overflow-hidden" style={{ background: "oklch(1 0 0 / 0.08)" }}>
              <div
                className="h-full rounded-full progress-teal"
                style={{ width: "62%", transition: "width 1s cubic-bezier(0.23,1,0.32,1)" }}
              />
            </div>
            <div className="text-xs mt-1.5 text-right" style={{ color: "oklch(0.76 0.14 175)", fontFamily: "'Space Grotesk', sans-serif" }}>
              62% to next level
            </div>
          </div>

          {/* Streak */}
          <div className="flex items-center gap-4 mb-5">
            <div
              className="flex items-center gap-2 px-3 py-2 rounded-lg"
              style={{ background: "oklch(0.83 0.16 80 / 0.12)", border: "1px solid oklch(0.83 0.16 80 / 0.2)" }}
            >
              <Flame size={14} style={{ color: "oklch(0.83 0.16 80)" }} />
              <span className="text-sm font-semibold" style={{ color: "oklch(0.83 0.16 80)", fontFamily: "'Space Grotesk', sans-serif" }}>
                7-day streak
              </span>
            </div>
            <div
              className="flex items-center gap-2 px-3 py-2 rounded-lg"
              style={{ background: "oklch(0.76 0.14 175 / 0.10)", border: "1px solid oklch(0.76 0.14 175 / 0.2)" }}
            >
              <Target size={14} style={{ color: "oklch(0.76 0.14 175)" }} />
              <span className="text-sm font-semibold" style={{ color: "oklch(0.76 0.14 175)", fontFamily: "'Space Grotesk', sans-serif" }}>
                3 missions active
              </span>
            </div>
          </div>

          {/* CTA */}
          <Link href="/mission-detail">
            <button
              className="btn-teal flex items-center gap-2 px-5 py-2.5 rounded-lg text-sm"
            >
              Continue Mission
              <ArrowRight size={15} />
            </button>
          </Link>
        </div>

        {/* Path cards */}
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 mb-6">
          <PathCard href="/skill-path"        icon={Zap}      label="Skill Path"    progress={68} color="oklch(0.76 0.14 175)" delay={80} />
          <PathCard href="/competition-path"  icon={Trophy}   label="Competition"   progress={45} color="oklch(0.83 0.16 80)"  delay={120} />
          <PathCard href="/fitness-path"      icon={Activity} label="Fitness"       progress={55} color="oklch(0.72 0.15 140)" delay={160} />
          <PathCard href="/mission-map"       icon={Map}      label="My Missions"   progress={40} color="oklch(0.65 0.18 250)" delay={200} />
          <PathCard href="/practice"          icon={Dumbbell} label="Practice"      progress={30} color="oklch(0.60 0.20 30)"  delay={240} />
          <PathCard href="/level-up"          icon={ArrowRight} label="Level Up"    progress={62} color="oklch(0.83 0.16 80)"  delay={280} />
        </div>

        {/* DONNA panel */}
        <div
          className="donna-panel p-5 animate-fade-up"
          style={{ animationDelay: "320ms" }}
        >
          <div className="flex items-start gap-3 mb-4">
            <div
              className="w-9 h-9 rounded-xl flex items-center justify-center shrink-0"
              style={{ background: "oklch(0.76 0.14 175 / 0.15)", border: "1px solid oklch(0.76 0.14 175 / 0.3)" }}
            >
              <MessageCircle size={16} style={{ color: "oklch(0.76 0.14 175)" }} />
            </div>
            <div>
              <div
                className="text-sm font-semibold mb-0.5"
                style={{ color: "oklch(0.76 0.14 175)", fontFamily: "'Barlow Condensed', sans-serif", letterSpacing: "0.04em" }}
              >
                DONNA — Your AI Guide
              </div>
              <p className="text-sm" style={{ color: "oklch(0.70 0.02 210)" }}>
                Want help understanding what to work on?
              </p>
            </div>
          </div>
          <div className="flex flex-wrap gap-2">
            {[
              "Explain my mission",
              "What should I practice?",
              "How do I level up?",
              "What did my coach notice?",
              "Help me prepare for a match",
            ].map((q) => (
              <Link key={q} href="/ask-donna">
                <button
                  className="text-xs px-3 py-1.5 rounded-lg font-medium transition-all duration-150"
                  style={{
                    background: "oklch(0.76 0.14 175 / 0.10)",
                    border: "1px solid oklch(0.76 0.14 175 / 0.2)",
                    color: "oklch(0.76 0.14 175)",
                  }}
                  onMouseEnter={(e) => {
                    (e.currentTarget as HTMLButtonElement).style.background = "oklch(0.76 0.14 175 / 0.18)";
                  }}
                  onMouseLeave={(e) => {
                    (e.currentTarget as HTMLButtonElement).style.background = "oklch(0.76 0.14 175 / 0.10)";
                  }}
                >
                  {q}
                </button>
              </Link>
            ))}
          </div>
        </div>
      </div>
    </AppLayout>
  );
}
