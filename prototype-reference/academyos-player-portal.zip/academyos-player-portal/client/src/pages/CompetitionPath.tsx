/* Screen 5 — Competition Path Progress
   Design: Mission Control · Dark Athletic SaaS · Teal accent */

import AppLayout from "@/components/AppLayout";
import { Link } from "wouter";
import { Trophy, ChevronRight } from "lucide-react";

interface CompSkill {
  name: string;
  description: string;
  progress: number;
  focus: boolean;
  tip: string;
}

const compSkills: CompSkill[] = [
  {
    name: "Rally Decisions",
    description: "Choosing the right shot during a rally",
    progress: 58,
    focus: false,
    tip: "Keep the ball in play with high-percentage shots.",
  },
  {
    name: "Target Choice",
    description: "Selecting the right target under pressure",
    progress: 45,
    focus: true,
    tip: "Current focus: choose safer crosscourt targets when under pressure.",
  },
  {
    name: "Scoring Awareness",
    description: "Understanding when to attack vs. defend",
    progress: 40,
    focus: false,
    tip: "Know the score and adjust your risk level accordingly.",
  },
  {
    name: "Pressure Response",
    description: "Staying composed when behind or under pressure",
    progress: 38,
    focus: false,
    tip: "Breathe, reset, and play one point at a time.",
  },
  {
    name: "Match Routines",
    description: "Pre-point and between-game routines",
    progress: 52,
    focus: false,
    tip: "Consistent routines help you reset faster after tough points.",
  },
  {
    name: "Tournament Readiness",
    description: "Performing in match conditions",
    progress: 35,
    focus: false,
    tip: "Practice like you play. Match experience builds this skill.",
  },
];

export default function CompetitionPath() {
  const overall = Math.round(compSkills.reduce((a, s) => a + s.progress, 0) / compSkills.length);
  const focusSkill = compSkills.find((s) => s.focus);

  return (
    <AppLayout>
      <div className="px-6 py-8 max-w-4xl">
        {/* Header */}
        <div className="mb-8 animate-fade-up">
          <div
            className="text-xs font-semibold tracking-widest uppercase mb-2"
            style={{ color: "oklch(0.83 0.16 80)", fontFamily: "'Barlow Condensed', sans-serif", letterSpacing: "0.14em" }}
          >
            Competition Path
          </div>
          <h1
            className="text-4xl font-bold leading-tight mb-1"
            style={{ color: "oklch(0.95 0.01 200)", fontFamily: "'Barlow Condensed', sans-serif" }}
          >
            Match Skills
          </h1>
          <p className="text-sm" style={{ color: "oklch(0.55 0.02 210)" }}>
            How you think and compete — not just how you hit.
          </p>
        </div>

        {/* Current focus highlight */}
        {focusSkill && (
          <div
            className="rounded-2xl p-5 mb-6 animate-fade-up"
            style={{
              background: "linear-gradient(135deg, oklch(0.16 0.02 80), oklch(0.17 0.015 210))",
              border: "1px solid oklch(0.83 0.16 80 / 0.3)",
              boxShadow: "0 0 30px oklch(0.83 0.16 80 / 0.06)",
              animationDelay: "60ms",
            }}
          >
            <div className="flex items-center gap-2 mb-2">
              <Trophy size={15} style={{ color: "oklch(0.83 0.16 80)" }} />
              <span
                className="text-xs font-semibold uppercase tracking-widest"
                style={{ color: "oklch(0.83 0.16 80)", fontFamily: "'Barlow Condensed', sans-serif", letterSpacing: "0.12em" }}
              >
                Current Competition Focus
              </span>
            </div>
            <p
              className="text-xl font-bold mb-1"
              style={{ color: "oklch(0.95 0.01 200)", fontFamily: "'Barlow Condensed', sans-serif" }}
            >
              "{focusSkill.tip}"
            </p>
            <p className="text-sm" style={{ color: "oklch(0.60 0.02 210)" }}>
              {focusSkill.description}
            </p>
            <div className="mt-3">
              <div className="h-2 rounded-full overflow-hidden" style={{ background: "oklch(1 0 0 / 0.08)" }}>
                <div
                  className="h-full rounded-full"
                  style={{
                    width: `${focusSkill.progress}%`,
                    background: "oklch(0.83 0.16 80)",
                    boxShadow: "0 0 8px oklch(0.83 0.16 80 / 0.5)",
                    transition: "width 800ms cubic-bezier(0.23,1,0.32,1)",
                  }}
                />
              </div>
              <div
                className="text-xs mt-1 text-right"
                style={{ color: "oklch(0.83 0.16 80)", fontFamily: "'Space Grotesk', sans-serif" }}
              >
                {focusSkill.progress}%
              </div>
            </div>
          </div>
        )}

        {/* Overall */}
        <div
          className="rounded-xl p-4 mb-6 animate-fade-up"
          style={{
            background: "oklch(0.16 0.015 210)",
            border: "1px solid oklch(1 0 0 / 0.07)",
            animationDelay: "100ms",
          }}
        >
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm font-semibold" style={{ color: "oklch(0.75 0.01 200)", fontFamily: "'Barlow Condensed', sans-serif" }}>
              Competition Path Overall
            </span>
            <span
              className="text-2xl font-bold"
              style={{ color: "oklch(0.83 0.16 80)", fontFamily: "'Space Grotesk', sans-serif" }}
            >
              {overall}%
            </span>
          </div>
          <div className="h-1.5 rounded-full overflow-hidden" style={{ background: "oklch(1 0 0 / 0.08)" }}>
            <div
              className="h-full rounded-full"
              style={{
                width: `${overall}%`,
                background: "oklch(0.83 0.16 80)",
                transition: "width 1s cubic-bezier(0.23,1,0.32,1)",
              }}
            />
          </div>
        </div>

        {/* Skills */}
        <div className="grid sm:grid-cols-2 gap-4">
          {compSkills.map((skill, i) => (
            <div
              key={skill.name}
              className="rounded-xl p-5 animate-fade-up"
              style={{
                background: skill.focus ? "linear-gradient(135deg, oklch(0.17 0.02 80), oklch(0.16 0.015 210))" : "oklch(0.16 0.015 210)",
                border: skill.focus ? "1px solid oklch(0.83 0.16 80 / 0.25)" : "1px solid oklch(1 0 0 / 0.07)",
                animationDelay: `${140 + i * 40}ms`,
              }}
            >
              <div className="flex items-start justify-between mb-2">
                <h3
                  className="text-base font-bold"
                  style={{ color: "oklch(0.92 0.01 200)", fontFamily: "'Barlow Condensed', sans-serif" }}
                >
                  {skill.name}
                </h3>
                {skill.focus && (
                  <span
                    className="text-xs px-2 py-0.5 rounded-full font-semibold"
                    style={{
                      background: "oklch(0.83 0.16 80 / 0.15)",
                      color: "oklch(0.83 0.16 80)",
                      fontFamily: "'Barlow Condensed', sans-serif",
                      letterSpacing: "0.06em",
                    }}
                  >
                    Focus
                  </span>
                )}
              </div>
              <p className="text-xs mb-3" style={{ color: "oklch(0.50 0.02 210)" }}>
                {skill.description}
              </p>
              <div className="mb-2">
                <div className="flex justify-between mb-1">
                  <span className="text-xs" style={{ color: "oklch(0.45 0.02 210)" }}>Progress</span>
                  <span
                    className="text-xs font-semibold"
                    style={{ color: skill.focus ? "oklch(0.83 0.16 80)" : "oklch(0.76 0.14 175)", fontFamily: "'Space Grotesk', sans-serif" }}
                  >
                    {skill.progress}%
                  </span>
                </div>
                <div className="h-1.5 rounded-full overflow-hidden" style={{ background: "oklch(1 0 0 / 0.08)" }}>
                  <div
                    className="h-full rounded-full"
                    style={{
                      width: `${skill.progress}%`,
                      background: skill.focus ? "oklch(0.83 0.16 80)" : "oklch(0.76 0.14 175)",
                      transition: "width 800ms cubic-bezier(0.23,1,0.32,1)",
                    }}
                  />
                </div>
              </div>
              <p className="text-xs italic" style={{ color: "oklch(0.48 0.02 210)" }}>
                {skill.tip}
              </p>
            </div>
          ))}
        </div>

        <div className="mt-6 animate-fade-up" style={{ animationDelay: "400ms" }}>
          <Link href="/ask-donna">
            <button
              className="flex items-center gap-2 text-sm font-semibold"
              style={{ color: "oklch(0.83 0.16 80)", fontFamily: "'Barlow Condensed', sans-serif", letterSpacing: "0.04em" }}
            >
              Ask DONNA how to prepare for a match <ChevronRight size={15} />
            </button>
          </Link>
        </div>
      </div>
    </AppLayout>
  );
}
