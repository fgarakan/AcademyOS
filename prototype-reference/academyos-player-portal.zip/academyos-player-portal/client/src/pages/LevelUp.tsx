/* Screen 7 — Level-Up Requirements
   Design: Mission Control · Dark Athletic SaaS · Teal accent */

import AppLayout from "@/components/AppLayout";
import { Link } from "wouter";
import { CheckCircle2, Circle, ArrowRight, Lock } from "lucide-react";

interface Requirement {
  label: string;
  detail: string;
  done: boolean;
}

const requirements: Requirement[] = [
  { label: "Prepare earlier",             detail: "Racket back before the ball bounces",            done: true  },
  { label: "Recover after wide balls",    detail: "Reset to the T after each wide ball",            done: false },
  { label: "Use crosscourt under pressure", detail: "Choose the safer target in tough spots",       done: false },
  { label: "Complete mission evidence",   detail: "3 practice sessions + coach observation",        done: false },
  { label: "Coach approval",             detail: "Coach confirms readiness for Orange Ball 3",      done: false },
];

const completed = requirements.filter((r) => r.done).length;
const total = requirements.length;
const pct = Math.round((completed / total) * 100);

export default function LevelUp() {
  return (
    <AppLayout>
      <div className="px-6 py-8 max-w-3xl">
        {/* Header */}
        <div className="mb-8 animate-fade-up">
          <div
            className="text-xs font-semibold tracking-widest uppercase mb-2"
            style={{ color: "oklch(0.83 0.16 80)", fontFamily: "'Barlow Condensed', sans-serif", letterSpacing: "0.14em" }}
          >
            Level Up
          </div>
          <h1
            className="text-4xl font-bold leading-tight mb-1"
            style={{ color: "oklch(0.95 0.01 200)", fontFamily: "'Barlow Condensed', sans-serif" }}
          >
            Your Next Unlock
          </h1>
          <p className="text-sm" style={{ color: "oklch(0.55 0.02 210)" }}>
            Here's what you're building toward — no pressure, just progress.
          </p>
        </div>

        {/* Level comparison */}
        <div
          className="rounded-2xl p-6 mb-6 animate-fade-up"
          style={{
            background: "linear-gradient(135deg, oklch(0.16 0.02 80), oklch(0.17 0.015 210))",
            border: "1px solid oklch(0.83 0.16 80 / 0.25)",
            boxShadow: "0 0 40px oklch(0.83 0.16 80 / 0.06)",
            animationDelay: "60ms",
          }}
        >
          <div className="flex items-center justify-between mb-5">
            {/* Current */}
            <div className="text-center">
              <div className="text-xs font-semibold uppercase tracking-widest mb-2" style={{ color: "oklch(0.55 0.02 210)", fontFamily: "'Barlow Condensed', sans-serif", letterSpacing: "0.10em" }}>
                Current Level
              </div>
              <div
                className="level-badge rounded-2xl px-5 py-3 text-center"
              >
                <div className="text-xs font-semibold uppercase tracking-wide mb-0.5" style={{ fontSize: "9px", letterSpacing: "0.10em" }}>
                  Orange Ball
                </div>
                <div
                  className="text-3xl font-bold leading-none"
                  style={{ fontFamily: "'Space Grotesk', sans-serif" }}
                >
                  2
                </div>
              </div>
            </div>

            {/* Arrow */}
            <div className="flex flex-col items-center gap-1">
              <div className="text-xs" style={{ color: "oklch(0.45 0.02 210)" }}>
                {completed}/{total} done
              </div>
              <ArrowRight size={24} style={{ color: "oklch(0.83 0.16 80)" }} />
              <div
                className="text-xs font-semibold"
                style={{ color: "oklch(0.83 0.16 80)", fontFamily: "'Space Grotesk', sans-serif" }}
              >
                {pct}%
              </div>
            </div>

            {/* Next */}
            <div className="text-center">
              <div className="text-xs font-semibold uppercase tracking-widest mb-2" style={{ color: "oklch(0.55 0.02 210)", fontFamily: "'Barlow Condensed', sans-serif", letterSpacing: "0.10em" }}>
                Next Level
              </div>
              <div
                className="rounded-2xl px-5 py-3 text-center"
                style={{
                  background: "oklch(0.20 0.015 210)",
                  border: "2px dashed oklch(0.83 0.16 80 / 0.4)",
                }}
              >
                <div className="text-xs font-semibold uppercase tracking-wide mb-0.5" style={{ fontSize: "9px", letterSpacing: "0.10em", color: "oklch(0.55 0.02 210)" }}>
                  Orange Ball
                </div>
                <div
                  className="text-3xl font-bold leading-none flex items-center gap-1"
                  style={{ fontFamily: "'Space Grotesk', sans-serif", color: "oklch(0.83 0.16 80)" }}
                >
                  3 <Lock size={16} style={{ color: "oklch(0.83 0.16 80 / 0.5)" }} />
                </div>
              </div>
            </div>
          </div>

          {/* Overall progress bar */}
          <div>
            <div className="flex justify-between mb-1.5">
              <span className="text-xs" style={{ color: "oklch(0.55 0.02 210)" }}>Level progress</span>
              <span className="text-xs font-semibold" style={{ color: "oklch(0.83 0.16 80)", fontFamily: "'Space Grotesk', sans-serif" }}>
                {pct}%
              </span>
            </div>
            <div className="h-2.5 rounded-full overflow-hidden" style={{ background: "oklch(1 0 0 / 0.08)" }}>
              <div
                className="h-full rounded-full"
                style={{
                  width: `${pct}%`,
                  background: "linear-gradient(90deg, oklch(0.83 0.16 80), oklch(0.76 0.18 60))",
                  boxShadow: "0 0 8px oklch(0.83 0.16 80 / 0.5)",
                  transition: "width 1s cubic-bezier(0.23,1,0.32,1)",
                }}
              />
            </div>
          </div>
        </div>

        {/* Requirements list */}
        <div
          className="rounded-xl overflow-hidden animate-fade-up"
          style={{
            border: "1px solid oklch(1 0 0 / 0.07)",
            animationDelay: "120ms",
          }}
        >
          <div
            className="px-5 py-3 border-b"
            style={{ background: "oklch(0.18 0.015 210)", borderColor: "oklch(1 0 0 / 0.07)" }}
          >
            <h2
              className="text-sm font-semibold uppercase tracking-widest"
              style={{ color: "oklch(0.75 0.01 200)", fontFamily: "'Barlow Condensed', sans-serif", letterSpacing: "0.10em" }}
            >
              What You're Building
            </h2>
          </div>
          <div style={{ background: "oklch(0.16 0.015 210)" }}>
            {requirements.map((req, i) => (
              <div
                key={req.label}
                className="flex items-start gap-4 px-5 py-4 animate-fade-up"
                style={{
                  borderBottom: i < requirements.length - 1 ? "1px solid oklch(1 0 0 / 0.05)" : "none",
                  animationDelay: `${160 + i * 50}ms`,
                }}
              >
                <div className="mt-0.5">
                  {req.done ? (
                    <CheckCircle2 size={18} style={{ color: "oklch(0.72 0.15 140)" }} />
                  ) : (
                    <Circle size={18} style={{ color: "oklch(0.35 0.02 210)" }} />
                  )}
                </div>
                <div className="flex-1">
                  <div
                    className="text-sm font-semibold mb-0.5"
                    style={{
                      color: req.done ? "oklch(0.72 0.15 140)" : "oklch(0.85 0.01 200)",
                      fontFamily: "'Barlow Condensed', sans-serif",
                      textDecoration: req.done ? "line-through" : "none",
                      textDecorationColor: "oklch(0.72 0.15 140 / 0.5)",
                    }}
                  >
                    {req.label}
                  </div>
                  <div className="text-xs" style={{ color: "oklch(0.50 0.02 210)" }}>
                    {req.detail}
                  </div>
                </div>
                {req.done && (
                  <span
                    className="text-xs px-2 py-0.5 rounded-full font-semibold"
                    style={{
                      background: "oklch(0.72 0.15 140 / 0.12)",
                      color: "oklch(0.72 0.15 140)",
                      fontFamily: "'Barlow Condensed', sans-serif",
                      letterSpacing: "0.06em",
                    }}
                  >
                    Done
                  </span>
                )}
              </div>
            ))}
          </div>
        </div>

        {/* Encouragement */}
        <div
          className="rounded-xl p-5 mt-4 animate-fade-up"
          style={{
            background: "oklch(0.16 0.015 210)",
            border: "1px solid oklch(0.76 0.14 175 / 0.15)",
            animationDelay: "440ms",
          }}
        >
          <p className="text-sm leading-relaxed" style={{ color: "oklch(0.70 0.02 210)" }}>
            You're <span style={{ color: "oklch(0.83 0.16 80)", fontWeight: 600 }}>1 out of 5</span> requirements complete. Keep working on your Wide Ball Recovery mission — that's the key to unlocking the next two requirements. You're on the right track.
          </p>
          <div className="mt-3">
            <Link href="/mission-detail">
              <button
                className="flex items-center gap-2 text-sm font-semibold"
                style={{ color: "oklch(0.76 0.14 175)", fontFamily: "'Barlow Condensed', sans-serif", letterSpacing: "0.04em" }}
              >
                Continue your mission <ArrowRight size={14} />
              </button>
            </Link>
          </div>
        </div>
      </div>
    </AppLayout>
  );
}
