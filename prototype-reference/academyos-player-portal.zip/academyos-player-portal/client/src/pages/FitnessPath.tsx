/* Screen 6 — Fitness Path Progress
   Design: Mission Control · Dark Athletic SaaS · Teal accent */

import AppLayout from "@/components/AppLayout";
import { Activity } from "lucide-react";

interface FitnessItem {
  name: string;
  description: string;
  progress: number;
  focus: boolean;
  color: string;
}

const fitnessItems: FitnessItem[] = [
  {
    name: "Mobility",
    description: "Hip, shoulder, and ankle range of motion",
    progress: 60,
    focus: false,
    color: "oklch(0.72 0.15 140)",
  },
  {
    name: "Coordination",
    description: "Hand-eye and footwork coordination",
    progress: 65,
    focus: false,
    color: "oklch(0.76 0.14 175)",
  },
  {
    name: "Speed",
    description: "First-step quickness and sprint speed",
    progress: 50,
    focus: false,
    color: "oklch(0.83 0.16 80)",
  },
  {
    name: "Agility",
    description: "Change of direction and court coverage",
    progress: 55,
    focus: true,
    color: "oklch(0.76 0.14 175)",
  },
  {
    name: "Strength",
    description: "Core and lower body stability",
    progress: 42,
    focus: false,
    color: "oklch(0.65 0.18 250)",
  },
  {
    name: "Recovery",
    description: "Balance recovery after wide movement",
    progress: 48,
    focus: true,
    color: "oklch(0.76 0.14 175)",
  },
  {
    name: "Tennis Transfer",
    description: "Applying fitness gains on the court",
    progress: 52,
    focus: false,
    color: "oklch(0.60 0.20 30)",
  },
];

function CircleProgress({ value, color, size = 64 }: { value: number; color: string; size?: number }) {
  const r = (size - 8) / 2;
  const circ = 2 * Math.PI * r;
  const offset = circ - (value / 100) * circ;
  return (
    <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`} className="shrink-0">
      <circle cx={size / 2} cy={size / 2} r={r} fill="none" stroke="oklch(1 0 0 / 0.08)" strokeWidth={5} />
      <circle
        cx={size / 2}
        cy={size / 2}
        r={r}
        fill="none"
        stroke={color}
        strokeWidth={5}
        strokeLinecap="round"
        strokeDasharray={circ}
        strokeDashoffset={offset}
        transform={`rotate(-90 ${size / 2} ${size / 2})`}
        style={{ transition: "stroke-dashoffset 800ms cubic-bezier(0.23,1,0.32,1)", filter: `drop-shadow(0 0 4px ${color}60)` }}
      />
      <text
        x={size / 2}
        y={size / 2 + 5}
        textAnchor="middle"
        fill={color}
        fontSize="13"
        fontFamily="'Space Grotesk', sans-serif"
        fontWeight="600"
      >
        {value}%
      </text>
    </svg>
  );
}

export default function FitnessPath() {
  const overall = Math.round(fitnessItems.reduce((a, s) => a + s.progress, 0) / fitnessItems.length);
  const focusItems = fitnessItems.filter((f) => f.focus);

  return (
    <AppLayout>
      <div className="px-6 py-8 max-w-4xl">
        {/* Header */}
        <div className="mb-8 animate-fade-up">
          <div
            className="text-xs font-semibold tracking-widest uppercase mb-2"
            style={{ color: "oklch(0.72 0.15 140)", fontFamily: "'Barlow Condensed', sans-serif", letterSpacing: "0.14em" }}
          >
            Fitness Path
          </div>
          <h1
            className="text-4xl font-bold leading-tight mb-1"
            style={{ color: "oklch(0.95 0.01 200)", fontFamily: "'Barlow Condensed', sans-serif" }}
          >
            Body Development
          </h1>
          <p className="text-sm" style={{ color: "oklch(0.55 0.02 210)" }}>
            Building the athletic foundation for your tennis game.
          </p>
        </div>

        {/* Focus highlight */}
        <div
          className="rounded-2xl p-5 mb-6 animate-fade-up"
          style={{
            background: "linear-gradient(135deg, oklch(0.16 0.02 175), oklch(0.18 0.015 210))",
            border: "1px solid oklch(0.76 0.14 175 / 0.25)",
            animationDelay: "60ms",
          }}
        >
          <div className="flex items-center gap-2 mb-2">
            <Activity size={14} style={{ color: "oklch(0.76 0.14 175)" }} />
            <span
              className="text-xs font-semibold uppercase tracking-widest"
              style={{ color: "oklch(0.76 0.14 175)", fontFamily: "'Barlow Condensed', sans-serif", letterSpacing: "0.12em" }}
            >
              Current Body Focus
            </span>
          </div>
          <p
            className="text-xl font-bold mb-1"
            style={{ color: "oklch(0.95 0.01 200)", fontFamily: "'Barlow Condensed', sans-serif" }}
          >
            "Recover to balance after wide movement."
          </p>
          <p className="text-sm" style={{ color: "oklch(0.60 0.02 210)" }}>
            Agility and recovery are your current fitness priorities — directly connected to your Wide Ball Recovery mission.
          </p>
          <div className="flex gap-3 mt-3">
            {focusItems.map((f) => (
              <div
                key={f.name}
                className="flex items-center gap-2 px-3 py-1.5 rounded-lg"
                style={{ background: "oklch(0.76 0.14 175 / 0.10)", border: "1px solid oklch(0.76 0.14 175 / 0.2)" }}
              >
                <span className="text-xs font-semibold" style={{ color: "oklch(0.76 0.14 175)" }}>
                  {f.name}
                </span>
                <span
                  className="text-xs"
                  style={{ color: "oklch(0.76 0.14 175)", fontFamily: "'Space Grotesk', sans-serif" }}
                >
                  {f.progress}%
                </span>
              </div>
            ))}
          </div>
        </div>

        {/* Overall ring */}
        <div
          className="rounded-xl p-5 mb-6 flex items-center gap-6 animate-fade-up"
          style={{
            background: "oklch(0.16 0.015 210)",
            border: "1px solid oklch(1 0 0 / 0.07)",
            animationDelay: "100ms",
          }}
        >
          <CircleProgress value={overall} color="oklch(0.72 0.15 140)" size={72} />
          <div>
            <div
              className="text-sm font-semibold mb-0.5"
              style={{ color: "oklch(0.72 0.15 140)", fontFamily: "'Barlow Condensed', sans-serif", letterSpacing: "0.06em" }}
            >
              Fitness Path Overall
            </div>
            <div
              className="text-3xl font-bold"
              style={{ color: "oklch(0.95 0.01 200)", fontFamily: "'Space Grotesk', sans-serif" }}
            >
              {overall}%
            </div>
            <div className="text-xs mt-0.5" style={{ color: "oklch(0.50 0.02 210)" }}>
              Across 7 fitness areas
            </div>
          </div>
        </div>

        {/* Fitness grid */}
        <div className="grid sm:grid-cols-2 gap-4">
          {fitnessItems.map((item, i) => (
            <div
              key={item.name}
              className="rounded-xl p-4 flex items-center gap-4 animate-fade-up"
              style={{
                background: item.focus ? "linear-gradient(135deg, oklch(0.17 0.02 175), oklch(0.16 0.015 210))" : "oklch(0.16 0.015 210)",
                border: item.focus ? "1px solid oklch(0.76 0.14 175 / 0.2)" : "1px solid oklch(1 0 0 / 0.07)",
                animationDelay: `${140 + i * 40}ms`,
              }}
            >
              <CircleProgress value={item.progress} color={item.color} size={56} />
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 mb-0.5">
                  <h3
                    className="text-base font-bold"
                    style={{ color: "oklch(0.92 0.01 200)", fontFamily: "'Barlow Condensed', sans-serif" }}
                  >
                    {item.name}
                  </h3>
                  {item.focus && (
                    <span
                      className="text-xs px-1.5 py-0.5 rounded-full"
                      style={{
                        background: "oklch(0.76 0.14 175 / 0.12)",
                        color: "oklch(0.76 0.14 175)",
                        fontFamily: "'Barlow Condensed', sans-serif",
                        fontSize: "10px",
                        letterSpacing: "0.06em",
                      }}
                    >
                      Focus
                    </span>
                  )}
                </div>
                <p className="text-xs" style={{ color: "oklch(0.50 0.02 210)" }}>
                  {item.description}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </AppLayout>
  );
}
