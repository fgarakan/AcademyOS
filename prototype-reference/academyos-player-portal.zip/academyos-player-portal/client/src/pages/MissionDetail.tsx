/* Screen 3 — Current Mission Detail
   Design: Mission Control · Dark Athletic SaaS · Teal accent */

import { Link } from "wouter";
import AppLayout from "@/components/AppLayout";
import { Target, Eye, CheckCircle2, Dumbbell, FileText, ArrowRight, ChevronLeft, Info } from "lucide-react";

function SectionCard({
  icon: Icon,
  iconColor,
  title,
  children,
  delay = 0,
}: {
  icon: React.ElementType;
  iconColor: string;
  title: string;
  children: React.ReactNode;
  delay?: number;
}) {
  return (
    <div
      className="rounded-xl p-5 animate-fade-up"
      style={{
        background: "oklch(0.16 0.015 210)",
        border: "1px solid oklch(1 0 0 / 0.07)",
        animationDelay: `${delay}ms`,
      }}
    >
      <div className="flex items-center gap-2.5 mb-3">
        <div
          className="w-7 h-7 rounded-lg flex items-center justify-center"
          style={{ background: `${iconColor}18` }}
        >
          <Icon size={14} style={{ color: iconColor }} />
        </div>
        <h3
          className="text-sm font-semibold uppercase tracking-widest"
          style={{ color: iconColor, fontFamily: "'Barlow Condensed', sans-serif", letterSpacing: "0.10em" }}
        >
          {title}
        </h3>
      </div>
      {children}
    </div>
  );
}

export default function MissionDetail() {
  return (
    <AppLayout>
      <div className="px-6 py-8 max-w-3xl">
        {/* Back */}
        <Link href="/mission-map">
          <button
            className="flex items-center gap-1.5 text-sm mb-6 transition-colors duration-150"
            style={{ color: "oklch(0.55 0.02 210)" }}
            onMouseEnter={(e) => { (e.currentTarget as HTMLButtonElement).style.color = "oklch(0.76 0.14 175)"; }}
            onMouseLeave={(e) => { (e.currentTarget as HTMLButtonElement).style.color = "oklch(0.55 0.02 210)"; }}
          >
            <ChevronLeft size={15} /> Back to Mission Map
          </button>
        </Link>

        {/* Header */}
        <div
          className="rounded-2xl p-6 mb-6 animate-fade-up"
          style={{
            background: "linear-gradient(135deg, oklch(0.16 0.02 175), oklch(0.18 0.015 210))",
            border: "1px solid oklch(0.76 0.14 175 / 0.3)",
            boxShadow: "0 0 40px oklch(0.76 0.14 175 / 0.08)",
          }}
        >
          <div
            className="text-xs font-semibold tracking-widest uppercase mb-2"
            style={{ color: "oklch(0.76 0.14 175)", fontFamily: "'Barlow Condensed', sans-serif", letterSpacing: "0.14em" }}
          >
            Active Mission
          </div>
          <h1
            className="text-3xl font-bold mb-2 leading-tight"
            style={{ color: "oklch(0.95 0.01 200)", fontFamily: "'Barlow Condensed', sans-serif" }}
          >
            Wide Ball Recovery
          </h1>
          <p className="text-sm mb-4" style={{ color: "oklch(0.65 0.02 210)" }}>
            Recover to balance after moving wide and play a safer crosscourt ball.
          </p>

          {/* Progress */}
          <div className="mb-4">
            <div className="flex justify-between mb-1.5">
              <span className="text-xs" style={{ color: "oklch(0.55 0.02 210)" }}>Mission Progress</span>
              <span className="text-xs font-semibold" style={{ color: "oklch(0.76 0.14 175)", fontFamily: "'Space Grotesk', sans-serif" }}>62%</span>
            </div>
            <div className="h-2 rounded-full overflow-hidden" style={{ background: "oklch(1 0 0 / 0.08)" }}>
              <div
                className="h-full rounded-full progress-teal"
                style={{ width: "62%", transition: "width 800ms cubic-bezier(0.23,1,0.32,1)" }}
              />
            </div>
          </div>

          <div className="flex gap-3">
            <Link href="/practice">
              <button className="btn-teal flex items-center gap-2 px-5 py-2.5 rounded-lg text-sm">
                Start Practice <ArrowRight size={14} />
              </button>
            </Link>
            <Link href="/ask-donna">
              <button
                className="flex items-center gap-2 px-4 py-2.5 rounded-lg text-sm font-semibold"
                style={{
                  background: "oklch(0.76 0.14 175 / 0.10)",
                  border: "1px solid oklch(0.76 0.14 175 / 0.2)",
                  color: "oklch(0.76 0.14 175)",
                  fontFamily: "'Barlow Condensed', sans-serif",
                  letterSpacing: "0.04em",
                }}
              >
                Ask DONNA
              </button>
            </Link>
          </div>
        </div>

        {/* Detail sections */}
        <div className="grid gap-4">
          <SectionCard icon={Target} iconColor="oklch(0.76 0.14 175)" title="Mission Goal" delay={80}>
            <p className="text-sm leading-relaxed" style={{ color: "oklch(0.75 0.01 200)" }}>
              Recover to balance after moving wide and play a safer crosscourt ball. This mission trains your ability to stay composed under pressure and choose the high-percentage shot.
            </p>
          </SectionCard>

          <SectionCard icon={Info} iconColor="oklch(0.83 0.16 80)" title="Why It Matters" delay={120}>
            <p className="text-sm leading-relaxed" style={{ color: "oklch(0.75 0.01 200)" }}>
              When you're pulled wide, the temptation is to go for a winner. But recovering first and playing crosscourt keeps you in the point and reduces unforced errors. This is a key skill for Orange Ball 3.
            </p>
          </SectionCard>

          <SectionCard icon={Dumbbell} iconColor="oklch(0.72 0.15 140)" title="What To Do" delay={160}>
            <ul className="space-y-2">
              {[
                "3 rounds of wide-ball shadow movement",
                "Short, quality reps — focus on recovery step",
                "After each wide ball, reset to the T position",
                "Practice crosscourt target placement with a cone",
              ].map((item, i) => (
                <li key={i} className="flex items-start gap-2.5 text-sm" style={{ color: "oklch(0.75 0.01 200)" }}>
                  <div
                    className="w-5 h-5 rounded-full flex items-center justify-center shrink-0 mt-0.5 text-xs font-bold"
                    style={{
                      background: "oklch(0.72 0.15 140 / 0.15)",
                      color: "oklch(0.72 0.15 140)",
                      fontFamily: "'Space Grotesk', sans-serif",
                    }}
                  >
                    {i + 1}
                  </div>
                  {item}
                </li>
              ))}
            </ul>
          </SectionCard>

          <SectionCard icon={Eye} iconColor="oklch(0.65 0.18 250)" title="Coach Watch-For" delay={200}>
            <p className="text-sm leading-relaxed" style={{ color: "oklch(0.75 0.01 200)" }}>
              Coach Martinez is watching for your recovery step after wide balls. Are you stopping and resetting, or are you still off-balance when you hit? The goal is a controlled, balanced contact point.
            </p>
          </SectionCard>

          <SectionCard icon={CheckCircle2} iconColor="oklch(0.76 0.14 175)" title="How To Know You Improved" delay={240}>
            <ul className="space-y-2">
              {[
                "You can recover to the T after 8/10 wide balls",
                "Your crosscourt ball lands in the target zone",
                "Coach confirms recovery in a match situation",
                "You complete the practice evidence (3 sessions)",
              ].map((item, i) => (
                <li key={i} className="flex items-start gap-2 text-sm" style={{ color: "oklch(0.75 0.01 200)" }}>
                  <CheckCircle2 size={14} className="shrink-0 mt-0.5" style={{ color: "oklch(0.76 0.14 175)" }} />
                  {item}
                </li>
              ))}
            </ul>
          </SectionCard>

          <SectionCard icon={FileText} iconColor="oklch(0.83 0.16 80)" title="Evidence Needed" delay={280}>
            <div className="space-y-3">
              {[
                { label: "Practice sessions completed", current: 1, required: 3 },
                { label: "Coach observation", current: 0, required: 1 },
                { label: "Match application", current: 0, required: 1 },
              ].map((item) => (
                <div key={item.label}>
                  <div className="flex justify-between mb-1">
                    <span className="text-xs" style={{ color: "oklch(0.65 0.02 210)" }}>{item.label}</span>
                    <span
                      className="text-xs font-semibold"
                      style={{ color: "oklch(0.83 0.16 80)", fontFamily: "'Space Grotesk', sans-serif" }}
                    >
                      {item.current}/{item.required}
                    </span>
                  </div>
                  <div className="h-1.5 rounded-full overflow-hidden" style={{ background: "oklch(1 0 0 / 0.08)" }}>
                    <div
                      className="h-full rounded-full"
                      style={{
                        width: `${(item.current / item.required) * 100}%`,
                        background: "oklch(0.83 0.16 80)",
                        transition: "width 800ms cubic-bezier(0.23,1,0.32,1)",
                      }}
                    />
                  </div>
                </div>
              ))}
            </div>
          </SectionCard>
        </div>
      </div>
    </AppLayout>
  );
}
