/* Screen 4 — Skill Path Progress
   Design: Mission Control · Dark Athletic SaaS · Teal accent */

import AppLayout from "@/components/AppLayout";
import { Link } from "wouter";
import { ChevronRight } from "lucide-react";

interface SkillItem {
  name: string;
  sub: string[];
  progress: number;
  status: "strong" | "active" | "developing";
  note: string;
}

const skills: SkillItem[] = [
  {
    name: "Forehand",
    sub: ["Preparation", "Contact", "Finish"],
    progress: 72,
    status: "strong",
    note: "Solid contact point. Working on finish consistency.",
  },
  {
    name: "Backhand",
    sub: ["Preparation", "Contact", "Finish"],
    progress: 55,
    status: "active",
    note: "Current focus: earlier preparation on the backhand side.",
  },
  {
    name: "Serve",
    sub: ["Toss", "Trophy Position", "Contact"],
    progress: 48,
    status: "developing",
    note: "Toss consistency is the key unlock for serve improvement.",
  },
  {
    name: "Volley",
    sub: ["Grip", "Contact", "Recovery"],
    progress: 40,
    status: "developing",
    note: "Developing compact swing and soft hands at the net.",
  },
  {
    name: "Movement / Footwork",
    sub: ["Split Step", "First Step", "Recovery"],
    progress: 65,
    status: "active",
    note: "Wide ball recovery is the active mission. Split-step timing is next.",
  },
  {
    name: "Preparation",
    sub: ["Early Turn", "Racket Back", "Ready Position"],
    progress: 68,
    status: "active",
    note: "Early prep mission completed. Maintaining consistency.",
  },
];

const statusColors: Record<SkillItem["status"], { bg: string; text: string; label: string }> = {
  strong:     { bg: "oklch(0.72 0.15 140 / 0.12)", text: "oklch(0.72 0.15 140)", label: "Strong" },
  active:     { bg: "oklch(0.76 0.14 175 / 0.12)", text: "oklch(0.76 0.14 175)", label: "Active Focus" },
  developing: { bg: "oklch(0.83 0.16 80 / 0.12)",  text: "oklch(0.83 0.16 80)",  label: "Developing" },
};

function SkillCard({ skill, delay }: { skill: SkillItem; delay: number }) {
  const s = statusColors[skill.status];
  return (
    <div
      className="rounded-xl p-5 card-glow animate-fade-up"
      style={{
        background: "oklch(0.16 0.015 210)",
        animationDelay: `${delay}ms`,
      }}
    >
      <div className="flex items-start justify-between mb-3">
        <div>
          <h3
            className="text-lg font-bold leading-tight"
            style={{ color: "oklch(0.92 0.01 200)", fontFamily: "'Barlow Condensed', sans-serif" }}
          >
            {skill.name}
          </h3>
          <div className="flex flex-wrap gap-1.5 mt-1">
            {skill.sub.map((s) => (
              <span
                key={s}
                className="text-xs px-2 py-0.5 rounded-full"
                style={{ background: "oklch(1 0 0 / 0.06)", color: "oklch(0.55 0.02 210)" }}
              >
                {s}
              </span>
            ))}
          </div>
        </div>
        <span
          className="text-xs px-2.5 py-1 rounded-full font-semibold shrink-0"
          style={{ background: s.bg, color: s.text, fontFamily: "'Barlow Condensed', sans-serif", letterSpacing: "0.06em" }}
        >
          {s.label}
        </span>
      </div>

      {/* Progress */}
      <div className="mb-3">
        <div className="flex justify-between mb-1.5">
          <span className="text-xs" style={{ color: "oklch(0.50 0.02 210)" }}>Progress</span>
          <span
            className="text-xs font-semibold"
            style={{ color: s.text, fontFamily: "'Space Grotesk', sans-serif" }}
          >
            {skill.progress}%
          </span>
        </div>
        <div className="h-2 rounded-full overflow-hidden" style={{ background: "oklch(1 0 0 / 0.08)" }}>
          <div
            className="h-full rounded-full"
            style={{
              width: `${skill.progress}%`,
              background: s.text,
              boxShadow: skill.status === "active" ? `0 0 6px ${s.text}60` : "none",
              transition: "width 800ms cubic-bezier(0.23,1,0.32,1)",
            }}
          />
        </div>
      </div>

      <p className="text-xs leading-relaxed" style={{ color: "oklch(0.55 0.02 210)" }}>
        {skill.note}
      </p>
    </div>
  );
}

export default function SkillPath() {
  const overall = Math.round(skills.reduce((a, s) => a + s.progress, 0) / skills.length);

  return (
    <AppLayout>
      <div className="px-6 py-8 max-w-4xl">
        {/* Header */}
        <div className="mb-8 animate-fade-up">
          <div
            className="text-xs font-semibold tracking-widest uppercase mb-2"
            style={{ color: "oklch(0.76 0.14 175)", fontFamily: "'Barlow Condensed', sans-serif", letterSpacing: "0.14em" }}
          >
            Skill Path
          </div>
          <h1
            className="text-4xl font-bold leading-tight mb-1"
            style={{ color: "oklch(0.95 0.01 200)", fontFamily: "'Barlow Condensed', sans-serif" }}
          >
            Technical Development
          </h1>
          <p className="text-sm" style={{ color: "oklch(0.55 0.02 210)" }}>
            Your technical skills — not grades, just your current journey.
          </p>
        </div>

        {/* Overall */}
        <div
          className="rounded-2xl p-5 mb-6 animate-fade-up"
          style={{
            background: "linear-gradient(135deg, oklch(0.16 0.02 175), oklch(0.18 0.015 210))",
            border: "1px solid oklch(0.76 0.14 175 / 0.2)",
            animationDelay: "60ms",
          }}
        >
          <div className="flex items-center justify-between">
            <div>
              <div className="text-sm font-semibold mb-1" style={{ color: "oklch(0.76 0.14 175)", fontFamily: "'Barlow Condensed', sans-serif", letterSpacing: "0.06em" }}>
                Overall Skill Progress
              </div>
              <div
                className="text-4xl font-bold"
                style={{ color: "oklch(0.95 0.01 200)", fontFamily: "'Space Grotesk', sans-serif" }}
              >
                {overall}%
              </div>
            </div>
            <div className="text-right">
              <div className="text-xs mb-1" style={{ color: "oklch(0.55 0.02 210)" }}>Level</div>
              <div
                className="level-badge rounded-xl px-4 py-2 text-lg font-bold"
                style={{ fontFamily: "'Barlow Condensed', sans-serif" }}
              >
                Orange Ball 2
              </div>
            </div>
          </div>
          <div className="mt-4 h-2 rounded-full overflow-hidden" style={{ background: "oklch(1 0 0 / 0.08)" }}>
            <div
              className="h-full rounded-full progress-teal"
              style={{ width: `${overall}%`, transition: "width 1s cubic-bezier(0.23,1,0.32,1)" }}
            />
          </div>
        </div>

        {/* Skills grid */}
        <div className="grid sm:grid-cols-2 gap-4">
          {skills.map((skill, i) => (
            <SkillCard key={skill.name} skill={skill} delay={80 + i * 40} />
          ))}
        </div>

        {/* CTA */}
        <div className="mt-6 animate-fade-up" style={{ animationDelay: "400ms" }}>
          <Link href="/mission-detail">
            <button
              className="flex items-center gap-2 text-sm font-semibold"
              style={{ color: "oklch(0.76 0.14 175)", fontFamily: "'Barlow Condensed', sans-serif", letterSpacing: "0.04em" }}
            >
              Work on your active mission <ChevronRight size={15} />
            </button>
          </Link>
        </div>
      </div>
    </AppLayout>
  );
}
