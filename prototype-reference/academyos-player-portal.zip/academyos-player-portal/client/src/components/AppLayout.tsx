/* AppLayout — Persistent sidebar + main content area
   Design: Mission Control · Dark Athletic SaaS · Teal accent */

import { useState } from "react";
import { Link, useLocation } from "wouter";
import {
  Home, Map, Target, Zap, Trophy, Activity,
  ArrowUp, Dumbbell, Star, MessageCircle, Menu, X, ChevronRight
} from "lucide-react";

const navItems = [
  { href: "/",                icon: Home,        label: "My Training" },
  { href: "/mission-map",     icon: Map,         label: "Mission Map" },
  { href: "/mission-detail",  icon: Target,      label: "Current Mission" },
  { href: "/skill-path",      icon: Zap,         label: "Skill Path" },
  { href: "/competition-path",icon: Trophy,      label: "Competition Path" },
  { href: "/fitness-path",    icon: Activity,    label: "Fitness Path" },
  { href: "/level-up",        icon: ArrowUp,     label: "Level Up" },
  { href: "/practice",        icon: Dumbbell,    label: "Practice" },
  { href: "/celebration",     icon: Star,        label: "Achievements" },
  { href: "/ask-donna",       icon: MessageCircle, label: "Ask DONNA" },
];

interface AppLayoutProps {
  children: React.ReactNode;
}

export default function AppLayout({ children }: AppLayoutProps) {
  const [location] = useLocation();
  const [mobileOpen, setMobileOpen] = useState(false);

  return (
    <div className="min-h-screen flex" style={{ background: "oklch(0.13 0.015 210)" }}>
      {/* Desktop Sidebar */}
      <aside
        className="hidden lg:flex flex-col w-60 shrink-0 border-r"
        style={{
          background: "oklch(0.12 0.015 210)",
          borderColor: "oklch(1 0 0 / 0.07)",
          position: "sticky",
          top: 0,
          height: "100vh",
        }}
      >
        {/* Logo */}
        <div className="px-5 py-5 border-b" style={{ borderColor: "oklch(1 0 0 / 0.07)" }}>
          <div className="flex items-center gap-2.5">
            <div
              className="w-8 h-8 rounded-lg flex items-center justify-center text-xs font-bold"
              style={{
                background: "linear-gradient(135deg, oklch(0.76 0.14 175), oklch(0.65 0.16 175))",
                color: "oklch(0.10 0.01 175)",
                fontFamily: "'Barlow Condensed', sans-serif",
                fontSize: "11px",
                letterSpacing: "0.05em",
              }}
            >
              AOS
            </div>
            <div>
              <div
                className="text-xs font-semibold tracking-widest uppercase"
                style={{ color: "oklch(0.76 0.14 175)", fontFamily: "'Barlow Condensed', sans-serif", letterSpacing: "0.12em" }}
              >
                AcademyOS
              </div>
              <div className="text-xs" style={{ color: "oklch(0.50 0.02 210)" }}>
                Player Portal
              </div>
            </div>
          </div>
        </div>

        {/* Player identity */}
        <div className="px-4 py-4 border-b" style={{ borderColor: "oklch(1 0 0 / 0.07)" }}>
          <div className="flex items-center gap-3">
            <div
              className="w-9 h-9 rounded-full flex items-center justify-center text-sm font-bold shrink-0"
              style={{
                background: "linear-gradient(135deg, oklch(0.83 0.16 80), oklch(0.76 0.18 60))",
                color: "oklch(0.12 0.01 80)",
                fontFamily: "'Barlow Condensed', sans-serif",
              }}
            >
              AC
            </div>
            <div className="min-w-0">
              <div className="text-sm font-semibold truncate" style={{ color: "oklch(0.90 0.01 200)" }}>
                Alex Chen
              </div>
              <div
                className="text-xs flex items-center gap-1"
                style={{ color: "oklch(0.76 0.14 175)", fontFamily: "'Space Grotesk', sans-serif" }}
              >
                <span
                  className="inline-block w-2 h-2 rounded-full"
                  style={{ background: "oklch(0.76 0.14 175)" }}
                />
                Orange Ball 2
              </div>
            </div>
          </div>
        </div>

        {/* Nav */}
        <nav className="flex-1 px-3 py-3 overflow-y-auto">
          <div className="space-y-0.5">
            {navItems.map(({ href, icon: Icon, label }) => {
              const isActive = location === href;
              return (
                <Link key={href} href={href}>
                  <div
                    className="nav-item"
                    style={
                      isActive
                        ? {
                            background: "oklch(0.76 0.14 175 / 0.12)",
                            color: "oklch(0.76 0.14 175)",
                            borderLeft: "3px solid oklch(0.76 0.14 175)",
                            paddingLeft: "calc(0.875rem - 3px)",
                          }
                        : {}
                    }
                  >
                    <Icon size={16} />
                    <span>{label}</span>
                    {isActive && (
                      <ChevronRight size={12} className="ml-auto opacity-60" />
                    )}
                  </div>
                </Link>
              );
            })}
          </div>
        </nav>

        {/* Footer */}
        <div className="px-4 py-4 border-t" style={{ borderColor: "oklch(1 0 0 / 0.07)" }}>
          <div className="text-xs" style={{ color: "oklch(0.40 0.02 210)" }}>
            Powered by AnglesOS
          </div>
        </div>
      </aside>

      {/* Mobile header */}
      <div
        className="lg:hidden fixed top-0 left-0 right-0 z-50 flex items-center justify-between px-4 py-3 border-b"
        style={{
          background: "oklch(0.12 0.015 210)",
          borderColor: "oklch(1 0 0 / 0.07)",
        }}
      >
        <div className="flex items-center gap-2">
          <div
            className="w-7 h-7 rounded-md flex items-center justify-center text-xs font-bold"
            style={{
              background: "linear-gradient(135deg, oklch(0.76 0.14 175), oklch(0.65 0.16 175))",
              color: "oklch(0.10 0.01 175)",
              fontFamily: "'Barlow Condensed', sans-serif",
            }}
          >
            AOS
          </div>
          <span
            className="text-sm font-semibold"
            style={{ color: "oklch(0.90 0.01 200)", fontFamily: "'Barlow Condensed', sans-serif", letterSpacing: "0.04em" }}
          >
            Player Portal
          </span>
        </div>
        <button
          onClick={() => setMobileOpen(!mobileOpen)}
          className="p-1.5 rounded-lg"
          style={{ color: "oklch(0.70 0.02 210)" }}
        >
          {mobileOpen ? <X size={20} /> : <Menu size={20} />}
        </button>
      </div>

      {/* Mobile nav drawer */}
      {mobileOpen && (
        <div
          className="lg:hidden fixed inset-0 z-40 flex"
          onClick={() => setMobileOpen(false)}
        >
          <div
            className="w-64 h-full flex flex-col pt-14 border-r"
            style={{
              background: "oklch(0.12 0.015 210)",
              borderColor: "oklch(1 0 0 / 0.07)",
            }}
            onClick={(e) => e.stopPropagation()}
          >
            <nav className="flex-1 px-3 py-3 overflow-y-auto">
              <div className="space-y-0.5">
                {navItems.map(({ href, icon: Icon, label }) => {
                  const isActive = location === href;
                  return (
                    <Link key={href} href={href}>
                      <div
                        className="nav-item"
                        style={
                          isActive
                            ? {
                                background: "oklch(0.76 0.14 175 / 0.12)",
                                color: "oklch(0.76 0.14 175)",
                                borderLeft: "3px solid oklch(0.76 0.14 175)",
                                paddingLeft: "calc(0.875rem - 3px)",
                              }
                            : {}
                        }
                        onClick={() => setMobileOpen(false)}
                      >
                        <Icon size={16} />
                        <span>{label}</span>
                      </div>
                    </Link>
                  );
                })}
              </div>
            </nav>
          </div>
          <div className="flex-1" style={{ background: "oklch(0 0 0 / 0.5)" }} />
        </div>
      )}

      {/* Main content */}
      <main className="flex-1 min-w-0 lg:pt-0 pt-14 overflow-x-hidden">
        {/* Top bar on desktop */}
        <div
          className="hidden lg:flex items-center justify-between px-6 py-3 border-b"
          style={{ borderColor: "oklch(1 0 0 / 0.06)", background: "oklch(0.13 0.015 210)" }}
        >
          <div className="flex items-center gap-2">
            {navItems.map(({ href, label }) =>
              location === href ? (
                <span
                  key={href}
                  className="text-sm font-semibold"
                  style={{ color: "oklch(0.85 0.01 200)", fontFamily: "'Barlow Condensed', sans-serif", letterSpacing: "0.04em" }}
                >
                  {label}
                </span>
              ) : null
            )}
          </div>
          <div
            className="text-xs px-2.5 py-1 rounded-full"
            style={{ background: "oklch(0.76 0.14 175 / 0.10)", color: "oklch(0.76 0.14 175)", fontFamily: "'Barlow Condensed', sans-serif", letterSpacing: "0.06em" }}
          >
            Orange Ball 2
          </div>
        </div>
        {children}
      </main>
    </div>
  );
}
