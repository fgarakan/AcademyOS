/**
 * Screen 7 — Attendance Exception Flow
 * Design: Premium Sports App, dark #0d1117, teal accent
 * Handle: everyone present, absences, unexpected players, early departures
 */
import { useState } from "react";
import { Link } from "wouter";
import PortalLayout from "@/components/PortalLayout";
import { CheckCircle2, UserX, UserPlus, UserMinus, AlertTriangle, ChevronRight, Check } from "lucide-react";

const ROSTERED_PLAYERS = [
  { name: "Sarah Chen", initials: "SC" },
  { name: "Marcus Thompson", initials: "MT" },
  { name: "Lily Rodriguez", initials: "LR" },
  { name: "James Park", initials: "JP" },
  { name: "Emma Wilson", initials: "EW" },
  { name: "Noah Kim", initials: "NK" },
  { name: "Ava Martinez", initials: "AM" },
  { name: "Ethan Lee", initials: "EL" },
];

type AttendanceStatus = "present" | "absent" | "early-leave";

export default function AttendanceException() {
  const [attendance, setAttendance] = useState<Record<string, AttendanceStatus>>(
    Object.fromEntries(ROSTERED_PLAYERS.map(p => [p.name, "present"]))
  );
  const [unrosteredName, setUnrosteredName] = useState("");
  const [unrosteredPlayers, setUnrosteredPlayers] = useState<string[]>([]);
  const [showUnrosteredWarning, setShowUnrosteredWarning] = useState(false);
  const [allPresent, setAllPresent] = useState(false);

  const toggleStatus = (name: string) => {
    setAttendance(prev => {
      const current = prev[name];
      const next: AttendanceStatus =
        current === "present" ? "absent" :
        current === "absent" ? "early-leave" : "present";
      return { ...prev, [name]: next };
    });
    setAllPresent(false);
  };

  const handleAllPresent = () => {
    setAllPresent(true);
    setAttendance(Object.fromEntries(ROSTERED_PLAYERS.map(p => [p.name, "present"])));
  };

  const addUnrostered = () => {
    if (!unrosteredName.trim()) return;
    setUnrosteredPlayers(prev => [...prev, unrosteredName.trim()]);
    setUnrosteredName("");
    setShowUnrosteredWarning(true);
  };

  const presentCount = Object.values(attendance).filter(s => s === "present").length;
  const absentCount = Object.values(attendance).filter(s => s === "absent").length;
  const earlyLeaveCount = Object.values(attendance).filter(s => s === "early-leave").length;

  return (
    <PortalLayout
      title="Attendance"
      subtitle="Orange Ball 2 · 4:00 PM"
      showBack
      backTo="/donna-wrapup"
      hideNav
    >
      <div className="screen-enter px-4 pt-4 space-y-5">
        {/* Summary bar */}
        <div className="grid grid-cols-3 gap-2">
          {[
            { label: "Present", count: presentCount, color: "oklch(0.72 0.18 145)" },
            { label: "Absent", count: absentCount, color: "oklch(0.65 0.22 25)" },
            { label: "Left Early", count: earlyLeaveCount, color: "oklch(0.78 0.16 75)" },
          ].map(({ label, count, color }) => (
            <div
              key={label}
              className="rounded-xl p-3 text-center"
              style={{ background: "oklch(0.155 0.01 220)", border: "1px solid oklch(1 0 0 / 0.08)" }}
            >
              <p className="text-xl font-bold" style={{ color, fontFamily: "'Syne', sans-serif" }}>{count}</p>
              <p className="text-xs" style={{ color: "oklch(0.55 0.015 220)" }}>{label}</p>
            </div>
          ))}
        </div>

        {/* Everyone present shortcut */}
        <button
          onClick={handleAllPresent}
          className="w-full flex items-center gap-3 p-4 rounded-2xl transition-all active:scale-[0.98]"
          style={{
            background: allPresent ? "oklch(0.72 0.18 145 / 0.12)" : "oklch(0.155 0.01 220)",
            border: allPresent ? "1px solid oklch(0.72 0.18 145 / 0.3)" : "1px solid oklch(1 0 0 / 0.08)",
          }}
        >
          <div
            className="w-10 h-10 rounded-full flex items-center justify-center flex-shrink-0"
            style={{ background: allPresent ? "oklch(0.72 0.18 145 / 0.2)" : "oklch(0.185 0.01 220)" }}
          >
            <CheckCircle2 size={20} style={{ color: allPresent ? "oklch(0.72 0.18 145)" : "oklch(0.55 0.015 220)" }} />
          </div>
          <div className="flex-1 text-left">
            <p className="text-sm font-semibold" style={{ color: "oklch(0.94 0.005 210)" }}>
              Everyone was here
            </p>
            <p className="text-xs" style={{ color: "oklch(0.58 0.015 220)" }}>
              All {ROSTERED_PLAYERS.length} rostered players attended
            </p>
          </div>
          {allPresent && <Check size={16} style={{ color: "oklch(0.72 0.18 145)" }} />}
        </button>

        {/* Player list */}
        <div>
          <p className="text-xs font-semibold uppercase tracking-widest mb-2" style={{ color: "oklch(0.58 0.015 220)" }}>
            Tap to mark exception
          </p>
          <div
            className="rounded-2xl overflow-hidden"
            style={{ background: "oklch(0.155 0.01 220)", border: "1px solid oklch(1 0 0 / 0.08)" }}
          >
            {ROSTERED_PLAYERS.map((player, i) => {
              const status = attendance[player.name];
              return (
                <button
                  key={player.name}
                  onClick={() => toggleStatus(player.name)}
                  className="w-full flex items-center gap-3 px-4 py-3 text-left transition-all active:scale-[0.99]"
                  style={{
                    borderBottom: i < ROSTERED_PLAYERS.length - 1 ? "1px solid oklch(1 0 0 / 0.06)" : "none",
                    background: status !== "present" ? "oklch(0.185 0.01 220)" : "transparent",
                  }}
                >
                  <div
                    className="w-9 h-9 rounded-full flex items-center justify-center text-xs font-bold flex-shrink-0"
                    style={{
                      background:
                        status === "absent" ? "oklch(0.65 0.22 25 / 0.15)" :
                        status === "early-leave" ? "oklch(0.78 0.16 75 / 0.15)" :
                        "oklch(0.72 0.18 145 / 0.12)",
                      color:
                        status === "absent" ? "oklch(0.65 0.22 25)" :
                        status === "early-leave" ? "oklch(0.78 0.16 75)" :
                        "oklch(0.72 0.18 145)",
                      fontFamily: "'Syne', sans-serif",
                    }}
                  >
                    {player.initials}
                  </div>
                  <p className="flex-1 text-sm font-medium" style={{ color: "oklch(0.94 0.005 210)" }}>
                    {player.name}
                  </p>
                  <div className="flex items-center gap-1.5">
                    {status === "present" && (
                      <span className="status-pill" style={{ background: "oklch(0.72 0.18 145 / 0.12)", color: "oklch(0.72 0.18 145)" }}>
                        Present
                      </span>
                    )}
                    {status === "absent" && (
                      <span className="status-pill" style={{ background: "oklch(0.65 0.22 25 / 0.12)", color: "oklch(0.65 0.22 25)" }}>
                        <UserX size={9} /> Absent
                      </span>
                    )}
                    {status === "early-leave" && (
                      <span className="status-pill" style={{ background: "oklch(0.78 0.16 75 / 0.12)", color: "oklch(0.78 0.16 75)" }}>
                        <UserMinus size={9} /> Left Early
                      </span>
                    )}
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        {/* Unrostered player */}
        <div>
          <p className="text-xs font-semibold uppercase tracking-widest mb-2" style={{ color: "oklch(0.58 0.015 220)" }}>
            Unexpected Player
          </p>
          <div className="flex gap-2">
            <input
              value={unrosteredName}
              onChange={e => setUnrosteredName(e.target.value)}
              onKeyDown={e => e.key === "Enter" && addUnrostered()}
              placeholder="Player name..."
              className="flex-1 rounded-xl px-4 py-2.5 text-sm outline-none"
              style={{
                background: "oklch(0.155 0.01 220)",
                border: "1px solid oklch(1 0 0 / 0.1)",
                color: "oklch(0.94 0.005 210)",
              }}
            />
            <button
              onClick={addUnrostered}
              className="px-4 py-2.5 rounded-xl text-sm font-semibold transition-all active:scale-[0.97]"
              style={{ background: "oklch(0.72 0.18 185 / 0.15)", color: "oklch(0.72 0.18 185)", border: "1px solid oklch(0.72 0.18 185 / 0.25)" }}
            >
              <UserPlus size={16} />
            </button>
          </div>

          {/* Unrostered list */}
          {unrosteredPlayers.length > 0 && (
            <div className="mt-2 space-y-2">
              {unrosteredPlayers.map(name => (
                <div
                  key={name}
                  className="rounded-xl p-3 flex items-center gap-3"
                  style={{ background: "oklch(0.78 0.16 75 / 0.08)", border: "1px solid oklch(0.78 0.16 75 / 0.2)" }}
                >
                  <AlertTriangle size={14} style={{ color: "oklch(0.78 0.16 75)", flexShrink: 0 }} />
                  <div className="flex-1">
                    <p className="text-sm font-semibold" style={{ color: "oklch(0.94 0.005 210)" }}>{name}</p>
                    <p className="text-xs" style={{ color: "oklch(0.78 0.16 75)" }}>
                      Director review required before adding to roster.
                    </p>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Director review warning */}
        {showUnrosteredWarning && (
          <div
            className="rounded-2xl p-4 flex items-start gap-3"
            style={{ background: "oklch(0.78 0.16 75 / 0.08)", border: "1px solid oklch(0.78 0.16 75 / 0.25)" }}
          >
            <AlertTriangle size={16} style={{ color: "oklch(0.78 0.16 75)", flexShrink: 0, marginTop: 2 }} />
            <div>
              <p className="text-sm font-semibold" style={{ color: "oklch(0.94 0.005 210)" }}>
                Director review required
              </p>
              <p className="text-xs mt-1" style={{ color: "oklch(0.72 0.015 220)" }}>
                Unrostered players cannot be added to the roster without director approval. This will be flagged in your wrap-up summary.
              </p>
            </div>
          </div>
        )}

        {/* Confirm button */}
        <Link href="/donna-wrapup">
          <button
            className="w-full flex items-center justify-center gap-2 py-4 rounded-2xl font-semibold text-sm transition-all active:scale-[0.98]"
            style={{
              background: "oklch(0.72 0.18 185)",
              color: "oklch(0.11 0.008 220)",
            }}
          >
            Confirm Attendance
            <ChevronRight size={16} />
          </button>
        </Link>

        <div className="h-4" />
      </div>
    </PortalLayout>
  );
}
