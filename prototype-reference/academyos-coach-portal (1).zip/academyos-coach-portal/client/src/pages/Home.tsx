// Home redirects to CoachToday — the main entry point of the Coach Portal
import { Redirect } from "wouter";

export default function Home() {
  return <Redirect to="/" />;
}
