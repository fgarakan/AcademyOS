/**
 * Screen 10 — Submitted Summary
 * Design: Premium Sports App, dark #0d1117, teal accent
 * Confirmation screen with summary of what was submitted
 */
import { Link } from "wouter";
import PortalLayout from "@/components/PortalLayout";
import { Users, Eye, AlertTriangle, MessageSquare, CalendarDays, Home } from "lucide-react";

const SUCCESS_IMAGE = "https://d2xsxph8kpxj0f.cloudfront.net/310519663491229281/WHXfAe2R2Axz3rJqghCqf9/wrapup-success-n7RxQGfzmkAAUkRtFzTkWG.webp";

const SUMMARY_ITEMS = [
  {
    icon: Users,
    title: "Attendance captured",
    detail: "7 of 8 present · 1 absence logged",
    color: "oklch(0.72 0.18 145)",
    status: "Done",
  },
  {
    icon: Eye,
    title: "Observations drafted",
    detail: "3 player notes · 2 curriculum links",
    color: "oklch(0.72 0.18 185)",
    status: "Done",
  },
  {
    icon: AlertTriangle,
    title: "Review items created",
    detail: "2 items sent to director queue",
    color: "oklch(0.65 0.22 25)",
    status: "Pending",
  },
  {
    icon: MessageSquare,
    title: "Parent-safe drafts",
    detail: "1 draft requires director approval",
    color: "oklch(0.78 0.16 75)",
    status: "Awaiting",
  },
  {
    icon: CalendarDays,
    title: "Next session suggestions",
    detail: "3 recommendations saved for review",
    color: "oklch(0.72 0.18 185)",
    status: "Saved",
  },
];

const STATUS_STYLES: Record<string, { bg: string; text: string }> = {
  Done: { bg: "oklch(0.72 0.18 145 / 0.12)", text: "oklch(0.72 0.18 145)" },
  Pending: { bg: "oklch(0.65 0.22 25 / 0.12)", text: "oklch(0.65 0.22 25)" },
  Awaiting: { bg: "oklch(0.78 0.16 75 / 0.12)", text: "oklch(0.78 0.16 75)" },
  Saved: { bg: "oklch(0.72 0.18 185 / 0.12)", text: "oklch(0.72 0.18 185)" },
};

export default function SubmittedSummary() {
  return (
    <PortalLayout
      hideNav={false}
      noPadding={false}
    >
      <div className="screen-enter px-4 pt-8 space-y-6">
        {/* Success illustration */}
        <div className="flex flex-col items-center text-center space-y-4">
          <div className="w-32 h-32 rounded-full overflow-hidden" style={{ border: "2px solid oklch(0.72 0.18 185 / 0.3)" }}>
            <img src={SUCCESS_IMAGE} alt="Success" className="w-full h-full object-cover" />
          </div>
          <div>
            <h1
              className="text-2xl font-bold"
              style={{ fontFamily: "'Syne', sans-serif", color: "oklch(0.94 0.005 210)" }}
            >
              Wrap-up submitted.
            </h1>
            <p className="text-sm mt-1" style={{ color: "oklch(0.58 0.015 220)" }}>
              Orange Ball 2 · Sunday, May 18 · 4:00 PM
            </p>
          </div>

          {/* Time saved badge */}
          <div
            className="flex items-center gap-2 px-4 py-2 rounded-full"
            style={{ background: "oklch(0.72 0.18 185 / 0.1)", border: "1px solid oklch(0.72 0.18 185 / 0.2)" }}
          >
            <div
              className="w-2 h-2 rounded-full"
              style={{ background: "oklch(0.72 0.18 185)" }}
            />
            <span className="text-xs font-semibold" style={{ color: "oklch(0.72 0.18 185)" }}>
              Completed in ~75 seconds
            </span>
          </div>
        </div>

        {/* Summary items */}
        <div>
          <p className="text-xs font-semibold uppercase tracking-widest mb-3" style={{ color: "oklch(0.58 0.015 220)" }}>
            What was submitted
          </p>
          <div
            className="rounded-2xl overflow-hidden"
            style={{ background: "oklch(0.155 0.01 220)", border: "1px solid oklch(1 0 0 / 0.08)" }}
          >
            {SUMMARY_ITEMS.map((item, i) => {
              const Icon = item.icon;
              const statusStyle = STATUS_STYLES[item.status];
              return (
                <div
                  key={item.title}
                  className="flex items-center gap-3 px-4 py-3"
                  style={{
                    borderBottom: i < SUMMARY_ITEMS.length - 1 ? "1px solid oklch(1 0 0 / 0.06)" : "none",
                  }}
                >
                  <div
                    className="w-8 h-8 rounded-xl flex items-center justify-center flex-shrink-0"
                    style={{ background: `${item.color.replace(")", " / 0.12)")}` }}
                  >
                    <Icon size={15} style={{ color: item.color }} />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-semibold" style={{ color: "oklch(0.94 0.005 210)" }}>
                      {item.title}
                    </p>
                    <p className="text-xs" style={{ color: "oklch(0.58 0.015 220)" }}>
                      {item.detail}
                    </p>
                  </div>
                  <span
                    className="status-pill flex-shrink-0"
                    style={{ background: statusStyle.bg, color: statusStyle.text }}
                  >
                    {item.status}
                  </span>
                </div>
              );
            })}
          </div>
        </div>

        {/* Important note */}
        <div
          className="rounded-2xl p-4 flex items-start gap-3"
          style={{ background: "oklch(0.78 0.16 75 / 0.06)", border: "1px solid oklch(0.78 0.16 75 / 0.2)" }}
        >
          <AlertTriangle size={15} style={{ color: "oklch(0.78 0.16 75)", flexShrink: 0, marginTop: 1 }} />
          <div>
            <p className="text-sm font-semibold" style={{ color: "oklch(0.94 0.005 210)" }}>
              Nothing sent to parents yet
            </p>
            <p className="text-xs mt-1" style={{ color: "oklch(0.72 0.015 220)" }}>
              Parent-safe drafts and director review items require approval before any communication is sent. Your director will review and approve.
            </p>
          </div>
        </div>

        {/* What's next */}
        <div>
          <p className="text-xs font-semibold uppercase tracking-widest mb-3" style={{ color: "oklch(0.58 0.015 220)" }}>
            What's next
          </p>
          <div className="space-y-2">
            {[
              { text: "Director reviews flagged items", sub: "Usually within 24 hours" },
              { text: "Parent communications approved", sub: "Director sends or approves drafts" },
              { text: "Next session suggestions available", sub: "In your Session Plan for Tuesday" },
            ].map(({ text, sub }, i) => (
              <div
                key={i}
                className="flex items-start gap-3 p-3 rounded-xl"
                style={{ background: "oklch(0.155 0.01 220)" }}
              >
                <div
                  className="w-5 h-5 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5 text-xs font-bold"
                  style={{ background: "oklch(0.72 0.18 185 / 0.15)", color: "oklch(0.72 0.18 185)", fontFamily: "'Syne', sans-serif" }}
                >
                  {i + 1}
                </div>
                <div>
                  <p className="text-sm font-medium" style={{ color: "oklch(0.88 0.005 210)" }}>{text}</p>
                  <p className="text-xs" style={{ color: "oklch(0.55 0.015 220)" }}>{sub}</p>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Back to today */}
        <Link href="/">
          <button
            className="w-full flex items-center justify-center gap-2 py-4 rounded-2xl font-semibold text-sm transition-all active:scale-[0.98]"
            style={{
              background: "oklch(0.72 0.18 185)",
              color: "oklch(0.11 0.008 220)",
            }}
          >
            <Home size={16} />
            Back to Today
          </button>
        </Link>

        <div className="h-4" />
      </div>
    </PortalLayout>
  );
}
