import { Link } from "wouter";

export default function NotFound() {
  return (
    <div
      className="min-h-screen flex flex-col items-center justify-center px-6 text-center"
      style={{ background: "oklch(0.11 0.008 220)", maxWidth: "480px", margin: "0 auto" }}
    >
      <div
        className="w-16 h-16 rounded-2xl flex items-center justify-center mb-6"
        style={{ background: "oklch(0.72 0.18 185 / 0.1)", border: "1px solid oklch(0.72 0.18 185 / 0.2)" }}
      >
        <span className="text-2xl font-bold" style={{ color: "oklch(0.72 0.18 185)", fontFamily: "'Syne', sans-serif" }}>
          ?
        </span>
      </div>
      <h1 className="text-2xl font-bold mb-2" style={{ fontFamily: "'Syne', sans-serif", color: "oklch(0.94 0.005 210)" }}>
        Page not found
      </h1>
      <p className="text-sm mb-8" style={{ color: "oklch(0.58 0.015 220)" }}>
        This screen doesn't exist in the Coach Portal.
      </p>
      <Link href="/">
        <button
          className="px-6 py-3 rounded-xl font-semibold text-sm transition-all active:scale-[0.97]"
          style={{ background: "oklch(0.72 0.18 185)", color: "oklch(0.11 0.008 220)" }}
        >
          Back to Today
        </button>
      </Link>
    </div>
  );
}
