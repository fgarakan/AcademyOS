/**
 * Screen 1 — Coach Today
 * Design: Premium Sports App, dark #0d1117, teal accent
 * Shows: next session, missing wrap-ups, player priorities, DONNA suggestions
 */
import { Link } from "wouter";
import PortalLayout from "@/components/PortalLayout";
import AcademyOSBrand from "@/components/AcademyOSBrand";
import {
  Clock, Users, BookOpen, AlertTriangle, ChevronRight,
  Play, Sparkles, Bell, CheckCircle2, Star
} from "lucide-react";

const DONNA_AVATAR = "https://d2xsxph8kpxj0f.cloudfront.net/310519663491229281/WHXfAe2R2Axz3rJqghCqf9/donna-avatar-VmzCYfHyghnGMkTsmi8HgV.webp";

export default function CoachToday() {
  return (
    <PortalLayout
      headerRight={
        <div className="flex items-center gap-2">
          <button
            className="relative w-9 h-9 rounded-xl flex items-center justify-center"
            style={{ background: "oklch(0.155 0.01 220)" }}
          >
            <Bell size={16} style={{ color: "oklch(0.58 0.015 220)" }} />
            <span
              className="absolute top-1.5 right-1.5 w-2 h-2 rounded-full"
              style={{ background: "oklch(0.72 0.18 185)" }}
            />
          </button>
          <div
            className="w-9 h-9 rounded-xl overflow-hidden"
            style={{ border: "2px solid oklch(0.72 0.18 185 / 0.4)" }}
          >
            <div
              className="w-full h-full flex items-center justify-center text-sm font-bold"
              style={{ background: "oklch(0.22 0.008 220)", color: "oklch(0.72 0.18 185)", fontFamily: "'Syne', sans-serif" }}
            >
              MC
            </div>
          </div>
        </div>
      }
    >
      <div className="screen-enter px-4 pt-4 space-y-5">
        {/* Brand header */}
        <div className="flex items-center justify-between">
          <AcademyOSBrand />
        </div>
        {/* Greeting */}
        <div>
          <p className="text-xs font-medium uppercase tracking-widest mb-1" style={{ color: "oklch(0.72 0.18 185)" }}>
            Sunday, May 18
          </p>
          <h1 className="text-2xl font-bold leading-tight" style={{ fontFamily: "'Syne', sans-serif", color: "oklch(0.94 0.005 210)" }}>
            Today's Coaching
          </h1>
          <p className="text-sm mt-0.5" style={{ color: "oklch(0.58 0.015 220)" }}>
            Your sessions, focus areas, and wrap-ups.
          </p>
        </div>

        {/* DONNA Suggestion Banner */}
        <Link href="/donna-assistant">
          <div
            className="rounded-2xl p-4 flex items-start gap-3 transition-all active:scale-[0.98]"
            style={{
              background: "linear-gradient(135deg, oklch(0.72 0.18 185 / 0.12), oklch(0.72 0.18 185 / 0.05))",
              border: "1px solid oklch(0.72 0.18 185 / 0.25)",
            }}
          >
            <div
              className="w-10 h-10 rounded-full overflow-hidden flex-shrink-0 donna-pulse"
              style={{ border: "2px solid oklch(0.72 0.18 185)" }}
            >
              <img src={DONNA_AVATAR} alt="DONNA" className="w-full h-full object-cover" />
            </div>
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-1.5 mb-1">
                <Sparkles size={12} style={{ color: "oklch(0.72 0.18 185)" }} />
                <span className="text-xs font-semibold uppercase tracking-wider" style={{ color: "oklch(0.72 0.18 185)" }}>
                  DONNA
                </span>
              </div>
              <p className="text-sm leading-snug" style={{ color: "oklch(0.88 0.005 210)" }}>
                "Your 4:00 Orange Ball 2 group has a recovery + crosscourt focus today. 2 players need attention."
              </p>
            </div>
            <ChevronRight size={16} style={{ color: "oklch(0.72 0.18 185)", flexShrink: 0 }} />
          </div>
        </Link>

        {/* Next Session Card */}
        <div>
          <p className="text-xs font-semibold uppercase tracking-widest mb-2" style={{ color: "oklch(0.58 0.015 220)" }}>
            Next Session
          </p>
          <div
            className="rounded-2xl overflow-hidden"
            style={{
              background: "oklch(0.155 0.01 220)",
              border: "1px solid oklch(1 0 0 / 0.08)",
            }}
          >
            {/* Session header */}
            <div
              className="px-4 py-3 flex items-center justify-between"
              style={{ borderBottom: "1px solid oklch(1 0 0 / 0.06)" }}
            >
              <div className="flex items-center gap-2">
                <div
                  className="w-2 h-2 rounded-full"
                  style={{ background: "oklch(0.72 0.18 185)" }}
                />
                <span className="text-xs font-semibold" style={{ color: "oklch(0.72 0.18 185)" }}>
                  Starting in 45 min
                </span>
              </div>
              <span
                className="status-pill"
                style={{ background: "oklch(0.72 0.18 185 / 0.12)", color: "oklch(0.72 0.18 185)" }}
              >
                Active
              </span>
            </div>

            <div className="px-4 py-4 space-y-3">
              <div>
                <h2 className="text-lg font-bold" style={{ fontFamily: "'Syne', sans-serif", color: "oklch(0.94 0.005 210)" }}>
                  Orange Ball 2
                </h2>
                <p className="text-sm" style={{ color: "oklch(0.58 0.015 220)" }}>
                  Level 3 · Intermediate
                </p>
              </div>

              <div className="grid grid-cols-2 gap-2">
                {[
                  { icon: Clock, label: "Time", value: "4:00 PM" },
                  { icon: Users, label: "Players", value: "8 expected" },
                  { icon: BookOpen, label: "Template", value: "Recovery Focus" },
                  { icon: Star, label: "Curriculum", value: "Crosscourt Rally" },
                ].map(({ icon: Icon, label, value }) => (
                  <div
                    key={label}
                    className="rounded-xl p-2.5 flex items-center gap-2"
                    style={{ background: "oklch(0.185 0.01 220)" }}
                  >
                    <Icon size={14} style={{ color: "oklch(0.72 0.18 185)", flexShrink: 0 }} />
                    <div className="min-w-0">
                      <p className="text-xs" style={{ color: "oklch(0.55 0.015 220)" }}>{label}</p>
                      <p className="text-xs font-semibold truncate" style={{ color: "oklch(0.88 0.005 210)" }}>{value}</p>
                    </div>
                  </div>
                ))}
              </div>

              <Link href="/session-plan">
                <button
                  className="w-full flex items-center justify-center gap-2 py-3.5 rounded-xl font-semibold text-sm transition-all active:scale-[0.98]"
                  style={{
                    background: "oklch(0.72 0.18 185)",
                    color: "oklch(0.11 0.008 220)",
                    fontFamily: "'DM Sans', sans-serif",
                  }}
                >
                  <Play size={16} fill="currentColor" />
                  Start Session
                </button>
              </Link>
            </div>
          </div>
        </div>

        {/* Missing Wrap-Ups */}
        <div>
          <p className="text-xs font-semibold uppercase tracking-widest mb-2" style={{ color: "oklch(0.58 0.015 220)" }}>
            Missing Wrap-Ups
          </p>
          <div
            className="rounded-2xl p-4 flex items-center gap-3"
            style={{
              background: "oklch(0.155 0.01 220)",
              border: "1px solid oklch(0.78 0.16 75 / 0.25)",
            }}
          >
            <div
              className="w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0"
              style={{ background: "oklch(0.78 0.16 75 / 0.12)" }}
            >
              <AlertTriangle size={18} style={{ color: "oklch(0.78 0.16 75)" }} />
            </div>
            <div className="flex-1">
              <p className="text-sm font-semibold" style={{ color: "oklch(0.94 0.005 210)" }}>
                2 sessions need wrap-up
              </p>
              <p className="text-xs" style={{ color: "oklch(0.58 0.015 220)" }}>
                Red Ball 1 · Yesterday 2:00 PM
              </p>
            </div>
            <Link href="/donna-wrapup">
              <button
                className="px-3 py-1.5 rounded-lg text-xs font-semibold transition-all active:scale-[0.97]"
                style={{ background: "oklch(0.78 0.16 75 / 0.15)", color: "oklch(0.78 0.16 75)" }}
              >
                Wrap Up
              </button>
            </Link>
          </div>
        </div>

        {/* Player Priorities */}
        <div>
          <div className="flex items-center justify-between mb-2">
            <p className="text-xs font-semibold uppercase tracking-widest" style={{ color: "oklch(0.58 0.015 220)" }}>
              Player Priorities
            </p>
            <Link href="/player-watch-list">
              <span className="text-xs font-medium" style={{ color: "oklch(0.72 0.18 185)" }}>
                See all
              </span>
            </Link>
          </div>
          <div className="space-y-2">
            {[
              { name: "Sarah Chen", priority: "Earlier forehand prep", flag: "attention", initials: "SC" },
              { name: "Marcus T.", priority: "Serve toss consistency", flag: "watch", initials: "MT" },
              { name: "Lily R.", priority: "Crosscourt depth", flag: "good", initials: "LR" },
            ].map(({ name, priority, flag, initials }) => (
              <Link key={name} href="/player-watch-list">
                <div
                  className="rounded-xl p-3 flex items-center gap-3 transition-all active:scale-[0.98]"
                  style={{ background: "oklch(0.155 0.01 220)", border: "1px solid oklch(1 0 0 / 0.06)" }}
                >
                  <div
                    className="w-9 h-9 rounded-full flex items-center justify-center text-xs font-bold flex-shrink-0"
                    style={{
                      background: flag === "attention"
                        ? "oklch(0.65 0.22 25 / 0.15)"
                        : flag === "watch"
                        ? "oklch(0.78 0.16 75 / 0.15)"
                        : "oklch(0.72 0.18 145 / 0.15)",
                      color: flag === "attention"
                        ? "oklch(0.65 0.22 25)"
                        : flag === "watch"
                        ? "oklch(0.78 0.16 75)"
                        : "oklch(0.72 0.18 145)",
                      fontFamily: "'Syne', sans-serif",
                    }}
                  >
                    {initials}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-semibold truncate" style={{ color: "oklch(0.94 0.005 210)" }}>
                      {name}
                    </p>
                    <p className="text-xs truncate" style={{ color: "oklch(0.58 0.015 220)" }}>
                      {priority}
                    </p>
                  </div>
                  <div
                    className="w-2 h-2 rounded-full flex-shrink-0"
                    style={{
                      background: flag === "attention"
                        ? "oklch(0.65 0.22 25)"
                        : flag === "watch"
                        ? "oklch(0.78 0.16 75)"
                        : "oklch(0.72 0.18 145)",
                    }}
                  />
                </div>
              </Link>
            ))}
          </div>
        </div>

        {/* Today's Schedule */}
        <div>
          <p className="text-xs font-semibold uppercase tracking-widest mb-2" style={{ color: "oklch(0.58 0.015 220)" }}>
            Full Schedule
          </p>
          <div
            className="rounded-2xl overflow-hidden"
            style={{ background: "oklch(0.155 0.01 220)", border: "1px solid oklch(1 0 0 / 0.08)" }}
          >
            {[
              { time: "10:00 AM", group: "Red Ball 1", status: "done", players: 6 },
              { time: "12:00 PM", group: "Green Ball", status: "done", players: 10 },
              { time: "4:00 PM", group: "Orange Ball 2", status: "next", players: 8 },
              { time: "6:00 PM", group: "Yellow Ball Advanced", status: "upcoming", players: 5 },
            ].map(({ time, group, status, players }, i, arr) => (
              <div
                key={time}
                className="px-4 py-3 flex items-center gap-3"
                style={{
                  borderBottom: i < arr.length - 1 ? "1px solid oklch(1 0 0 / 0.06)" : "none",
                }}
              >
                <div className="w-16 flex-shrink-0">
                  <p className="text-xs font-medium" style={{ color: "oklch(0.58 0.015 220)" }}>{time}</p>
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-semibold truncate" style={{ color: "oklch(0.94 0.005 210)" }}>{group}</p>
                  <p className="text-xs" style={{ color: "oklch(0.55 0.015 220)" }}>{players} players</p>
                </div>
                {status === "done" && <CheckCircle2 size={16} style={{ color: "oklch(0.72 0.18 145)", flexShrink: 0 }} />}
                {status === "next" && (
                  <span className="status-pill" style={{ background: "oklch(0.72 0.18 185 / 0.12)", color: "oklch(0.72 0.18 185)" }}>
                    Next
                  </span>
                )}
                {status === "upcoming" && (
                  <span className="status-pill" style={{ background: "oklch(0.22 0.008 220)", color: "oklch(0.55 0.015 220)" }}>
                    Later
                  </span>
                )}
              </div>
            ))}
          </div>
        </div>

        {/* Ask DONNA button */}
        <Link href="/donna-assistant">
          <button
            className="w-full flex items-center justify-center gap-2 py-4 rounded-2xl font-semibold text-sm transition-all active:scale-[0.98]"
            style={{
              background: "oklch(0.155 0.01 220)",
              border: "1px solid oklch(0.72 0.18 185 / 0.3)",
              color: "oklch(0.72 0.18 185)",
              fontFamily: "'DM Sans', sans-serif",
            }}
          >
            <img src={DONNA_AVATAR} alt="DONNA" className="w-5 h-5 rounded-full object-cover" />
            Ask DONNA
          </button>
        </Link>

        <div className="h-4" />
      </div>
    </PortalLayout>
  );
}
