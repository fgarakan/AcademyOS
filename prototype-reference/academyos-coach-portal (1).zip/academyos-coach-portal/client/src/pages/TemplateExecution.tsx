/**
 * Screen 3 — Template Execution View
 * Design: Premium Sports App, dark #0d1117, teal accent
 * Big readable cards, timing, instructions, watch-fors, make easier/harder, capture note
 */
import { useState } from "react";
import { Link } from "wouter";
import PortalLayout from "@/components/PortalLayout";
import { ChevronLeft, ChevronRight, TrendingUp, TrendingDown, PenLine, Eye, Users, Trophy, Clock } from "lucide-react";
import { toast } from "sonner";

const DRILLS = [
  {
    id: 1,
    block: "Warm-Up",
    name: "Dynamic Movement + Mini-Rally",
    duration: "10 min",
    instructions: "Players start at baseline. Coach feeds alternating crosscourt balls. Players rally cooperatively, focusing on split-step before each shot.",
    watchFors: ["Split-step timing", "Racket preparation height", "Recovery to base"],
    groupOrg: "2 players per court, rotate every 3 min",
    scoring: "Cooperative — count consecutive crosscourt rallies",
    easier: "Shorter court, slower feed",
    harder: "Add target cones, increase pace",
  },
  {
    id: 2,
    block: "Technical Focus",
    name: "Crosscourt Groundstrokes",
    duration: "20 min",
    instructions: "Coach feeds from center. Players hit crosscourt forehand, recover to center, hit crosscourt backhand. Emphasize recovery step after each shot.",
    watchFors: ["Forehand prep before ball crosses service line", "Recovery footwork — shuffle not cross-step", "Finish position — racket above shoulder"],
    groupOrg: "3 groups of 3, rotate on coach signal",
    scoring: "Count clean crosscourt shots in 2 min window",
    easier: "Feed from closer, allow double bounce",
    harder: "Add direction change on coach signal",
  },
  {
    id: 3,
    block: "Point Play",
    name: "Crosscourt-Only Points",
    duration: "15 min",
    instructions: "Live points, crosscourt only. Any down-the-line shot = point to opponent. First to 7 wins. Rotate partners.",
    watchFors: ["Decision-making under pressure", "Recovery quality when losing point", "Positive body language"],
    groupOrg: "Pairs on each court, winner stays",
    scoring: "First to 7 points, winner stays on court",
    easier: "Allow one DTL per game",
    harder: "Must hit 3 crosscourt before going DTL",
  },
  {
    id: 4,
    block: "Cool Down",
    name: "Stretch + Debrief",
    duration: "5 min",
    instructions: "Light stretching. Coach asks 2 players to share one thing they worked on. Set focus for next session.",
    watchFors: ["Engagement during debrief", "Self-awareness in responses"],
    groupOrg: "Full group circle",
    scoring: "N/A",
    easier: "N/A",
    harder: "N/A",
  },
];

export default function TemplateExecution() {
  const [currentDrill, setCurrentDrill] = useState(0);
  const drill = DRILLS[currentDrill];

  return (
    <PortalLayout
      title={drill.block}
      subtitle={`Drill ${currentDrill + 1} of ${DRILLS.length}`}
      showBack
      backTo="/session-plan"
      hideNav={false}
      headerRight={
        <Link href="/donna-wrapup">
          <button
            className="px-3 py-1.5 rounded-xl text-xs font-semibold transition-all active:scale-[0.97]"
            style={{ background: "oklch(0.78 0.16 75 / 0.15)", color: "oklch(0.78 0.16 75)" }}
          >
            Wrap Up
          </button>
        </Link>
      }
    >
      <div className="screen-enter px-4 pt-4 space-y-4">
        {/* Progress bar */}
        <div className="flex gap-1.5">
          {DRILLS.map((_, i) => (
            <button
              key={i}
              onClick={() => setCurrentDrill(i)}
              className="flex-1 h-1.5 rounded-full transition-all"
              style={{
                background: i <= currentDrill
                  ? "oklch(0.72 0.18 185)"
                  : "oklch(0.22 0.008 220)",
              }}
            />
          ))}
        </div>

        {/* Main drill card */}
        <div
          className="rounded-2xl overflow-hidden"
          style={{
            background: "oklch(0.155 0.01 220)",
            border: "1px solid oklch(1 0 0 / 0.08)",
          }}
        >
          {/* Drill header */}
          <div
            className="px-4 py-4"
            style={{
              background: "linear-gradient(135deg, oklch(0.72 0.18 185 / 0.1), transparent)",
              borderBottom: "1px solid oklch(1 0 0 / 0.08)",
            }}
          >
            <div className="flex items-center gap-2 mb-1">
              <Clock size={13} style={{ color: "oklch(0.72 0.18 185)" }} />
              <span className="text-xs font-semibold" style={{ color: "oklch(0.72 0.18 185)" }}>
                {drill.duration}
              </span>
            </div>
            <h2
              className="text-xl font-bold leading-tight"
              style={{ fontFamily: "'Syne', sans-serif", color: "oklch(0.94 0.005 210)" }}
            >
              {drill.name}
            </h2>
          </div>

          {/* Instructions */}
          <div className="px-4 py-4" style={{ borderBottom: "1px solid oklch(1 0 0 / 0.06)" }}>
            <p className="text-sm leading-relaxed" style={{ color: "oklch(0.82 0.005 210)" }}>
              {drill.instructions}
            </p>
          </div>

          {/* Group org + scoring */}
          <div
            className="grid grid-cols-2 divide-x px-0"
            style={{ borderBottom: "1px solid oklch(1 0 0 / 0.06)", borderColor: "oklch(1 0 0 / 0.06)" }}
          >
            <div className="px-4 py-3">
              <div className="flex items-center gap-1.5 mb-1">
                <Users size={12} style={{ color: "oklch(0.58 0.015 220)" }} />
                <span className="text-xs" style={{ color: "oklch(0.55 0.015 220)" }}>Group</span>
              </div>
              <p className="text-xs font-medium" style={{ color: "oklch(0.82 0.005 210)" }}>{drill.groupOrg}</p>
            </div>
            <div className="px-4 py-3">
              <div className="flex items-center gap-1.5 mb-1">
                <Trophy size={12} style={{ color: "oklch(0.58 0.015 220)" }} />
                <span className="text-xs" style={{ color: "oklch(0.55 0.015 220)" }}>Scoring</span>
              </div>
              <p className="text-xs font-medium" style={{ color: "oklch(0.82 0.005 210)" }}>{drill.scoring}</p>
            </div>
          </div>

          {/* Watch-fors */}
          <div className="px-4 py-4" style={{ borderBottom: "1px solid oklch(1 0 0 / 0.06)" }}>
            <div className="flex items-center gap-1.5 mb-2">
              <Eye size={13} style={{ color: "oklch(0.72 0.18 185)" }} />
              <span className="text-xs font-semibold uppercase tracking-wider" style={{ color: "oklch(0.72 0.18 185)" }}>
                Watch For
              </span>
            </div>
            <div className="space-y-1.5">
              {drill.watchFors.map((w, i) => (
                <div key={i} className="flex items-start gap-2">
                  <div
                    className="w-1.5 h-1.5 rounded-full mt-1.5 flex-shrink-0"
                    style={{ background: "oklch(0.72 0.18 185)" }}
                  />
                  <p className="text-sm" style={{ color: "oklch(0.82 0.005 210)" }}>{w}</p>
                </div>
              ))}
            </div>
          </div>

          {/* Easier / Harder */}
          {drill.easier !== "N/A" && (
            <div className="grid grid-cols-2 gap-2 px-4 py-4" style={{ borderBottom: "1px solid oklch(1 0 0 / 0.06)" }}>
              <button
                className="flex items-center gap-2 p-3 rounded-xl transition-all active:scale-[0.97]"
                style={{ background: "oklch(0.78 0.16 75 / 0.1)", border: "1px solid oklch(0.78 0.16 75 / 0.2)" }}
                onClick={() => toast.success("Drill simplified", { description: drill.easier })}
              >
                <TrendingDown size={14} style={{ color: "oklch(0.78 0.16 75)" }} />
                <div className="text-left">
                  <p className="text-xs font-semibold" style={{ color: "oklch(0.78 0.16 75)" }}>Make Easier</p>
                  <p className="text-xs" style={{ color: "oklch(0.58 0.015 220)" }}>{drill.easier}</p>
                </div>
              </button>
              <button
                className="flex items-center gap-2 p-3 rounded-xl transition-all active:scale-[0.97]"
                style={{ background: "oklch(0.72 0.18 145 / 0.1)", border: "1px solid oklch(0.72 0.18 145 / 0.2)" }}
                onClick={() => toast.success("Drill progressed", { description: drill.harder })}
              >
                <TrendingUp size={14} style={{ color: "oklch(0.72 0.18 145)" }} />
                <div className="text-left">
                  <p className="text-xs font-semibold" style={{ color: "oklch(0.72 0.18 145)" }}>Make Harder</p>
                  <p className="text-xs" style={{ color: "oklch(0.58 0.015 220)" }}>{drill.harder}</p>
                </div>
              </button>
            </div>
          )}

          {/* Capture note */}
          <div className="px-4 py-4">
            <Link href="/player-observation">
              <button
                className="w-full flex items-center justify-center gap-2 py-3 rounded-xl text-sm font-semibold transition-all active:scale-[0.98]"
                style={{
                  background: "oklch(0.185 0.01 220)",
                  border: "1px solid oklch(1 0 0 / 0.1)",
                  color: "oklch(0.88 0.005 210)",
                }}
              >
                <PenLine size={15} style={{ color: "oklch(0.72 0.18 185)" }} />
                Capture a Note
              </button>
            </Link>
          </div>
        </div>

        {/* Navigation */}
        <div className="flex gap-3">
          <button
            onClick={() => setCurrentDrill(Math.max(0, currentDrill - 1))}
            disabled={currentDrill === 0}
            className="flex-1 flex items-center justify-center gap-2 py-3.5 rounded-xl font-semibold text-sm transition-all active:scale-[0.98] disabled:opacity-40"
            style={{
              background: "oklch(0.155 0.01 220)",
              border: "1px solid oklch(1 0 0 / 0.08)",
              color: "oklch(0.88 0.005 210)",
            }}
          >
            <ChevronLeft size={16} />
            Previous
          </button>
          {currentDrill < DRILLS.length - 1 ? (
            <button
              onClick={() => setCurrentDrill(currentDrill + 1)}
              className="flex-1 flex items-center justify-center gap-2 py-3.5 rounded-xl font-semibold text-sm transition-all active:scale-[0.98]"
              style={{
                background: "oklch(0.72 0.18 185)",
                color: "oklch(0.11 0.008 220)",
              }}
            >
              Next
              <ChevronRight size={16} />
            </button>
          ) : (
            <Link href="/donna-wrapup" className="flex-1">
              <button
                className="w-full flex items-center justify-center gap-2 py-3.5 rounded-xl font-semibold text-sm transition-all active:scale-[0.98]"
                style={{
                  background: "oklch(0.72 0.18 185)",
                  color: "oklch(0.11 0.008 220)",
                }}
              >
                Wrap Up
                <ChevronRight size={16} />
              </button>
            </Link>
          )}
        </div>

        <div className="h-4" />
      </div>
    </PortalLayout>
  );
}
