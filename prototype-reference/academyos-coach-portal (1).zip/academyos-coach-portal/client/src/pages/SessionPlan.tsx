/**
 * Screen 2 — Session Plan
 * Design: Premium Sports App, dark #0d1117, teal accent
 * Shows: session goal, template, curriculum, block timeline, drills, watch-fors, player priorities
 */
import { Link } from "wouter";
import PortalLayout from "@/components/PortalLayout";
import { Play, Eye, ChevronRight, Target, BookOpen, Clock, Users, TrendingUp, TrendingDown } from "lucide-react";

const BLOCKS = [
  { name: "Warm-Up", duration: "10 min", drills: ["Dynamic movement", "Mini-rally crosscourt"], color: "oklch(0.72 0.18 145)" },
  { name: "Technical Focus", duration: "20 min", drills: ["Crosscourt groundstrokes", "Recovery footwork pattern"], color: "oklch(0.72 0.18 185)" },
  { name: "Point Play", duration: "15 min", drills: ["Crosscourt-only points", "Recovery challenge game"], color: "oklch(0.78 0.16 75)" },
  { name: "Cool Down", duration: "5 min", drills: ["Stretch + debrief"], color: "oklch(0.58 0.015 220)" },
];

export default function SessionPlan() {
  return (
    <PortalLayout
      title="Session Plan"
      subtitle="Orange Ball 2 · 4:00 PM"
      showBack
      backTo="/"
      headerRight={
        <Link href="/template-execution">
          <button
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold transition-all active:scale-[0.97]"
            style={{ background: "oklch(0.72 0.18 185)", color: "oklch(0.11 0.008 220)" }}
          >
            <Play size={12} fill="currentColor" />
            Run
          </button>
        </Link>
      }
    >
      <div className="screen-enter px-4 pt-4 space-y-5">
        {/* Session Goal */}
        <div
          className="rounded-2xl p-4"
          style={{
            background: "linear-gradient(135deg, oklch(0.72 0.18 185 / 0.1), oklch(0.72 0.18 185 / 0.04))",
            border: "1px solid oklch(0.72 0.18 185 / 0.2)",
          }}
        >
          <div className="flex items-center gap-2 mb-2">
            <Target size={14} style={{ color: "oklch(0.72 0.18 185)" }} />
            <span className="text-xs font-semibold uppercase tracking-wider" style={{ color: "oklch(0.72 0.18 185)" }}>
              Session Goal
            </span>
          </div>
          <p className="text-base font-semibold leading-snug" style={{ color: "oklch(0.94 0.005 210)", fontFamily: "'Syne', sans-serif" }}>
            Build crosscourt consistency with active recovery between shots
          </p>
        </div>

        {/* Sources */}
        <div className="grid grid-cols-2 gap-2">
          <div
            className="rounded-xl p-3"
            style={{ background: "oklch(0.155 0.01 220)", border: "1px solid oklch(1 0 0 / 0.08)" }}
          >
            <div className="flex items-center gap-1.5 mb-1">
              <BookOpen size={12} style={{ color: "oklch(0.72 0.18 185)" }} />
              <span className="text-xs" style={{ color: "oklch(0.58 0.015 220)" }}>Template</span>
            </div>
            <p className="text-sm font-semibold" style={{ color: "oklch(0.94 0.005 210)" }}>Recovery Focus v2</p>
          </div>
          <div
            className="rounded-xl p-3"
            style={{ background: "oklch(0.155 0.01 220)", border: "1px solid oklch(1 0 0 / 0.08)" }}
          >
            <div className="flex items-center gap-1.5 mb-1">
              <Target size={12} style={{ color: "oklch(0.78 0.16 75)" }} />
              <span className="text-xs" style={{ color: "oklch(0.58 0.015 220)" }}>Curriculum</span>
            </div>
            <p className="text-sm font-semibold" style={{ color: "oklch(0.94 0.005 210)" }}>Crosscourt Rally</p>
          </div>
        </div>

        {/* Block Timeline */}
        <div>
          <p className="text-xs font-semibold uppercase tracking-widest mb-3" style={{ color: "oklch(0.58 0.015 220)" }}>
            Block Timeline
          </p>
          <div className="space-y-2">
            {BLOCKS.map((block, i) => (
              <div
                key={block.name}
                className="rounded-xl overflow-hidden"
                style={{ background: "oklch(0.155 0.01 220)", border: "1px solid oklch(1 0 0 / 0.08)" }}
              >
                <div
                  className="px-4 py-3 flex items-center gap-3"
                  style={{ borderLeft: `3px solid ${block.color}` }}
                >
                  <div className="flex-1">
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-medium" style={{ color: "oklch(0.55 0.015 220)" }}>
                        {i + 1}
                      </span>
                      <p className="text-sm font-semibold" style={{ color: "oklch(0.94 0.005 210)", fontFamily: "'Syne', sans-serif" }}>
                        {block.name}
                      </p>
                    </div>
                    <div className="flex items-center gap-1 mt-1">
                      <Clock size={11} style={{ color: "oklch(0.55 0.015 220)" }} />
                      <span className="text-xs" style={{ color: "oklch(0.55 0.015 220)" }}>{block.duration}</span>
                    </div>
                  </div>
                </div>
                <div className="px-4 pb-3 space-y-1">
                  {block.drills.map(drill => (
                    <div key={drill} className="flex items-start gap-2">
                      <div
                        className="w-1 h-1 rounded-full mt-1.5 flex-shrink-0"
                        style={{ background: block.color }}
                      />
                      <p className="text-xs" style={{ color: "oklch(0.72 0.015 220)" }}>{drill}</p>
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Coach Watch-Fors */}
        <div>
          <p className="text-xs font-semibold uppercase tracking-widest mb-2" style={{ color: "oklch(0.58 0.015 220)" }}>
            Coach Watch-Fors
          </p>
          <div
            className="rounded-2xl p-4 space-y-2"
            style={{ background: "oklch(0.155 0.01 220)", border: "1px solid oklch(1 0 0 / 0.08)" }}
          >
            {[
              "Players recovering to base position after each shot",
              "Forehand preparation before ball crosses service line",
              "Racket head speed on crosscourt finish",
            ].map((item, i) => (
              <div key={i} className="flex items-start gap-2">
                <Eye size={13} style={{ color: "oklch(0.72 0.18 185)", flexShrink: 0, marginTop: 2 }} />
                <p className="text-sm" style={{ color: "oklch(0.88 0.005 210)" }}>{item}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Player Priorities */}
        <div>
          <div className="flex items-center justify-between mb-2">
            <p className="text-xs font-semibold uppercase tracking-widest" style={{ color: "oklch(0.58 0.015 220)" }}>
              Player Priorities
            </p>
            <Link href="/player-watch-list">
              <span className="text-xs font-medium" style={{ color: "oklch(0.72 0.18 185)" }}>View all</span>
            </Link>
          </div>
          <div className="space-y-2">
            {[
              { name: "Sarah Chen", focus: "Earlier forehand prep", flag: true },
              { name: "Marcus T.", focus: "Serve toss consistency", flag: true },
            ].map(({ name, focus, flag }) => (
              <div
                key={name}
                className="rounded-xl p-3 flex items-center gap-3"
                style={{
                  background: "oklch(0.155 0.01 220)",
                  border: "1px solid oklch(0.65 0.22 25 / 0.2)",
                  borderLeft: "3px solid oklch(0.65 0.22 25)",
                }}
              >
                <div className="flex-1">
                  <p className="text-sm font-semibold" style={{ color: "oklch(0.94 0.005 210)" }}>{name}</p>
                  <p className="text-xs" style={{ color: "oklch(0.58 0.015 220)" }}>{focus}</p>
                </div>
                {flag && (
                  <div
                    className="w-6 h-6 rounded-full flex items-center justify-center"
                    style={{ background: "oklch(0.65 0.22 25 / 0.15)" }}
                  >
                    <span className="text-xs">⚑</span>
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>

        {/* Progression / Regression */}
        <div>
          <p className="text-xs font-semibold uppercase tracking-widest mb-2" style={{ color: "oklch(0.58 0.015 220)" }}>
            Adjustments
          </p>
          <div className="grid grid-cols-2 gap-2">
            <div
              className="rounded-xl p-3"
              style={{ background: "oklch(0.72 0.18 145 / 0.08)", border: "1px solid oklch(0.72 0.18 145 / 0.2)" }}
            >
              <div className="flex items-center gap-1.5 mb-1">
                <TrendingUp size={13} style={{ color: "oklch(0.72 0.18 145)" }} />
                <span className="text-xs font-semibold" style={{ color: "oklch(0.72 0.18 145)" }}>Progression</span>
              </div>
              <p className="text-xs" style={{ color: "oklch(0.72 0.015 220)" }}>Add target zones, increase pace</p>
            </div>
            <div
              className="rounded-xl p-3"
              style={{ background: "oklch(0.78 0.16 75 / 0.08)", border: "1px solid oklch(0.78 0.16 75 / 0.2)" }}
            >
              <div className="flex items-center gap-1.5 mb-1">
                <TrendingDown size={13} style={{ color: "oklch(0.78 0.16 75)" }} />
                <span className="text-xs font-semibold" style={{ color: "oklch(0.78 0.16 75)" }}>Regression</span>
              </div>
              <p className="text-xs" style={{ color: "oklch(0.72 0.015 220)" }}>Feed balls, shorter court</p>
            </div>
          </div>
        </div>

        {/* Start button */}
        <Link href="/template-execution">
          <button
            className="w-full flex items-center justify-center gap-2 py-4 rounded-2xl font-semibold text-sm transition-all active:scale-[0.98]"
            style={{
              background: "oklch(0.72 0.18 185)",
              color: "oklch(0.11 0.008 220)",
              fontFamily: "'DM Sans', sans-serif",
            }}
          >
            <Play size={16} fill="currentColor" />
            Start Template Execution
          </button>
        </Link>

        <div className="h-4" />
      </div>
    </PortalLayout>
  );
}
