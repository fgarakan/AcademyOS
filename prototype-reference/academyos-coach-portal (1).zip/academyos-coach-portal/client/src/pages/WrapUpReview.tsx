/**
 * Screen 9 — Wrap-Up Review
 * Design: Premium Sports App, dark #0d1117, teal accent
 * Before submission: attendance, session, observations, curriculum, director items, parent drafts, next session
 */
import { useState } from "react";
import { Link } from "wouter";
import PortalLayout from "@/components/PortalLayout";
import {
  Users, BookOpen, Eye, Target, AlertTriangle, MessageSquare,
  CalendarDays, ChevronRight, Edit3, Save, X, CheckCircle2
} from "lucide-react";

const REVIEW_SECTIONS = [
  {
    id: "attendance",
    icon: Users,
    title: "Attendance",
    color: "oklch(0.72 0.18 145)",
    items: [
      "7 of 8 players present",
      "Sarah Chen — absent",
      "All others confirmed present",
    ],
    status: "ready",
  },
  {
    id: "session",
    icon: BookOpen,
    title: "Session Actual",
    color: "oklch(0.72 0.18 185)",
    items: [
      "Template: Recovery Focus v2 — completed",
      "Crosscourt drill ran 25 min (extended by coach)",
      "Point play shortened to 10 min",
    ],
    status: "ready",
  },
  {
    id: "observations",
    icon: Eye,
    title: "Player Observations",
    color: "oklch(0.78 0.16 75)",
    items: [
      "Lily R. — Crosscourt depth breakthrough (Skill Path)",
      "Marcus T. — Serve toss regression under pressure (Growth)",
      "Noah K. — Distraction during point play (Attention)",
    ],
    status: "ready",
  },
  {
    id: "curriculum",
    icon: Target,
    title: "Curriculum Evidence",
    color: "oklch(0.72 0.18 185)",
    items: [
      "Crosscourt Rally — Lily R. ready for Level 4",
      "Recovery Footwork — Group average improved",
    ],
    status: "ready",
  },
  {
    id: "director",
    icon: AlertTriangle,
    title: "Director Review Items",
    color: "oklch(0.65 0.22 25)",
    items: [
      "Noah K. engagement concern — parent follow-up suggested",
      "Unrostered player Jeremy S. — roster review required",
    ],
    status: "review",
  },
  {
    id: "parent",
    icon: MessageSquare,
    title: "Parent-Safe Drafts",
    color: "oklch(0.78 0.16 75)",
    items: [
      "Lily R. parent: 'Lily had a great session today — her crosscourt depth is improving significantly.' (Draft — requires approval)",
      "Noah K. parent: Draft pending director review",
    ],
    status: "draft",
    note: "No automatic parent send. Requires director approval.",
  },
  {
    id: "next",
    icon: CalendarDays,
    title: "Next Session Suggestions",
    color: "oklch(0.72 0.18 185)",
    items: [
      "Progress Lily R. to target cone drill",
      "Individual check-in with Noah K. before session",
      "Serve toss focus for Marcus T. — 10 min dedicated block",
    ],
    status: "saved",
  },
];

const STATUS_STYLES: Record<string, { bg: string; text: string; label: string }> = {
  ready: { bg: "oklch(0.72 0.18 145 / 0.12)", text: "oklch(0.72 0.18 145)", label: "Ready" },
  review: { bg: "oklch(0.65 0.22 25 / 0.12)", text: "oklch(0.65 0.22 25)", label: "Needs Review" },
  draft: { bg: "oklch(0.78 0.16 75 / 0.12)", text: "oklch(0.78 0.16 75)", label: "Draft" },
  saved: { bg: "oklch(0.72 0.18 185 / 0.12)", text: "oklch(0.72 0.18 185)", label: "Saved" },
};

export default function WrapUpReview() {
  const [expanded, setExpanded] = useState<string | null>("attendance");

  return (
    <PortalLayout
      title="Review Wrap-Up"
      subtitle="Orange Ball 2 · May 18"
      showBack
      backTo="/donna-wrapup"
      hideNav
    >
      <div className="screen-enter px-4 pt-4 space-y-4">
        {/* Summary header */}
        <div
          className="rounded-2xl p-4"
          style={{
            background: "linear-gradient(135deg, oklch(0.72 0.18 185 / 0.1), oklch(0.72 0.18 185 / 0.04))",
            border: "1px solid oklch(0.72 0.18 185 / 0.2)",
          }}
        >
          <p className="text-xs font-semibold uppercase tracking-wider mb-1" style={{ color: "oklch(0.72 0.18 185)" }}>
            Ready to Submit
          </p>
          <p className="text-sm" style={{ color: "oklch(0.82 0.005 210)" }}>
            Review each section below. Director items and parent drafts require approval — nothing is sent automatically.
          </p>
        </div>

        {/* Review sections */}
        <div className="space-y-2">
          {REVIEW_SECTIONS.map(section => {
            const isOpen = expanded === section.id;
            const statusStyle = STATUS_STYLES[section.status];
            const Icon = section.icon;

            return (
              <div
                key={section.id}
                className="rounded-2xl overflow-hidden"
                style={{ background: "oklch(0.155 0.01 220)", border: "1px solid oklch(1 0 0 / 0.08)" }}
              >
                <button
                  className="w-full flex items-center gap-3 px-4 py-3 text-left"
                  onClick={() => setExpanded(isOpen ? null : section.id)}
                >
                  <div
                    className="w-8 h-8 rounded-xl flex items-center justify-center flex-shrink-0"
                    style={{ background: `${section.color.replace(")", " / 0.12)")}` }}
                  >
                    <Icon size={15} style={{ color: section.color }} />
                  </div>
                  <div className="flex-1">
                    <p className="text-sm font-semibold" style={{ color: "oklch(0.94 0.005 210)" }}>
                      {section.title}
                    </p>
                    <p className="text-xs" style={{ color: "oklch(0.55 0.015 220)" }}>
                      {section.items.length} item{section.items.length !== 1 ? "s" : ""}
                    </p>
                  </div>
                  <span className="status-pill" style={{ background: statusStyle.bg, color: statusStyle.text }}>
                    {statusStyle.label}
                  </span>
                </button>

                {isOpen && (
                  <div
                    className="px-4 pb-4 space-y-2"
                    style={{ borderTop: "1px solid oklch(1 0 0 / 0.06)" }}
                  >
                    <div className="pt-3 space-y-2">
                      {section.items.map((item, i) => (
                        <div key={i} className="flex items-start gap-2">
                          <CheckCircle2 size={13} style={{ color: section.color, flexShrink: 0, marginTop: 2 }} />
                          <p className="text-sm" style={{ color: "oklch(0.82 0.005 210)" }}>{item}</p>
                        </div>
                      ))}
                      {section.note && (
                        <div
                          className="rounded-xl p-2.5 flex items-start gap-2 mt-2"
                          style={{ background: "oklch(0.78 0.16 75 / 0.08)", border: "1px solid oklch(0.78 0.16 75 / 0.2)" }}
                        >
                          <AlertTriangle size={12} style={{ color: "oklch(0.78 0.16 75)", flexShrink: 0, marginTop: 1 }} />
                          <p className="text-xs" style={{ color: "oklch(0.78 0.16 75)" }}>{section.note}</p>
                        </div>
                      )}
                    </div>
                  </div>
                )}
              </div>
            );
          })}
        </div>

        {/* Action buttons */}
        <div className="space-y-2">
          <Link href="/submitted-summary">
            <button
              className="w-full flex items-center justify-center gap-2 py-4 rounded-2xl font-semibold text-sm transition-all active:scale-[0.98]"
              style={{
                background: "oklch(0.72 0.18 185)",
                color: "oklch(0.11 0.008 220)",
              }}
            >
              <CheckCircle2 size={16} />
              Submit for Review
            </button>
          </Link>

          <div className="grid grid-cols-3 gap-2">
            <Link href="/donna-wrapup">
              <button
                className="w-full flex items-center justify-center gap-1.5 py-3 rounded-xl text-xs font-semibold transition-all active:scale-[0.97]"
                style={{
                  background: "oklch(0.155 0.01 220)",
                  border: "1px solid oklch(1 0 0 / 0.08)",
                  color: "oklch(0.82 0.005 210)",
                }}
              >
                <Edit3 size={13} />
                Edit
              </button>
            </Link>
            <button
              className="flex items-center justify-center gap-1.5 py-3 rounded-xl text-xs font-semibold transition-all active:scale-[0.97]"
              style={{
                background: "oklch(0.155 0.01 220)",
                border: "1px solid oklch(1 0 0 / 0.08)",
                color: "oklch(0.82 0.005 210)",
              }}
              onClick={() => {}}
            >
              <Save size={13} />
              Save Draft
            </button>
            <Link href="/">
              <button
                className="w-full flex items-center justify-center gap-1.5 py-3 rounded-xl text-xs font-semibold transition-all active:scale-[0.97]"
                style={{
                  background: "oklch(0.155 0.01 220)",
                  border: "1px solid oklch(0.65 0.22 25 / 0.2)",
                  color: "oklch(0.65 0.22 25)",
                }}
              >
                <X size={13} />
                Cancel
              </button>
            </Link>
          </div>
        </div>

        <div className="h-4" />
      </div>
    </PortalLayout>
  );
}
