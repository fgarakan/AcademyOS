/**
 * Screen 6 — DONNA Daily Wrap-Up
 * Design: Premium Sports App, dark #0d1117, teal accent
 * One question at a time, transcript, editable response, side summary panel
 */
import { useState } from "react";
import { Link, useLocation } from "wouter";
import PortalLayout from "@/components/PortalLayout";
import { Mic, ChevronRight, SkipForward, Sparkles, CheckCircle2 } from "lucide-react";

const DONNA_AVATAR = "https://d2xsxph8kpxj0f.cloudfront.net/310519663491229281/WHXfAe2R2Axz3rJqghCqf9/donna-avatar-VmzCYfHyghnGMkTsmi8HgV.webp";

const QUESTIONS = [
  {
    id: 1,
    question: "How did the session go overall?",
    hint: "Energy level, group dynamics, what worked well",
    placeholder: "e.g. Great energy, crosscourt drill was a hit...",
    summaryKey: "Session Overview",
  },
  {
    id: 2,
    question: "Any attendance exceptions?",
    hint: "Absences, late arrivals, unexpected players",
    placeholder: "e.g. Everyone was here except Sarah...",
    summaryKey: "Attendance",
    hasFlow: true,
    flowHref: "/attendance-exception",
  },
  {
    id: 3,
    question: "Any players stand out positively?",
    hint: "Breakthroughs, effort, improvement worth noting",
    placeholder: "e.g. Lily really nailed the crosscourt depth today...",
    summaryKey: "Positive Highlights",
  },
  {
    id: 4,
    question: "Any players need extra attention?",
    hint: "Struggles, concerns, players to watch next session",
    placeholder: "e.g. Marcus still reverting on serve toss under pressure...",
    summaryKey: "Attention Items",
    hasFlow: true,
    flowHref: "/player-observation",
  },
  {
    id: 5,
    question: "Anything to adjust for next time?",
    hint: "Template changes, drill modifications, group splits",
    placeholder: "e.g. Start with point play earlier, group was ready...",
    summaryKey: "Next Session Notes",
  },
  {
    id: 6,
    question: "Any parent or director follow-up needed?",
    hint: "Communications, concerns, review items",
    placeholder: "e.g. Noah's parent asked about private lessons...",
    summaryKey: "Follow-Up Items",
  },
];

export default function DonnaWrapUp() {
  const [, navigate] = useLocation();
  const [currentQ, setCurrentQ] = useState(0);
  const [answers, setAnswers] = useState<Record<number, string>>({});
  const [showSummary, setShowSummary] = useState(false);

  const q = QUESTIONS[currentQ];
  const progress = ((currentQ) / QUESTIONS.length) * 100;
  const isLast = currentQ === QUESTIONS.length - 1;

  const handleNext = () => {
    if (isLast) {
      navigate("/wrapup-review");
    } else {
      setCurrentQ(prev => prev + 1);
    }
  };

  const handleSkip = () => {
    if (isLast) {
      navigate("/wrapup-review");
    } else {
      setCurrentQ(prev => prev + 1);
    }
  };

  const completedCount = Object.keys(answers).length;

  return (
    <PortalLayout
      title="DONNA Wrap-Up"
      subtitle={`Question ${currentQ + 1} of ${QUESTIONS.length}`}
      showBack
      backTo="/"
      hideNav
      headerRight={
        <button
          onClick={() => setShowSummary(!showSummary)}
          className="px-3 py-1.5 rounded-xl text-xs font-semibold transition-all active:scale-[0.97]"
          style={{
            background: showSummary ? "oklch(0.72 0.18 185)" : "oklch(0.155 0.01 220)",
            color: showSummary ? "oklch(0.11 0.008 220)" : "oklch(0.72 0.18 185)",
            border: "1px solid oklch(0.72 0.18 185 / 0.3)",
          }}
        >
          Summary
        </button>
      }
    >
      <div className="screen-enter px-4 pt-4 space-y-4">
        {/* Progress */}
        <div>
          <div className="flex justify-between items-center mb-1.5">
            <span className="text-xs" style={{ color: "oklch(0.55 0.015 220)" }}>
              {completedCount} of {QUESTIONS.length} answered
            </span>
            <span className="text-xs font-semibold" style={{ color: "oklch(0.72 0.18 185)" }}>
              {Math.round(progress)}%
            </span>
          </div>
          <div className="h-1.5 rounded-full overflow-hidden" style={{ background: "oklch(0.22 0.008 220)" }}>
            <div
              className="h-full rounded-full transition-all duration-500"
              style={{ width: `${progress}%`, background: "oklch(0.72 0.18 185)" }}
            />
          </div>
        </div>

        {/* Summary panel */}
        {showSummary && (
          <div
            className="rounded-2xl p-4 space-y-2"
            style={{
              background: "oklch(0.72 0.18 185 / 0.06)",
              border: "1px solid oklch(0.72 0.18 185 / 0.2)",
            }}
          >
            <div className="flex items-center gap-1.5 mb-2">
              <Sparkles size={13} style={{ color: "oklch(0.72 0.18 185)" }} />
              <span className="text-xs font-semibold uppercase tracking-wider" style={{ color: "oklch(0.72 0.18 185)" }}>
                Summary Building
              </span>
            </div>
            {QUESTIONS.map((question, i) => (
              <div key={i} className="flex items-start gap-2">
                <div
                  className="w-4 h-4 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5"
                  style={{
                    background: answers[i] ? "oklch(0.72 0.18 185 / 0.2)" : "oklch(0.22 0.008 220)",
                  }}
                >
                  {answers[i]
                    ? <CheckCircle2 size={10} style={{ color: "oklch(0.72 0.18 185)" }} />
                    : <span className="text-xs" style={{ color: "oklch(0.55 0.015 220)", fontSize: "8px" }}>{i + 1}</span>
                  }
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-xs font-medium" style={{ color: "oklch(0.72 0.015 220)" }}>
                    {question.summaryKey}
                  </p>
                  {answers[i] && (
                    <p className="text-xs mt-0.5 line-clamp-2" style={{ color: "oklch(0.82 0.005 210)" }}>
                      {answers[i]}
                    </p>
                  )}
                </div>
              </div>
            ))}
          </div>
        )}

        {/* DONNA question card */}
        <div
          className="rounded-2xl overflow-hidden"
          style={{
            background: "oklch(0.155 0.01 220)",
            border: "1px solid oklch(1 0 0 / 0.08)",
          }}
        >
          {/* DONNA header */}
          <div
            className="px-4 py-3 flex items-center gap-3"
            style={{ borderBottom: "1px solid oklch(1 0 0 / 0.06)" }}
          >
            <div
              className="w-8 h-8 rounded-full overflow-hidden flex-shrink-0"
              style={{ border: "1.5px solid oklch(0.72 0.18 185)" }}
            >
              <img src={DONNA_AVATAR} alt="DONNA" className="w-full h-full object-cover" />
            </div>
            <div>
              <div className="flex items-center gap-1">
                <Sparkles size={11} style={{ color: "oklch(0.72 0.18 185)" }} />
                <span className="text-xs font-semibold" style={{ color: "oklch(0.72 0.18 185)" }}>DONNA</span>
              </div>
            </div>
          </div>

          {/* Question */}
          <div className="px-4 py-4">
            <h2
              className="text-lg font-bold leading-snug mb-1"
              style={{ fontFamily: "'Syne', sans-serif", color: "oklch(0.94 0.005 210)" }}
            >
              {q.question}
            </h2>
            <p className="text-xs" style={{ color: "oklch(0.58 0.015 220)" }}>{q.hint}</p>
          </div>

          {/* Response area */}
          <div className="px-4 pb-4 space-y-3">
            {/* Voice input */}
            <button
              className="w-full flex items-center gap-3 p-3 rounded-xl transition-all active:scale-[0.98]"
              style={{
                background: "oklch(0.72 0.18 185 / 0.08)",
                border: "1px dashed oklch(0.72 0.18 185 / 0.4)",
              }}
              onClick={() => {
                setAnswers(prev => ({
                  ...prev,
                  [currentQ]: prev[currentQ] || "Voice input captured — tap to edit"
                }));
              }}
            >
              <div
                className="w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0"
                style={{ background: "oklch(0.72 0.18 185 / 0.15)" }}
              >
                <Mic size={15} style={{ color: "oklch(0.72 0.18 185)" }} />
              </div>
              <div className="text-left">
                <p className="text-sm font-medium" style={{ color: "oklch(0.72 0.18 185)" }}>
                  Tap to speak
                </p>
                <p className="text-xs" style={{ color: "oklch(0.58 0.015 220)" }}>
                  30–90 seconds · DONNA will transcribe
                </p>
              </div>
            </button>

            {/* Text input */}
            <textarea
              value={answers[currentQ] || ""}
              onChange={e => setAnswers(prev => ({ ...prev, [currentQ]: e.target.value }))}
              placeholder={q.placeholder}
              rows={3}
              className="w-full rounded-xl px-4 py-3 text-sm outline-none resize-none"
              style={{
                background: "oklch(0.185 0.01 220)",
                border: "1px solid oklch(1 0 0 / 0.1)",
                color: "oklch(0.94 0.005 210)",
              }}
            />

            {/* Attendance / observation flow link */}
            {q.hasFlow && (
              <Link href={q.flowHref!}>
                <button
                  className="w-full flex items-center justify-between px-4 py-2.5 rounded-xl text-sm transition-all active:scale-[0.97]"
                  style={{
                    background: "oklch(0.185 0.01 220)",
                    border: "1px solid oklch(1 0 0 / 0.1)",
                    color: "oklch(0.72 0.18 185)",
                  }}
                >
                  <span className="font-medium">
                    {currentQ === 1 ? "Open Attendance Flow" : "Open Player Observation"}
                  </span>
                  <ChevronRight size={15} />
                </button>
              </Link>
            )}
          </div>
        </div>

        {/* Navigation buttons */}
        <div className="flex gap-3">
          <button
            onClick={handleSkip}
            className="flex items-center justify-center gap-1.5 px-4 py-3.5 rounded-xl text-sm font-medium transition-all active:scale-[0.97]"
            style={{
              background: "oklch(0.155 0.01 220)",
              border: "1px solid oklch(1 0 0 / 0.08)",
              color: "oklch(0.58 0.015 220)",
            }}
          >
            <SkipForward size={14} />
            Skip
          </button>
          <button
            onClick={handleNext}
            className="flex-1 flex items-center justify-center gap-2 py-3.5 rounded-xl font-semibold text-sm transition-all active:scale-[0.98]"
            style={{
              background: "oklch(0.72 0.18 185)",
              color: "oklch(0.11 0.008 220)",
            }}
          >
            {isLast ? "Review & Submit" : "Next"}
            <ChevronRight size={16} />
          </button>
        </div>

        {/* Question dots */}
        <div className="flex justify-center gap-1.5 pb-2">
          {QUESTIONS.map((_, i) => (
            <button
              key={i}
              onClick={() => setCurrentQ(i)}
              className="transition-all"
              style={{
                width: i === currentQ ? "20px" : "6px",
                height: "6px",
                borderRadius: "9999px",
                background: i === currentQ
                  ? "oklch(0.72 0.18 185)"
                  : answers[i]
                  ? "oklch(0.72 0.18 185 / 0.5)"
                  : "oklch(0.22 0.008 220)",
              }}
            />
          ))}
        </div>

        <div className="h-4" />
      </div>
    </PortalLayout>
  );
}
