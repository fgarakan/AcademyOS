/**
 * Screen 5 — DONNA Coach Assistant
 * Design: Premium Sports App, dark #0d1117, teal accent
 * Role-aware AI assistant with quick actions and chat interface
 */
import { useState, useRef, useEffect } from "react";
import { Link } from "wouter";
import PortalLayout from "@/components/PortalLayout";
import { Send, Mic, Play, Settings, PenLine, Zap, CheckCircle, Sparkles } from "lucide-react";

const DONNA_AVATAR = "https://d2xsxph8kpxj0f.cloudfront.net/310519663491229281/WHXfAe2R2Axz3rJqghCqf9/donna-avatar-VmzCYfHyghnGMkTsmi8HgV.webp";

const QUICK_ACTIONS = [
  { label: "Start session", icon: Play, href: "/session-plan" },
  { label: "Modify for today's group", icon: Settings, href: "/session-plan" },
  { label: "Make this easier", icon: Zap, href: "/template-execution" },
  { label: "Make this harder", icon: Zap, href: "/template-execution" },
  { label: "Capture a note", icon: PenLine, href: "/player-observation" },
  { label: "Wrap up session", icon: CheckCircle, href: "/donna-wrapup" },
];

const INITIAL_MESSAGES = [
  {
    role: "donna",
    text: "How can I help with today's coaching?",
    time: "Now",
  },
  {
    role: "donna",
    text: "Your 4:00 Orange Ball 2 group has a recovery + crosscourt focus today. 2 players need attention — Sarah Chen and Noah Kim. Want me to pull up their notes?",
    time: "Now",
  },
];

const RESPONSES: Record<string, string> = {
  "sarah": "Sarah Chen's focus today is earlier forehand preparation. Watch for: prepares before ball crosses service line. Last note: improved recovery but opens early under pressure. I'd suggest keeping her in the crosscourt drill and giving specific feedback on her preparation timing.",
  "noah": "Noah Kim showed distraction during point play in the last session. I'd recommend a quick check-in before the session starts. His parent was also flagged for a follow-up — I can draft that for you after wrap-up.",
  "easier": "For the crosscourt drill: feed from closer to the net, allow double bounce, and use shorter court markers. This reduces time pressure and lets players focus on technique.",
  "harder": "To progress the drill: add target cones in the crosscourt corner, increase feed pace, and require 3 consecutive crosscourt shots before any direction change.",
  "wrap": "Ready to start your wrap-up! I'll guide you through 6 quick questions — should take about 60-90 seconds. Tap 'Wrap Up Session' to begin.",
  "default": "Got it. I'm here to help you run a great session today. What else do you need?",
};

function getResponse(input: string): string {
  const lower = input.toLowerCase();
  if (lower.includes("sarah")) return RESPONSES.sarah;
  if (lower.includes("noah")) return RESPONSES.noah;
  if (lower.includes("easier") || lower.includes("simple")) return RESPONSES.easier;
  if (lower.includes("harder") || lower.includes("progress")) return RESPONSES.harder;
  if (lower.includes("wrap") || lower.includes("done") || lower.includes("finish")) return RESPONSES.wrap;
  return RESPONSES.default;
}

export default function DonnaAssistant() {
  const [messages, setMessages] = useState(INITIAL_MESSAGES);
  const [input, setInput] = useState("");
  const [typing, setTyping] = useState(false);
  const bottomRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, typing]);

  const sendMessage = (text: string) => {
    if (!text.trim()) return;
    const userMsg = { role: "user", text: text.trim(), time: "Now" };
    setMessages(prev => [...prev, userMsg]);
    setInput("");
    setTyping(true);
    setTimeout(() => {
      setTyping(false);
      setMessages(prev => [...prev, {
        role: "donna",
        text: getResponse(text),
        time: "Now",
      }]);
    }, 1200);
  };

  return (
    <PortalLayout
      title="DONNA"
      subtitle="Your coaching assistant"
      showBack
      backTo="/"
      hideNav={false}
      noPadding={true}
    >
      <div className="screen-enter flex flex-col h-full" style={{ minHeight: "calc(100vh - 120px)" }}>
        {/* DONNA header */}
        <div
          className="px-4 py-4 flex items-center gap-3"
          style={{ borderBottom: "1px solid oklch(1 0 0 / 0.07)" }}
        >
          <div
            className="w-12 h-12 rounded-full overflow-hidden donna-pulse flex-shrink-0"
            style={{ border: "2px solid oklch(0.72 0.18 185)" }}
          >
            <img src={DONNA_AVATAR} alt="DONNA" className="w-full h-full object-cover" />
          </div>
          <div>
            <div className="flex items-center gap-1.5">
              <Sparkles size={12} style={{ color: "oklch(0.72 0.18 185)" }} />
              <span className="text-xs font-semibold uppercase tracking-wider" style={{ color: "oklch(0.72 0.18 185)" }}>
                AI-Powered
              </span>
            </div>
            <p className="text-sm" style={{ color: "oklch(0.72 0.015 220)" }}>
              Role-aware · Coach Mode · Orange Ball 2
            </p>
          </div>
        </div>

        {/* Quick actions */}
        <div className="px-4 py-3" style={{ borderBottom: "1px solid oklch(1 0 0 / 0.07)" }}>
          <p className="text-xs font-semibold uppercase tracking-widest mb-2" style={{ color: "oklch(0.55 0.015 220)" }}>
            Quick Actions
          </p>
          <div className="flex gap-2 overflow-x-auto pb-1">
            {QUICK_ACTIONS.map(({ label, icon: Icon, href }) => (
              <Link key={label} href={href}>
                <button
                  className="flex-shrink-0 flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-medium transition-all active:scale-[0.97]"
                  style={{
                    background: "oklch(0.155 0.01 220)",
                    border: "1px solid oklch(1 0 0 / 0.08)",
                    color: "oklch(0.82 0.005 210)",
                  }}
                >
                  <Icon size={12} style={{ color: "oklch(0.72 0.18 185)" }} />
                  {label}
                </button>
              </Link>
            ))}
          </div>
        </div>

        {/* Chat messages */}
        <div className="flex-1 overflow-y-auto px-4 py-4 space-y-3 pb-32">
          {messages.map((msg, i) => (
            <div
              key={i}
              className={`flex gap-2 ${msg.role === "user" ? "flex-row-reverse" : "flex-row"}`}
            >
              {msg.role === "donna" && (
                <div
                  className="w-7 h-7 rounded-full overflow-hidden flex-shrink-0 mt-1"
                  style={{ border: "1.5px solid oklch(0.72 0.18 185)" }}
                >
                  <img src={DONNA_AVATAR} alt="DONNA" className="w-full h-full object-cover" />
                </div>
              )}
              <div
                className="max-w-[80%] rounded-2xl px-4 py-3"
                style={{
                  background: msg.role === "donna"
                    ? "oklch(0.155 0.01 220)"
                    : "oklch(0.72 0.18 185)",
                  color: msg.role === "donna"
                    ? "oklch(0.88 0.005 210)"
                    : "oklch(0.11 0.008 220)",
                  borderRadius: msg.role === "donna"
                    ? "4px 16px 16px 16px"
                    : "16px 4px 16px 16px",
                }}
              >
                <p className="text-sm leading-relaxed">{msg.text}</p>
              </div>
            </div>
          ))}

          {/* Typing indicator */}
          {typing && (
            <div className="flex gap-2">
              <div
                className="w-7 h-7 rounded-full overflow-hidden flex-shrink-0 mt-1"
                style={{ border: "1.5px solid oklch(0.72 0.18 185)" }}
              >
                <img src={DONNA_AVATAR} alt="DONNA" className="w-full h-full object-cover" />
              </div>
              <div
                className="rounded-2xl px-4 py-3 flex items-center gap-1"
                style={{ background: "oklch(0.155 0.01 220)", borderRadius: "4px 16px 16px 16px" }}
              >
                <div className="w-1.5 h-1.5 rounded-full typing-dot" style={{ background: "oklch(0.72 0.18 185)" }} />
                <div className="w-1.5 h-1.5 rounded-full typing-dot" style={{ background: "oklch(0.72 0.18 185)" }} />
                <div className="w-1.5 h-1.5 rounded-full typing-dot" style={{ background: "oklch(0.72 0.18 185)" }} />
              </div>
            </div>
          )}
          <div ref={bottomRef} />
        </div>

        {/* Input */}
        <div
          className="fixed bottom-16 left-1/2 -translate-x-1/2 w-full px-4 py-3"
          style={{
            maxWidth: "480px",
            background: "oklch(0.11 0.008 220 / 0.95)",
            backdropFilter: "blur(12px)",
            borderTop: "1px solid oklch(1 0 0 / 0.07)",
          }}
        >
          <div className="flex items-center gap-2">
            <button
              className="w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0 transition-all active:scale-[0.97]"
              style={{ background: "oklch(0.72 0.18 185 / 0.12)", border: "1px solid oklch(0.72 0.18 185 / 0.25)" }}
              onClick={() => {
                setTyping(true);
                setTimeout(() => {
                  setTyping(false);
                  setMessages(prev => [...prev,
                    { role: "user", text: "🎤 Voice input", time: "Now" },
                    { role: "donna", text: "Voice input received. I heard you mention the session wrap-up. Ready when you are — tap 'Wrap Up Session' to begin.", time: "Now" }
                  ]);
                }, 2000);
              }}
            >
              <Mic size={16} style={{ color: "oklch(0.72 0.18 185)" }} />
            </button>
            <input
              value={input}
              onChange={e => setInput(e.target.value)}
              onKeyDown={e => e.key === "Enter" && sendMessage(input)}
              placeholder="Ask DONNA anything..."
              className="flex-1 rounded-xl px-4 py-2.5 text-sm outline-none"
              style={{
                background: "oklch(0.155 0.01 220)",
                border: "1px solid oklch(1 0 0 / 0.1)",
                color: "oklch(0.94 0.005 210)",
              }}
            />
            <button
              onClick={() => sendMessage(input)}
              className="w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0 transition-all active:scale-[0.97]"
              style={{ background: "oklch(0.72 0.18 185)" }}
            >
              <Send size={15} style={{ color: "oklch(0.11 0.008 220)" }} />
            </button>
          </div>
        </div>
      </div>
    </PortalLayout>
  );
}
