/**
 * Screen 8 — Player Observation Flow
 * Design: Premium Sports App, dark #0d1117, teal accent
 * Quick note: player, type, strength, growth, curriculum link, visibility, urgency
 */
import { useState } from "react";
import { Link } from "wouter";
import PortalLayout from "@/components/PortalLayout";
import { Sparkles, ChevronRight, Lock, Globe, AlertCircle } from "lucide-react";

const DONNA_AVATAR = "https://d2xsxph8kpxj0f.cloudfront.net/310519663491229281/WHXfAe2R2Axz3rJqghCqf9/donna-avatar-VmzCYfHyghnGMkTsmi8HgV.webp";

const PLAYERS = ["Sarah Chen", "Marcus Thompson", "Lily Rodriguez", "James Park", "Emma Wilson", "Noah Kim", "Ava Martinez", "Ethan Lee"];
const OBS_TYPES = ["Technical", "Tactical", "Physical", "Mental/Emotional", "Match Behavior"];
const CURRICULUM_LINKS = ["Crosscourt Rally", "Recovery Footwork", "Serve Mechanics", "Net Approach", "Match Play"];
const URGENCY_LEVELS = [
  { label: "Low", color: "oklch(0.72 0.18 145)" },
  { label: "Medium", color: "oklch(0.78 0.16 75)" },
  { label: "High", color: "oklch(0.65 0.22 25)" },
];

const DONNA_SUGGESTIONS = [
  { path: "Skill Path", text: "Evidence of crosscourt consistency improvement — log under Skill Path milestone" },
  { path: "Competition Path", text: "Positive match behavior noted — relevant to Competition Path readiness" },
  { path: "Fitness Path", text: "Recovery footwork improving — log under Fitness Path movement goals" },
  { path: "Next Session", text: "Ready for progression drill — suggest adding target cones next session" },
];

export default function PlayerObservation() {
  const [selectedPlayer, setSelectedPlayer] = useState("");
  const [obsType, setObsType] = useState("");
  const [strength, setStrength] = useState("");
  const [growth, setGrowth] = useState("");
  const [curriculumLink, setCurriculumLink] = useState("");
  const [visibility, setVisibility] = useState<"internal" | "parent-safe">("internal");
  const [urgency, setUrgency] = useState("Low");
  const [showSuggestions, setShowSuggestions] = useState(false);

  const isReady = selectedPlayer && obsType && (strength || growth);

  return (
    <PortalLayout
      title="Player Observation"
      subtitle="Quick note capture"
      showBack
      backTo="/player-watch-list"
      hideNav
    >
      <div className="screen-enter px-4 pt-4 space-y-5">
        {/* Player select */}
        <div>
          <label className="text-xs font-semibold uppercase tracking-widest mb-2 block" style={{ color: "oklch(0.58 0.015 220)" }}>
            Player
          </label>
          <div className="flex flex-wrap gap-2">
            {PLAYERS.map(name => (
              <button
                key={name}
                onClick={() => setSelectedPlayer(name)}
                className="px-3 py-1.5 rounded-full text-xs font-medium transition-all active:scale-[0.97]"
                style={{
                  background: selectedPlayer === name ? "oklch(0.72 0.18 185)" : "oklch(0.155 0.01 220)",
                  color: selectedPlayer === name ? "oklch(0.11 0.008 220)" : "oklch(0.72 0.015 220)",
                  border: selectedPlayer === name ? "none" : "1px solid oklch(1 0 0 / 0.08)",
                }}
              >
                {name.split(" ")[0]}
              </button>
            ))}
          </div>
        </div>

        {/* Observation type */}
        <div>
          <label className="text-xs font-semibold uppercase tracking-widest mb-2 block" style={{ color: "oklch(0.58 0.015 220)" }}>
            Observation Type
          </label>
          <div className="flex flex-wrap gap-2">
            {OBS_TYPES.map(type => (
              <button
                key={type}
                onClick={() => setObsType(type)}
                className="px-3 py-1.5 rounded-full text-xs font-medium transition-all active:scale-[0.97]"
                style={{
                  background: obsType === type ? "oklch(0.72 0.18 185 / 0.15)" : "oklch(0.155 0.01 220)",
                  color: obsType === type ? "oklch(0.72 0.18 185)" : "oklch(0.72 0.015 220)",
                  border: obsType === type ? "1px solid oklch(0.72 0.18 185 / 0.4)" : "1px solid oklch(1 0 0 / 0.08)",
                }}
              >
                {type}
              </button>
            ))}
          </div>
        </div>

        {/* Strength */}
        <div>
          <label className="text-xs font-semibold uppercase tracking-widest mb-2 block" style={{ color: "oklch(0.58 0.015 220)" }}>
            Strength Observed
          </label>
          <textarea
            value={strength}
            onChange={e => setStrength(e.target.value)}
            placeholder="What did they do well?"
            rows={2}
            className="w-full rounded-xl px-4 py-3 text-sm outline-none resize-none"
            style={{
              background: "oklch(0.155 0.01 220)",
              border: "1px solid oklch(1 0 0 / 0.1)",
              color: "oklch(0.94 0.005 210)",
            }}
          />
        </div>

        {/* Growth area */}
        <div>
          <label className="text-xs font-semibold uppercase tracking-widest mb-2 block" style={{ color: "oklch(0.58 0.015 220)" }}>
            Growth Area
          </label>
          <textarea
            value={growth}
            onChange={e => setGrowth(e.target.value)}
            placeholder="What needs work or attention?"
            rows={2}
            className="w-full rounded-xl px-4 py-3 text-sm outline-none resize-none"
            style={{
              background: "oklch(0.155 0.01 220)",
              border: "1px solid oklch(1 0 0 / 0.1)",
              color: "oklch(0.94 0.005 210)",
            }}
          />
        </div>

        {/* Curriculum link */}
        <div>
          <label className="text-xs font-semibold uppercase tracking-widest mb-2 block" style={{ color: "oklch(0.58 0.015 220)" }}>
            Curriculum Link
          </label>
          <div className="flex flex-wrap gap-2">
            {CURRICULUM_LINKS.map(link => (
              <button
                key={link}
                onClick={() => setCurriculumLink(link)}
                className="px-3 py-1.5 rounded-full text-xs font-medium transition-all active:scale-[0.97]"
                style={{
                  background: curriculumLink === link ? "oklch(0.78 0.16 75 / 0.15)" : "oklch(0.155 0.01 220)",
                  color: curriculumLink === link ? "oklch(0.78 0.16 75)" : "oklch(0.72 0.015 220)",
                  border: curriculumLink === link ? "1px solid oklch(0.78 0.16 75 / 0.4)" : "1px solid oklch(1 0 0 / 0.08)",
                }}
              >
                {link}
              </button>
            ))}
          </div>
        </div>

        {/* Visibility + Urgency row */}
        <div className="grid grid-cols-2 gap-3">
          <div>
            <label className="text-xs font-semibold uppercase tracking-widest mb-2 block" style={{ color: "oklch(0.58 0.015 220)" }}>
              Visibility
            </label>
            <div className="flex flex-col gap-1.5">
              {[
                { key: "internal", label: "Internal", icon: Lock },
                { key: "parent-safe", label: "Parent-Safe", icon: Globe },
              ].map(({ key, label, icon: Icon }) => (
                <button
                  key={key}
                  onClick={() => setVisibility(key as typeof visibility)}
                  className="flex items-center gap-2 px-3 py-2 rounded-xl text-xs font-medium transition-all active:scale-[0.97]"
                  style={{
                    background: visibility === key ? "oklch(0.72 0.18 185 / 0.12)" : "oklch(0.155 0.01 220)",
                    color: visibility === key ? "oklch(0.72 0.18 185)" : "oklch(0.72 0.015 220)",
                    border: visibility === key ? "1px solid oklch(0.72 0.18 185 / 0.3)" : "1px solid oklch(1 0 0 / 0.08)",
                  }}
                >
                  <Icon size={11} />
                  {label}
                </button>
              ))}
            </div>
          </div>
          <div>
            <label className="text-xs font-semibold uppercase tracking-widest mb-2 block" style={{ color: "oklch(0.58 0.015 220)" }}>
              Urgency
            </label>
            <div className="flex flex-col gap-1.5">
              {URGENCY_LEVELS.map(({ label, color }) => (
                <button
                  key={label}
                  onClick={() => setUrgency(label)}
                  className="flex items-center gap-2 px-3 py-2 rounded-xl text-xs font-medium transition-all active:scale-[0.97]"
                  style={{
                    background: urgency === label ? `${color.replace(")", " / 0.12)")}` : "oklch(0.155 0.01 220)",
                    color: urgency === label ? color : "oklch(0.72 0.015 220)",
                    border: urgency === label ? `1px solid ${color.replace(")", " / 0.3)")}` : "1px solid oklch(1 0 0 / 0.08)",
                  }}
                >
                  <AlertCircle size={11} />
                  {label}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* DONNA suggestions */}
        <div>
          <button
            onClick={() => setShowSuggestions(!showSuggestions)}
            className="w-full flex items-center gap-3 p-3 rounded-xl transition-all active:scale-[0.98]"
            style={{
              background: "oklch(0.72 0.18 185 / 0.06)",
              border: "1px solid oklch(0.72 0.18 185 / 0.2)",
            }}
          >
            <div
              className="w-8 h-8 rounded-full overflow-hidden flex-shrink-0"
              style={{ border: "1.5px solid oklch(0.72 0.18 185)" }}
            >
              <img src={DONNA_AVATAR} alt="DONNA" className="w-full h-full object-cover" />
            </div>
            <div className="flex-1 text-left">
              <div className="flex items-center gap-1">
                <Sparkles size={11} style={{ color: "oklch(0.72 0.18 185)" }} />
                <span className="text-xs font-semibold" style={{ color: "oklch(0.72 0.18 185)" }}>
                  DONNA Suggestions
                </span>
              </div>
              <p className="text-xs" style={{ color: "oklch(0.58 0.015 220)" }}>
                Tap to see path evidence & next session ideas
              </p>
            </div>
            <ChevronRight
              size={14}
              style={{
                color: "oklch(0.72 0.18 185)",
                transform: showSuggestions ? "rotate(90deg)" : "none",
                transition: "transform 200ms ease-out",
              }}
            />
          </button>

          {showSuggestions && (
            <div className="mt-2 space-y-2">
              {DONNA_SUGGESTIONS.map(({ path, text }) => (
                <div
                  key={path}
                  className="rounded-xl p-3 flex items-start gap-2"
                  style={{ background: "oklch(0.155 0.01 220)", border: "1px solid oklch(1 0 0 / 0.08)" }}
                >
                  <div
                    className="w-1.5 h-1.5 rounded-full mt-1.5 flex-shrink-0"
                    style={{ background: "oklch(0.72 0.18 185)" }}
                  />
                  <div>
                    <p className="text-xs font-semibold mb-0.5" style={{ color: "oklch(0.72 0.18 185)" }}>{path}</p>
                    <p className="text-xs" style={{ color: "oklch(0.72 0.015 220)" }}>{text}</p>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Save button */}
        <Link href="/donna-wrapup">
          <button
            disabled={!isReady}
            className="w-full flex items-center justify-center gap-2 py-4 rounded-2xl font-semibold text-sm transition-all active:scale-[0.98] disabled:opacity-40"
            style={{
              background: "oklch(0.72 0.18 185)",
              color: "oklch(0.11 0.008 220)",
            }}
          >
            Save Observation
            <ChevronRight size={16} />
          </button>
        </Link>

        <div className="h-4" />
      </div>
    </PortalLayout>
  );
}
