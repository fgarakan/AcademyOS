/**
 * Screen 4 — Player Watch List
 * Design: Premium Sports App, dark #0d1117, teal accent
 * Shows: players, priority, watch-for, last note, risk flag, quick note button
 */
import { useState } from "react";
import { Link } from "wouter";
import PortalLayout from "@/components/PortalLayout";
import { AlertTriangle, Eye, PenLine, ChevronDown, ChevronUp, MessageSquare } from "lucide-react";

const PLAYERS = [
  {
    name: "Sarah Chen",
    initials: "SC",
    level: "Orange Ball 2",
    priority: "Earlier forehand preparation",
    watchFor: "Prepares before ball crosses service line",
    lastNote: "Improved recovery but opens early under pressure",
    lastNoteDate: "2 days ago",
    flag: "attention",
    flagLabel: "Needs Attention",
  },
  {
    name: "Marcus Thompson",
    initials: "MT",
    level: "Orange Ball 2",
    priority: "Serve toss consistency",
    watchFor: "Toss placement — in front and to the right",
    lastNote: "Toss improving in warm-up but reverts under match pressure",
    lastNoteDate: "Yesterday",
    flag: "watch",
    flagLabel: "Watch",
  },
  {
    name: "Lily Rodriguez",
    initials: "LR",
    level: "Orange Ball 2",
    priority: "Crosscourt depth",
    watchFor: "Finish position — racket above shoulder",
    lastNote: "Great session — depth improving, ready for progression",
    lastNoteDate: "Today",
    flag: "good",
    flagLabel: "Progressing",
  },
  {
    name: "James Park",
    initials: "JP",
    level: "Orange Ball 2",
    priority: "Net approach footwork",
    watchFor: "Split-step timing at net",
    lastNote: "Hesitant at net — needs confidence drills",
    lastNoteDate: "3 days ago",
    flag: "watch",
    flagLabel: "Watch",
  },
  {
    name: "Emma Wilson",
    initials: "EW",
    level: "Orange Ball 2",
    priority: "Backhand slice consistency",
    watchFor: "Low contact point on slice",
    lastNote: "Solid session, slice improving in rallies",
    lastNoteDate: "Yesterday",
    flag: "good",
    flagLabel: "Progressing",
  },
  {
    name: "Noah Kim",
    initials: "NK",
    level: "Orange Ball 2",
    priority: "Match intensity",
    watchFor: "Engagement during point play",
    lastNote: "Distracted during point play — check in with parent",
    lastNoteDate: "Today",
    flag: "attention",
    flagLabel: "Needs Attention",
  },
];

const FLAG_STYLES: Record<string, { bg: string; text: string; dot: string }> = {
  attention: {
    bg: "oklch(0.65 0.22 25 / 0.12)",
    text: "oklch(0.65 0.22 25)",
    dot: "oklch(0.65 0.22 25)",
  },
  watch: {
    bg: "oklch(0.78 0.16 75 / 0.12)",
    text: "oklch(0.78 0.16 75)",
    dot: "oklch(0.78 0.16 75)",
  },
  good: {
    bg: "oklch(0.72 0.18 145 / 0.12)",
    text: "oklch(0.72 0.18 145)",
    dot: "oklch(0.72 0.18 145)",
  },
};

function PlayerCard({ player }: { player: typeof PLAYERS[0] }) {
  const [expanded, setExpanded] = useState(false);
  const styles = FLAG_STYLES[player.flag];

  return (
    <div
      className="rounded-2xl overflow-hidden transition-all"
      style={{ background: "oklch(0.155 0.01 220)", border: "1px solid oklch(1 0 0 / 0.08)" }}
    >
      <button
        className="w-full px-4 py-3 flex items-center gap-3 text-left"
        onClick={() => setExpanded(!expanded)}
      >
        <div
          className="w-10 h-10 rounded-full flex items-center justify-center text-sm font-bold flex-shrink-0"
          style={{ background: styles.bg, color: styles.text, fontFamily: "'Syne', sans-serif" }}
        >
          {player.initials}
        </div>
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2">
            <p className="text-sm font-semibold" style={{ color: "oklch(0.94 0.005 210)" }}>
              {player.name}
            </p>
            <span
              className="status-pill"
              style={{ background: styles.bg, color: styles.text }}
            >
              {player.flagLabel}
            </span>
          </div>
          <p className="text-xs truncate mt-0.5" style={{ color: "oklch(0.58 0.015 220)" }}>
            {player.priority}
          </p>
        </div>
        {expanded
          ? <ChevronUp size={16} style={{ color: "oklch(0.55 0.015 220)", flexShrink: 0 }} />
          : <ChevronDown size={16} style={{ color: "oklch(0.55 0.015 220)", flexShrink: 0 }} />
        }
      </button>

      {expanded && (
        <div
          className="px-4 pb-4 space-y-3"
          style={{ borderTop: "1px solid oklch(1 0 0 / 0.06)" }}
        >
          <div className="pt-3 space-y-3">
            {/* Watch-for */}
            <div className="flex items-start gap-2">
              <Eye size={13} style={{ color: "oklch(0.72 0.18 185)", flexShrink: 0, marginTop: 2 }} />
              <div>
                <p className="text-xs font-semibold mb-0.5" style={{ color: "oklch(0.72 0.18 185)" }}>Watch For</p>
                <p className="text-sm" style={{ color: "oklch(0.82 0.005 210)" }}>{player.watchFor}</p>
              </div>
            </div>

            {/* Last note */}
            <div className="flex items-start gap-2">
              <MessageSquare size={13} style={{ color: "oklch(0.58 0.015 220)", flexShrink: 0, marginTop: 2 }} />
              <div>
                <p className="text-xs font-semibold mb-0.5" style={{ color: "oklch(0.58 0.015 220)" }}>
                  Last Note · {player.lastNoteDate}
                </p>
                <p className="text-sm italic" style={{ color: "oklch(0.72 0.015 220)" }}>"{player.lastNote}"</p>
              </div>
            </div>

            {/* Quick note button */}
            <Link href="/player-observation">
              <button
                className="w-full flex items-center justify-center gap-2 py-2.5 rounded-xl text-sm font-semibold transition-all active:scale-[0.97]"
                style={{
                  background: "oklch(0.185 0.01 220)",
                  border: "1px solid oklch(1 0 0 / 0.1)",
                  color: "oklch(0.88 0.005 210)",
                }}
              >
                <PenLine size={14} style={{ color: "oklch(0.72 0.18 185)" }} />
                Add Note for {player.name.split(" ")[0]}
              </button>
            </Link>
          </div>
        </div>
      )}
    </div>
  );
}

export default function PlayerWatchList() {
  const [filter, setFilter] = useState<"all" | "attention" | "watch" | "good">("all");

  const filtered = filter === "all" ? PLAYERS : PLAYERS.filter(p => p.flag === filter);
  const attentionCount = PLAYERS.filter(p => p.flag === "attention").length;

  return (
    <PortalLayout
      title="Player Watch List"
      subtitle="Orange Ball 2 · Today"
      showBack
      backTo="/"
      headerRight={
        <Link href="/player-observation">
          <button
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold transition-all active:scale-[0.97]"
            style={{ background: "oklch(0.72 0.18 185 / 0.12)", color: "oklch(0.72 0.18 185)", border: "1px solid oklch(0.72 0.18 185 / 0.25)" }}
          >
            <PenLine size={12} />
            Add Note
          </button>
        </Link>
      }
    >
      <div className="screen-enter px-4 pt-4 space-y-4">
        {/* Attention banner */}
        {attentionCount > 0 && (
          <div
            className="rounded-xl p-3 flex items-center gap-3"
            style={{ background: "oklch(0.65 0.22 25 / 0.08)", border: "1px solid oklch(0.65 0.22 25 / 0.2)" }}
          >
            <AlertTriangle size={16} style={{ color: "oklch(0.65 0.22 25)", flexShrink: 0 }} />
            <p className="text-sm" style={{ color: "oklch(0.88 0.005 210)" }}>
              <span className="font-semibold" style={{ color: "oklch(0.65 0.22 25)" }}>{attentionCount} players</span> need attention today
            </p>
          </div>
        )}

        {/* Filter tabs */}
        <div className="flex gap-2 overflow-x-auto pb-1">
          {[
            { key: "all", label: "All Players" },
            { key: "attention", label: "Attention" },
            { key: "watch", label: "Watch" },
            { key: "good", label: "Progressing" },
          ].map(({ key, label }) => (
            <button
              key={key}
              onClick={() => setFilter(key as typeof filter)}
              className="flex-shrink-0 px-3 py-1.5 rounded-full text-xs font-semibold transition-all active:scale-[0.97]"
              style={{
                background: filter === key ? "oklch(0.72 0.18 185)" : "oklch(0.155 0.01 220)",
                color: filter === key ? "oklch(0.11 0.008 220)" : "oklch(0.58 0.015 220)",
                border: filter === key ? "none" : "1px solid oklch(1 0 0 / 0.08)",
              }}
            >
              {label}
            </button>
          ))}
        </div>

        {/* Player cards */}
        <div className="space-y-2">
          {filtered.map(player => (
            <PlayerCard key={player.name} player={player} />
          ))}
        </div>

        <div className="h-4" />
      </div>
    </PortalLayout>
  );
}
