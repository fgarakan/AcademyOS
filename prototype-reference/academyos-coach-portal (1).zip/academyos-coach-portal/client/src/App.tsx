import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/NotFound";
import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";

// Coach Portal Screens
import CoachToday from "./pages/CoachToday";
import SessionPlan from "./pages/SessionPlan";
import TemplateExecution from "./pages/TemplateExecution";
import PlayerWatchList from "./pages/PlayerWatchList";
import DonnaAssistant from "./pages/DonnaAssistant";
import DonnaWrapUp from "./pages/DonnaWrapUp";
import AttendanceException from "./pages/AttendanceException";
import PlayerObservation from "./pages/PlayerObservation";
import WrapUpReview from "./pages/WrapUpReview";
import SubmittedSummary from "./pages/SubmittedSummary";

function Router() {
  return (
    <Switch>
      <Route path="/" component={CoachToday} />
      <Route path="/session-plan" component={SessionPlan} />
      <Route path="/template-execution" component={TemplateExecution} />
      <Route path="/player-watch-list" component={PlayerWatchList} />
      <Route path="/donna-assistant" component={DonnaAssistant} />
      <Route path="/donna-wrapup" component={DonnaWrapUp} />
      <Route path="/attendance-exception" component={AttendanceException} />
      <Route path="/player-observation" component={PlayerObservation} />
      <Route path="/wrapup-review" component={WrapUpReview} />
      <Route path="/submitted-summary" component={SubmittedSummary} />
      <Route path="/404" component={NotFound} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider defaultTheme="dark">
        <TooltipProvider>
          <Toaster />
          <Router />
        </TooltipProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;
