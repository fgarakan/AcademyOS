/**
 * PortalLayout — AcademyOS Coach Portal
 * Design: Premium Sports App, dark #0d1117, teal accent #00c9b1
 * Bottom tab nav, sticky header, mobile-first max-width 480px
 */
import { Link, useLocation } from "wouter";
import { CalendarDays, Users, Zap, MessageCircle, ChevronLeft } from "lucide-react";
import { cn } from "@/lib/utils";

const NAV_ITEMS = [
  { path: "/", label: "Today", icon: CalendarDays },
  { path: "/player-watch-list", label: "Players", icon: Users },
  { path: "/template-execution", label: "On Court", icon: Zap },
  { path: "/donna-assistant", label: "DONNA", icon: MessageCircle },
];

interface PortalLayoutProps {
  children: React.ReactNode;
  title?: string;
  subtitle?: string;
  showBack?: boolean;
  backTo?: string;
  headerRight?: React.ReactNode;
  hideNav?: boolean;
  noPadding?: boolean;
}

export default function PortalLayout({
  children,
  title,
  subtitle,
  showBack,
  backTo = "/",
  headerRight,
  hideNav = false,
  noPadding = false,
}: PortalLayoutProps) {
  const [location] = useLocation();

  return (
    <div
      className="min-h-screen flex flex-col"
      style={{ background: "oklch(0.11 0.008 220)", maxWidth: "480px", margin: "0 auto" }}
    >
      {/* Header */}
      {(title || showBack || headerRight) && (
        <header
          className="sticky top-0 z-40 flex items-center gap-3 px-4 py-3"
          style={{
            background: "oklch(0.11 0.008 220 / 0.92)",
            backdropFilter: "blur(12px)",
            borderBottom: "1px solid oklch(1 0 0 / 0.07)",
          }}
        >
          {showBack && (
            <Link href={backTo}>
              <button
                className="flex items-center justify-center w-9 h-9 rounded-xl transition-all"
                style={{ background: "oklch(0.155 0.01 220)" }}
              >
                <ChevronLeft size={18} style={{ color: "oklch(0.72 0.18 185)" }} />
              </button>
            </Link>
          )}
          <div className="flex-1 min-w-0">
            {title && (
              <h1
                className="text-base font-bold leading-tight truncate"
                style={{ fontFamily: "'Syne', sans-serif", color: "oklch(0.94 0.005 210)" }}
              >
                {title}
              </h1>
            )}
            {subtitle && (
              <p className="text-xs truncate" style={{ color: "oklch(0.58 0.015 220)" }}>
                {subtitle}
              </p>
            )}
          </div>
          {headerRight && <div className="flex-shrink-0">{headerRight}</div>}
        </header>
      )}

      {/* Main content */}
      <main className={cn("flex-1 overflow-y-auto", !noPadding && "pb-24")}>
        {children}
      </main>

      {/* Bottom navigation */}
      {!hideNav && (
        <nav
          className="fixed bottom-0 left-1/2 -translate-x-1/2 w-full z-50 flex items-center justify-around px-2 py-2"
          style={{
            maxWidth: "480px",
            background: "oklch(0.155 0.01 220 / 0.96)",
            backdropFilter: "blur(16px)",
            borderTop: "1px solid oklch(1 0 0 / 0.08)",
          }}
        >
          {NAV_ITEMS.map(({ path, label, icon: Icon }) => {
            const active = location === path;
            return (
              <Link key={path} href={path}>
                <button
                  className="flex flex-col items-center gap-1 px-4 py-2 rounded-xl transition-all"
                  style={{
                    background: active ? "oklch(0.72 0.18 185 / 0.12)" : "transparent",
                    minWidth: "64px",
                  }}
                >
                  <Icon
                    size={20}
                    style={{
                      color: active ? "oklch(0.72 0.18 185)" : "oklch(0.55 0.015 220)",
                      transition: "color 180ms ease-out",
                    }}
                  />
                  <span
                    className="text-xs font-medium"
                    style={{
                      color: active ? "oklch(0.72 0.18 185)" : "oklch(0.55 0.015 220)",
                      fontFamily: "'DM Sans', sans-serif",
                      transition: "color 180ms ease-out",
                    }}
                  >
                    {label}
                  </span>
                </button>
              </Link>
            );
          })}
        </nav>
      )}
    </div>
  );
}
