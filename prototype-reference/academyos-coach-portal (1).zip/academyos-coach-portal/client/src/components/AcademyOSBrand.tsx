/**
 * AcademyOS Brand Header — used in Coach Today top bar
 * Design: Syne font, teal accent dot, minimal wordmark
 */
export default function AcademyOSBrand() {
  return (
    <div className="flex items-center gap-2">
      {/* Logo mark */}
      <div
        className="w-7 h-7 rounded-lg flex items-center justify-center"
        style={{
          background: "linear-gradient(135deg, oklch(0.72 0.18 185), oklch(0.60 0.18 200))",
        }}
      >
        <svg width="14" height="14" viewBox="0 0 14 14" fill="none">
          <path d="M7 1L13 4.5V9.5L7 13L1 9.5V4.5L7 1Z" stroke="oklch(0.11 0.008 220)" strokeWidth="1.5" fill="none" />
          <circle cx="7" cy="7" r="2" fill="oklch(0.11 0.008 220)" />
        </svg>
      </div>
      {/* Wordmark */}
      <div>
        <span
          className="text-sm font-bold leading-none"
          style={{ fontFamily: "'Syne', sans-serif", color: "oklch(0.94 0.005 210)" }}
        >
          AcademyOS
        </span>
        <div className="flex items-center gap-1 mt-0.5">
          <div className="w-1.5 h-1.5 rounded-full" style={{ background: "oklch(0.72 0.18 185)" }} />
          <span className="text-xs" style={{ color: "oklch(0.72 0.18 185)", fontFamily: "'DM Sans', sans-serif" }}>
            Coach Portal
          </span>
        </div>
      </div>
    </div>
  );
}
