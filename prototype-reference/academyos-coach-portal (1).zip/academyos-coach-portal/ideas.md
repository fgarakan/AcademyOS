# AcademyOS Coach Portal — Design Brainstorm

## Context
Dark premium athletic SaaS. Aqua/teal accents. Mobile-first, on-court usability. DONNA as role-aware AI assistant. Coaches are tired, on-court, and need clarity at a glance.

---

<response>
<probability>0.07</probability>
<idea>

**Design Movement:** Terminal-Meets-Athletic — Hacker aesthetic softened by sport energy

**Core Principles:**
1. Monospace data readability — every number feels precise and authoritative
2. Neon-on-dark contrast — information pops like a scoreboard
3. Card-as-court — each card is a contained "court zone" with clear boundaries
4. Zero decoration — every pixel earns its place

**Color Philosophy:**
- Background: near-black `#0a0e0f` — deep court shadow
- Surface: `#111618` — dark slate, like a coach's clipboard at night
- Accent: `#00e5c8` — electric teal, the one color that cuts through everything
- Warning: `#f5a623` — amber, like a caution cone
- Text: `#e8f4f2` — slightly warm white, not clinical

**Layout Paradigm:**
- Vertical stack of "zones" — each zone is a full-width band
- Left-anchored labels, right-anchored values
- No centered content except DONNA's voice interface
- Navigation: bottom tab bar (thumb-reachable)

**Signature Elements:**
1. Thin horizontal rule separators with teal glow
2. Monospace font for times, scores, counts
3. DONNA's responses appear in a "terminal-style" expanding block

**Interaction Philosophy:**
- Tap targets minimum 56px height
- Swipe-to-dismiss for completed items
- Long-press reveals secondary actions

**Animation:**
- Slide-up panels (200ms ease-out)
- DONNA typing indicator: three dots with stagger
- Card entrance: fade + translateY(8px) → 0

**Typography System:**
- Display: `Space Grotesk` Bold — headers, session titles
- Body: `Inter` Regular — descriptions, notes
- Data: `JetBrains Mono` — times, counts, codes

</idea>
</response>

<response>
<probability>0.06</probability>
<idea>

**Design Movement:** Premium Sports App — Nike Training Club meets Notion

**Core Principles:**
1. Information hierarchy through weight, not decoration
2. Generous breathing room — whitespace as signal of confidence
3. Teal as the single accent color — used sparingly, meaning everything
4. Cards feel physical — subtle elevation, not flat

**Color Philosophy:**
- Background: `#0d1117` — GitHub dark, familiar and trusted
- Surface: `#161b22` — slightly lighter, card separation
- Accent: `#00c9b1` — teal that reads as "go" and "AI"
- Secondary surface: `#1c2128`
- Text primary: `#f0f6fc`
- Text muted: `#8b949e`

**Layout Paradigm:**
- Single-column mobile scroll with sticky header
- Section headers act as visual anchors
- DONNA panel slides in from bottom as a sheet
- Bottom navigation with 4 tabs

**Signature Elements:**
1. Pill badges for status (Active, Pending, Done)
2. Left-border accent lines on priority items
3. DONNA's avatar: animated teal pulse ring

**Interaction Philosophy:**
- One primary action per screen
- Secondary actions behind "..." menus
- DONNA always accessible via FAB

**Animation:**
- Sheet open: spring physics (stiffness 300, damping 30)
- Badge pulse: 2s loop, subtle scale
- Progress bars: fill on mount with ease-out

**Typography System:**
- Display: `Syne` ExtraBold — screen titles
- Body: `DM Sans` — readable, friendly
- Mono: `Fira Code` — data values

</idea>
</response>

<response>
<probability>0.05</probability>
<idea>

**Design Movement:** Tactical Dashboard — Military briefing meets sports analytics

**Core Principles:**
1. Information density with visual hierarchy — no wasted space
2. Color-coded priority system — red/amber/green/teal
3. Asymmetric layouts — data on left, actions on right
4. DONNA as command interface — feels like a comms channel

**Color Philosophy:**
- Background: `#080c0d` — almost black
- Surface: `#0f1519` — dark teal-tinted slate
- Accent: `#14f0c8` — bright mint-teal
- Alert: `#ff4757` — red for attention flags
- Caution: `#ffa502` — amber for watch items
- Success: `#2ed573` — green for completed

**Layout Paradigm:**
- Split-panel on tablet, stacked on mobile
- Left rail: navigation + session context
- Main area: current task/screen
- Right drawer: DONNA assistant (collapsible)

**Signature Elements:**
1. Dashed border containers for "in-progress" states
2. Scan-line texture overlay (very subtle, 2% opacity)
3. Corner-bracket decorators on key cards

**Interaction Philosophy:**
- Keyboard-style tap feedback
- Status indicators always visible
- DONNA responses feel like comms messages

**Animation:**
- Scan-line sweep on screen load
- Data values count up on mount
- DONNA messages: typewriter effect

**Typography System:**
- Display: `Barlow Condensed` Bold — compact, athletic
- Body: `IBM Plex Sans` — technical, readable
- Mono: `IBM Plex Mono` — data

</idea>
</response>

---

## Selected Design: **Premium Sports App** (Response 2)

**Rationale:** Balances the dark premium aesthetic of AcademyOS with coach-friendly readability. Syne + DM Sans gives a modern athletic feel without being intimidating. The teal accent system maps perfectly to DONNA's AI identity. Bottom navigation ensures thumb-reachable UX on mobile. Single-column scroll with generous spacing reduces cognitive load for tired coaches.
