/**
 * OnboardingContext — AcademyOS Donna Onboarding
 * Manages all 10-screen state: selections, navigation, DNA summary
 */
import React, { createContext, useContext, useState, useCallback } from 'react';

export type Screen =
  | 'welcome'
  | 'academy-basics'
  | 'coaching-philosophy'
  | 'coach-communication'
  | 'session-design'
  | 'player-development'
  | 'parent-communication'
  | 'dna-summary'
  | 'donna-chat'
  | 'final-activation';

export const SCREENS: Screen[] = [
  'welcome',
  'academy-basics',
  'coaching-philosophy',
  'coach-communication',
  'session-design',
  'player-development',
  'parent-communication',
  'dna-summary',
  'donna-chat',
  'final-activation',
];

export const PROGRESS_STEPS = [
  { id: 'academy-basics', label: 'Academy Basics', screen: 'academy-basics' as Screen },
  { id: 'coaching-dna', label: 'Coaching DNA', screen: 'coaching-philosophy' as Screen },
  { id: 'session-defaults', label: 'Session Defaults', screen: 'session-design' as Screen },
  { id: 'parent-comms', label: 'Parent Communication', screen: 'parent-communication' as Screen },
  { id: 'review', label: 'Review', screen: 'dna-summary' as Screen },
];

export interface OnboardingState {
  // Academy Basics
  academyName: string;
  ageGroups: string[];
  academyModel: string;

  // Coaching Philosophy (up to 3)
  coachingStyles: string[];

  // Coach Communication
  primaryCommunication: string;
  secondaryCommunication: string;

  // Session Design
  sessionDesigns: string[];

  // Player Development (ordered top 5)
  playerPriorities: string[];

  // Parent Communication
  parentStyles: string[];
}

const defaultState: OnboardingState = {
  academyName: '',
  ageGroups: [],
  academyModel: '',
  coachingStyles: [],
  primaryCommunication: '',
  secondaryCommunication: '',
  sessionDesigns: [],
  playerPriorities: [],
  parentStyles: [],
};

interface OnboardingContextValue {
  currentScreen: Screen;
  state: OnboardingState;
  goTo: (screen: Screen) => void;
  goNext: () => void;
  goPrev: () => void;
  updateState: (partial: Partial<OnboardingState>) => void;
  toggleArrayItem: (key: keyof OnboardingState, item: string, max?: number) => void;
  getProgressPercent: () => number;
  getStepStatus: (stepScreen: string) => 'complete' | 'active' | 'upcoming';
}

const OnboardingContext = createContext<OnboardingContextValue | null>(null);

export function OnboardingProvider({ children }: { children: React.ReactNode }) {
  const [currentScreen, setCurrentScreen] = useState<Screen>('welcome');
  const [state, setState] = useState<OnboardingState>(defaultState);

  const goTo = useCallback((screen: Screen) => {
    setCurrentScreen(screen);
  }, []);

  const goNext = useCallback(() => {
    const idx = SCREENS.indexOf(currentScreen);
    if (idx < SCREENS.length - 1) {
      setCurrentScreen(SCREENS[idx + 1]);
    }
  }, [currentScreen]);

  const goPrev = useCallback(() => {
    const idx = SCREENS.indexOf(currentScreen);
    if (idx > 0) {
      setCurrentScreen(SCREENS[idx - 1]);
    }
  }, [currentScreen]);

  const updateState = useCallback((partial: Partial<OnboardingState>) => {
    setState(prev => ({ ...prev, ...partial }));
  }, []);

  const toggleArrayItem = useCallback(
    (key: keyof OnboardingState, item: string, max?: number) => {
      setState(prev => {
        const arr = prev[key] as string[];
        if (arr.includes(item)) {
          return { ...prev, [key]: arr.filter(i => i !== item) };
        }
        if (max && arr.length >= max) {
          // Replace the last item if at max
          return { ...prev, [key]: [...arr.slice(0, max - 1), item] };
        }
        return { ...prev, [key]: [...arr, item] };
      });
    },
    []
  );

  const getProgressPercent = useCallback(() => {
    const contentScreens = SCREENS.filter(s => s !== 'welcome' && s !== 'donna-chat' && s !== 'final-activation');
    const idx = contentScreens.indexOf(currentScreen as typeof contentScreens[number]);
    if (idx < 0) return currentScreen === 'final-activation' ? 100 : 0;
    return Math.round(((idx + 1) / contentScreens.length) * 100);
  }, [currentScreen]);

  const getStepStatus = useCallback(
    (stepScreen: string): 'complete' | 'active' | 'upcoming' => {
      const stepIdx = SCREENS.indexOf(stepScreen as Screen);
      const currentIdx = SCREENS.indexOf(currentScreen);
      if (currentIdx > stepIdx) return 'complete';
      if (currentIdx === stepIdx) return 'active';
      return 'upcoming';
    },
    [currentScreen]
  );

  return (
    <OnboardingContext.Provider
      value={{
        currentScreen,
        state,
        goTo,
        goNext,
        goPrev,
        updateState,
        toggleArrayItem,
        getProgressPercent,
        getStepStatus,
      }}
    >
      {children}
    </OnboardingContext.Provider>
  );
}

export function useOnboarding() {
  const ctx = useContext(OnboardingContext);
  if (!ctx) throw new Error('useOnboarding must be used within OnboardingProvider');
  return ctx;
}
