/**
 * DNASummaryScreen — AnglesOS Brand Kit v1.0
 * The most important screen — shareable DNA card + full detail review
 * Accent: #00C9A7 teal | Font: Inter
 * Background: #0A0F0E | Surface: #111A18 | Border: rgba(0,201,167,0.10)
 */
import { useOnboarding } from '@/contexts/OnboardingContext';
import { ArrowRight, Edit2, MessageSquare, CheckCircle2 } from 'lucide-react';

const DNA_BG = 'https://d2xsxph8kpxj0f.cloudfront.net/310519663491229281/hThsvPRkRg2ZPapL6S2sHW/dna-card-bg-jJGh4LRaLWFkDjmMqgu3Cs.webp';

const COACHING_LABELS: Record<string, string> = {
  'fundamentals-first': 'Fundamentals First', 'game-based': 'Game-Based Learning',
  'high-performance': 'High-Performance Discipline', 'player-centered': 'Player-Centered Coaching',
  'tactical-first': 'Tactical First', 'movement-first': 'Movement First',
  'competition-ready': 'Competition-Ready', 'joy-retention': 'Joy + Retention',
};
const COMM_LABELS: Record<string, string> = {
  'direct-clear': 'Direct + Clear', 'encouraging-positive': 'Encouraging + Positive',
  'question-led': 'Question-Led', 'high-energy': 'High-Energy Motivator',
  'calm-precise': 'Calm + Precise', 'standards-based': 'Standards-Based',
};
const SESSION_LABELS: Record<string, string> = {
  'technique-blocks': 'Technique Blocks', 'live-ball-heavy': 'Live Ball Heavy',
  'constraint-games': 'Constraint Games', 'point-play': 'Point Play Progression',
  'stations': 'Stations + Rotations', 'assessment': 'Assessment Moments', 'fitness-integrated': 'Fitness Integrated',
};
const PARENT_LABELS: Record<string, string> = {
  'simple-reassuring': 'Simple + Reassuring', 'progress-focused': 'Progress-Focused',
  'developmental-education': 'Developmental Education', 'actionable-support': 'Actionable At-Home Support',
  'minimal-noise': 'Minimal Parent Noise', 'transparent-levels': 'Transparent Level Progression',
  'tournament-support': 'Tournament Support Guidance',
};
const PLAYER_LABELS: Record<string, string> = {
  'technical-foundation': 'Technical Foundation', 'tactical-iq': 'Tactical IQ',
  'movement-quality': 'Movement Quality', 'competitive-toughness': 'Competitive Toughness',
  'emotional-regulation': 'Emotional Regulation', 'consistency': 'Consistency + Rally Tolerance',
  'aggressive-identity': 'Aggressive Identity', 'all-court': 'All-Court Development',
  'serve-return': 'Serve + Return Priority', 'independence': 'Independence + Ownership',
};
const MODEL_LABELS: Record<string, string> = {
  'development': 'Development Academy', 'high-performance': 'High Performance Academy',
  'rec-competitive': 'Recreational + Competitive', 'multi-site': 'Multi-Site Academy',
  'private': 'Private Coaching Program', 'school-club': 'School / Club Program',
};
const AGE_LABELS: Record<string, string> = {
  'red-ball': 'Red Ball', 'orange-ball': 'Orange Ball', 'green-ball': 'Green Ball',
  'yellow-ball': 'Yellow Ball', 'high-performance': 'High Performance', 'adult': 'Adult',
};

interface SectionRowProps {
  label: string;
  items: string[];
  labelMap: Record<string, string>;
  ranked?: boolean;
}
function SectionRow({ label, items, labelMap, ranked }: SectionRowProps) {
  if (items.length === 0) return null;
  return (
    <div style={{ marginBottom: 16 }}>
      <p style={{ fontFamily: 'Inter', fontWeight: 700, fontSize: 10, color: '#3A6660', textTransform: 'uppercase', letterSpacing: '0.1em', marginBottom: 7 }}>
        {label}
      </p>
      <div style={{ display: 'flex', flexWrap: 'wrap', gap: 5 }}>
        {items.map((id, i) => (
          <div key={id} style={{
            display: 'flex', alignItems: 'center', gap: 5,
            background: 'rgba(0,201,167,0.06)', border: '1px solid rgba(0,201,167,0.15)',
            borderRadius: 6, padding: '3px 9px',
          }}>
            {ranked && items.length > 1 && (
              <span style={{ fontFamily: 'Inter', fontWeight: 700, fontSize: 9, color: '#00C9A7' }}>{i + 1}</span>
            )}
            <span style={{ fontFamily: 'Inter', fontSize: 12, color: '#C8E0DC' }}>{labelMap[id] || id}</span>
          </div>
        ))}
      </div>
    </div>
  );
}

function generateNarrativeSummary(state: ReturnType<typeof useOnboarding>['state']): string {
  const academy = state.academyName || 'Your academy';
  const styles = state.coachingStyles.map(id => COACHING_LABELS[id]).filter(Boolean);
  const comm = state.primaryCommunication ? COMM_LABELS[state.primaryCommunication] : null;
  const parentStyle = state.parentStyles[0] ? PARENT_LABELS[state.parentStyles[0]] : null;
  let summary = `${academy} is built around`;
  if (styles.length > 0) {
    summary += ` ${styles.join(', ').toLowerCase()}`;
  } else {
    summary += ' a balanced coaching approach';
  }
  summary += '. DONNA will generate sessions with technical preparation, live-ball decision making, and pressure-based scoring.';
  if (comm) summary += ` Coaches will receive ${comm.toLowerCase()} cues`;
  if (parentStyle) summary += ` while parent updates stay ${parentStyle.toLowerCase()}`;
  summary += '.';
  return summary;
}

export default function DNASummaryScreen() {
  const { state, goTo, goNext } = useOnboarding();
  const narrative = generateNarrativeSummary(state);

  return (
    <div style={{ maxWidth: 860, fontFamily: 'Inter, -apple-system, BlinkMacSystemFont, sans-serif', animation: 'slide-up 320ms var(--ease-snappy) both' }}>
      {/* Header */}
      <div style={{ marginBottom: 28 }}>
        <p style={{ fontFamily: 'Inter', fontWeight: 700, fontSize: 10, color: '#00C9A7', textTransform: 'uppercase', letterSpacing: '0.1em', marginBottom: 8 }}>
          Review — Academy DNA
        </p>
        <h2 style={{ fontFamily: 'Inter', fontWeight: 700, fontSize: 'clamp(1.5rem, 2.5vw, 2rem)', color: '#E8F0EE', lineHeight: 1.2, marginBottom: 8 }}>
          Here's your Academy <span style={{ color: '#00C9A7' }}>Coaching DNA.</span>
        </h2>
        <p style={{ fontFamily: 'Inter', fontSize: 13, color: '#5A7A76', lineHeight: 1.6, maxWidth: 520 }}>
          Review your selections. DONNA will use these to generate all your academy defaults.
        </p>
      </div>

      <div style={{ display: 'flex', gap: 20, alignItems: 'flex-start' }}>
        {/* Left: DNA Card */}
        <div style={{
          width: 300,
          flexShrink: 0,
          borderRadius: 16,
          overflow: 'hidden',
          position: 'relative',
          border: '1px solid rgba(0,201,167,0.20)',
          boxShadow: '0 0 40px rgba(0,201,167,0.08)',
        }}>
          <div style={{
            position: 'absolute', inset: 0,
            backgroundImage: `url(${DNA_BG})`,
            backgroundSize: 'cover', backgroundPosition: 'center',
            opacity: 0.5,
          }} />
          <div style={{
            position: 'absolute', inset: 0,
            background: 'linear-gradient(160deg, rgba(0,201,167,0.06) 0%, rgba(10,15,14,0.88) 60%)',
          }} />

          <div style={{ position: 'relative', zIndex: 1, padding: '20px' }}>
            {/* Card header */}
            <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 16 }}>
              <div style={{
                width: 28, height: 28, borderRadius: 8,
                background: 'linear-gradient(135deg, #00C9A7, #00E5C4)',
                display: 'flex', alignItems: 'center', justifyContent: 'center',
              }}>
                <span style={{ fontFamily: 'Inter', fontWeight: 800, fontSize: 13, color: '#050D0B' }}>A</span>
              </div>
              <div>
                <p style={{ fontFamily: 'Inter', fontWeight: 700, fontSize: 13, color: '#E8F0EE', lineHeight: 1.1 }}>
                  {state.academyName || 'Your Academy'}
                </p>
                <p style={{ fontFamily: 'Inter', fontWeight: 600, fontSize: 10, color: '#00C9A7', letterSpacing: '0.06em' }}>
                  Academy DNA
                </p>
              </div>
            </div>

            {/* Narrative */}
            <p style={{ fontFamily: 'Inter', fontSize: 12, color: 'rgba(200,224,220,0.8)', lineHeight: 1.65, marginBottom: 16 }}>
              {narrative}
            </p>

            {/* Key stats */}
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 7, marginBottom: 16 }}>
              {[
                { label: 'Coaching Styles', value: state.coachingStyles.length },
                { label: 'Session Blocks', value: state.sessionDesigns.length },
                { label: 'Dev Priorities', value: state.playerPriorities.length },
                { label: 'Parent Styles', value: state.parentStyles.length },
              ].map(stat => (
                <div key={stat.label} style={{
                  background: 'rgba(0,201,167,0.06)', border: '1px solid rgba(0,201,167,0.12)',
                  borderRadius: 8, padding: '8px 10px',
                }}>
                  <p style={{ fontFamily: 'Inter', fontWeight: 700, fontSize: 18, color: '#00C9A7', lineHeight: 1 }}>
                    {stat.value}
                  </p>
                  <p style={{ fontFamily: 'Inter', fontSize: 10, color: '#5A7A76', marginTop: 2 }}>
                    {stat.label}
                  </p>
                </div>
              ))}
            </div>

            {/* Model badge */}
            {state.academyModel && (
              <div style={{
                display: 'inline-flex', alignItems: 'center', gap: 5,
                background: 'rgba(0,201,167,0.08)', border: '1px solid rgba(0,201,167,0.18)',
                borderRadius: 6, padding: '3px 10px',
              }}>
                <span style={{ fontFamily: 'Inter', fontSize: 11, color: '#A0B8B4' }}>
                  {MODEL_LABELS[state.academyModel] || state.academyModel}
                </span>
              </div>
            )}
          </div>
        </div>

        {/* Right: Full detail sections */}
        <div style={{ flex: 1, minWidth: 0 }}>
          <SectionRow label="Academy Type" items={[state.academyModel].filter(Boolean) as string[]} labelMap={MODEL_LABELS} />
          <SectionRow label="Age Groups" items={state.ageGroups} labelMap={AGE_LABELS} />
          <SectionRow label="Coaching Philosophy" items={state.coachingStyles} labelMap={COACHING_LABELS} />
          <SectionRow label="Coach Communication" items={[state.primaryCommunication, state.secondaryCommunication].filter(Boolean) as string[]} labelMap={COMM_LABELS} />
          <SectionRow label="Session Design Defaults" items={state.sessionDesigns} labelMap={SESSION_LABELS} />
          <SectionRow label="Player Development Priorities" items={state.playerPriorities} labelMap={PLAYER_LABELS} ranked />
          <SectionRow label="Parent Communication Style" items={state.parentStyles} labelMap={PARENT_LABELS} />

          {/* What DONNA will build */}
          <div style={{
            background: 'rgba(0,201,167,0.05)', border: '1px solid rgba(0,201,167,0.12)',
            borderRadius: 10, padding: '10px 14px', marginTop: 4,
          }}>
            <p style={{ fontFamily: 'Inter', fontSize: 12, color: '#C8E0DC', lineHeight: 1.6 }}>
              DONNA will now generate: curriculum defaults, session templates, coach cues, player dashboard language, and parent communication tone.
            </p>
          </div>
        </div>
      </div>

      {/* Action buttons */}
      <div style={{ display: 'flex', gap: 10, flexWrap: 'wrap', marginTop: 28 }}>
        <button onClick={goNext} style={{
          display: 'flex', alignItems: 'center', gap: 8,
          background: '#00C9A7', color: '#050D0B', border: 'none', borderRadius: 10,
          padding: '11px 22px', fontFamily: 'Inter', fontWeight: 600, fontSize: 14, cursor: 'pointer',
          transition: 'all 160ms var(--ease-snappy)',
        }}
          onMouseEnter={e => { (e.currentTarget as HTMLButtonElement).style.background = '#00E5C4'; (e.currentTarget as HTMLButtonElement).style.transform = 'translateY(-1px)'; (e.currentTarget as HTMLButtonElement).style.boxShadow = '0 8px 24px rgba(0,201,167,0.3)'; }}
          onMouseLeave={e => { (e.currentTarget as HTMLButtonElement).style.background = '#00C9A7'; (e.currentTarget as HTMLButtonElement).style.transform = 'translateY(0)'; (e.currentTarget as HTMLButtonElement).style.boxShadow = 'none'; }}
          onMouseDown={e => { (e.currentTarget as HTMLButtonElement).style.transform = 'scale(0.97)'; }}
          onMouseUp={e => { (e.currentTarget as HTMLButtonElement).style.transform = 'translateY(-1px)'; }}
        >
          <CheckCircle2 size={15} />
          Approve Academy DNA
          <ArrowRight size={14} />
        </button>

        <button onClick={() => goTo('coaching-philosophy')} style={{
          display: 'flex', alignItems: 'center', gap: 7,
          background: 'rgba(255,255,255,0.04)', color: '#A0B8B4',
          border: '1px solid rgba(255,255,255,0.08)', borderRadius: 10,
          padding: '11px 18px', fontFamily: 'Inter', fontWeight: 500, fontSize: 13,
          cursor: 'pointer', transition: 'all 160ms var(--ease-snappy)',
        }}
          onMouseEnter={e => { (e.currentTarget as HTMLButtonElement).style.background = 'rgba(255,255,255,0.08)'; (e.currentTarget as HTMLButtonElement).style.color = '#E8F0EE'; }}
          onMouseLeave={e => { (e.currentTarget as HTMLButtonElement).style.background = 'rgba(255,255,255,0.04)'; (e.currentTarget as HTMLButtonElement).style.color = '#A0B8B4'; }}
        >
          <Edit2 size={13} /> Edit Selections
        </button>

        <button onClick={() => goTo('donna-chat')} style={{
          display: 'flex', alignItems: 'center', gap: 7,
          background: 'rgba(0,201,167,0.06)', color: '#00C9A7',
          border: '1px solid rgba(0,201,167,0.20)', borderRadius: 10,
          padding: '11px 18px', fontFamily: 'Inter', fontWeight: 500, fontSize: 13,
          cursor: 'pointer', transition: 'all 160ms var(--ease-snappy)',
        }}
          onMouseEnter={e => { (e.currentTarget as HTMLButtonElement).style.background = 'rgba(0,201,167,0.12)'; }}
          onMouseLeave={e => { (e.currentTarget as HTMLButtonElement).style.background = 'rgba(0,201,167,0.06)'; }}
        >
          <MessageSquare size={13} /> Adjust with DONNA
        </button>
      </div>
    </div>
  );
}
