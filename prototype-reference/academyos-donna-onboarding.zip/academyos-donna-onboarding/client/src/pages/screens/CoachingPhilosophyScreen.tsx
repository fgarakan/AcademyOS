/**
 * CoachingPhilosophyScreen — AnglesOS Brand Kit v1.0
 * Step 2 of 5 — Select up to 3 coaching styles
 * Accent: #00C9A7 teal | Font: Inter
 */
import { useOnboarding } from '@/contexts/OnboardingContext';
import { ArrowRight, ArrowLeft, Sparkles } from 'lucide-react';

const COACHING_STYLES = [
  { id: 'fundamentals-first', label: 'Fundamentals First', desc: 'Technique, balance, grips, preparation, and clean contact before complexity.', icon: '🎯' },
  { id: 'game-based', label: 'Game-Based Learning', desc: 'Players learn through constraints, live-ball situations, scoring, and decision-making.', icon: '🎮' },
  { id: 'high-performance', label: 'High-Performance Discipline', desc: 'Clear standards, intensity, accountability, and quality reps.', icon: '⚡' },
  { id: 'player-centered', label: 'Player-Centered Coaching', desc: 'Confidence, ownership, athlete voice, and individual learning styles.', icon: '🧠' },
  { id: 'tactical-first', label: 'Tactical First', desc: 'Court geometry, patterns, decisions, and point construction.', icon: '♟️' },
  { id: 'movement-first', label: 'Movement First', desc: 'Footwork, spacing, recovery, athletic positions, and body organisation.', icon: '🏃' },
  { id: 'competition-ready', label: 'Competition-Ready', desc: 'Pressure training, match habits, routines, tournament behaviour.', icon: '🏆' },
  { id: 'joy-retention', label: 'Joy + Retention', desc: 'Fun, belonging, energy, confidence, and long-term love of the game.', icon: '✨' },
];

const NAV_BTN: React.CSSProperties = {
  display: 'flex', alignItems: 'center', gap: 6,
  background: 'rgba(255,255,255,0.04)', color: '#A0B8B4',
  border: '1px solid rgba(255,255,255,0.08)', borderRadius: 10,
  padding: '10px 18px', fontFamily: 'Inter', fontWeight: 500, fontSize: 13, cursor: 'pointer',
  transition: 'all 160ms var(--ease-snappy)',
};

export default function CoachingPhilosophyScreen() {
  const { state, toggleArrayItem, goNext, goPrev } = useOnboarding();
  const selected = state.coachingStyles;

  const getSelectedLabels = () =>
    selected.map(id => COACHING_STYLES.find(s => s.id === id)?.label).filter(Boolean).join(' + ');

  return (
    <div style={{ maxWidth: 780, fontFamily: 'Inter, -apple-system, BlinkMacSystemFont, sans-serif', animation: 'slide-up 320ms var(--ease-snappy) both' }}>
      {/* Header */}
      <div style={{ marginBottom: 28 }}>
        <p style={{ fontFamily: 'Inter', fontWeight: 700, fontSize: 10, color: '#00C9A7', textTransform: 'uppercase', letterSpacing: '0.1em', marginBottom: 8 }}>
          Step 2 of 5 — Coaching DNA
        </p>
        <h2 style={{ fontFamily: 'Inter', fontWeight: 700, fontSize: 'clamp(1.5rem, 2.5vw, 2rem)', color: '#E8F0EE', lineHeight: 1.2, marginBottom: 8 }}>
          How do you want players to learn?
        </h2>
        <p style={{ fontFamily: 'Inter', fontSize: 13, color: '#5A7A76', lineHeight: 1.6 }}>
          Select up to 3 primary coaching styles that define your academy.
        </p>
      </div>

      {/* Selection counter */}
      <div style={{ display: 'flex', alignItems: 'center', gap: 6, marginBottom: 16 }}>
        {[0, 1, 2].map(i => (
          <div key={i} style={{ width: 28, height: 4, borderRadius: 9999, background: i < selected.length ? '#00C9A7' : 'rgba(0,201,167,0.12)', transition: 'background 200ms' }} />
        ))}
        <span style={{ fontFamily: 'Inter', fontSize: 11, color: '#5A7A76', marginLeft: 4 }}>
          {selected.length}/3 selected
        </span>
      </div>

      {/* Cards grid */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(200px, 1fr))', gap: 8, marginBottom: 20 }}>
        {COACHING_STYLES.map(style => {
          const isSelected = selected.includes(style.id);
          const rank = selected.indexOf(style.id) + 1;
          const isDisabled = !isSelected && selected.length >= 3;
          return (
            <button
              key={style.id}
              onClick={() => !isDisabled && toggleArrayItem('coachingStyles', style.id, 3)}
              style={{
                padding: '14px 16px',
                textAlign: 'left',
                borderRadius: 12,
                background: isSelected ? 'rgba(0, 201, 167, 0.06)' : '#111A18',
                border: isSelected ? '1px solid rgba(0, 201, 167, 0.40)' : '1px solid rgba(0, 201, 167, 0.08)',
                cursor: isDisabled ? 'not-allowed' : 'pointer',
                opacity: isDisabled ? 0.4 : 1,
                position: 'relative',
                overflow: 'hidden',
                transition: 'all 160ms var(--ease-snappy)',
                boxShadow: isSelected ? '0 0 0 1px rgba(0,201,167,0.15), 0 0 28px rgba(0,201,167,0.08)' : 'none',
              }}
              onMouseEnter={e => {
                if (!isSelected && !isDisabled) {
                  (e.currentTarget as HTMLButtonElement).style.transform = 'translateY(-2px)';
                  (e.currentTarget as HTMLButtonElement).style.borderColor = 'rgba(0,201,167,0.25)';
                  (e.currentTarget as HTMLButtonElement).style.boxShadow = '0 8px 32px rgba(0,0,0,0.5)';
                }
              }}
              onMouseLeave={e => {
                if (!isSelected && !isDisabled) {
                  (e.currentTarget as HTMLButtonElement).style.transform = 'translateY(0)';
                  (e.currentTarget as HTMLButtonElement).style.borderColor = 'rgba(0,201,167,0.08)';
                  (e.currentTarget as HTMLButtonElement).style.boxShadow = 'none';
                }
              }}
            >
              {/* Top teal bar when selected */}
              {isSelected && (
                <div style={{ position: 'absolute', top: 0, left: 0, right: 0, height: 2, background: 'linear-gradient(90deg, #00C9A7, #00E5C4)' }} />
              )}
              {/* Rank badge */}
              {isSelected && (
                <div style={{
                  position: 'absolute', top: 10, right: 10,
                  width: 18, height: 18, borderRadius: '50%',
                  background: '#00C9A7', color: '#050D0B',
                  fontFamily: 'Inter', fontWeight: 700, fontSize: 10,
                  display: 'flex', alignItems: 'center', justifyContent: 'center',
                }}>
                  {rank}
                </div>
              )}
              <div style={{ fontSize: 20, marginBottom: 8 }}>{style.icon}</div>
              <p style={{ fontFamily: 'Inter', fontSize: 13, fontWeight: isSelected ? 600 : 500, color: isSelected ? '#E8F0EE' : '#A0B8B4', marginBottom: 4, lineHeight: 1.3 }}>
                {style.label}
              </p>
              <p style={{ fontFamily: 'Inter', fontSize: 11, color: isSelected ? '#5A7A76' : '#3A6660', lineHeight: 1.5 }}>
                {style.desc}
              </p>
            </button>
          );
        })}
      </div>

      {/* DONNA live summary */}
      {selected.length > 0 && (
        <div style={{
          background: 'rgba(0,201,167,0.05)', border: '1px solid rgba(0,201,167,0.12)',
          borderRadius: 10, padding: '10px 14px', marginBottom: 20,
          display: 'flex', gap: 8, alignItems: 'flex-start',
          animation: 'scale-in 280ms var(--ease-snappy) both',
        }}>
          <Sparkles size={13} color="#00C9A7" style={{ flexShrink: 0, marginTop: 1 }} />
          <div>
            <p style={{ fontFamily: 'Inter', fontSize: 13, color: '#C8E0DC', lineHeight: 1.6 }}>
              Your coaching style: <span style={{ color: '#00C9A7', fontWeight: 600 }}>{getSelectedLabels()}</span>
            </p>
            {selected.length === 3 && (
              <p style={{ fontFamily: 'Inter', fontSize: 11, color: '#5A7A76', marginTop: 4 }}>
                I'll use these to shape curriculum, session templates, and coach cues.
              </p>
            )}
          </div>
        </div>
      )}

      {/* Navigation */}
      <div style={{ display: 'flex', gap: 10 }}>
        <button onClick={goPrev} style={NAV_BTN}
          onMouseEnter={e => { (e.currentTarget as HTMLButtonElement).style.background = 'rgba(255,255,255,0.08)'; (e.currentTarget as HTMLButtonElement).style.color = '#E8F0EE'; }}
          onMouseLeave={e => { (e.currentTarget as HTMLButtonElement).style.background = 'rgba(255,255,255,0.04)'; (e.currentTarget as HTMLButtonElement).style.color = '#A0B8B4'; }}
        >
          <ArrowLeft size={14} /> Back
        </button>
        <button
          onClick={goNext}
          style={{
            display: 'flex', alignItems: 'center', gap: 8,
            background: '#00C9A7', color: '#050D0B', border: 'none', borderRadius: 10,
            padding: '10px 22px', fontFamily: 'Inter', fontWeight: 600, fontSize: 14, cursor: 'pointer',
            transition: 'all 160ms var(--ease-snappy)',
          }}
          onMouseEnter={e => { (e.currentTarget as HTMLButtonElement).style.background = '#00E5C4'; (e.currentTarget as HTMLButtonElement).style.transform = 'translateY(-1px)'; (e.currentTarget as HTMLButtonElement).style.boxShadow = '0 8px 24px rgba(0,201,167,0.3)'; }}
          onMouseLeave={e => { (e.currentTarget as HTMLButtonElement).style.background = '#00C9A7'; (e.currentTarget as HTMLButtonElement).style.transform = 'translateY(0)'; (e.currentTarget as HTMLButtonElement).style.boxShadow = 'none'; }}
          onMouseDown={e => { (e.currentTarget as HTMLButtonElement).style.transform = 'scale(0.97)'; }}
          onMouseUp={e => { (e.currentTarget as HTMLButtonElement).style.transform = 'translateY(-1px)'; }}
        >
          Continue <ArrowRight size={14} />
        </button>
      </div>
    </div>
  );
}
