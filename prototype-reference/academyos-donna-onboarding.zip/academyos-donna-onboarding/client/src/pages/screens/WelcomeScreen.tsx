/**
 * WelcomeScreen — AnglesOS Brand Kit v1.0
 * Full-screen dark welcome with DONNA introduction
 * Background: #0A0F0E with subtle teal radial glow
 * Accent: #00C9A7 teal
 * Font: Inter
 */
import { useOnboarding } from '@/contexts/OnboardingContext';
import { ArrowRight, Sparkles, Zap } from 'lucide-react';
import DonnaPanel from '@/components/DonnaPanel';

const HERO_BG = 'https://d2xsxph8kpxj0f.cloudfront.net/310519663491229281/hThsvPRkRg2ZPapL6S2sHW/academy-hero-bg-U3idVehAw3u4YgsNPcCqTh.webp';

const PROGRESS_STEPS = [
  'Academy Basics',
  'Coaching DNA',
  'Session Defaults',
  'Player Priorities',
  'Review & Activate',
];

const FEATURES = [
  { icon: '⚡', label: 'Curriculum Builder', desc: 'Auto-generate session plans by pathway' },
  { icon: '🎯', label: 'Player Pathways', desc: 'Track every player\'s development arc' },
  { icon: '📊', label: 'Academy Analytics', desc: 'Real-time completion and progress data' },
  { icon: '💬', label: 'Parent Reports', desc: 'Automated communication, your voice' },
];

export default function WelcomeScreen() {
  const { goTo } = useOnboarding();

  return (
    <div
      style={{
        display: 'flex',
        height: '100vh',
        width: '100vw',
        overflow: 'hidden',
        background: '#0A0F0E',
        fontFamily: 'Inter, -apple-system, BlinkMacSystemFont, sans-serif',
      }}
    >
      {/* Main welcome content */}
      <div
        style={{
          flex: 1,
          display: 'flex',
          flexDirection: 'column',
          overflowY: 'auto',
          position: 'relative',
        }}
      >
        {/* Hero background image — subtle overlay */}
        <div
          style={{
            position: 'absolute',
            inset: 0,
            backgroundImage: `url(${HERO_BG})`,
            backgroundSize: 'cover',
            backgroundPosition: 'center',
            opacity: 0.12,
            zIndex: 0,
          }}
        />
        {/* Gradient overlay */}
        <div
          style={{
            position: 'absolute',
            inset: 0,
            background: 'linear-gradient(to right, #0A0F0E 0%, rgba(10,15,14,0.85) 60%, #0A0F0E 100%)',
            zIndex: 1,
          }}
        />
        {/* Teal ambient glow */}
        <div
          style={{
            position: 'absolute',
            top: '-5%',
            left: '15%',
            width: '70%',
            height: '55%',
            background: 'radial-gradient(ellipse, rgba(0, 201, 167, 0.08) 0%, transparent 70%)',
            pointerEvents: 'none',
            zIndex: 2,
          }}
        />

        <div
          style={{
            flex: 1,
            display: 'flex',
            flexDirection: 'column',
            justifyContent: 'center',
            padding: '48px 56px',
            position: 'relative',
            zIndex: 3,
            maxWidth: 700,
          }}
        >
          {/* Eyebrow */}
          <div
            style={{
              display: 'inline-flex',
              alignItems: 'center',
              gap: 6,
              background: 'rgba(0, 201, 167, 0.08)',
              border: '1px solid rgba(0, 201, 167, 0.15)',
              borderRadius: 9999,
              padding: '4px 12px',
              marginBottom: 28,
              width: 'fit-content',
              animation: 'fade-in 300ms var(--ease-snappy) both',
            }}
          >
            <Sparkles size={11} color="#00C9A7" />
            <span
              style={{
                fontFamily: 'Inter',
                fontWeight: 600,
                fontSize: 11,
                color: '#00C9A7',
                textTransform: 'uppercase',
                letterSpacing: '0.08em',
              }}
            >
              AcademyOS — Director Onboarding
            </span>
          </div>

          {/* Headline */}
          <h1
            style={{
              fontFamily: 'Inter',
              fontWeight: 700,
              fontSize: 'clamp(2rem, 3.5vw, 2.8rem)',
              lineHeight: 1.15,
              color: '#E8F0EE',
              marginBottom: 16,
              animation: 'slide-up 350ms var(--ease-snappy) 80ms both',
            }}
          >
            Meet DONNA —<br />
            <span style={{ color: '#00C9A7' }}>Your AI Academy Assist</span>
          </h1>

          {/* Role parenthetical */}
          <p
            style={{
              fontFamily: 'Inter',
              fontWeight: 500,
              fontSize: 13,
              color: '#5A7A76',
              marginBottom: 20,
              letterSpacing: '0.01em',
              animation: 'slide-up 350ms var(--ease-snappy) 110ms both',
            }}
          >
            ( Director of Operations &amp; Neural Network Assistant )
          </p>

          {/* Subtitle */}
          <p
            style={{
              fontFamily: 'Inter',
              fontWeight: 400,
              fontSize: 15,
              lineHeight: 1.65,
              color: '#A0B8B4',
              marginBottom: 36,
              maxWidth: 520,
              animation: 'slide-up 350ms var(--ease-snappy) 140ms both',
            }}
          >
            DONNA learns how your academy thinks, coaches, and communicates — then builds every curriculum, session plan, and player pathway around your DNA.
          </p>

          {/* Setup steps */}
          <div
            style={{
              marginBottom: 36,
              animation: 'slide-up 350ms var(--ease-snappy) 200ms both',
            }}
          >
            <p
              style={{
                fontFamily: 'Inter',
                fontWeight: 700,
                fontSize: 10,
                color: '#2A4A46',
                textTransform: 'uppercase',
                letterSpacing: '0.1em',
                marginBottom: 12,
              }}
            >
              5 steps — takes about 4 minutes
            </p>
            <div style={{ display: 'flex', alignItems: 'center', flexWrap: 'wrap', gap: 0 }}>
              {PROGRESS_STEPS.map((step, i) => (
                <div key={step} style={{ display: 'flex', alignItems: 'center' }}>
                  <div
                    style={{
                      display: 'flex',
                      alignItems: 'center',
                      gap: 7,
                      background: '#111A18',
                      border: '1px solid rgba(0, 201, 167, 0.10)',
                      borderRadius: 7,
                      padding: '5px 10px',
                    }}
                  >
                    <div
                      style={{
                        width: 18,
                        height: 18,
                        borderRadius: '50%',
                        background: 'rgba(0, 201, 167, 0.10)',
                        border: '1px solid rgba(0, 201, 167, 0.20)',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                        flexShrink: 0,
                      }}
                    >
                      <span style={{ fontFamily: 'Inter', fontWeight: 700, fontSize: 9, color: '#00C9A7' }}>
                        {i + 1}
                      </span>
                    </div>
                    <span style={{ fontFamily: 'Inter', fontSize: 12, color: '#A0B8B4', whiteSpace: 'nowrap' }}>
                      {step}
                    </span>
                  </div>
                  {i < PROGRESS_STEPS.length - 1 && (
                    <div style={{ width: 16, height: 1, background: 'rgba(0, 201, 167, 0.12)', flexShrink: 0 }} />
                  )}
                </div>
              ))}
            </div>
          </div>

          {/* CTAs */}
          <div
            style={{
              display: 'flex',
              gap: 12,
              alignItems: 'center',
              animation: 'slide-up 350ms var(--ease-snappy) 560ms both',
            }}
          >
            <button
              onClick={() => goTo('academy-basics')}
              style={{
                display: 'flex',
                alignItems: 'center',
                gap: 8,
                background: '#00C9A7',
                color: '#050D0B',
                fontFamily: 'Inter',
                fontWeight: 600,
                fontSize: 14,
                padding: '11px 22px',
                borderRadius: 10,
                border: 'none',
                cursor: 'pointer',
                transition: 'all 160ms cubic-bezier(0.23, 1, 0.32, 1)',
              }}
              onMouseEnter={e => {
                (e.currentTarget as HTMLButtonElement).style.background = '#00E5C4';
                (e.currentTarget as HTMLButtonElement).style.transform = 'translateY(-1px)';
                (e.currentTarget as HTMLButtonElement).style.boxShadow = '0 8px 24px rgba(0, 201, 167, 0.3)';
              }}
              onMouseLeave={e => {
                (e.currentTarget as HTMLButtonElement).style.background = '#00C9A7';
                (e.currentTarget as HTMLButtonElement).style.transform = 'translateY(0)';
                (e.currentTarget as HTMLButtonElement).style.boxShadow = 'none';
              }}
              onMouseDown={e => { (e.currentTarget as HTMLButtonElement).style.transform = 'scale(0.97)'; }}
              onMouseUp={e => { (e.currentTarget as HTMLButtonElement).style.transform = 'translateY(-1px)'; }}
            >
              <Zap size={14} />
              Start with DONNA
              <ArrowRight size={14} />
            </button>

            <button
              onClick={() => goTo('dna-summary')}
              style={{
                background: 'rgba(255, 255, 255, 0.04)',
                color: '#E8F0EE',
                fontFamily: 'Inter',
                fontWeight: 500,
                fontSize: 14,
                padding: '11px 22px',
                borderRadius: 10,
                border: '1px solid rgba(255, 255, 255, 0.08)',
                cursor: 'pointer',
                transition: 'all 160ms cubic-bezier(0.23, 1, 0.32, 1)',
              }}
              onMouseEnter={e => {
                (e.currentTarget as HTMLButtonElement).style.background = 'rgba(255, 255, 255, 0.08)';
                (e.currentTarget as HTMLButtonElement).style.color = '#00C9A7';
              }}
              onMouseLeave={e => {
                (e.currentTarget as HTMLButtonElement).style.background = 'rgba(255, 255, 255, 0.04)';
                (e.currentTarget as HTMLButtonElement).style.color = '#E8F0EE';
              }}
            >
              Use recommended defaults
            </button>
          </div>

          <p
            style={{
              marginTop: 16,
              fontFamily: 'Inter',
              fontSize: 11,
              color: '#3A6660',
            }}
          >
            ≈ 4 minutes to complete
          </p>
        </div>

        {/* Feature cards — bottom strip */}
        <div
          style={{
            padding: '0 56px 40px',
            position: 'relative',
            zIndex: 3,
            animation: 'slide-up 350ms var(--ease-snappy) 640ms both',
          }}
        >
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 10 }}>
            {FEATURES.map((f, i) => (
              <div
                key={f.label}
                style={{
                  background: '#111A18',
                  border: '1px solid rgba(0, 201, 167, 0.08)',
                  borderRadius: 10,
                  padding: '12px 14px',
                  animation: `stagger-in 320ms var(--ease-snappy) ${700 + i * 55}ms both`,
                }}
              >
                <div style={{ fontSize: 18, marginBottom: 6 }}>{f.icon}</div>
                <p style={{ fontFamily: 'Inter', fontWeight: 600, fontSize: 12, color: '#E8F0EE', marginBottom: 3 }}>
                  {f.label}
                </p>
                <p style={{ fontFamily: 'Inter', fontSize: 11, color: '#5A7A76', lineHeight: 1.4 }}>
                  {f.desc}
                </p>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* DONNA Panel */}
      <DonnaPanel
        donnaMessage="I'm DONNA — your AI Academy Director. I'll learn how your academy thinks, coaches, and communicates. Then I'll build every curriculum and session plan around your DNA."
        showSummary={false}
      />
    </div>
  );
}
