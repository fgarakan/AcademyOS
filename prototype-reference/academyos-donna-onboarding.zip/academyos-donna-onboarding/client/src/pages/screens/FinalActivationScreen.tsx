/**
 * FinalActivationScreen — AnglesOS Brand Kit v1.0
 * Celebration + next steps
 * Accent: #00C9A7 teal | Font: Inter
 */
import { useOnboarding } from '@/contexts/OnboardingContext';
import { ArrowRight, BookOpen, LayoutTemplate, Users, UserPlus, Bell, BarChart2, CheckCircle2 } from 'lucide-react';
import { toast } from 'sonner';

const NEXT_STEPS = [
  { id: 'curriculum', icon: BookOpen, label: 'Build Curriculum Defaults', desc: 'Set level requirements, skill progressions, and assessment criteria.' },
  { id: 'templates', icon: LayoutTemplate, label: 'Create Class Templates', desc: 'Generate session plans for each age group and level.' },
  { id: 'coaches', icon: Users, label: 'Add Coaches', desc: 'Invite coaches and assign roles, groups, and permissions.' },
  { id: 'players', icon: UserPlus, label: 'Add Players', desc: 'Import or create player profiles and assign to groups.' },
  { id: 'parent-rules', icon: Bell, label: 'Set Parent Communication Rules', desc: 'Configure notification schedules and report formats.' },
  { id: 'dashboard', icon: BarChart2, label: 'Preview Director Dashboard', desc: 'See your academy overview, analytics, and quick actions.' },
];

export default function FinalActivationScreen() {
  const { state, goTo } = useOnboarding();

  const handleNextStep = (id: string) => {
    toast.success(`Opening ${NEXT_STEPS.find(s => s.id === id)?.label}...`, {
      description: 'Feature coming soon in the full AnglesOS platform.',
    });
  };

  return (
    <div style={{ maxWidth: 820, fontFamily: 'Inter, -apple-system, BlinkMacSystemFont, sans-serif', animation: 'slide-up 320ms var(--ease-snappy) both' }}>
      {/* Success header */}
      <div style={{ marginBottom: 36 }}>
        <div style={{
          width: 52, height: 52, borderRadius: '50%',
          background: 'rgba(0,201,167,0.08)', border: '1px solid rgba(0,201,167,0.25)',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          marginBottom: 20, boxShadow: '0 0 24px rgba(0,201,167,0.15)',
        }}>
          <CheckCircle2 size={24} color="#00C9A7" />
        </div>

        <h1 style={{
          fontFamily: 'Inter', fontWeight: 700,
          fontSize: 'clamp(1.8rem, 3.5vw, 2.6rem)',
          color: '#E8F0EE', lineHeight: 1.1, marginBottom: 16,
        }}>
          Your academy foundation<br />
          <span style={{ color: '#00C9A7' }}>is ready.</span>
        </h1>

        {/* DONNA message */}
        <div style={{
          background: 'rgba(0,201,167,0.05)', border: '1px solid rgba(0,201,167,0.12)',
          borderRadius: 10, padding: '10px 14px', maxWidth: 560,
          display: 'flex', gap: 8, alignItems: 'flex-start',
        }}>
          <div style={{ width: 6, height: 6, borderRadius: '50%', background: '#00C9A7', flexShrink: 0, marginTop: 4 }} />
          <p style={{ fontFamily: 'Inter', fontSize: 13, color: '#C8E0DC', lineHeight: 1.65 }}>
            I've created{state.academyName ? ` ${state.academyName}'s` : ' your'} coaching DNA. Next, I can help you set up curriculum levels, class templates, coach roles, and parent/player portals.
          </p>
        </div>
      </div>

      {/* DNA summary pills */}
      {(state.coachingStyles.length > 0 || state.sessionDesigns.length > 0) && (
        <div style={{ marginBottom: 28 }}>
          <p style={{ fontFamily: 'Inter', fontWeight: 700, fontSize: 10, color: '#3A6660', textTransform: 'uppercase', letterSpacing: '0.1em', marginBottom: 10 }}>
            Academy DNA Active
          </p>
          <div style={{ display: 'flex', flexWrap: 'wrap', gap: 5 }}>
            {[
              ...state.coachingStyles.map(id => id),
              ...state.sessionDesigns.slice(0, 3).map(id => id),
              ...state.playerPriorities.slice(0, 2).map(id => id),
            ].map(id => (
              <div key={id} style={{
                background: 'rgba(0,201,167,0.06)', border: '1px solid rgba(0,201,167,0.15)',
                borderRadius: 6, padding: '3px 10px',
                display: 'flex', alignItems: 'center', gap: 5,
              }}>
                <div style={{ width: 4, height: 4, borderRadius: '50%', background: '#00C9A7' }} />
                <span style={{ fontFamily: 'Inter', fontSize: 12, color: '#A0B8B4' }}>
                  {id.replace(/-/g, ' ').replace(/\b\w/g, c => c.toUpperCase())}
                </span>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Next steps */}
      <div style={{ marginBottom: 28 }}>
        <p style={{ fontFamily: 'Inter', fontWeight: 700, fontSize: 10, color: '#3A6660', textTransform: 'uppercase', letterSpacing: '0.1em', marginBottom: 12 }}>
          Continue Setup
        </p>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(240px, 1fr))', gap: 8 }}>
          {NEXT_STEPS.map(step => {
            const Icon = step.icon;
            return (
              <button
                key={step.id}
                onClick={() => handleNextStep(step.id)}
                style={{
                  background: '#111A18', border: '1px solid rgba(0,201,167,0.08)',
                  borderRadius: 12, padding: '14px', textAlign: 'left',
                  cursor: 'pointer', transition: 'all 180ms var(--ease-snappy)',
                  display: 'flex', flexDirection: 'column', gap: 8,
                }}
                onMouseEnter={e => {
                  const btn = e.currentTarget as HTMLButtonElement;
                  btn.style.borderColor = 'rgba(0,201,167,0.30)';
                  btn.style.background = 'rgba(0,201,167,0.05)';
                  btn.style.transform = 'translateY(-2px)';
                  btn.style.boxShadow = '0 8px 32px rgba(0,0,0,0.5)';
                }}
                onMouseLeave={e => {
                  const btn = e.currentTarget as HTMLButtonElement;
                  btn.style.borderColor = 'rgba(0,201,167,0.08)';
                  btn.style.background = '#111A18';
                  btn.style.transform = 'translateY(0)';
                  btn.style.boxShadow = 'none';
                }}
                onMouseDown={e => { (e.currentTarget as HTMLButtonElement).style.transform = 'scale(0.98)'; }}
                onMouseUp={e => { (e.currentTarget as HTMLButtonElement).style.transform = 'translateY(-2px)'; }}
              >
                <div style={{
                  width: 34, height: 34, borderRadius: 9,
                  background: 'rgba(0,201,167,0.08)', border: '1px solid rgba(0,201,167,0.15)',
                  display: 'flex', alignItems: 'center', justifyContent: 'center',
                }}>
                  <Icon size={16} color="#00C9A7" />
                </div>
                <div>
                  <p style={{ fontFamily: 'Inter', fontWeight: 600, fontSize: 13, color: '#E8F0EE', marginBottom: 3, lineHeight: 1.2 }}>
                    {step.label}
                  </p>
                  <p style={{ fontFamily: 'Inter', fontSize: 11, color: '#5A7A76', lineHeight: 1.5 }}>
                    {step.desc}
                  </p>
                </div>
                <div style={{ display: 'flex', alignItems: 'center', gap: 4, marginTop: 'auto' }}>
                  <span style={{ fontFamily: 'Inter', fontWeight: 600, fontSize: 11, color: '#00C9A7', opacity: 0.7 }}>Set up</span>
                  <ArrowRight size={11} color="#00C9A7" style={{ opacity: 0.7 }} />
                </div>
              </button>
            );
          })}
        </div>
      </div>

      {/* Primary CTAs */}
      <div style={{ display: 'flex', gap: 10, alignItems: 'center', flexWrap: 'wrap' }}>
        <button
          onClick={() => toast.success('Continuing setup...', { description: 'Full setup flow coming soon.' })}
          style={{
            display: 'flex', alignItems: 'center', gap: 8,
            background: '#00C9A7', color: '#050D0B', border: 'none', borderRadius: 10,
            padding: '11px 22px', fontFamily: 'Inter', fontWeight: 600, fontSize: 14,
            cursor: 'pointer', transition: 'all 160ms var(--ease-snappy)',
          }}
          onMouseEnter={e => { (e.currentTarget as HTMLButtonElement).style.background = '#00E5C4'; (e.currentTarget as HTMLButtonElement).style.transform = 'translateY(-1px)'; (e.currentTarget as HTMLButtonElement).style.boxShadow = '0 8px 24px rgba(0,201,167,0.3)'; }}
          onMouseLeave={e => { (e.currentTarget as HTMLButtonElement).style.background = '#00C9A7'; (e.currentTarget as HTMLButtonElement).style.transform = 'translateY(0)'; (e.currentTarget as HTMLButtonElement).style.boxShadow = 'none'; }}
          onMouseDown={e => { (e.currentTarget as HTMLButtonElement).style.transform = 'scale(0.97)'; }}
          onMouseUp={e => { (e.currentTarget as HTMLButtonElement).style.transform = 'translateY(-1px)'; }}
        >
          Continue Setup <ArrowRight size={14} />
        </button>

        <button
          onClick={() => toast.success('Opening Director Dashboard...', { description: 'Dashboard preview coming soon.' })}
          style={{
            display: 'flex', alignItems: 'center', gap: 7,
            background: 'rgba(255,255,255,0.04)', color: '#A0B8B4',
            border: '1px solid rgba(255,255,255,0.08)', borderRadius: 10,
            padding: '11px 18px', fontFamily: 'Inter', fontWeight: 500, fontSize: 13,
            cursor: 'pointer', transition: 'all 160ms var(--ease-snappy)',
          }}
          onMouseEnter={e => { (e.currentTarget as HTMLButtonElement).style.background = 'rgba(255,255,255,0.08)'; (e.currentTarget as HTMLButtonElement).style.color = '#E8F0EE'; }}
          onMouseLeave={e => { (e.currentTarget as HTMLButtonElement).style.background = 'rgba(255,255,255,0.04)'; (e.currentTarget as HTMLButtonElement).style.color = '#A0B8B4'; }}
        >
          <BarChart2 size={14} /> Go to Director Dashboard
        </button>

        <button
          onClick={() => goTo('welcome')}
          style={{
            background: 'transparent', color: '#3A6660',
            border: 'none', borderRadius: 8,
            padding: '11px 10px', fontFamily: 'Inter', fontSize: 12,
            cursor: 'pointer',
          }}
        >
          Start over
        </button>
      </div>
    </div>
  );
}
