/**
 * ParentCommunicationScreen — AnglesOS Brand Kit v1.0
 * Parent communication style selection
 * Accent: #00C9A7 teal | Font: Inter
 */
import { useOnboarding } from '@/contexts/OnboardingContext';
import { ArrowRight, ArrowLeft, Sparkles } from 'lucide-react';

const PARENT_STYLES = [
  { id: 'simple-reassuring', label: 'Simple + Reassuring', desc: 'Clear, calm updates without overwhelming parents.', icon: '🕊️' },
  { id: 'progress-focused', label: 'Progress-Focused', desc: 'Shows what improved, what is next, and why it matters.', icon: '📈' },
  { id: 'developmental-education', label: 'Developmental Education', desc: "Helps parents understand the academy's teaching model.", icon: '📚' },
  { id: 'actionable-support', label: 'Actionable At-Home Support', desc: 'Gives parents helpful ways to support without interfering.', icon: '🏠' },
  { id: 'minimal-noise', label: 'Minimal Parent Noise', desc: 'Only important updates, no overcommunication.', icon: '🔕' },
  { id: 'transparent-levels', label: 'Transparent Level Progression', desc: 'Shows what the player needs to do to move up.', icon: '🎯' },
  { id: 'tournament-support', label: 'Tournament Support Guidance', desc: 'Helps parents support players emotionally and practically.', icon: '🏆' },
];

const NAV_BTN: React.CSSProperties = {
  display: 'flex', alignItems: 'center', gap: 6,
  background: 'rgba(255,255,255,0.04)', color: '#A0B8B4',
  border: '1px solid rgba(255,255,255,0.08)', borderRadius: 10,
  padding: '10px 18px', fontFamily: 'Inter', fontWeight: 500, fontSize: 13, cursor: 'pointer',
  transition: 'all 160ms var(--ease-snappy)',
};

export default function ParentCommunicationScreen() {
  const { state, toggleArrayItem, goNext, goPrev } = useOnboarding();
  const selected = state.parentStyles;

  return (
    <div style={{ maxWidth: 780, fontFamily: 'Inter, -apple-system, BlinkMacSystemFont, sans-serif', animation: 'slide-up 320ms var(--ease-snappy) both' }}>
      {/* Header */}
      <div style={{ marginBottom: 28 }}>
        <p style={{ fontFamily: 'Inter', fontWeight: 700, fontSize: 10, color: '#00C9A7', textTransform: 'uppercase', letterSpacing: '0.1em', marginBottom: 8 }}>
          Parent Communication
        </p>
        <h2 style={{ fontFamily: 'Inter', fontWeight: 700, fontSize: 'clamp(1.5rem, 2.5vw, 2rem)', color: '#E8F0EE', lineHeight: 1.2, marginBottom: 8 }}>
          How should AcademyOS communicate with parents?
        </h2>
        <p style={{ fontFamily: 'Inter', fontSize: 13, color: '#5A7A76', lineHeight: 1.6 }}>
          Select all communication styles that fit your academy culture.
        </p>
      </div>

      {/* Cards */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(210px, 1fr))', gap: 8, marginBottom: 20 }}>
        {PARENT_STYLES.map(style => {
          const isSelected = selected.includes(style.id);
          return (
            <button
              key={style.id}
              onClick={() => toggleArrayItem('parentStyles', style.id)}
              style={{
                padding: '14px 16px',
                textAlign: 'left',
                borderRadius: 12,
                background: isSelected ? 'rgba(0,201,167,0.06)' : '#111A18',
                border: isSelected ? '1px solid rgba(0,201,167,0.40)' : '1px solid rgba(0,201,167,0.08)',
                cursor: 'pointer',
                position: 'relative',
                overflow: 'hidden',
                transition: 'all 160ms var(--ease-snappy)',
                boxShadow: isSelected ? '0 0 0 1px rgba(0,201,167,0.12)' : 'none',
              }}
              onMouseEnter={e => {
                if (!isSelected) {
                  (e.currentTarget as HTMLButtonElement).style.transform = 'translateY(-2px)';
                  (e.currentTarget as HTMLButtonElement).style.borderColor = 'rgba(0,201,167,0.25)';
                  (e.currentTarget as HTMLButtonElement).style.boxShadow = '0 8px 32px rgba(0,0,0,0.5)';
                }
              }}
              onMouseLeave={e => {
                if (!isSelected) {
                  (e.currentTarget as HTMLButtonElement).style.transform = 'translateY(0)';
                  (e.currentTarget as HTMLButtonElement).style.borderColor = 'rgba(0,201,167,0.08)';
                  (e.currentTarget as HTMLButtonElement).style.boxShadow = 'none';
                }
              }}
            >
              {isSelected && (
                <div style={{ position: 'absolute', top: 0, left: 0, right: 0, height: 2, background: 'linear-gradient(90deg, #00C9A7, #00E5C4)' }} />
              )}
              {isSelected && (
                <div style={{
                  position: 'absolute', top: 10, right: 10,
                  width: 16, height: 16, borderRadius: '50%',
                  background: '#00C9A7', display: 'flex', alignItems: 'center', justifyContent: 'center',
                }}>
                  <span style={{ fontSize: 9, color: '#050D0B', fontWeight: 700 }}>✓</span>
                </div>
              )}
              <div style={{ fontSize: 20, marginBottom: 8 }}>{style.icon}</div>
              <p style={{ fontFamily: 'Inter', fontSize: 13, fontWeight: isSelected ? 600 : 500, color: isSelected ? '#E8F0EE' : '#A0B8B4', marginBottom: 4, lineHeight: 1.3 }}>
                {style.label}
              </p>
              <p style={{ fontFamily: 'Inter', fontSize: 11, color: '#5A7A76', lineHeight: 1.5 }}>
                {style.desc}
              </p>
            </button>
          );
        })}
      </div>

      {/* DONNA summary */}
      {selected.length > 0 && (
        <div style={{
          background: 'rgba(0,201,167,0.05)', border: '1px solid rgba(0,201,167,0.12)',
          borderRadius: 10, padding: '10px 14px', marginBottom: 20,
          display: 'flex', gap: 8, alignItems: 'flex-start',
          animation: 'scale-in 280ms var(--ease-snappy) both',
        }}>
          <Sparkles size={13} color="#00C9A7" style={{ flexShrink: 0, marginTop: 1 }} />
          <p style={{ fontFamily: 'Inter', fontSize: 13, color: '#C8E0DC', lineHeight: 1.6 }}>
            I'll apply {selected.length} communication style{selected.length > 1 ? 's' : ''} to all parent-facing messages, progress reports, and tournament updates.
          </p>
        </div>
      )}

      {/* Navigation */}
      <div style={{ display: 'flex', gap: 10 }}>
        <button onClick={goPrev} style={NAV_BTN}
          onMouseEnter={e => { (e.currentTarget as HTMLButtonElement).style.background = 'rgba(255,255,255,0.08)'; (e.currentTarget as HTMLButtonElement).style.color = '#E8F0EE'; }}
          onMouseLeave={e => { (e.currentTarget as HTMLButtonElement).style.background = 'rgba(255,255,255,0.04)'; (e.currentTarget as HTMLButtonElement).style.color = '#A0B8B4'; }}
        >
          <ArrowLeft size={14} /> Back
        </button>
        <button onClick={goNext} style={{
          display: 'flex', alignItems: 'center', gap: 8,
          background: '#00C9A7', color: '#050D0B', border: 'none', borderRadius: 10,
          padding: '10px 22px', fontFamily: 'Inter', fontWeight: 600, fontSize: 14, cursor: 'pointer',
          transition: 'all 160ms var(--ease-snappy)',
        }}
          onMouseEnter={e => { (e.currentTarget as HTMLButtonElement).style.background = '#00E5C4'; (e.currentTarget as HTMLButtonElement).style.transform = 'translateY(-1px)'; (e.currentTarget as HTMLButtonElement).style.boxShadow = '0 8px 24px rgba(0,201,167,0.3)'; }}
          onMouseLeave={e => { (e.currentTarget as HTMLButtonElement).style.background = '#00C9A7'; (e.currentTarget as HTMLButtonElement).style.transform = 'translateY(0)'; (e.currentTarget as HTMLButtonElement).style.boxShadow = 'none'; }}
          onMouseDown={e => { (e.currentTarget as HTMLButtonElement).style.transform = 'scale(0.97)'; }}
          onMouseUp={e => { (e.currentTarget as HTMLButtonElement).style.transform = 'translateY(-1px)'; }}
        >
          Review Academy DNA <ArrowRight size={14} />
        </button>
      
      </div>
    </div>
  );
}
