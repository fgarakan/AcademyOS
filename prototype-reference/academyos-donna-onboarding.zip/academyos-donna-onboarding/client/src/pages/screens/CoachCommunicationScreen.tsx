/**
 * CoachCommunicationScreen — AnglesOS Brand Kit v1.0
 * Step 3 of 5 — Primary + secondary communication style
 * Accent: #00C9A7 teal | Secondary: #A07DE0 purple | Font: Inter
 */
import { useOnboarding } from '@/contexts/OnboardingContext';
import { ArrowRight, ArrowLeft, Sparkles } from 'lucide-react';

const COMM_STYLES = [
  { id: 'direct-clear', label: 'Direct + Clear', desc: 'Simple commands, clear standards, fast corrections.', icon: '⚡' },
  { id: 'encouraging-positive', label: 'Encouraging + Positive', desc: 'Confidence-building while still correcting.', icon: '🌟' },
  { id: 'question-led', label: 'Question-Led', desc: 'Guided discovery through smart questions.', icon: '💡' },
  { id: 'high-energy', label: 'High-Energy Motivator', desc: 'Energy, enthusiasm, and momentum.', icon: '🔥' },
  { id: 'calm-precise', label: 'Calm + Precise', desc: 'Low-noise, technical, focused coaching.', icon: '🎯' },
  { id: 'standards-based', label: 'Standards-Based', desc: 'Clear expectations, accountability, and consistency.', icon: '📐' },
];

const NAV_BTN: React.CSSProperties = {
  display: 'flex', alignItems: 'center', gap: 6,
  background: 'rgba(255,255,255,0.04)', color: '#A0B8B4',
  border: '1px solid rgba(255,255,255,0.08)', borderRadius: 10,
  padding: '10px 18px', fontFamily: 'Inter', fontWeight: 500, fontSize: 13, cursor: 'pointer',
  transition: 'all 160ms var(--ease-snappy)',
};

export default function CoachCommunicationScreen() {
  const { state, updateState, goNext, goPrev } = useOnboarding();

  const setPrimary = (id: string) => {
    if (state.secondaryCommunication === id) {
      updateState({ primaryCommunication: id, secondaryCommunication: '' });
    } else {
      updateState({ primaryCommunication: id });
    }
  };

  const setSecondary = (id: string) => {
    if (state.primaryCommunication === id) return;
    updateState({ secondaryCommunication: state.secondaryCommunication === id ? '' : id });
  };

  const getPrimaryLabel = () => COMM_STYLES.find(s => s.id === state.primaryCommunication)?.label;
  const getSecondaryLabel = () => COMM_STYLES.find(s => s.id === state.secondaryCommunication)?.label;

  return (
    <div style={{ maxWidth: 780, fontFamily: 'Inter, -apple-system, BlinkMacSystemFont, sans-serif', animation: 'slide-up 320ms var(--ease-snappy) both' }}>
      {/* Header */}
      <div style={{ marginBottom: 28 }}>
        <p style={{ fontFamily: 'Inter', fontWeight: 700, fontSize: 10, color: '#00C9A7', textTransform: 'uppercase', letterSpacing: '0.1em', marginBottom: 8 }}>
          Step 3 of 5 — Coach Communication
        </p>
        <h2 style={{ fontFamily: 'Inter', fontWeight: 700, fontSize: 'clamp(1.5rem, 2.5vw, 2rem)', color: '#E8F0EE', lineHeight: 1.2, marginBottom: 8 }}>
          How should coaches communicate with players?
        </h2>
        <p style={{ fontFamily: 'Inter', fontSize: 13, color: '#5A7A76', lineHeight: 1.6 }}>
          Choose a primary and optional secondary communication style.
        </p>
      </div>

      {/* Selection indicators */}
      <div style={{ display: 'flex', gap: 10, marginBottom: 16 }}>
        <div style={{
          display: 'flex', alignItems: 'center', gap: 6,
          background: state.primaryCommunication ? 'rgba(0,201,167,0.08)' : 'rgba(255,255,255,0.03)',
          border: `1px solid ${state.primaryCommunication ? 'rgba(0,201,167,0.20)' : 'rgba(255,255,255,0.06)'}`,
          borderRadius: 6, padding: '4px 10px',
        }}>
          <div style={{ width: 7, height: 7, borderRadius: '50%', background: '#00C9A7' }} />
          <span style={{ fontFamily: 'Inter', fontSize: 11, color: state.primaryCommunication ? '#00C9A7' : '#3A6660' }}>
            Primary: {getPrimaryLabel() || 'Not selected'}
          </span>
        </div>
        <div style={{
          display: 'flex', alignItems: 'center', gap: 6,
          background: state.secondaryCommunication ? 'rgba(160,125,224,0.08)' : 'rgba(255,255,255,0.03)',
          border: `1px solid ${state.secondaryCommunication ? 'rgba(160,125,224,0.20)' : 'rgba(255,255,255,0.06)'}`,
          borderRadius: 6, padding: '4px 10px',
        }}>
          <div style={{ width: 7, height: 7, borderRadius: '50%', background: '#A07DE0' }} />
          <span style={{ fontFamily: 'Inter', fontSize: 11, color: state.secondaryCommunication ? '#A07DE0' : '#3A6660' }}>
            Secondary: {getSecondaryLabel() || 'Optional'}
          </span>
        </div>
      </div>

      {/* Cards */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(220px, 1fr))', gap: 8, marginBottom: 20 }}>
        {COMM_STYLES.map(style => {
          const isPrimary = state.primaryCommunication === style.id;
          const isSecondary = state.secondaryCommunication === style.id;
          const isSelected = isPrimary || isSecondary;

          return (
            <div
              key={style.id}
              style={{
                padding: '14px 16px',
                textAlign: 'left',
                borderRadius: 12,
                background: isSelected ? 'rgba(0,201,167,0.05)' : '#111A18',
                border: isSelected ? '1px solid rgba(0,201,167,0.30)' : '1px solid rgba(0,201,167,0.08)',
                position: 'relative',
                overflow: 'hidden',
                transition: 'all 160ms var(--ease-snappy)',
              }}
            >
              {/* Top accent bar */}
              {isSelected && (
                <div style={{
                  position: 'absolute', top: 0, left: 0, right: 0, height: 2,
                  background: isPrimary ? 'linear-gradient(90deg, #00C9A7, #00E5C4)' : 'linear-gradient(90deg, #A07DE0, #C4A8F0)',
                }} />
              )}
              {/* Badge */}
              {isSelected && (
                <div style={{
                  position: 'absolute', top: 10, right: 10,
                  background: isPrimary ? '#00C9A7' : '#A07DE0',
                  color: '#050D0B', borderRadius: 4, padding: '1px 6px',
                  fontFamily: 'Inter', fontSize: 9, fontWeight: 700, letterSpacing: '0.06em',
                }}>
                  {isPrimary ? 'PRIMARY' : 'SECONDARY'}
                </div>
              )}

              <div style={{ fontSize: 20, marginBottom: 8 }}>{style.icon}</div>
              <p style={{ fontFamily: 'Inter', fontSize: 13, fontWeight: isSelected ? 600 : 500, color: isSelected ? '#E8F0EE' : '#A0B8B4', marginBottom: 4, lineHeight: 1.3 }}>
                {style.label}
              </p>
              <p style={{ fontFamily: 'Inter', fontSize: 11, color: '#5A7A76', lineHeight: 1.5, marginBottom: 12 }}>
                {style.desc}
              </p>

              {/* Action buttons */}
              <div style={{ display: 'flex', gap: 5 }}>
                <button
                  onClick={() => setPrimary(style.id)}
                  style={{
                    flex: 1, padding: '5px 0',
                    background: isPrimary ? '#00C9A7' : 'rgba(0,201,167,0.06)',
                    border: `1px solid ${isPrimary ? '#00C9A7' : 'rgba(0,201,167,0.15)'}`,
                    borderRadius: 6,
                    color: isPrimary ? '#050D0B' : '#5A7A76',
                    fontFamily: 'Inter', fontSize: 10, fontWeight: 600, letterSpacing: '0.04em',
                    cursor: 'pointer', transition: 'all 120ms var(--ease-snappy)',
                  }}
                  onMouseEnter={e => { if (!isPrimary) (e.currentTarget as HTMLButtonElement).style.background = 'rgba(0,201,167,0.12)'; }}
                  onMouseLeave={e => { if (!isPrimary) (e.currentTarget as HTMLButtonElement).style.background = 'rgba(0,201,167,0.06)'; }}
                >
                  Primary
                </button>
                <button
                  onClick={() => setSecondary(style.id)}
                  disabled={isPrimary}
                  style={{
                    flex: 1, padding: '5px 0',
                    background: isSecondary ? '#A07DE0' : 'rgba(160,125,224,0.06)',
                    border: `1px solid ${isSecondary ? '#A07DE0' : 'rgba(160,125,224,0.15)'}`,
                    borderRadius: 6,
                    color: isSecondary ? '#050D0B' : '#5A7A76',
                    fontFamily: 'Inter', fontSize: 10, fontWeight: 600, letterSpacing: '0.04em',
                    cursor: isPrimary ? 'not-allowed' : 'pointer',
                    opacity: isPrimary ? 0.3 : 1,
                    transition: 'all 120ms var(--ease-snappy)',
                  }}
                >
                  Secondary
                </button>
              </div>
            </div>
          );
        })}
      </div>

      {/* DONNA summary */}
      {state.primaryCommunication && (
        <div style={{
          background: 'rgba(0,201,167,0.05)', border: '1px solid rgba(0,201,167,0.12)',
          borderRadius: 10, padding: '10px 14px', marginBottom: 20,
          display: 'flex', gap: 8, alignItems: 'flex-start',
          animation: 'scale-in 280ms var(--ease-snappy) both',
        }}>
          <Sparkles size={13} color="#00C9A7" style={{ flexShrink: 0, marginTop: 1 }} />
          <p style={{ fontFamily: 'Inter', fontSize: 13, color: '#C8E0DC', lineHeight: 1.6 }}>
            I'll use this to shape coach notes, session cues, player feedback, and parent-safe language.
          </p>
        </div>
      )}

      {/* Navigation */}
      <div style={{ display: 'flex', gap: 10 }}>
        <button onClick={goPrev} style={NAV_BTN}
          onMouseEnter={e => { (e.currentTarget as HTMLButtonElement).style.background = 'rgba(255,255,255,0.08)'; (e.currentTarget as HTMLButtonElement).style.color = '#E8F0EE'; }}
          onMouseLeave={e => { (e.currentTarget as HTMLButtonElement).style.background = 'rgba(255,255,255,0.04)'; (e.currentTarget as HTMLButtonElement).style.color = '#A0B8B4'; }}
        >
          <ArrowLeft size={14} /> Back
        </button>
        <button onClick={goNext} style={{
          display: 'flex', alignItems: 'center', gap: 8,
          background: '#00C9A7', color: '#050D0B', border: 'none', borderRadius: 10,
          padding: '10px 22px', fontFamily: 'Inter', fontWeight: 600, fontSize: 14, cursor: 'pointer',
          transition: 'all 160ms var(--ease-snappy)',
        }}
          onMouseEnter={e => { (e.currentTarget as HTMLButtonElement).style.background = '#00E5C4'; (e.currentTarget as HTMLButtonElement).style.transform = 'translateY(-1px)'; (e.currentTarget as HTMLButtonElement).style.boxShadow = '0 8px 24px rgba(0,201,167,0.3)'; }}
          onMouseLeave={e => { (e.currentTarget as HTMLButtonElement).style.background = '#00C9A7'; (e.currentTarget as HTMLButtonElement).style.transform = 'translateY(0)'; (e.currentTarget as HTMLButtonElement).style.boxShadow = 'none'; }}
          onMouseDown={e => { (e.currentTarget as HTMLButtonElement).style.transform = 'scale(0.97)'; }}
          onMouseUp={e => { (e.currentTarget as HTMLButtonElement).style.transform = 'translateY(-1px)'; }}
        >
          Continue <ArrowRight size={14} />
        </button>
      </div>
    </div>
  );
}
