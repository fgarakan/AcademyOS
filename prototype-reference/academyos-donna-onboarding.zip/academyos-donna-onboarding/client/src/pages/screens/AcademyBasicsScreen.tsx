/**
 * AcademyBasicsScreen — AnglesOS Brand Kit v1.0
 * Step 1 of 5 — Academy name, age groups, model
 * Accent: #00C9A7 teal | Font: Inter
 * Surface: #111A18 | Border: rgba(0,201,167,0.10)
 */
import { useState } from 'react';
import { useOnboarding } from '@/contexts/OnboardingContext';
import { ArrowRight, ArrowLeft, Sparkles } from 'lucide-react';

const AGE_GROUPS = [
  { id: 'red-ball', label: 'Red Ball', sub: 'Ages 5–8', color: '#E05252' },
  { id: 'orange-ball', label: 'Orange Ball', sub: 'Ages 8–10', color: '#FF9500' },
  { id: 'green-ball', label: 'Green Ball', sub: 'Ages 9–11', color: '#34C759' },
  { id: 'yellow-ball', label: 'Yellow Ball', sub: 'Ages 10+', color: '#FFD60A' },
  { id: 'high-performance', label: 'High Performance', sub: 'Elite juniors', color: '#00C9A7' },
  { id: 'adult', label: 'Adult', sub: 'All levels', color: '#A07DE0' },
];

const ACADEMY_MODELS = [
  { id: 'development', label: 'Development Academy', desc: 'Long-term player development focus' },
  { id: 'high-performance', label: 'High Performance Academy', desc: 'Elite training and competition' },
  { id: 'rec-competitive', label: 'Recreational + Competitive', desc: 'Mixed program for all levels' },
  { id: 'multi-site', label: 'Multi-Site Academy', desc: 'Multiple locations and coaches' },
  { id: 'private', label: 'Private Coaching Program', desc: 'Individual and small group focus' },
  { id: 'school-club', label: 'School / Club Program', desc: 'Institutional or club-based' },
];

const LABEL_STYLE: React.CSSProperties = {
  display: 'block',
  fontFamily: 'Inter',
  fontWeight: 700,
  fontSize: 10,
  color: '#3A6660',
  letterSpacing: '0.1em',
  textTransform: 'uppercase',
  marginBottom: 10,
};

export default function AcademyBasicsScreen() {
  const { state, updateState, toggleArrayItem, goNext, goPrev } = useOnboarding();
  const [nameInput, setNameInput] = useState(state.academyName);

  const handleContinue = () => {
    updateState({ academyName: nameInput });
    goNext();
  };

  const canContinue = nameInput.trim().length > 0 || state.ageGroups.length > 0 || !!state.academyModel;

  return (
    <div
      style={{
        maxWidth: 720,
        animation: 'slide-up 320ms var(--ease-snappy) both',
        fontFamily: 'Inter, -apple-system, BlinkMacSystemFont, sans-serif',
      }}
    >
      {/* Screen header */}
      <div style={{ marginBottom: 32 }}>
        <p
          style={{
            fontFamily: 'Inter',
            fontWeight: 700,
            fontSize: 10,
            color: '#00C9A7',
            textTransform: 'uppercase',
            letterSpacing: '0.1em',
            marginBottom: 8,
          }}
        >
          Step 1 of 5
        </p>
        <h2
          style={{
            fontFamily: 'Inter',
            fontWeight: 700,
            fontSize: 'clamp(1.5rem, 2.5vw, 2rem)',
            color: '#E8F0EE',
            lineHeight: 1.2,
            marginBottom: 8,
          }}
        >
          Tell me about your academy
        </h2>
        <p style={{ fontFamily: 'Inter', fontSize: 13, color: '#5A7A76', lineHeight: 1.6 }}>
          This shapes your curriculum levels, templates, and coach views.
        </p>
      </div>

      {/* Academy Name */}
      <div style={{ marginBottom: 24 }}>
        <label style={LABEL_STYLE}>Academy Name</label>
        <input
          type="text"
          value={nameInput}
          onChange={e => setNameInput(e.target.value)}
          placeholder="e.g. Ace Tennis Academy"
          style={{
            width: '100%',
            maxWidth: 400,
            background: '#141F1D',
            border: '1px solid rgba(0, 201, 167, 0.12)',
            borderRadius: 10,
            padding: '10px 14px',
            color: '#E8F0EE',
            fontSize: 14,
            fontFamily: 'Inter',
            outline: 'none',
            transition: 'border-color 160ms var(--ease-snappy), box-shadow 160ms var(--ease-snappy)',
            boxSizing: 'border-box',
          }}
          onFocus={e => {
            e.target.style.borderColor = 'rgba(0, 201, 167, 0.40)';
            e.target.style.boxShadow = '0 0 0 3px rgba(0, 201, 167, 0.08)';
          }}
          onBlur={e => {
            e.target.style.borderColor = 'rgba(0, 201, 167, 0.12)';
            e.target.style.boxShadow = 'none';
          }}
        />
      </div>

      {/* Age Groups */}
      <div style={{ marginBottom: 24 }}>
        <label style={LABEL_STYLE}>Primary Age Groups</label>
        <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8 }}>
          {AGE_GROUPS.map(group => {
            const selected = state.ageGroups.includes(group.id);
            return (
              <button
                key={group.id}
                onClick={() => toggleArrayItem('ageGroups', group.id)}
                style={{
                  display: 'flex',
                  alignItems: 'center',
                  gap: 8,
                  padding: '8px 14px',
                  borderRadius: 8,
                  background: selected ? 'rgba(0, 201, 167, 0.06)' : '#111A18',
                  border: selected
                    ? '1px solid rgba(0, 201, 167, 0.40)'
                    : '1px solid rgba(0, 201, 167, 0.10)',
                  cursor: 'pointer',
                  transition: 'all 160ms var(--ease-snappy)',
                  boxShadow: selected ? '0 0 0 1px rgba(0, 201, 167, 0.15)' : 'none',
                }}
                onMouseEnter={e => {
                  if (!selected) {
                    (e.currentTarget as HTMLButtonElement).style.borderColor = 'rgba(0, 201, 167, 0.25)';
                    (e.currentTarget as HTMLButtonElement).style.background = '#141F1D';
                  }
                }}
                onMouseLeave={e => {
                  if (!selected) {
                    (e.currentTarget as HTMLButtonElement).style.borderColor = 'rgba(0, 201, 167, 0.10)';
                    (e.currentTarget as HTMLButtonElement).style.background = '#111A18';
                  }
                }}
              >
                <div
                  style={{
                    width: 9,
                    height: 9,
                    borderRadius: '50%',
                    background: group.color,
                    flexShrink: 0,
                    boxShadow: selected ? `0 0 6px ${group.color}80` : 'none',
                  }}
                />
                <div style={{ textAlign: 'left' }}>
                  <p
                    style={{
                      fontFamily: 'Inter',
                      fontSize: 13,
                      fontWeight: selected ? 600 : 400,
                      color: selected ? '#E8F0EE' : '#A0B8B4',
                      lineHeight: 1.2,
                    }}
                  >
                    {group.label}
                  </p>
                  <p
                    style={{
                      fontFamily: 'Inter',
                      fontSize: 11,
                      color: selected ? '#00C9A7' : '#5A7A76',
                      lineHeight: 1.2,
                    }}
                  >
                    {group.sub}
                  </p>
                </div>
              </button>
            );
          })}
        </div>
      </div>

      {/* Academy Model */}
      <div style={{ marginBottom: 24 }}>
        <label style={LABEL_STYLE}>Academy Model</label>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(220px, 1fr))', gap: 8 }}>
          {ACADEMY_MODELS.map(model => {
            const selected = state.academyModel === model.id;
            return (
              <button
                key={model.id}
                onClick={() => updateState({ academyModel: model.id })}
                style={{
                  padding: '12px 14px',
                  textAlign: 'left',
                  borderRadius: 10,
                  background: selected ? 'rgba(0, 201, 167, 0.06)' : '#111A18',
                  border: selected
                    ? '1px solid rgba(0, 201, 167, 0.40)'
                    : '1px solid rgba(0, 201, 167, 0.08)',
                  cursor: 'pointer',
                  transition: 'all 160ms var(--ease-snappy)',
                  boxShadow: selected ? '0 0 0 1px rgba(0, 201, 167, 0.15)' : 'none',
                }}
                onMouseEnter={e => {
                  if (!selected) {
                    (e.currentTarget as HTMLButtonElement).style.transform = 'translateY(-2px)';
                    (e.currentTarget as HTMLButtonElement).style.borderColor = 'rgba(0, 201, 167, 0.25)';
                    (e.currentTarget as HTMLButtonElement).style.boxShadow = '0 8px 32px rgba(0,0,0,0.5)';
                  }
                }}
                onMouseLeave={e => {
                  if (!selected) {
                    (e.currentTarget as HTMLButtonElement).style.transform = 'translateY(0)';
                    (e.currentTarget as HTMLButtonElement).style.borderColor = 'rgba(0, 201, 167, 0.08)';
                    (e.currentTarget as HTMLButtonElement).style.boxShadow = 'none';
                  }
                }}
              >
                <p
                  style={{
                    fontFamily: 'Inter',
                    fontSize: 13,
                    fontWeight: selected ? 600 : 500,
                    color: selected ? '#E8F0EE' : '#A0B8B4',
                    marginBottom: 3,
                    lineHeight: 1.3,
                  }}
                >
                  {model.label}
                </p>
                <p
                  style={{
                    fontFamily: 'Inter',
                    fontSize: 11,
                    color: selected ? '#00C9A7' : '#5A7A76',
                    lineHeight: 1.4,
                  }}
                >
                  {model.desc}
                </p>
              </button>
            );
          })}
        </div>
      </div>

      {/* DONNA confirmation */}
      {(state.ageGroups.length > 0 || state.academyModel) && (
        <div
          style={{
            background: 'rgba(0, 201, 167, 0.05)',
            border: '1px solid rgba(0, 201, 167, 0.12)',
            borderRadius: 10,
            padding: '10px 14px',
            marginBottom: 24,
            display: 'flex',
            gap: 8,
            alignItems: 'flex-start',
            animation: 'scale-in 280ms var(--ease-snappy) both',
          }}
        >
          <Sparkles size={13} color="#00C9A7" style={{ flexShrink: 0, marginTop: 1 }} />
          <p style={{ fontFamily: 'Inter', fontSize: 13, color: '#C8E0DC', lineHeight: 1.6 }}>
            I'll use this to customise your curriculum levels, templates, and coach views.
          </p>
        </div>
      )}

      {/* Navigation */}
      <div style={{ display: 'flex', gap: 10, alignItems: 'center' }}>
        <button
          onClick={goPrev}
          style={{
            display: 'flex',
            alignItems: 'center',
            gap: 6,
            background: 'rgba(255, 255, 255, 0.04)',
            color: '#A0B8B4',
            border: '1px solid rgba(255, 255, 255, 0.08)',
            borderRadius: 10,
            padding: '10px 18px',
            fontFamily: 'Inter',
            fontWeight: 500,
            fontSize: 13,
            cursor: 'pointer',
            transition: 'all 160ms var(--ease-snappy)',
          }}
          onMouseEnter={e => {
            (e.currentTarget as HTMLButtonElement).style.background = 'rgba(255,255,255,0.08)';
            (e.currentTarget as HTMLButtonElement).style.color = '#E8F0EE';
          }}
          onMouseLeave={e => {
            (e.currentTarget as HTMLButtonElement).style.background = 'rgba(255,255,255,0.04)';
            (e.currentTarget as HTMLButtonElement).style.color = '#A0B8B4';
          }}
        >
          <ArrowLeft size={14} />
          Back
        </button>
        <button
          onClick={handleContinue}
          disabled={!canContinue}
          style={{
            display: 'flex',
            alignItems: 'center',
            gap: 8,
            background: canContinue ? '#00C9A7' : 'rgba(0, 201, 167, 0.20)',
            color: canContinue ? '#050D0B' : '#3A6660',
            border: 'none',
            borderRadius: 10,
            padding: '10px 22px',
            fontFamily: 'Inter',
            fontWeight: 600,
            fontSize: 14,
            cursor: canContinue ? 'pointer' : 'not-allowed',
            transition: 'all 160ms var(--ease-snappy)',
          }}
          onMouseEnter={e => {
            if (canContinue) {
              (e.currentTarget as HTMLButtonElement).style.background = '#00E5C4';
              (e.currentTarget as HTMLButtonElement).style.transform = 'translateY(-1px)';
              (e.currentTarget as HTMLButtonElement).style.boxShadow = '0 8px 24px rgba(0, 201, 167, 0.3)';
            }
          }}
          onMouseLeave={e => {
            if (canContinue) {
              (e.currentTarget as HTMLButtonElement).style.background = '#00C9A7';
              (e.currentTarget as HTMLButtonElement).style.transform = 'translateY(0)';
              (e.currentTarget as HTMLButtonElement).style.boxShadow = 'none';
            }
          }}
          onMouseDown={e => { if (canContinue) (e.currentTarget as HTMLButtonElement).style.transform = 'scale(0.97)'; }}
          onMouseUp={e => { if (canContinue) (e.currentTarget as HTMLButtonElement).style.transform = 'translateY(-1px)'; }}
        >
          Continue
          <ArrowRight size={14} />
        </button>
      </div>
    </div>
  );
}
