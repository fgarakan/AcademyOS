/**
 * PlayerDevelopmentScreen — AnglesOS Brand Kit v1.0
 * Step 5 of 5 — Select + rank up to 5 player development priorities
 * Accent: #00C9A7 teal | Font: Inter
 */
import { useState } from 'react';
import { useOnboarding } from '@/contexts/OnboardingContext';
import { ArrowRight, ArrowLeft, GripVertical, X, Sparkles } from 'lucide-react';

const ALL_PRIORITIES = [
  { id: 'technical-foundation', label: 'Technical Foundation', icon: '🎯' },
  { id: 'tactical-iq', label: 'Tactical IQ', icon: '♟️' },
  { id: 'movement-quality', label: 'Movement Quality', icon: '🏃' },
  { id: 'competitive-toughness', label: 'Competitive Toughness', icon: '💪' },
  { id: 'emotional-regulation', label: 'Emotional Regulation', icon: '🧘' },
  { id: 'consistency', label: 'Consistency + Rally Tolerance', icon: '🔄' },
  { id: 'aggressive-identity', label: 'Aggressive Identity', icon: '⚡' },
  { id: 'all-court', label: 'All-Court Development', icon: '🎾' },
  { id: 'serve-return', label: 'Serve + Return Priority', icon: '🏹' },
  { id: 'independence', label: 'Independence + Ownership', icon: '🧠' },
];

const NAV_BTN: React.CSSProperties = {
  display: 'flex', alignItems: 'center', gap: 6,
  background: 'rgba(255,255,255,0.04)', color: '#A0B8B4',
  border: '1px solid rgba(255,255,255,0.08)', borderRadius: 10,
  padding: '10px 18px', fontFamily: 'Inter', fontWeight: 500, fontSize: 13, cursor: 'pointer',
  transition: 'all 160ms var(--ease-snappy)',
};

export default function PlayerDevelopmentScreen() {
  const { state, updateState, goNext, goPrev } = useOnboarding();
  const [dragIdx, setDragIdx] = useState<number | null>(null);
  const [dragOver, setDragOver] = useState<number | null>(null);
  const selected = state.playerPriorities;

  const togglePriority = (id: string) => {
    if (selected.includes(id)) {
      updateState({ playerPriorities: selected.filter(s => s !== id) });
    } else if (selected.length < 5) {
      updateState({ playerPriorities: [...selected, id] });
    }
  };

  const removeFromRank = (id: string) => {
    updateState({ playerPriorities: selected.filter(s => s !== id) });
  };

  const handleDragStart = (i: number) => setDragIdx(i);
  const handleDragOver = (e: React.DragEvent, i: number) => { e.preventDefault(); setDragOver(i); };
  const handleDrop = (e: React.DragEvent, i: number) => {
    e.preventDefault();
    if (dragIdx === null || dragIdx === i) return;
    const newArr = [...selected];
    const [moved] = newArr.splice(dragIdx, 1);
    newArr.splice(i, 0, moved);
    updateState({ playerPriorities: newArr });
    setDragIdx(null); setDragOver(null);
  };
  const handleDragEnd = () => { setDragIdx(null); setDragOver(null); };
  const getPriorityData = (id: string) => ALL_PRIORITIES.find(p => p.id === id);

  return (
    <div style={{ maxWidth: 780, fontFamily: 'Inter, -apple-system, BlinkMacSystemFont, sans-serif', animation: 'slide-up 320ms var(--ease-snappy) both' }}>
      {/* Header */}
      <div style={{ marginBottom: 28 }}>
        <p style={{ fontFamily: 'Inter', fontWeight: 700, fontSize: 10, color: '#00C9A7', textTransform: 'uppercase', letterSpacing: '0.1em', marginBottom: 8 }}>
          Step 5 of 5 — Player Development
        </p>
        <h2 style={{ fontFamily: 'Inter', fontWeight: 700, fontSize: 'clamp(1.5rem, 2.5vw, 2rem)', color: '#E8F0EE', lineHeight: 1.2, marginBottom: 8 }}>
          What matters most in your player development model?
        </h2>
        <p style={{ fontFamily: 'Inter', fontSize: 13, color: '#5A7A76', lineHeight: 1.6 }}>
          Select up to 5 priorities, then drag to rank them.
        </p>
      </div>

      <div style={{ display: 'flex', gap: 24, alignItems: 'flex-start' }}>
        {/* Left: selectable pills */}
        <div style={{ flex: 1 }}>
          <p style={{ fontFamily: 'Inter', fontWeight: 700, fontSize: 10, color: '#3A6660', textTransform: 'uppercase', letterSpacing: '0.1em', marginBottom: 10 }}>
            Select priorities ({selected.length}/5)
          </p>
          <div style={{ display: 'flex', flexWrap: 'wrap', gap: 7 }}>
            {ALL_PRIORITIES.map(priority => {
              const isSelected = selected.includes(priority.id);
              const rank = selected.indexOf(priority.id) + 1;
              const isMaxed = selected.length >= 5 && !isSelected;
              return (
                <button
                  key={priority.id}
                  onClick={() => !isMaxed && togglePriority(priority.id)}
                  style={{
                    display: 'flex', alignItems: 'center', gap: 6,
                    padding: '7px 12px', borderRadius: 8,
                    background: isSelected ? 'rgba(0,201,167,0.08)' : '#111A18',
                    border: isSelected ? '1px solid rgba(0,201,167,0.35)' : '1px solid rgba(0,201,167,0.08)',
                    opacity: isMaxed ? 0.3 : 1,
                    cursor: isMaxed ? 'not-allowed' : 'pointer',
                    transition: 'all 160ms var(--ease-snappy)',
                  }}
                  onMouseEnter={e => {
                    if (!isMaxed && !isSelected) {
                      (e.currentTarget as HTMLButtonElement).style.borderColor = 'rgba(0,201,167,0.25)';
                      (e.currentTarget as HTMLButtonElement).style.background = '#141F1D';
                    }
                  }}
                  onMouseLeave={e => {
                    if (!isMaxed && !isSelected) {
                      (e.currentTarget as HTMLButtonElement).style.borderColor = 'rgba(0,201,167,0.08)';
                      (e.currentTarget as HTMLButtonElement).style.background = '#111A18';
                    }
                  }}
                >
                  {isSelected && (
                    <div style={{
                      width: 16, height: 16, borderRadius: '50%',
                      background: '#00C9A7', color: '#050D0B',
                      fontFamily: 'Inter', fontWeight: 700, fontSize: 9,
                      display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0,
                    }}>
                      {rank}
                    </div>
                  )}
                  <span style={{ fontSize: 13 }}>{priority.icon}</span>
                  <span style={{ fontFamily: 'Inter', fontSize: 12, fontWeight: isSelected ? 600 : 400, color: isSelected ? '#E8F0EE' : '#A0B8B4' }}>
                    {priority.label}
                  </span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Right: ranked stack */}
        <div style={{ width: 210, flexShrink: 0 }}>
          <p style={{ fontFamily: 'Inter', fontWeight: 700, fontSize: 10, color: '#3A6660', textTransform: 'uppercase', letterSpacing: '0.1em', marginBottom: 10 }}>
            Priority Rank
          </p>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 5, minHeight: 200 }}>
            {selected.length === 0 && (
              <div style={{
                border: '1px dashed rgba(0,201,167,0.12)', borderRadius: 10,
                padding: '20px 12px', textAlign: 'center',
              }}>
                <p style={{ fontFamily: 'Inter', fontSize: 11, color: '#3A6660', lineHeight: 1.5 }}>
                  Select priorities to rank them
                </p>
              </div>
            )}
            {selected.map((id, i) => {
              const data = getPriorityData(id);
              if (!data) return null;
              return (
                <div
                  key={id}
                  draggable
                  onDragStart={() => handleDragStart(i)}
                  onDragOver={e => handleDragOver(e, i)}
                  onDrop={e => handleDrop(e, i)}
                  onDragEnd={handleDragEnd}
                  style={{
                    display: 'flex', alignItems: 'center', gap: 7,
                    background: dragOver === i ? 'rgba(0,201,167,0.08)' : '#111A18',
                    border: `1px solid ${dragOver === i ? 'rgba(0,201,167,0.30)' : 'rgba(0,201,167,0.10)'}`,
                    borderRadius: 8, padding: '8px 10px',
                    cursor: 'grab', transition: 'all 150ms var(--ease-snappy)',
                    opacity: dragIdx === i ? 0.5 : 1,
                  }}
                >
                  <GripVertical size={13} color="#3A6660" style={{ flexShrink: 0 }} />
                  <div style={{
                    width: 18, height: 18, borderRadius: '50%',
                    background: '#00C9A7', color: '#050D0B',
                    fontFamily: 'Inter', fontWeight: 700, fontSize: 9,
                    display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0,
                  }}>
                    {i + 1}
                  </div>
                  <span style={{ fontSize: 12 }}>{data.icon}</span>
                  <span style={{ flex: 1, fontFamily: 'Inter', fontSize: 11, fontWeight: 500, color: '#E8F0EE', lineHeight: 1.2 }}>
                    {data.label}
                  </span>
                  <button onClick={() => removeFromRank(id)} style={{ background: 'none', border: 'none', cursor: 'pointer', padding: 0, flexShrink: 0 }}>
                    <X size={11} color="#5A7A76" />
                  </button>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* DONNA summary */}
      {selected.length >= 3 && (
        <div style={{
          background: 'rgba(0,201,167,0.05)', border: '1px solid rgba(0,201,167,0.12)',
          borderRadius: 10, padding: '10px 14px', marginTop: 20, marginBottom: 20,
          display: 'flex', gap: 8, alignItems: 'flex-start',
          animation: 'scale-in 280ms var(--ease-snappy) both',
        }}>
          <Sparkles size={13} color="#00C9A7" style={{ flexShrink: 0, marginTop: 1 }} />
          <p style={{ fontFamily: 'Inter', fontSize: 13, color: '#C8E0DC', lineHeight: 1.6 }}>
            These priorities will influence level requirements, player dashboards, coach watch-fors, and parent updates.
          </p>
        </div>
      )}

      {/* Navigation */}
      <div style={{ display: 'flex', gap: 10, marginTop: selected.length < 3 ? 20 : 0 }}>
        <button onClick={goPrev} style={NAV_BTN}
          onMouseEnter={e => { (e.currentTarget as HTMLButtonElement).style.background = 'rgba(255,255,255,0.08)'; (e.currentTarget as HTMLButtonElement).style.color = '#E8F0EE'; }}
          onMouseLeave={e => { (e.currentTarget as HTMLButtonElement).style.background = 'rgba(255,255,255,0.04)'; (e.currentTarget as HTMLButtonElement).style.color = '#A0B8B4'; }}
        >
          <ArrowLeft size={14} /> Back
        </button>
        <button onClick={goNext} style={{
          display: 'flex', alignItems: 'center', gap: 8,
          background: '#00C9A7', color: '#050D0B', border: 'none', borderRadius: 10,
          padding: '10px 22px', fontFamily: 'Inter', fontWeight: 600, fontSize: 14, cursor: 'pointer',
          transition: 'all 160ms var(--ease-snappy)',
        }}
          onMouseEnter={e => { (e.currentTarget as HTMLButtonElement).style.background = '#00E5C4'; (e.currentTarget as HTMLButtonElement).style.transform = 'translateY(-1px)'; (e.currentTarget as HTMLButtonElement).style.boxShadow = '0 8px 24px rgba(0,201,167,0.3)'; }}
          onMouseLeave={e => { (e.currentTarget as HTMLButtonElement).style.background = '#00C9A7'; (e.currentTarget as HTMLButtonElement).style.transform = 'translateY(0)'; (e.currentTarget as HTMLButtonElement).style.boxShadow = 'none'; }}
          onMouseDown={e => { (e.currentTarget as HTMLButtonElement).style.transform = 'scale(0.97)'; }}
          onMouseUp={e => { (e.currentTarget as HTMLButtonElement).style.transform = 'translateY(-1px)'; }}
        >
          Continue <ArrowRight size={14} />
        </button>
      </div>
    </div>
  );
}
