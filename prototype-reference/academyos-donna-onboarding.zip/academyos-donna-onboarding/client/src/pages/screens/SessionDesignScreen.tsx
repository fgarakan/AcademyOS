/**
 * SessionDesignScreen — AnglesOS Brand Kit v1.0
 * Step 4 of 5 — Session building blocks + live timeline preview
 * Accent: #00C9A7 teal | Font: Inter
 */
import { useOnboarding } from '@/contexts/OnboardingContext';
import { ArrowRight, ArrowLeft, Sparkles } from 'lucide-react';

const SESSION_BLOCKS = [
  { id: 'technique-blocks', label: 'Technique Blocks', desc: 'Dedicated repetition and technical development.', icon: '🔧', timelineLabel: 'Technical', color: '#00C9A7', duration: 20 },
  { id: 'live-ball-heavy', label: 'Live Ball Heavy', desc: 'More rally-based learning and open-skill environments.', icon: '🎾', timelineLabel: 'Live Ball', color: '#34C759', duration: 25 },
  { id: 'constraint-games', label: 'Constraint Games', desc: 'Rules, targets, scoring, and limitations that teach.', icon: '🎮', timelineLabel: 'Constraint', color: '#FFAA00', duration: 20 },
  { id: 'point-play', label: 'Point Play Progression', desc: 'Cooperative rally → competitive rally → point play.', icon: '📈', timelineLabel: 'Point Play', color: '#E05252', duration: 20 },
  { id: 'stations', label: 'Stations + Rotations', desc: 'Best for larger groups, multiple courts, and assistant coaches.', icon: '🔄', timelineLabel: 'Stations', color: '#A07DE0', duration: 25 },
  { id: 'assessment', label: 'Assessment Moments', desc: 'DONNA adds short check-ins to capture evidence.', icon: '📊', timelineLabel: 'Assessment', color: '#FF9500', duration: 10 },
  { id: 'fitness-integrated', label: 'Fitness Integrated', desc: 'Physical development is built into tennis sessions.', icon: '💪', timelineLabel: 'Fitness', color: '#00C9A7', duration: 15 },
];

const FIXED_BLOCKS = [
  { label: 'Warm-Up', color: 'fixed', duration: 10 },
  { label: 'Reflection', color: 'fixed', duration: 5 },
];

const NAV_BTN: React.CSSProperties = {
  display: 'flex', alignItems: 'center', gap: 6,
  background: 'rgba(255,255,255,0.04)', color: '#A0B8B4',
  border: '1px solid rgba(255,255,255,0.08)', borderRadius: 10,
  padding: '10px 18px', fontFamily: 'Inter', fontWeight: 500, fontSize: 13, cursor: 'pointer',
  transition: 'all 160ms var(--ease-snappy)',
};

export default function SessionDesignScreen() {
  const { state, toggleArrayItem, goNext, goPrev } = useOnboarding();
  const selected = state.sessionDesigns;

  const getTimelineBlocks = () => [
    FIXED_BLOCKS[0],
    ...selected.map(id => {
      const block = SESSION_BLOCKS.find(b => b.id === id);
      return block ? { label: block.timelineLabel, color: block.color, duration: block.duration } : null;
    }).filter(Boolean) as { label: string; color: string; duration: number }[],
    FIXED_BLOCKS[1],
  ];

  const totalDuration = getTimelineBlocks().reduce((sum, b) => sum + b.duration, 0);

  return (
    <div style={{ maxWidth: 780, fontFamily: 'Inter, -apple-system, BlinkMacSystemFont, sans-serif', animation: 'slide-up 320ms var(--ease-snappy) both' }}>
      {/* Header */}
      <div style={{ marginBottom: 28 }}>
        <p style={{ fontFamily: 'Inter', fontWeight: 700, fontSize: 10, color: '#00C9A7', textTransform: 'uppercase', letterSpacing: '0.1em', marginBottom: 8 }}>
          Step 4 of 5 — Session Defaults
        </p>
        <h2 style={{ fontFamily: 'Inter', fontWeight: 700, fontSize: 'clamp(1.5rem, 2.5vw, 2rem)', color: '#E8F0EE', lineHeight: 1.2, marginBottom: 8 }}>
          How should a typical session be built?
        </h2>
        <p style={{ fontFamily: 'Inter', fontSize: 13, color: '#5A7A76', lineHeight: 1.6 }}>
          Select the building blocks for your default session structure.
        </p>
      </div>

      {/* Session blocks */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(200px, 1fr))', gap: 8, marginBottom: 20 }}>
        {SESSION_BLOCKS.map(block => {
          const isSelected = selected.includes(block.id);
          return (
            <button
              key={block.id}
              onClick={() => toggleArrayItem('sessionDesigns', block.id)}
              style={{
                padding: '12px 14px',
                textAlign: 'left',
                borderRadius: 10,
                background: isSelected ? 'rgba(0,201,167,0.05)' : '#111A18',
                border: isSelected ? '1px solid rgba(0,201,167,0.35)' : '1px solid rgba(0,201,167,0.08)',
                cursor: 'pointer',
                position: 'relative',
                overflow: 'hidden',
                transition: 'all 160ms var(--ease-snappy)',
                boxShadow: isSelected ? '0 0 0 1px rgba(0,201,167,0.12)' : 'none',
              }}
              onMouseEnter={e => {
                if (!isSelected) {
                  (e.currentTarget as HTMLButtonElement).style.transform = 'translateY(-2px)';
                  (e.currentTarget as HTMLButtonElement).style.borderColor = 'rgba(0,201,167,0.25)';
                  (e.currentTarget as HTMLButtonElement).style.boxShadow = '0 8px 32px rgba(0,0,0,0.5)';
                }
              }}
              onMouseLeave={e => {
                if (!isSelected) {
                  (e.currentTarget as HTMLButtonElement).style.transform = 'translateY(0)';
                  (e.currentTarget as HTMLButtonElement).style.borderColor = 'rgba(0,201,167,0.08)';
                  (e.currentTarget as HTMLButtonElement).style.boxShadow = 'none';
                }
              }}
            >
              {isSelected && (
                <div style={{ position: 'absolute', top: 0, left: 0, right: 0, height: 2, background: `${block.color}` }} />
              )}
              <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 6 }}>
                <span style={{ fontSize: 16 }}>{block.icon}</span>
                {isSelected && (
                  <div style={{
                    marginLeft: 'auto', width: 16, height: 16, borderRadius: '50%',
                    background: '#00C9A7', display: 'flex', alignItems: 'center', justifyContent: 'center',
                  }}>
                    <span style={{ fontSize: 9, color: '#050D0B', fontWeight: 700 }}>✓</span>
                  </div>
                )}
              </div>
              <p style={{ fontFamily: 'Inter', fontSize: 12, fontWeight: isSelected ? 600 : 500, color: isSelected ? '#E8F0EE' : '#A0B8B4', marginBottom: 3, lineHeight: 1.3 }}>
                {block.label}
              </p>
              <p style={{ fontFamily: 'Inter', fontSize: 11, color: '#5A7A76', lineHeight: 1.4, marginBottom: 4 }}>
                {block.desc}
              </p>
              <p style={{ fontFamily: 'Inter', fontSize: 10, color: isSelected ? '#00C9A7' : '#3A6660', fontWeight: 600 }}>
                ~{block.duration} min
              </p>
            </button>
          );
        })}
      </div>

      {/* Live session timeline */}
      <div style={{
        background: '#111A18',
        border: '1px solid rgba(0,201,167,0.08)',
        borderRadius: 12,
        padding: '16px 18px',
        marginBottom: 20,
      }}>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 12 }}>
          <p style={{ fontFamily: 'Inter', fontWeight: 700, fontSize: 10, color: '#3A6660', textTransform: 'uppercase', letterSpacing: '0.1em' }}>
            Session Preview
          </p>
          <p style={{ fontFamily: 'Inter', fontSize: 11, color: '#5A7A76' }}>
            ~{totalDuration} min total
          </p>
        </div>

        {/* Timeline rail */}
        <div style={{ display: 'flex', gap: 3, marginBottom: 6, height: 32, alignItems: 'stretch' }}>
          {getTimelineBlocks().map((block, i) => (
            <div
              key={i}
              style={{
                flex: block.duration,
                background: block.color === 'fixed' ? 'rgba(255,255,255,0.04)' : `${block.color}1A`,
                border: `1px solid ${block.color === 'fixed' ? 'rgba(255,255,255,0.08)' : `${block.color}40`}`,
                borderRadius: 5,
                display: 'flex', alignItems: 'center', justifyContent: 'center',
                minWidth: 0, overflow: 'hidden',
                transition: 'all 200ms var(--ease-snappy)',
              }}
            >
              <span style={{
                fontFamily: 'Inter', fontSize: 9, fontWeight: 600,
                color: block.color === 'fixed' ? '#3A6660' : block.color,
                whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis', padding: '0 4px',
              }}>
                {block.label}
              </span>
            </div>
          ))}
        </div>

        {/* Duration labels */}
        <div style={{ display: 'flex', gap: 3 }}>
          {getTimelineBlocks().map((block, i) => (
            <div key={i} style={{ flex: block.duration, textAlign: 'center', minWidth: 0, overflow: 'hidden' }}>
              <span style={{ fontFamily: 'Inter', fontSize: 9, color: '#2A4A46', whiteSpace: 'nowrap' }}>
                {block.duration}m
              </span>
            </div>
          ))}
        </div>

        {selected.length === 0 && (
          <p style={{ fontFamily: 'Inter', fontSize: 12, color: '#3A6660', textAlign: 'center', marginTop: 8 }}>
            Select blocks above to build your session
          </p>
        )}
      </div>

      {/* DONNA summary */}
      {selected.length > 0 && (
        <div style={{
          background: 'rgba(0,201,167,0.05)', border: '1px solid rgba(0,201,167,0.12)',
          borderRadius: 10, padding: '10px 14px', marginBottom: 20,
          display: 'flex', gap: 8, alignItems: 'flex-start',
          animation: 'scale-in 280ms var(--ease-snappy) both',
        }}>
          <Sparkles size={13} color="#00C9A7" style={{ flexShrink: 0, marginTop: 1 }} />
          <p style={{ fontFamily: 'Inter', fontSize: 13, color: '#C8E0DC', lineHeight: 1.6 }}>
            I'll generate your session templates with: {selected.map(id => SESSION_BLOCKS.find(b => b.id === id)?.timelineLabel).join(' → ')}.
          </p>
        </div>
      )}

      {/* Navigation */}
      <div style={{ display: 'flex', gap: 10 }}>
        <button onClick={goPrev} style={NAV_BTN}
          onMouseEnter={e => { (e.currentTarget as HTMLButtonElement).style.background = 'rgba(255,255,255,0.08)'; (e.currentTarget as HTMLButtonElement).style.color = '#E8F0EE'; }}
          onMouseLeave={e => { (e.currentTarget as HTMLButtonElement).style.background = 'rgba(255,255,255,0.04)'; (e.currentTarget as HTMLButtonElement).style.color = '#A0B8B4'; }}
        >
          <ArrowLeft size={14} /> Back
        </button>
        <button onClick={goNext} style={{
          display: 'flex', alignItems: 'center', gap: 8,
          background: '#00C9A7', color: '#050D0B', border: 'none', borderRadius: 10,
          padding: '10px 22px', fontFamily: 'Inter', fontWeight: 600, fontSize: 14, cursor: 'pointer',
          transition: 'all 160ms var(--ease-snappy)',
        }}
          onMouseEnter={e => { (e.currentTarget as HTMLButtonElement).style.background = '#00E5C4'; (e.currentTarget as HTMLButtonElement).style.transform = 'translateY(-1px)'; (e.currentTarget as HTMLButtonElement).style.boxShadow = '0 8px 24px rgba(0,201,167,0.3)'; }}
          onMouseLeave={e => { (e.currentTarget as HTMLButtonElement).style.background = '#00C9A7'; (e.currentTarget as HTMLButtonElement).style.transform = 'translateY(0)'; (e.currentTarget as HTMLButtonElement).style.boxShadow = 'none'; }}
          onMouseDown={e => { (e.currentTarget as HTMLButtonElement).style.transform = 'scale(0.97)'; }}
          onMouseUp={e => { (e.currentTarget as HTMLButtonElement).style.transform = 'translateY(-1px)'; }}
        >
          Continue <ArrowRight size={14} />
        </button>
      </div>
    </div>
  );
}
