/**
 * DonnaChatScreen — AnglesOS Brand Kit v1.0
 * Conversational AI interface for adjusting Academy DNA
 * Accent: #00C9A7 teal | Font: Inter
 */
import { useState, useRef, useEffect } from 'react';
import { useOnboarding } from '@/contexts/OnboardingContext';
import { ArrowRight, Send, CheckCircle2, X, Edit2 } from 'lucide-react';

const DONNA_AVATAR = 'https://d2xsxph8kpxj0f.cloudfront.net/310519663491229281/hThsvPRkRg2ZPapL6S2sHW/donna-avatar-ADZ5kk7trPkwpGjTPMbMQm.webp';

interface Message {
  id: string;
  role: 'user' | 'donna';
  text: string;
  timestamp: string;
  proposal?: { title: string; changes: string[]; affected: string[] };
}

const EXAMPLE_PROMPTS = [
  'Make this less intense for younger kids.',
  'We are more game-based than technical.',
  'Parents need more education.',
  'I want coaches to be more direct.',
  'Make Orange Ball more fun but High Performance more disciplined.',
];

const DONNA_RESPONSES: Record<string, Message['proposal']> = {
  'Make this less intense for younger kids.': {
    title: 'Adjusted intensity by age group',
    changes: ['Red/Orange Ball: Shifted to Joy + Retention and Game-Based Learning', 'Removed High-Performance Discipline from junior groups', 'Added more fun-based session blocks for ages 5–10'],
    affected: ['Curriculum defaults', 'Session templates', 'Coach cues', 'Parent communication'],
  },
  'We are more game-based than technical.': {
    title: 'Rebalanced toward Game-Based Learning',
    changes: ['Promoted Game-Based Learning to primary coaching style', 'Added Constraint Games and Live Ball Heavy to all session defaults', 'Reduced Technique Block duration from 20 to 10 minutes'],
    affected: ['Session templates', 'Coach cues', 'Curriculum defaults'],
  },
  'Parents need more education.': {
    title: 'Enhanced parent education layer',
    changes: ['Added Developmental Education as primary parent communication style', 'Enabled Actionable At-Home Support in all parent reports', 'Added "Why we do this" context to all progress updates'],
    affected: ['Parent communication', 'Progress reports', 'Tournament guidance'],
  },
  'I want coaches to be more direct.': {
    title: 'Shifted to Direct + Clear coaching voice',
    changes: ['Set Direct + Clear as primary communication style', 'Updated all coach cue templates to use clear commands', 'Removed ambiguous language from session feedback prompts'],
    affected: ['Coach cues', 'Session templates', 'Player feedback'],
  },
  'Make Orange Ball more fun but High Performance more disciplined.': {
    title: 'Split academy DNA by level',
    changes: ['Orange Ball: Joy + Retention + Game-Based Learning as primary styles', 'High Performance: High-Performance Discipline + Competition-Ready as primary styles', 'Created separate session templates for each group'],
    affected: ['Curriculum defaults', 'Session templates', 'Coach cues', 'Parent communication'],
  },
};

function getTimestamp() {
  return new Date().toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' });
}

function getDonnaResponse(userMessage: string): Message {
  const matchKey = Object.keys(DONNA_RESPONSES).find(k =>
    userMessage.toLowerCase().includes(k.toLowerCase().slice(0, 20))
  );
  const proposal = matchKey ? DONNA_RESPONSES[matchKey] : {
    title: 'Adjustments applied',
    changes: ['Updated coaching philosophy based on your feedback', 'Revised session structure to match your preferences', 'Adjusted communication tone accordingly'],
    affected: ['Curriculum defaults', 'Session templates', 'Coach cues'],
  };
  return {
    id: Math.random().toString(36).slice(2),
    role: 'donna',
    text: `I can adjust your academy DNA based on your feedback. Here's what I'd change:`,
    timestamp: getTimestamp(),
    proposal,
  };
}

export default function DonnaChatScreen() {
  const { goTo } = useOnboarding();
  const [messages, setMessages] = useState<Message[]>([
    {
      id: 'intro', role: 'donna',
      text: "I'm here to fine-tune your Academy DNA. Tell me what you'd like to adjust — I'll propose specific changes and show you exactly what they affect.",
      timestamp: getTimestamp(),
    },
  ]);
  const [input, setInput] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const [approvedProposal, setApprovedProposal] = useState<string | null>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isTyping]);

  const sendMessage = (text: string) => {
    if (!text.trim()) return;
    const userMsg: Message = { id: Math.random().toString(36).slice(2), role: 'user', text: text.trim(), timestamp: getTimestamp() };
    setMessages(prev => [...prev, userMsg]);
    setInput('');
    setIsTyping(true);
    setTimeout(() => {
      setIsTyping(false);
      setMessages(prev => [...prev, getDonnaResponse(text)]);
    }, 1200 + Math.random() * 800);
  };

  const approveProposal = (msgId: string) => {
    setApprovedProposal(msgId);
    setTimeout(() => goTo('dna-summary'), 800);
  };

  return (
    <div style={{ display: 'flex', flexDirection: 'column', height: '100%', maxWidth: 720, fontFamily: 'Inter, -apple-system, BlinkMacSystemFont, sans-serif' }}>
      {/* Header */}
      <div style={{ paddingBottom: 16, flexShrink: 0 }}>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 4 }}>
          <div>
            <p style={{ fontFamily: 'Inter', fontWeight: 700, fontSize: 10, color: '#00C9A7', textTransform: 'uppercase', letterSpacing: '0.1em', marginBottom: 6 }}>
              DONNA Adjustment
            </p>
            <h2 style={{ fontFamily: 'Inter', fontWeight: 700, fontSize: '1.4rem', color: '#E8F0EE', lineHeight: 1.2 }}>
              Ask DONNA to adjust your DNA
            </h2>
          </div>
          <button onClick={() => goTo('dna-summary')} style={{
            display: 'flex', alignItems: 'center', gap: 5,
            background: 'rgba(255,255,255,0.04)', color: '#A0B8B4',
            border: '1px solid rgba(255,255,255,0.08)', borderRadius: 8,
            padding: '7px 12px', fontFamily: 'Inter', fontWeight: 500, fontSize: 12, cursor: 'pointer',
            transition: 'all 160ms var(--ease-snappy)',
          }}
            onMouseEnter={e => { (e.currentTarget as HTMLButtonElement).style.color = '#E8F0EE'; (e.currentTarget as HTMLButtonElement).style.background = 'rgba(255,255,255,0.08)'; }}
            onMouseLeave={e => { (e.currentTarget as HTMLButtonElement).style.color = '#A0B8B4'; (e.currentTarget as HTMLButtonElement).style.background = 'rgba(255,255,255,0.04)'; }}
          >
            <ArrowRight size={12} style={{ transform: 'rotate(180deg)' }} />
            Back to DNA
          </button>
        </div>
      </div>

      {/* Messages */}
      <div style={{ flex: 1, overflowY: 'auto', display: 'flex', flexDirection: 'column', gap: 12 }}>
        {messages.map(msg => (
          <div key={msg.id} style={{
            display: 'flex', gap: 9,
            flexDirection: msg.role === 'user' ? 'row-reverse' : 'row',
            alignItems: 'flex-start',
          }}>
            {msg.role === 'donna' && (
              <div style={{
                width: 30, height: 30, borderRadius: '50%', overflow: 'hidden',
                border: '1px solid rgba(0,201,167,0.30)', flexShrink: 0,
              }}>
                <img src={DONNA_AVATAR} alt="DONNA" style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
              </div>
            )}
            <div style={{ maxWidth: '80%', display: 'flex', flexDirection: 'column', gap: 5 }}>
              <div style={{
                background: msg.role === 'donna' ? '#111A18' : 'rgba(0,201,167,0.08)',
                border: `1px solid ${msg.role === 'donna' ? 'rgba(0,201,167,0.10)' : 'rgba(0,201,167,0.20)'}`,
                borderRadius: msg.role === 'donna' ? '4px 12px 12px 12px' : '12px 4px 12px 12px',
                padding: '10px 14px',
              }}>
                <p style={{ fontFamily: 'Inter', fontSize: 13, color: msg.role === 'donna' ? '#C8E0DC' : '#E8F0EE', lineHeight: 1.6 }}>
                  {msg.text}
                </p>
              </div>

              {/* Proposal card */}
              {msg.proposal && (
                <div style={{
                  background: '#111A18', border: '1px solid rgba(0,201,167,0.15)',
                  borderRadius: 12, overflow: 'hidden',
                }}>
                  <div style={{
                    background: 'rgba(0,201,167,0.05)', borderBottom: '1px solid rgba(0,201,167,0.10)',
                    padding: '10px 14px', display: 'flex', alignItems: 'center', gap: 7,
                  }}>
                    <div style={{ width: 7, height: 7, borderRadius: '50%', background: '#00C9A7', flexShrink: 0 }} />
                    <p style={{ fontFamily: 'Inter', fontWeight: 600, fontSize: 13, color: '#00C9A7' }}>
                      {msg.proposal.title}
                    </p>
                  </div>
                  <div style={{ padding: '12px 14px' }}>
                    <div style={{ marginBottom: 10 }}>
                      <p style={{ fontFamily: 'Inter', fontWeight: 700, fontSize: 10, color: '#3A6660', textTransform: 'uppercase', letterSpacing: '0.1em', marginBottom: 7 }}>
                        Proposed Changes
                      </p>
                      {msg.proposal.changes.map((change, i) => (
                        <div key={i} style={{ display: 'flex', gap: 7, alignItems: 'flex-start', marginBottom: 5 }}>
                          <div style={{ width: 4, height: 4, borderRadius: '50%', background: '#00C9A7', marginTop: 6, flexShrink: 0 }} />
                          <p style={{ fontFamily: 'Inter', fontSize: 12, color: '#A0B8B4', lineHeight: 1.5 }}>{change}</p>
                        </div>
                      ))}
                    </div>
                    <div style={{ marginBottom: 12 }}>
                      <p style={{ fontFamily: 'Inter', fontWeight: 700, fontSize: 10, color: '#3A6660', textTransform: 'uppercase', letterSpacing: '0.1em', marginBottom: 7 }}>
                        Affected Areas
                      </p>
                      <div style={{ display: 'flex', flexWrap: 'wrap', gap: 5 }}>
                        {msg.proposal.affected.map(area => (
                          <span key={area} style={{
                            background: 'rgba(0,201,167,0.06)', border: '1px solid rgba(0,201,167,0.15)',
                            borderRadius: 5, padding: '2px 8px',
                            fontFamily: 'Inter', fontSize: 11, color: '#5A7A76',
                          }}>
                            {area}
                          </span>
                        ))}
                      </div>
                    </div>
                    {approvedProposal !== msg.id ? (
                      <div style={{ display: 'flex', gap: 6 }}>
                        <button onClick={() => approveProposal(msg.id)} style={{
                          display: 'flex', alignItems: 'center', gap: 5,
                          background: '#00C9A7', color: '#050D0B', border: 'none', borderRadius: 7,
                          padding: '6px 12px', fontFamily: 'Inter', fontWeight: 600, fontSize: 12, cursor: 'pointer',
                          transition: 'all 160ms var(--ease-snappy)',
                        }}>
                          <CheckCircle2 size={12} /> Approve
                        </button>
                        <button onClick={() => goTo('coaching-philosophy')} style={{
                          display: 'flex', alignItems: 'center', gap: 5,
                          background: 'rgba(255,255,255,0.04)', color: '#A0B8B4',
                          border: '1px solid rgba(255,255,255,0.08)', borderRadius: 7,
                          padding: '6px 10px', fontFamily: 'Inter', fontSize: 12, cursor: 'pointer',
                        }}>
                          <Edit2 size={11} /> Edit
                        </button>
                        <button onClick={() => goTo('dna-summary')} style={{
                          display: 'flex', alignItems: 'center', gap: 5,
                          background: 'transparent', color: '#5A7A76',
                          border: '1px solid rgba(255,255,255,0.06)', borderRadius: 7,
                          padding: '6px 10px', fontFamily: 'Inter', fontSize: 12, cursor: 'pointer',
                        }}>
                          <X size={11} /> Cancel
                        </button>
                      </div>
                    ) : (
                      <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                        <CheckCircle2 size={14} color="#00C9A7" />
                        <p style={{ fontFamily: 'Inter', fontSize: 12, color: '#00C9A7' }}>
                          Changes approved. Updating your DNA...
                        </p>
                      </div>
                    )}
                  </div>
                </div>
              )}
              <p style={{ fontFamily: 'Inter', fontSize: 10, color: '#3A6660', alignSelf: msg.role === 'user' ? 'flex-end' : 'flex-start' }}>
                {msg.timestamp}
              </p>
            </div>
          </div>
        ))}

        {/* Typing indicator */}
        {isTyping && (
          <div style={{ display: 'flex', gap: 9, alignItems: 'flex-start' }}>
            <div style={{ width: 30, height: 30, borderRadius: '50%', overflow: 'hidden', border: '1px solid rgba(0,201,167,0.30)', flexShrink: 0 }}>
              <img src={DONNA_AVATAR} alt="DONNA" style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
            </div>
            <div style={{
              background: '#111A18', border: '1px solid rgba(0,201,167,0.10)',
              borderRadius: '4px 12px 12px 12px', padding: '10px 14px',
              display: 'flex', gap: 4, alignItems: 'center',
            }}>
              {[0, 1, 2].map(i => (
                <div key={i} style={{
                  width: 5, height: 5, borderRadius: '50%', background: '#00C9A7',
                  animation: `blink 1.2s ${i * 0.2}s ease-in-out infinite`,
                }} />
              ))}
            </div>
          </div>
        )}
        <div ref={messagesEndRef} />
      </div>

      {/* Example prompts */}
      <div style={{ paddingTop: 10, flexShrink: 0 }}>
        <div style={{ display: 'flex', gap: 5, flexWrap: 'wrap' }}>
          {EXAMPLE_PROMPTS.map(prompt => (
            <button key={prompt} onClick={() => sendMessage(prompt)} style={{
              background: 'rgba(0,201,167,0.04)', border: '1px solid rgba(0,201,167,0.10)',
              borderRadius: 6, padding: '4px 9px',
              fontFamily: 'Inter', fontSize: 11, color: '#5A7A76',
              cursor: 'pointer', transition: 'all 120ms', whiteSpace: 'nowrap',
            }}
              onMouseEnter={e => { (e.currentTarget as HTMLButtonElement).style.color = '#00C9A7'; (e.currentTarget as HTMLButtonElement).style.borderColor = 'rgba(0,201,167,0.25)'; }}
              onMouseLeave={e => { (e.currentTarget as HTMLButtonElement).style.color = '#5A7A76'; (e.currentTarget as HTMLButtonElement).style.borderColor = 'rgba(0,201,167,0.10)'; }}
            >
              {prompt}
            </button>
          ))}
        </div>
      </div>

      {/* Input area */}
      <div style={{ paddingTop: 10, paddingBottom: 4, flexShrink: 0 }}>
        <div style={{
          display: 'flex', gap: 8, alignItems: 'flex-end',
          background: '#111A18', border: '1px solid rgba(0,201,167,0.12)',
          borderRadius: 12, padding: '8px 10px',
          transition: 'border-color 160ms var(--ease-snappy)',
        }}>
          <textarea
            value={input}
            onChange={e => setInput(e.target.value)}
            onKeyDown={e => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); sendMessage(input); } }}
            placeholder="Tell DONNA what to adjust..."
            rows={1}
            style={{
              flex: 1, background: 'transparent', border: 'none', outline: 'none',
              color: '#E8F0EE', fontFamily: 'Inter', fontSize: 13, resize: 'none', lineHeight: 1.5,
            }}
          />
          <button
            onClick={() => sendMessage(input)}
            disabled={!input.trim() || isTyping}
            style={{
              width: 32, height: 32, borderRadius: 8, flexShrink: 0,
              background: input.trim() && !isTyping ? '#00C9A7' : 'rgba(0,201,167,0.08)',
              border: 'none', cursor: input.trim() && !isTyping ? 'pointer' : 'not-allowed',
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              transition: 'all 160ms var(--ease-snappy)',
            }}
          >
            <Send size={13} color={input.trim() && !isTyping ? '#050D0B' : '#3A6660'} />
          </button>
        </div>
      </div>
    </div>
  );
}
