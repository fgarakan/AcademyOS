/**
 * Home — AcademyOS Donna Onboarding
 * Orchestrates all 10 screens with OnboardingProvider
 * Design: AnglesOS Brand Kit v1.0 — Dark Command Center
 */
import { OnboardingProvider, useOnboarding } from '@/contexts/OnboardingContext';
import OnboardingLayout from '@/components/OnboardingLayout';
import WelcomeScreen from './screens/WelcomeScreen';
import AcademyBasicsScreen from './screens/AcademyBasicsScreen';
import CoachingPhilosophyScreen from './screens/CoachingPhilosophyScreen';
import CoachCommunicationScreen from './screens/CoachCommunicationScreen';
import SessionDesignScreen from './screens/SessionDesignScreen';
import PlayerDevelopmentScreen from './screens/PlayerDevelopmentScreen';
import ParentCommunicationScreen from './screens/ParentCommunicationScreen';
import DNASummaryScreen from './screens/DNASummaryScreen';
import DonnaChatScreen from './screens/DonnaChatScreen';
import FinalActivationScreen from './screens/FinalActivationScreen';

const DONNA_MESSAGES: Record<string, string> = {
  'welcome': "Hi, I'm DONNA. I'll guide you through setting up your academy's coaching DNA in about 4 minutes.",
  'academy-basics': "Let's start with the basics. Tell me about your academy so I can customize everything for you.",
  'coaching-philosophy': "Your coaching philosophy is the heart of your academy. Choose up to 3 styles that define how you teach.",
  'coach-communication': "Great choices. Now let's define how your coaches should communicate — this shapes every session cue and player interaction.",
  'session-design': "I'll use these building blocks to generate all your session templates. Select what fits your academy.",
  'player-development': "These priorities will appear in player dashboards, coach watch-fors, and parent updates. Rank your top 5.",
  'parent-communication': "The last piece. How should parents receive information about their child's progress?",
  'dna-summary': "Here's everything I've learned about your academy. Review and approve when ready.",
  'donna-chat': "Tell me what to adjust. I'll propose specific changes and show you exactly what they affect.",
  'final-activation': "Your academy DNA is live. I've created all your defaults. What would you like to set up next?",
};

function OnboardingRouter() {
  const { currentScreen, state } = useOnboarding();

  const showSummary = ['coaching-philosophy', 'coach-communication', 'session-design', 'player-development', 'parent-communication', 'dna-summary'].includes(currentScreen);

  const donnaMessage = DONNA_MESSAGES[currentScreen];

  // Welcome screen has its own full-bleed layout
  if (currentScreen === 'welcome') {
    return (
      <OnboardingLayout donnaMessage={donnaMessage} showSummary={false}>
        <WelcomeScreen />
      </OnboardingLayout>
    );
  }

  return (
    <OnboardingLayout donnaMessage={donnaMessage} showSummary={showSummary}>
      {currentScreen === 'academy-basics' && <AcademyBasicsScreen />}
      {currentScreen === 'coaching-philosophy' && <CoachingPhilosophyScreen />}
      {currentScreen === 'coach-communication' && <CoachCommunicationScreen />}
      {currentScreen === 'session-design' && <SessionDesignScreen />}
      {currentScreen === 'player-development' && <PlayerDevelopmentScreen />}
      {currentScreen === 'parent-communication' && <ParentCommunicationScreen />}
      {currentScreen === 'dna-summary' && <DNASummaryScreen />}
      {currentScreen === 'donna-chat' && <DonnaChatScreen />}
      {currentScreen === 'final-activation' && <FinalActivationScreen />}
    </OnboardingLayout>
  );
}

export default function Home() {
  return (
    <OnboardingProvider>
      <OnboardingRouter />
    </OnboardingProvider>
  );
}
