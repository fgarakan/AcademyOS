/**
 * OnboardingLayout — AnglesOS Brand Kit v1.0
 * Layout: Main Content (flex-1) | DONNA Panel (320px fixed, right)
 * Background: #0A0F0E (--background)
 * Progress bar: teal gradient, 3px, top of content area
 * Font: Inter
 */
import { ReactNode } from 'react';
import DonnaPanel from './DonnaPanel';
import { useOnboarding } from '@/contexts/OnboardingContext';

const SCREEN_PROGRESS: Record<string, number> = {
  'welcome': 0,
  'academy-basics': 14,
  'coaching-philosophy': 28,
  'coach-communication': 42,
  'session-design': 56,
  'player-development': 70,
  'parent-communication': 84,
  'dna-summary': 96,
  'donna-chat': 96,
  'final-activation': 100,
};

interface OnboardingLayoutProps {
  children: ReactNode;
  donnaMessage?: string;
  showSummary?: boolean;
}

export default function OnboardingLayout({
  children,
  donnaMessage,
  showSummary = false,
}: OnboardingLayoutProps) {
  const { currentScreen } = useOnboarding();
  const progress = SCREEN_PROGRESS[currentScreen] || 0;
  const isWelcome = currentScreen === 'welcome';

  return (
    <div
      style={{
        display: 'flex',
        height: '100vh',
        width: '100vw',
        overflow: 'hidden',
        background: '#0A0F0E',
        fontFamily: 'Inter, -apple-system, BlinkMacSystemFont, sans-serif',
      }}
    >
      {/* Main content area */}
      <div
        style={{
          flex: 1,
          display: 'flex',
          flexDirection: 'column',
          overflow: 'hidden',
          minWidth: 0,
        }}
      >
        {/* Top progress bar — hidden on welcome screen */}
        {!isWelcome && (
          <div
            style={{
              height: 3,
              background: 'rgba(0, 201, 167, 0.08)',
              flexShrink: 0,
            }}
          >
            <div
              style={{
                height: '100%',
                background: 'linear-gradient(90deg, #00C9A7, #00E5C4)',
                borderRadius: '0 9999px 9999px 0',
                width: `${progress}%`,
                transition: 'width 400ms cubic-bezier(0.77, 0, 0.175, 1)',
                boxShadow: '0 0 6px rgba(0, 201, 167, 0.3)',
              }}
            />
          </div>
        )}

        {/* Screen content */}
        <main
          key={currentScreen}
          style={{
            flex: 1,
            overflowY: 'auto',
            overflowX: 'hidden',
            display: 'flex',
            flexDirection: 'column',
            padding: isWelcome ? 0 : 24,
          }}
        >
          {children}
        </main>
      </div>

      {/* DONNA Panel — right side, 320px fixed */}
      <DonnaPanel donnaMessage={donnaMessage} showSummary={showSummary} />
    </div>
  );
}
