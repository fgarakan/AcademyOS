/**
 * DonnaPanel — AnglesOS Brand Kit v1.0
 * Width: 320px fixed, right side
 * Background: #0D1614 (--sidebar)
 * Border-left: 1px solid rgba(0,201,167,0.08)
 * Font: Inter
 * Accent: #00C9A7 teal only
 */
import { useOnboarding } from '@/contexts/OnboardingContext';
import { Sparkles, CheckCircle2, Circle, ChevronRight } from 'lucide-react';

const DONNA_AVATAR_URL = 'https://d2xsxph8kpxj0f.cloudfront.net/310519663491229281/hThsvPRkRg2ZPapL6S2sHW/donna-avatar-ADZ5kk7trPkwpGjTPMbMQm.webp';

const PROGRESS_STEPS = [
  { id: 'academy-basics', label: 'Academy Basics', step: 1 },
  { id: 'coaching-philosophy', label: 'Coaching Philosophy', step: 2 },
  { id: 'coach-communication', label: 'Coach Communication', step: 3 },
  { id: 'session-design', label: 'Session Design', step: 4 },
  { id: 'player-development', label: 'Player Development', step: 5 },
  { id: 'parent-communication', label: 'Parent Communication', step: 6 },
  { id: 'dna-summary', label: 'Review Academy DNA', step: 7 },
];

const COACHING_LABELS: Record<string, string> = {
  'fundamentals-first': 'Fundamentals First',
  'game-based': 'Game-Based Learning',
  'high-performance': 'High-Performance',
  'player-centered': 'Player-Centered',
  'tactical-first': 'Tactical First',
  'movement-first': 'Movement First',
  'competition-ready': 'Competition-Ready',
  'joy-retention': 'Joy + Retention',
};

const COMM_LABELS: Record<string, string> = {
  'direct-clear': 'Direct + Clear',
  'encouraging-positive': 'Encouraging',
  'question-led': 'Question-Led',
  'high-energy': 'High-Energy',
  'calm-precise': 'Calm + Precise',
  'standards-based': 'Standards-Based',
};

const SESSION_LABELS: Record<string, string> = {
  'technique-blocks': 'Technique Blocks',
  'live-ball-heavy': 'Live Ball Heavy',
  'constraint-games': 'Constraint Games',
  'point-play': 'Point Play',
  'stations': 'Stations',
  'assessment': 'Assessment',
  'fitness-integrated': 'Fitness',
};

const PLAYER_LABELS: Record<string, string> = {
  'technical-foundation': 'Technical Foundation',
  'tactical-iq': 'Tactical IQ',
  'movement-quality': 'Movement Quality',
  'competitive-toughness': 'Competitive Toughness',
  'emotional-regulation': 'Emotional Regulation',
  'consistency': 'Consistency',
  'aggressive-identity': 'Aggressive Identity',
  'all-court': 'All-Court',
  'serve-return': 'Serve + Return',
  'independence': 'Independence',
};

interface DonnaPanelProps {
  donnaMessage?: string;
  showSummary?: boolean;
}

export default function DonnaPanel({ donnaMessage, showSummary }: DonnaPanelProps) {
  const { currentScreen, state, getStepStatus } = useOnboarding();

  const isWelcome = currentScreen === 'welcome';
  const isFinal = currentScreen === 'final-activation';
  const isDonnaChat = currentScreen === 'donna-chat';

  // Build live DNA summary lines
  const summaryLines: { label: string; values: string[] }[] = [];
  if (state.academyName) summaryLines.push({ label: 'Academy', values: [state.academyName] });
  if (state.academyModel) summaryLines.push({ label: 'Model', values: [state.academyModel.replace(/-/g, ' ').replace(/\b\w/g, c => c.toUpperCase())] });
  if (state.ageGroups.length > 0) summaryLines.push({ label: 'Age Groups', values: state.ageGroups.map(g => g.replace(/-/g, ' ').replace(/\b\w/g, c => c.toUpperCase())) });
  if (state.coachingStyles.length > 0) summaryLines.push({ label: 'Philosophy', values: state.coachingStyles.map(id => COACHING_LABELS[id] || id) });
  if (state.primaryCommunication) summaryLines.push({ label: 'Coach Voice', values: [COMM_LABELS[state.primaryCommunication] || state.primaryCommunication] });
  if (state.sessionDesigns.length > 0) summaryLines.push({ label: 'Sessions', values: state.sessionDesigns.map(id => SESSION_LABELS[id] || id) });
  if (state.playerPriorities.length > 0) summaryLines.push({ label: 'Dev Focus', values: state.playerPriorities.slice(0, 3).map(id => PLAYER_LABELS[id] || id) });

  return (
    <aside
      style={{
        width: 320,
        flexShrink: 0,
        background: '#0D1614',
        borderLeft: '1px solid rgba(0, 201, 167, 0.08)',
        padding: 20,
        display: 'flex',
        flexDirection: 'column',
        overflowY: 'auto',
        height: '100%',
      }}
    >
      {/* DONNA Header */}
      <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 20 }}>
        {/* Avatar */}
        <div style={{ position: 'relative', flexShrink: 0 }}>
          <div
            style={{
              width: 36,
              height: 36,
              borderRadius: '50%',
              overflow: 'hidden',
              background: 'linear-gradient(135deg, #00C9A7, #00A882)',
              boxShadow: '0 0 16px rgba(0, 201, 167, 0.25)',
              animation: 'donna-blink 4s ease-in-out infinite',
            }}
          >
            <img
              src={DONNA_AVATAR_URL}
              alt="DONNA"
              style={{ width: '100%', height: '100%', objectFit: 'cover' }}
              onError={e => {
                (e.currentTarget as HTMLImageElement).style.display = 'none';
              }}
            />
          </div>
          {/* Active status dot */}
          <div
            style={{
              position: 'absolute',
              bottom: 0,
              right: 0,
              width: 8,
              height: 8,
              borderRadius: '50%',
              background: '#00C9A7',
              border: '1.5px solid #0D1614',
              animation: 'teal-pulse-ring 2s ease-out infinite',
            }}
          />
        </div>
        <div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 5 }}>
            <p style={{ fontFamily: 'Inter', fontWeight: 600, fontSize: 14, color: '#E8F0EE', lineHeight: 1.2 }}>DONNA</p>
            <Sparkles size={11} color="#00C9A7" />
          </div>
          <p style={{ fontFamily: 'Inter', fontSize: 11, color: '#5A7A76', marginTop: 1 }}>
            Director of Operations &amp; Neural Network Assistant
          </p>
        </div>
      </div>

      {/* DONNA Message Bubble */}
      {donnaMessage && (
        <div
          style={{
            background: 'rgba(0, 201, 167, 0.05)',
            border: '1px solid rgba(0, 201, 167, 0.12)',
            borderRadius: 12,
            padding: '12px 16px',
            marginBottom: 20,
            animation: 'scale-in 280ms var(--ease-snappy) both',
          }}
        >
          <p style={{ fontFamily: 'Inter', fontWeight: 400, fontSize: 13, color: '#C8E0DC', lineHeight: 1.6 }}>
            {donnaMessage}
          </p>
        </div>
      )}

      {/* Progress Steps — shown on non-welcome, non-final, non-chat screens */}
      {!isWelcome && !isFinal && !isDonnaChat && (
        <div style={{ marginBottom: 20 }}>
          <p
            style={{
              fontFamily: 'Inter',
              fontWeight: 700,
              fontSize: 10,
              color: '#2A4A46',
              textTransform: 'uppercase',
              letterSpacing: '0.1em',
              marginBottom: 10,
            }}
          >
            Setup Progress
          </p>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
            {PROGRESS_STEPS.map(step => {
              const status = getStepStatus(step.id);
              return (
                <div
                  key={step.id}
                  style={{
                    display: 'flex',
                    alignItems: 'center',
                    gap: 8,
                    padding: '6px 8px',
                    borderRadius: 6,
                    background: status === 'active' ? 'rgba(0, 201, 167, 0.08)' : 'transparent',
                    transition: 'background 160ms var(--ease-snappy)',
                  }}
                >
                  {status === 'complete' ? (
                    <CheckCircle2 size={13} color="#00C9A7" style={{ flexShrink: 0 }} />
                  ) : status === 'active' ? (
                    <div
                      style={{
                        width: 13,
                        height: 13,
                        borderRadius: '50%',
                        border: '2px solid #00C9A7',
                        flexShrink: 0,
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                      }}
                    >
                      <div style={{ width: 5, height: 5, borderRadius: '50%', background: '#00C9A7' }} />
                    </div>
                  ) : (
                    <Circle size={13} color="#2A4A46" style={{ flexShrink: 0 }} />
                  )}
                  <p
                    style={{
                      fontFamily: 'Inter',
                      fontSize: 12,
                      fontWeight: status === 'active' ? 600 : 400,
                      color: status === 'complete' ? '#5A7A76' : status === 'active' ? '#00C9A7' : '#3A6660',
                      lineHeight: 1.3,
                    }}
                  >
                    {step.label}
                  </p>
                  {status === 'active' && (
                    <ChevronRight size={11} color="#00C9A7" style={{ marginLeft: 'auto', flexShrink: 0 }} />
                  )}
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Live DNA Summary — shown when showSummary is true and there's data */}
      {showSummary && summaryLines.length > 0 && (
        <div
          style={{
            background: 'rgba(0, 201, 167, 0.04)',
            border: '1px solid rgba(0, 201, 167, 0.10)',
            borderRadius: 12,
            padding: '12px 14px',
            marginBottom: 16,
            animation: 'fade-in 200ms var(--ease-snappy) both',
          }}
        >
          <p
            style={{
              fontFamily: 'Inter',
              fontWeight: 700,
              fontSize: 10,
              color: '#2A4A46',
              textTransform: 'uppercase',
              letterSpacing: '0.1em',
              marginBottom: 10,
            }}
          >
            Academy DNA — Building
          </p>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
            {summaryLines.map(line => (
              <div key={line.label}>
                <p
                  style={{
                    fontFamily: 'Inter',
                    fontWeight: 600,
                    fontSize: 10,
                    color: '#3A6660',
                    textTransform: 'uppercase',
                    letterSpacing: '0.08em',
                    marginBottom: 3,
                  }}
                >
                  {line.label}
                </p>
                <div style={{ display: 'flex', flexWrap: 'wrap', gap: 3 }}>
                  {line.values.map(v => (
                    <span
                      key={v}
                      style={{
                        background: 'rgba(0, 201, 167, 0.10)',
                        border: '1px solid rgba(0, 201, 167, 0.18)',
                        borderRadius: 4,
                        padding: '1px 7px',
                        fontFamily: 'Inter',
                        fontSize: 11,
                        fontWeight: 500,
                        color: '#A0B8B4',
                      }}
                    >
                      {v}
                    </span>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Building indicator — shown on active content screens */}
      {!isWelcome && !isFinal && (
        <div style={{ marginTop: 'auto', paddingTop: 12 }}>
          <div
            style={{
              display: 'flex',
              alignItems: 'center',
              gap: 8,
              background: 'rgba(0, 201, 167, 0.04)',
              border: '1px solid rgba(0, 201, 167, 0.08)',
              borderRadius: 8,
              padding: '8px 12px',
            }}
          >
            <div
              style={{
                width: 6,
                height: 6,
                borderRadius: '50%',
                background: '#00C9A7',
                animation: 'donna-pulse 1.5s ease-in-out infinite',
                flexShrink: 0,
              }}
            />
            <p
              style={{
                fontFamily: 'Inter',
                fontSize: 11,
                color: '#5A7A76',
                lineHeight: 1.4,
              }}
            >
              Building academy defaults
            </p>
          </div>
        </div>
      )}

      {/* Welcome screen — DONNA principle */}
      {isWelcome && (
        <div style={{ marginTop: 'auto' }}>
          <div
            style={{
              background: 'rgba(0, 201, 167, 0.04)',
              border: '1px solid rgba(0, 201, 167, 0.08)',
              borderRadius: 8,
              padding: '10px 12px',
            }}
          >
            <p
              style={{
                fontFamily: 'Inter',
                fontWeight: 600,
                fontSize: 11,
                color: '#3A6660',
                lineHeight: 1.5,
                fontStyle: 'italic',
              }}
            >
              "DONNA proposes. Directors approve. Nothing changes until approved."
            </p>
          </div>
        </div>
      )}

      {/* Final screen — completion state */}
      {isFinal && (
        <div style={{ marginTop: 'auto' }}>
          <div
            style={{
              background: 'rgba(0, 201, 167, 0.06)',
              border: '1px solid rgba(0, 201, 167, 0.15)',
              borderRadius: 10,
              padding: '12px 14px',
            }}
          >
            <div style={{ display: 'flex', alignItems: 'center', gap: 6, marginBottom: 6 }}>
              <CheckCircle2 size={13} color="#00C9A7" />
              <p style={{ fontFamily: 'Inter', fontWeight: 600, fontSize: 12, color: '#00C9A7' }}>
                Academy DNA Active
              </p>
            </div>
            <p style={{ fontFamily: 'Inter', fontSize: 11, color: '#5A7A76', lineHeight: 1.5 }}>
              {summaryLines.length} configuration{summaryLines.length !== 1 ? 's' : ''} applied. DONNA is ready to generate your curriculum.
            </p>
          </div>
        </div>
      )}
    </aside>
  );
}
