# AcademyOS Donna Onboarding — Design Brainstorm

<response>
<text>
## Idea A — "Obsidian Court" (Dark Athletic Precision)

**Design Movement:** Post-brutalist athletic dark UI, inspired by Nike Training Club + Linear.app

**Core Principles:**
1. Near-black backgrounds with surgical use of a single electric accent (cyan-green #00E5A0)
2. Typographic hierarchy through weight contrast — a heavy display serif for titles, clean mono-spaced for Donna's voice
3. Cards float on layered darkness — each level of depth is a distinct shade of near-black
4. Every interaction has a physical feel — pills "click" with micro-scale transforms

**Color Philosophy:**
- Background: #0A0B0E (near-black with a blue undertone)
- Surface: #111318 / #181C24
- Accent: #00E5A0 (electric mint — athletic, premium, alive)
- Secondary accent: #6366F1 (indigo for Donna's glow)
- Text: #F0F2F7 (cool white) / #8B92A5 (muted)

**Layout Paradigm:**
- Split-panel: Donna lives in a persistent left sidebar (~320px), content flows right
- Progress steps run vertically along the left edge
- No centered hero layouts — asymmetric tension

**Signature Elements:**
1. Donna's avatar card with a soft pulsing indigo glow ring
2. Selection pills that "charge up" with an electric mint fill on selection
3. Session timeline as an animated horizontal rail

**Interaction Philosophy:**
- Pills snap with a 120ms scale(0.96) press then spring back
- Selected state glows — box-shadow with accent color
- Donna's summary card types in character by character

**Animation:**
- Screen transitions: 200ms slide-right with opacity fade
- Pill selection: 150ms scale + glow bloom
- Progress bar: smooth 300ms ease-out fill
- Donna card: 2s breathing pulse on the glow ring

**Typography System:**
- Display: "Syne" (bold 700/800) for screen titles
- Body: "DM Sans" (400/500) for descriptions
- Donna voice: "DM Mono" (400) for AI-generated summaries
</text>
<probability>0.08</probability>
</response>

<response>
<text>
## Idea B — "Chalk & Carbon" (Coaching Board Aesthetic)

**Design Movement:** Sports analytics meets editorial — WSJ sports data visualization + Figma

**Core Principles:**
1. Deep charcoal backgrounds with warm amber accents (coaching board chalk feel)
2. Generous whitespace inside cards, tight spacing between cards
3. Data-forward: every selection immediately updates a live "DNA preview" panel
4. Handcrafted feel through subtle grain texture on backgrounds

**Color Philosophy:**
- Background: #0F0F0F (pure near-black)
- Surface: #1A1A1A / #242424
- Accent: #F59E0B (amber — warm, energetic, trophy-gold)
- Donna accent: #E879F9 (fuchsia — AI/intelligence signal)
- Text: #FAFAFA / #A3A3A3

**Layout Paradigm:**
- Top progress bar (horizontal steps)
- Full-width content area with a floating Donna summary drawer on the right
- Pills arranged in a masonry-style grid

**Signature Elements:**
1. Grain texture overlay on all background surfaces
2. Amber underline strokes on selected pills
3. Donna's summary as a "live document" that builds in real-time

**Typography System:**
- Display: "Bebas Neue" for bold impact titles
- Body: "IBM Plex Sans" for clarity
- Donna: "IBM Plex Mono" for AI voice
</text>
<probability>0.06</probability>
</response>

<response>
<text>
## Idea C — "Midnight Gradient" (Premium AI-First Dark)

**Design Movement:** Vercel/Stripe dark dashboard meets Apple Vision Pro spatial UI

**Core Principles:**
1. True black base with subtle blue-purple gradient washes behind key sections
2. Glass-morphism cards with backdrop-blur and translucent borders
3. Donna's presence is felt through a persistent glowing orb/avatar
4. Motion is the primary differentiator — everything breathes

**Color Philosophy:**
- Background: #050508 (true dark)
- Glass surfaces: rgba(255,255,255,0.04) with 1px rgba(255,255,255,0.08) border
- Accent: #7C6FFF (soft violet — premium, intelligent)
- Glow: #4F46E5 → #7C3AED gradient
- Text: #FFFFFF / #94A3B8

**Layout Paradigm:**
- Centered content with max-width 720px
- Donna floats as a persistent bottom-right orb that expands into summary
- Progress dots at top center

**Signature Elements:**
1. Glassmorphic pill cards with hover glow
2. Donna orb that pulses and expands
3. Gradient mesh background that shifts subtly between screens

**Typography System:**
- Display: "Cal Sans" / "Clash Display" for headings
- Body: "Geist" for clean readability
- Donna: "Geist Mono" for AI voice
</text>
<probability>0.07</probability>
</response>

---

## Selected Design: **Idea A — "Obsidian Court"**

Split-panel dark athletic precision. Donna lives in a persistent left panel with a pulsing indigo glow. Electric mint (#00E5A0) for selections. Syne + DM Sans + DM Mono typography. Every pill has a physical click feel.
