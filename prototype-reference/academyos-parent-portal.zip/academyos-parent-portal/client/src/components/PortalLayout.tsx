/*
 * AcademyOS Parent Portal — PortalLayout
 * "Midnight Court" design: dark sidebar + main content + DONNA panel
 * Sidebar: near-black, aqua active indicator
 * DONNA: fixed right panel on desktop, bottom sheet on mobile
 */
import { useState } from "react";
import { Link, useLocation } from "wouter";
import {
  Home,
  User,
  Zap,
  Trophy,
  Activity,
  ArrowRight,
  Calendar,
  Users,
  CheckCircle,
  MessageSquare,
  Menu,
  X,
  Bot,
  ChevronRight,
  Sparkles,
} from "lucide-react";
import { donnaQuickActions, donnaResponses, player } from "@/lib/data";
import { cn } from "@/lib/utils";

const navItems = [
  { path: "/", label: "Home", icon: Home },
  { path: "/snapshot", label: "Development Snapshot", icon: User },
  { path: "/skill-path", label: "Skill Path", icon: Zap },
  { path: "/competition-path", label: "Competition Path", icon: Trophy },
  { path: "/fitness-path", label: "Fitness Path", icon: Activity },
  { path: "/next-steps", label: "Next Steps", icon: ArrowRight },
  { path: "/request-lesson", label: "Request Private Lesson", icon: Calendar },
  { path: "/coach-selection", label: "Coach Selection", icon: Users },
  { path: "/confirmation", label: "Confirmation", icon: CheckCircle },
  { path: "/message", label: "Message Academy", icon: MessageSquare },
];

interface DonnaPanelProps {
  onClose?: () => void;
  mobile?: boolean;
}

function DonnaPanel({ onClose, mobile }: DonnaPanelProps) {
  const [activeResponse, setActiveResponse] = useState<string | null>(null);
  const [customInput, setCustomInput] = useState("");
  const [customResponse, setCustomResponse] = useState<string | null>(null);

  const handleQuickAction = (action: string) => {
    setActiveResponse(donnaResponses[action] || null);
    setCustomResponse(null);
  };

  const handleCustomSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!customInput.trim()) return;
    setCustomResponse(
      "Thank you for your question. I've noted it for the academy team. An **academy-approved response** will be sent to you within 1–2 business days."
    );
    setCustomInput("");
    setActiveResponse(null);
  };

  return (
    <div
      className={cn(
        "donna-panel flex flex-col h-full",
        mobile ? "rounded-t-2xl" : ""
      )}
    >
      {/* Header */}
      <div className="flex items-center justify-between px-5 pt-5 pb-4 border-b border-white/8">
        <div className="flex items-center gap-2.5">
          <div
            className="w-8 h-8 rounded-full flex items-center justify-center"
            style={{ background: "oklch(0.72 0.14 175 / 20%)" }}
          >
            <Bot size={16} style={{ color: "oklch(0.72 0.14 175)" }} />
          </div>
          <div>
            <p
              className="text-sm font-semibold"
              style={{ fontFamily: "'Space Grotesk', sans-serif" }}
            >
              DONNA
            </p>
            <p className="text-xs" style={{ color: "oklch(0.58 0.01 220)" }}>
              Parent Assistant
            </p>
          </div>
        </div>
        {mobile && onClose && (
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg hover:bg-white/5 transition-colors"
          >
            <X size={18} className="text-muted-foreground" />
          </button>
        )}
        <div
          className="flex items-center gap-1 px-2 py-0.5 rounded-full text-xs"
          style={{
            background: "oklch(0.72 0.14 175 / 12%)",
            color: "oklch(0.72 0.14 175)",
            border: "1px solid oklch(0.72 0.14 175 / 25%)",
          }}
        >
          <Sparkles size={10} />
          AI-Powered
        </div>
      </div>

      {/* Prompt */}
      <div className="px-5 py-4">
        <p className="text-sm text-muted-foreground leading-relaxed">
          How can I help you understand{" "}
          <span className="text-foreground font-medium">{player.name}'s</span>{" "}
          development?
        </p>
      </div>

      {/* Response area */}
      {(activeResponse || customResponse) && (
        <div
          className="mx-4 mb-4 p-4 rounded-xl text-sm leading-relaxed animate-slide-up"
          style={{
            background: "oklch(0.72 0.14 175 / 8%)",
            border: "1px solid oklch(0.72 0.14 175 / 20%)",
            color: "oklch(0.88 0.005 220)",
          }}
        >
          <div
            className="text-xs font-medium mb-2 flex items-center gap-1"
            style={{ color: "oklch(0.72 0.14 175)" }}
          >
            <Bot size={12} />
            DONNA
          </div>
          <p
            dangerouslySetInnerHTML={{
              __html: (activeResponse || customResponse || "").replace(
                /\*\*(.+?)\*\*/g,
                '<strong style="color: oklch(0.88 0.005 220)">$1</strong>'
              ),
            }}
          />
          {customResponse && (
            <p
              className="mt-2 text-xs italic"
              style={{ color: "oklch(0.58 0.01 220)" }}
            >
              Academy-approved response required before sending.
            </p>
          )}
        </div>
      )}

      {/* Quick actions */}
      <div className="px-4 flex-1 overflow-y-auto">
        <p
          className="text-xs font-medium mb-3 uppercase tracking-wider"
          style={{ color: "oklch(0.58 0.01 220)" }}
        >
          Quick Actions
        </p>
        <div className="flex flex-col gap-2">
          {donnaQuickActions.map((action) => (
            <button
              key={action}
              onClick={() => handleQuickAction(action)}
              className="w-full text-left px-3.5 py-2.5 rounded-lg text-sm transition-all duration-150 flex items-center justify-between group"
              style={{
                background:
                  activeResponse === donnaResponses[action]
                    ? "oklch(0.72 0.14 175 / 12%)"
                    : "oklch(1 0 0 / 4%)",
                border:
                  activeResponse === donnaResponses[action]
                    ? "1px solid oklch(0.72 0.14 175 / 30%)"
                    : "1px solid oklch(1 0 0 / 6%)",
                color: "oklch(0.85 0.005 220)",
              }}
            >
              <span>{action}</span>
              <ChevronRight
                size={14}
                className="opacity-40 group-hover:opacity-80 transition-opacity"
              />
            </button>
          ))}
        </div>
      </div>

      {/* Custom input */}
      <div className="p-4 border-t border-white/8 mt-4">
        <form onSubmit={handleCustomSubmit} className="flex gap-2">
          <input
            type="text"
            value={customInput}
            onChange={(e) => setCustomInput(e.target.value)}
            placeholder="Ask a question…"
            className="flex-1 px-3 py-2 rounded-lg text-sm outline-none transition-all"
            style={{
              background: "oklch(1 0 0 / 6%)",
              border: "1px solid oklch(1 0 0 / 10%)",
              color: "oklch(0.95 0.005 220)",
            }}
          />
          <button
            type="submit"
            className="btn-aqua px-3 py-2 rounded-lg text-sm font-medium"
          >
            Send
          </button>
        </form>
      </div>
    </div>
  );
}

interface PortalLayoutProps {
  children: React.ReactNode;
}

export default function PortalLayout({ children }: PortalLayoutProps) {
  const [location] = useLocation();
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [donnaOpen, setDonnaOpen] = useState(false);

  return (
    <div
      className="min-h-screen flex"
      style={{ background: "oklch(0.1 0.005 220)" }}
    >
      {/* Mobile sidebar overlay */}
      {sidebarOpen && (
        <div
          className="fixed inset-0 z-40 bg-black/60 lg:hidden"
          onClick={() => setSidebarOpen(false)}
        />
      )}

      {/* Sidebar */}
      <aside
        className={cn(
          "fixed top-0 left-0 h-full z-50 w-64 flex flex-col transition-transform duration-300 ease-out lg:translate-x-0 lg:static lg:z-auto",
          sidebarOpen ? "translate-x-0" : "-translate-x-full"
        )}
        style={{
          background: "oklch(0.12 0.006 220)",
          borderRight: "1px solid oklch(1 0 0 / 8%)",
        }}
      >
        {/* Logo */}
        <div className="px-5 pt-6 pb-5 border-b border-white/8">
          <div className="flex items-center justify-between">
            <div>
              <div className="flex items-center gap-2 mb-0.5">
                <div
                  className="w-6 h-6 rounded flex items-center justify-center"
                  style={{ background: "oklch(0.72 0.14 175)" }}
                >
                  <span
                    className="text-xs font-bold"
                    style={{ color: "oklch(0.08 0.005 220)" }}
                  >
                    A
                  </span>
                </div>
                <span
                  className="text-sm font-semibold tracking-tight"
                  style={{ fontFamily: "'Space Grotesk', sans-serif" }}
                >
                  AcademyOS
                </span>
              </div>
              <p className="text-xs" style={{ color: "oklch(0.58 0.01 220)" }}>
                Parent Portal
              </p>
            </div>
            <button
              onClick={() => setSidebarOpen(false)}
              className="lg:hidden p-1.5 rounded-lg hover:bg-white/5"
            >
              <X size={16} className="text-muted-foreground" />
            </button>
          </div>
        </div>

        {/* Player info */}
        <div className="px-4 py-4 border-b border-white/8">
          <div className="flex items-center gap-3">
            <div
              className="w-9 h-9 rounded-full flex items-center justify-center text-sm font-semibold"
              style={{
                background: "oklch(0.72 0.14 175 / 20%)",
                color: "oklch(0.72 0.14 175)",
                border: "1px solid oklch(0.72 0.14 175 / 30%)",
              }}
            >
              {player.name[0]}
            </div>
            <div>
              <p className="text-sm font-medium">{player.name}</p>
              <p
                className="text-xs"
                style={{ color: "oklch(0.58 0.01 220)" }}
              >
                Level {player.level}
              </p>
            </div>
          </div>
        </div>

        {/* Nav */}
        <nav className="flex-1 overflow-y-auto py-3 px-2">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = location === item.path;
            return (
              <Link key={item.path} href={item.path}>
                <div
                  onClick={() => setSidebarOpen(false)}
                  className={cn(
                    "flex items-center gap-3 px-3 py-2.5 rounded-lg mb-0.5 text-sm transition-all duration-150 group",
                    isActive
                      ? "text-foreground"
                      : "text-muted-foreground hover:text-foreground hover:bg-white/4"
                  )}
                  style={
                    isActive
                      ? {
                          background: "oklch(0.72 0.14 175 / 12%)",
                          borderLeft: "2px solid oklch(0.72 0.14 175)",
                          paddingLeft: "10px",
                        }
                      : {}
                  }
                >
                  <Icon
                    size={16}
                    style={
                      isActive ? { color: "oklch(0.72 0.14 175)" } : {}
                    }
                  />
                  <span className="text-xs font-medium leading-tight">
                    {item.label}
                  </span>
                </div>
              </Link>
            );
          })}
        </nav>

        {/* Footer */}
        <div className="p-4 border-t border-white/8">
          <p
            className="text-xs text-center"
            style={{ color: "oklch(0.45 0.008 220)" }}
          >
            Powered by AcademyOS
          </p>
        </div>
      </aside>

      {/* Main content */}
      <div className="flex-1 flex flex-col min-w-0">
        {/* Top bar (mobile) */}
        <header
          className="lg:hidden flex items-center justify-between px-4 py-3 border-b border-white/8 sticky top-0 z-30"
          style={{ background: "oklch(0.12 0.006 220)" }}
        >
          <button
            onClick={() => setSidebarOpen(true)}
            className="p-2 rounded-lg hover:bg-white/5"
          >
            <Menu size={20} className="text-foreground" />
          </button>
          <div className="flex items-center gap-2">
            <div
              className="w-5 h-5 rounded flex items-center justify-center"
              style={{ background: "oklch(0.72 0.14 175)" }}
            >
              <span
                className="text-xs font-bold"
                style={{ color: "oklch(0.08 0.005 220)" }}
              >
                A
              </span>
            </div>
            <span
              className="text-sm font-semibold"
              style={{ fontFamily: "'Space Grotesk', sans-serif" }}
            >
              AcademyOS
            </span>
          </div>
          <button
            onClick={() => setDonnaOpen(true)}
            className="p-2 rounded-lg"
            style={{
              background: "oklch(0.72 0.14 175 / 15%)",
              border: "1px solid oklch(0.72 0.14 175 / 30%)",
            }}
          >
            <Bot size={18} style={{ color: "oklch(0.72 0.14 175)" }} />
          </button>
        </header>

        {/* Page content */}
        <main className="flex-1 overflow-y-auto">{children}</main>
      </div>

      {/* DONNA panel — desktop */}
      <aside
        className="hidden lg:flex flex-col w-80 xl:w-96 h-screen sticky top-0 overflow-hidden"
        style={{
          background: "oklch(0.12 0.006 220)",
          borderLeft: "1px solid oklch(1 0 0 / 8%)",
        }}
      >
        <DonnaPanel />
      </aside>

      {/* DONNA bottom sheet — mobile */}
      {donnaOpen && (
        <>
          <div
            className="fixed inset-0 z-50 bg-black/60 lg:hidden"
            onClick={() => setDonnaOpen(false)}
          />
          <div
            className="fixed bottom-0 left-0 right-0 z-50 h-[80vh] lg:hidden animate-slide-up"
            style={{
              background: "oklch(0.12 0.006 220)",
              borderTop: "1px solid oklch(1 0 0 / 8%)",
              borderRadius: "1.25rem 1.25rem 0 0",
            }}
          >
            <DonnaPanel onClose={() => setDonnaOpen(false)} mobile />
          </div>
        </>
      )}
    </div>
  );
}
