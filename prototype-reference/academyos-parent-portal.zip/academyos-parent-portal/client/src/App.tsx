/*
 * AcademyOS Parent Portal — App Router
 * "Midnight Court" design: dark theme, all 10 screens wired
 */
import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/NotFound";
import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";

// All 10 screens
import Home from "./pages/Home";
import Snapshot from "./pages/Snapshot";
import SkillPath from "./pages/SkillPath";
import CompetitionPath from "./pages/CompetitionPath";
import FitnessPath from "./pages/FitnessPath";
import NextSteps from "./pages/NextSteps";
import RequestLesson from "./pages/RequestLesson";
import CoachSelection from "./pages/CoachSelection";
import Confirmation from "./pages/Confirmation";
import Message from "./pages/Message";

function Router() {
  return (
    <Switch>
      <Route path="/" component={Home} />
      <Route path="/snapshot" component={Snapshot} />
      <Route path="/skill-path" component={SkillPath} />
      <Route path="/competition-path" component={CompetitionPath} />
      <Route path="/fitness-path" component={FitnessPath} />
      <Route path="/next-steps" component={NextSteps} />
      <Route path="/request-lesson" component={RequestLesson} />
      <Route path="/coach-selection" component={CoachSelection} />
      <Route path="/confirmation" component={Confirmation} />
      <Route path="/message" component={Message} />
      <Route path="/404" component={NotFound} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider defaultTheme="dark">
        <TooltipProvider>
          <Toaster />
          <Router />
        </TooltipProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;
