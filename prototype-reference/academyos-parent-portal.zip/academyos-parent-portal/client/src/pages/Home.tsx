/*
 * AcademyOS Parent Portal — Screen 1: Home
 * "Midnight Court" design: hero snapshot card + path cards grid + DONNA CTA
 */
import { Link } from "wouter";
import PortalLayout from "@/components/PortalLayout";
import {
  User,
  Zap,
  Trophy,
  Activity,
  ArrowRight,
  Calendar,
  MessageSquare,
  ChevronRight,
  CheckCircle,
  TrendingUp,
} from "lucide-react";
import { player } from "@/lib/data";

const pathCards = [
  {
    path: "/skill-path",
    icon: Zap,
    label: "Skill Path",
    description: "Technical focus & practice guidance",
    color: "oklch(0.72 0.14 175)",
    bg: "oklch(0.72 0.14 175 / 10%)",
  },
  {
    path: "/competition-path",
    icon: Trophy,
    label: "Competition Path",
    description: "Tactical development & match readiness",
    color: "oklch(0.72 0.16 60)",
    bg: "oklch(0.72 0.16 60 / 10%)",
  },
  {
    path: "/fitness-path",
    icon: Activity,
    label: "Fitness Path",
    description: "Movement, mobility & at-home support",
    color: "oklch(0.65 0.18 300)",
    bg: "oklch(0.65 0.18 300 / 10%)",
  },
  {
    path: "/next-steps",
    icon: ArrowRight,
    label: "Next Steps",
    description: "How to support this month",
    color: "oklch(0.70 0.16 240)",
    bg: "oklch(0.70 0.16 240 / 10%)",
  },
];

const actionCards = [
  {
    path: "/request-lesson",
    icon: Calendar,
    label: "Request Private Lesson",
    cta: "Book now",
    accent: "oklch(0.72 0.14 175)",
  },
  {
    path: "/message",
    icon: MessageSquare,
    label: "Message the Academy",
    cta: "Send message",
    accent: "oklch(0.70 0.16 240)",
  },
];

export default function Home() {
  return (
    <PortalLayout>
      <div className="p-5 lg:p-8 max-w-3xl mx-auto">
        {/* Page header */}
        <div className="mb-8 animate-slide-up">
          <p
            className="text-xs font-medium uppercase tracking-widest mb-2"
            style={{ color: "oklch(0.72 0.14 175)" }}
          >
            Parent Portal
          </p>
          <h1
            className="text-2xl lg:text-3xl font-bold mb-2"
            style={{ fontFamily: "'Space Grotesk', sans-serif" }}
          >
            Welcome back
          </h1>
          <p className="text-sm text-muted-foreground leading-relaxed max-w-lg">
            See what {player.name} is working on, why it matters, and how to
            support their development.
          </p>
        </div>

        {/* Child Development Snapshot card */}
        <Link href="/snapshot">
          <div
            className="aos-card p-5 mb-6 cursor-pointer animate-slide-up delay-1"
            style={{
              background:
                "linear-gradient(135deg, oklch(0.14 0.007 220) 0%, oklch(0.16 0.012 175) 100%)",
              borderLeft: "3px solid oklch(0.72 0.14 175)",
            }}
          >
            <div className="flex items-start justify-between mb-4">
              <div className="flex items-center gap-2.5">
                <div
                  className="w-9 h-9 rounded-full flex items-center justify-center text-sm font-bold"
                  style={{
                    background: "oklch(0.72 0.14 175 / 20%)",
                    color: "oklch(0.72 0.14 175)",
                    border: "1px solid oklch(0.72 0.14 175 / 30%)",
                  }}
                >
                  {player.name[0]}
                </div>
                <div>
                  <p className="text-sm font-semibold">{player.name}</p>
                  <div className="aos-badge mt-0.5">Level {player.level}</div>
                </div>
              </div>
              <div className="flex items-center gap-1 text-xs text-muted-foreground">
                <span>View snapshot</span>
                <ChevronRight size={14} />
              </div>
            </div>

            {/* Progress bar */}
            <div className="mb-4">
              <div className="flex justify-between text-xs mb-1.5">
                <span className="text-muted-foreground">
                  Progress to {player.nextLevel}
                </span>
                <span style={{ color: "oklch(0.72 0.14 175)" }}>
                  On track
                </span>
              </div>
              <div className="aos-progress-track">
                <div className="aos-progress-fill" style={{ width: "62%" }} />
              </div>
            </div>

            {/* Summary */}
            <p className="text-sm text-muted-foreground leading-relaxed mb-4">
              {player.coachApprovedSummary}
            </p>

            {/* Stats row */}
            <div className="grid grid-cols-3 gap-3">
              {[
                { label: "Current Focus", value: "Forehand prep" },
                { label: "Attendance", value: player.attendanceRate },
                { label: "Sessions", value: `${player.sessionsThisMonth} this month` },
              ].map((stat) => (
                <div
                  key={stat.label}
                  className="rounded-lg p-2.5 text-center"
                  style={{ background: "oklch(1 0 0 / 5%)" }}
                >
                  <p className="text-xs text-muted-foreground mb-0.5">
                    {stat.label}
                  </p>
                  <p className="text-xs font-semibold">{stat.value}</p>
                </div>
              ))}
            </div>

            {/* Recommended action */}
            <div
              className="mt-4 flex items-center gap-2 px-3 py-2.5 rounded-lg"
              style={{
                background: "oklch(0.72 0.14 175 / 8%)",
                border: "1px solid oklch(0.72 0.14 175 / 20%)",
              }}
            >
              <TrendingUp
                size={14}
                style={{ color: "oklch(0.72 0.14 175)" }}
              />
              <p className="text-xs" style={{ color: "oklch(0.85 0.005 220)" }}>
                <span
                  className="font-medium"
                  style={{ color: "oklch(0.72 0.14 175)" }}
                >
                  Recommended:{" "}
                </span>
                {player.nextRecommendedAction}
              </p>
            </div>
          </div>
        </Link>

        {/* Path cards */}
        <div className="mb-6 animate-slide-up delay-2">
          <h2
            className="text-sm font-semibold mb-3 uppercase tracking-wider text-muted-foreground"
            style={{ fontFamily: "'Space Grotesk', sans-serif" }}
          >
            Development Paths
          </h2>
          <div className="grid grid-cols-2 gap-3">
            {pathCards.map((card) => {
              const Icon = card.icon;
              return (
                <Link key={card.path} href={card.path}>
                  <div
                    className="aos-card p-4 cursor-pointer group"
                    style={{ background: card.bg }}
                  >
                    <div
                      className="w-8 h-8 rounded-lg flex items-center justify-center mb-3"
                      style={{
                        background: `${card.color.replace(")", " / 20%)")}`,
                      }}
                    >
                      <Icon size={16} style={{ color: card.color }} />
                    </div>
                    <p
                      className="text-sm font-semibold mb-0.5"
                      style={{ fontFamily: "'Space Grotesk', sans-serif" }}
                    >
                      {card.label}
                    </p>
                    <p
                      className="text-xs leading-snug"
                      style={{ color: "oklch(0.58 0.01 220)" }}
                    >
                      {card.description}
                    </p>
                    <div className="flex items-center gap-1 mt-3 text-xs font-medium group-hover:gap-2 transition-all">
                      <span style={{ color: card.color }}>View</span>
                      <ChevronRight size={12} style={{ color: card.color }} />
                    </div>
                  </div>
                </Link>
              );
            })}
          </div>
        </div>

        {/* Action cards */}
        <div className="animate-slide-up delay-3">
          <h2
            className="text-sm font-semibold mb-3 uppercase tracking-wider text-muted-foreground"
            style={{ fontFamily: "'Space Grotesk', sans-serif" }}
          >
            Actions
          </h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {actionCards.map((card) => {
              const Icon = card.icon;
              return (
                <Link key={card.path} href={card.path}>
                  <div className="aos-card p-4 cursor-pointer flex items-center justify-between group">
                    <div className="flex items-center gap-3">
                      <div
                        className="w-9 h-9 rounded-xl flex items-center justify-center"
                        style={{
                          background: `${card.accent.replace(")", " / 15%)")}`,
                          border: `1px solid ${card.accent.replace(")", " / 25%)")}`,
                        }}
                      >
                        <Icon size={16} style={{ color: card.accent }} />
                      </div>
                      <p className="text-sm font-medium">{card.label}</p>
                    </div>
                    <div
                      className="flex items-center gap-1 text-xs font-semibold px-3 py-1.5 rounded-full transition-all"
                      style={{
                        background: `${card.accent.replace(")", " / 15%)")}`,
                        color: card.accent,
                      }}
                    >
                      {card.cta}
                      <ChevronRight size={12} />
                    </div>
                  </div>
                </Link>
              );
            })}
          </div>
        </div>

        {/* Coach-approved note */}
        <div
          className="mt-6 flex items-start gap-2.5 p-4 rounded-xl animate-slide-up delay-4"
          style={{
            background: "oklch(0.14 0.007 220)",
            border: "1px solid oklch(1 0 0 / 6%)",
          }}
        >
          <CheckCircle
            size={16}
            className="mt-0.5 shrink-0"
            style={{ color: "oklch(0.72 0.14 175)" }}
          />
          <p className="text-xs text-muted-foreground leading-relaxed">
            All information in this portal has been reviewed and approved by{" "}
            {player.name}'s coaching team. Last updated: {player.lastAssessment}.
          </p>
        </div>
      </div>
    </PortalLayout>
  );
}
