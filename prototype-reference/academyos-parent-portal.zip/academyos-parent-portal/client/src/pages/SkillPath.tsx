/*
 * AcademyOS Parent Portal — Screen 3: Skill Path View
 * "Midnight Court" design: technical focus, why it matters, parent guidance
 */
import { Link } from "wouter";
import PortalLayout from "@/components/PortalLayout";
import {
  ChevronLeft,
  Zap,
  Eye,
  Heart,
  BookOpen,
  Home,
  ChevronRight,
} from "lucide-react";
import { skillPath, player } from "@/lib/data";

export default function SkillPath() {
  return (
    <PortalLayout>
      <div className="p-5 lg:p-8 max-w-3xl mx-auto">
        <Link href="/">
          <div className="flex items-center gap-1.5 text-sm text-muted-foreground mb-6 hover:text-foreground transition-colors cursor-pointer w-fit">
            <ChevronLeft size={16} />
            Back to Home
          </div>
        </Link>

        <div className="mb-6 animate-slide-up">
          <div className="flex items-center gap-2 mb-1">
            <Zap size={16} style={{ color: "oklch(0.72 0.14 175)" }} />
            <p
              className="text-xs font-medium uppercase tracking-widest"
              style={{ color: "oklch(0.72 0.14 175)" }}
            >
              Skill Path
            </p>
          </div>
          <h1
            className="text-2xl font-bold"
            style={{ fontFamily: "'Space Grotesk', sans-serif" }}
          >
            Technical Development
          </h1>
          <p className="text-sm text-muted-foreground mt-1">
            What {player.name} is working on technically and how you can help.
          </p>
        </div>

        {/* Current focus */}
        <div
          className="rounded-2xl p-5 mb-4 animate-slide-up delay-1"
          style={{
            background:
              "linear-gradient(135deg, oklch(0.14 0.007 220) 0%, oklch(0.16 0.014 175) 100%)",
            borderLeft: "3px solid oklch(0.72 0.14 175)",
          }}
        >
          <p className="text-xs text-muted-foreground uppercase tracking-wider mb-1">
            Current Skill Focus
          </p>
          <p
            className="text-xl font-bold mb-3"
            style={{
              fontFamily: "'Space Grotesk', sans-serif",
              color: "oklch(0.72 0.14 175)",
            }}
          >
            {skillPath.currentFocus}
          </p>
          <p className="text-sm text-muted-foreground leading-relaxed">
            {skillPath.whatImproving}
          </p>
        </div>

        {/* Info cards */}
        {[
          {
            icon: Heart,
            color: "oklch(0.65 0.18 340)",
            bg: "oklch(0.65 0.18 340 / 8%)",
            border: "oklch(0.65 0.18 340 / 20%)",
            title: "Why It Matters",
            content: skillPath.whyItMatters,
          },
          {
            icon: BookOpen,
            color: "oklch(0.70 0.16 240)",
            bg: "oklch(0.70 0.16 240 / 8%)",
            border: "oklch(0.70 0.16 240 / 20%)",
            title: "Evidence Collected",
            content: skillPath.evidenceCollected,
          },
          {
            icon: Home,
            color: "oklch(0.72 0.16 60)",
            bg: "oklch(0.72 0.16 60 / 8%)",
            border: "oklch(0.72 0.16 60 / 20%)",
            title: "Practice Recommendation",
            content: skillPath.practiceRecommendation,
          },
          {
            icon: Eye,
            color: "oklch(0.65 0.18 300)",
            bg: "oklch(0.65 0.18 300 / 8%)",
            border: "oklch(0.65 0.18 300 / 20%)",
            title: "What Parents Should Notice",
            content: skillPath.whatParentsShouldNotice,
          },
        ].map((card, i) => {
          const Icon = card.icon;
          return (
            <div
              key={card.title}
              className={`rounded-xl p-4 mb-4 animate-slide-up delay-${i + 2}`}
              style={{
                background: card.bg,
                border: `1px solid ${card.border}`,
              }}
            >
              <div className="flex items-center gap-2 mb-2">
                <Icon size={14} style={{ color: card.color }} />
                <p
                  className="text-xs font-semibold uppercase tracking-wider"
                  style={{ color: card.color }}
                >
                  {card.title}
                </p>
              </div>
              <p className="text-sm leading-relaxed">{card.content}</p>
            </div>
          );
        })}

        {/* Navigation */}
        <div className="flex gap-3 mt-2 animate-slide-up delay-6">
          <Link href="/competition-path" className="flex-1">
            <button
              className="w-full py-3 rounded-xl text-sm font-medium flex items-center justify-center gap-2 transition-all"
              style={{
                background: "oklch(1 0 0 / 6%)",
                border: "1px solid oklch(1 0 0 / 10%)",
                color: "oklch(0.85 0.005 220)",
              }}
            >
              Competition Path
              <ChevronRight size={14} />
            </button>
          </Link>
          <Link href="/request-lesson" className="flex-1">
            <button className="btn-aqua w-full py-3 rounded-xl text-sm font-semibold">
              Request Lesson
            </button>
          </Link>
        </div>
      </div>
    </PortalLayout>
  );
}
