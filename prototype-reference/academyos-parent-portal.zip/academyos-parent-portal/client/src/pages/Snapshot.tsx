/*
 * AcademyOS Parent Portal — Screen 2: Child Development Snapshot
 * "Midnight Court" design: level progress, priorities, coach-approved note
 */
import { Link } from "wouter";
import PortalLayout from "@/components/PortalLayout";
import {
  ChevronLeft,
  CheckCircle,
  Target,
  Calendar,
  TrendingUp,
  Star,
} from "lucide-react";
import { player } from "@/lib/data";

export default function Snapshot() {
  return (
    <PortalLayout>
      <div className="p-5 lg:p-8 max-w-3xl mx-auto">
        {/* Back */}
        <Link href="/">
          <div className="flex items-center gap-1.5 text-sm text-muted-foreground mb-6 hover:text-foreground transition-colors cursor-pointer w-fit">
            <ChevronLeft size={16} />
            Back to Home
          </div>
        </Link>

        {/* Header */}
        <div className="mb-6 animate-slide-up">
          <p
            className="text-xs font-medium uppercase tracking-widest mb-1"
            style={{ color: "oklch(0.72 0.14 175)" }}
          >
            Development Snapshot
          </p>
          <h1
            className="text-2xl font-bold"
            style={{ fontFamily: "'Space Grotesk', sans-serif" }}
          >
            {player.name}'s Progress
          </h1>
        </div>

        {/* Level card */}
        <div
          className="rounded-2xl p-5 mb-5 animate-slide-up delay-1"
          style={{
            background:
              "linear-gradient(135deg, oklch(0.14 0.007 220) 0%, oklch(0.16 0.014 175) 100%)",
            border: "1px solid oklch(0.72 0.14 175 / 20%)",
          }}
        >
          <div className="flex items-center justify-between mb-4">
            <div>
              <p
                className="text-xs text-muted-foreground mb-1 uppercase tracking-wider"
              >
                Current Level
              </p>
              <p
                className="text-2xl font-bold"
                style={{
                  fontFamily: "'Space Grotesk', sans-serif",
                  color: "oklch(0.72 0.14 175)",
                }}
              >
                {player.level}
              </p>
            </div>
            <div className="text-right">
              <p className="text-xs text-muted-foreground mb-1 uppercase tracking-wider">
                Next Level
              </p>
              <p
                className="text-2xl font-bold"
                style={{ fontFamily: "'Space Grotesk', sans-serif" }}
              >
                {player.nextLevel}
              </p>
            </div>
          </div>

          {/* Progress bar */}
          <div className="mb-2">
            <div className="flex justify-between text-xs mb-2">
              <span className="text-muted-foreground">Development progress</span>
              <span style={{ color: "oklch(0.72 0.14 175)" }}>62%</span>
            </div>
            <div className="aos-progress-track" style={{ height: "8px" }}>
              <div
                className="aos-progress-fill"
                style={{
                  width: "62%",
                  height: "8px",
                  boxShadow: "0 0 12px oklch(0.72 0.14 175 / 50%)",
                }}
              />
            </div>
          </div>
          <p className="text-xs text-muted-foreground">
            {player.name} is making steady progress toward {player.nextLevel}.
          </p>
        </div>

        {/* Priorities */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-5 animate-slide-up delay-2">
          <div
            className="rounded-xl p-4"
            style={{
              background: "oklch(0.72 0.14 175 / 8%)",
              border: "1px solid oklch(0.72 0.14 175 / 20%)",
            }}
          >
            <div className="flex items-center gap-2 mb-2">
              <Target size={14} style={{ color: "oklch(0.72 0.14 175)" }} />
              <p
                className="text-xs font-semibold uppercase tracking-wider"
                style={{ color: "oklch(0.72 0.14 175)" }}
              >
                Main Priority
              </p>
            </div>
            <p className="text-sm font-medium">{player.mainPriority}</p>
          </div>
          <div
            className="rounded-xl p-4"
            style={{
              background: "oklch(0.70 0.16 240 / 8%)",
              border: "1px solid oklch(0.70 0.16 240 / 20%)",
            }}
          >
            <div className="flex items-center gap-2 mb-2">
              <TrendingUp
                size={14}
                style={{ color: "oklch(0.70 0.16 240)" }}
              />
              <p
                className="text-xs font-semibold uppercase tracking-wider"
                style={{ color: "oklch(0.70 0.16 240)" }}
              >
                Secondary Priority
              </p>
            </div>
            <p className="text-sm font-medium">{player.secondaryPriority}</p>
          </div>
        </div>

        {/* Evidence summary */}
        <div
          className="rounded-xl p-4 mb-4 animate-slide-up delay-3"
          style={{
            background: "oklch(0.14 0.007 220)",
            border: "1px solid oklch(1 0 0 / 8%)",
          }}
        >
          <p
            className="text-xs font-semibold uppercase tracking-wider mb-2 text-muted-foreground"
          >
            Evidence Summary
          </p>
          <p className="text-sm leading-relaxed">{player.evidenceSummary}</p>
        </div>

        {/* Coach-approved progress note */}
        <div
          className="rounded-xl p-4 mb-4 animate-slide-up delay-3"
          style={{
            background: "oklch(0.14 0.007 220)",
            border: "1px solid oklch(1 0 0 / 8%)",
          }}
        >
          <div className="flex items-center gap-2 mb-2">
            <CheckCircle
              size={14}
              style={{ color: "oklch(0.72 0.14 175)" }}
            />
            <p
              className="text-xs font-semibold uppercase tracking-wider"
              style={{ color: "oklch(0.72 0.14 175)" }}
            >
              Coach-Approved Progress Note
            </p>
          </div>
          <p className="text-sm leading-relaxed text-muted-foreground">
            {player.progressNote}
          </p>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-3 gap-3 mb-5 animate-slide-up delay-4">
          {[
            {
              icon: Calendar,
              label: "Last Assessment",
              value: player.lastAssessment,
              color: "oklch(0.72 0.14 175)",
            },
            {
              icon: Star,
              label: "Attendance",
              value: player.attendanceRate,
              color: "oklch(0.72 0.16 60)",
            },
            {
              icon: TrendingUp,
              label: "Sessions",
              value: `${player.sessionsThisMonth} this month`,
              color: "oklch(0.65 0.18 300)",
            },
          ].map((stat) => {
            const Icon = stat.icon;
            return (
              <div
                key={stat.label}
                className="rounded-xl p-3 text-center"
                style={{
                  background: "oklch(0.14 0.007 220)",
                  border: "1px solid oklch(1 0 0 / 8%)",
                }}
              >
                <Icon
                  size={16}
                  className="mx-auto mb-1.5"
                  style={{ color: stat.color }}
                />
                <p className="text-xs text-muted-foreground mb-0.5">
                  {stat.label}
                </p>
                <p className="text-xs font-semibold">{stat.value}</p>
              </div>
            );
          })}
        </div>

        {/* CTA */}
        <Link href="/request-lesson">
          <button className="btn-aqua w-full py-3 rounded-xl text-sm font-semibold animate-slide-up delay-5">
            Request a Private Lesson
          </button>
        </Link>
      </div>
    </PortalLayout>
  );
}
