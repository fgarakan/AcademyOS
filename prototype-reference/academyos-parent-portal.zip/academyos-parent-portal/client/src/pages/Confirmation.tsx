/*
 * AcademyOS Parent Portal — Screen 9: Request Confirmation
 * "Midnight Court" design: clear summary, no auto-booking language, calm status
 */
import { Link } from "wouter";
import PortalLayout from "@/components/PortalLayout";
import { CheckCircle, Clock, Home, MessageSquare } from "lucide-react";
import { player, coaches } from "@/lib/data";

export default function Confirmation() {
  const coach = coaches.find((c) => c.id === "farshad") || coaches[1];

  return (
    <PortalLayout>
      <div className="p-5 lg:p-8 max-w-2xl mx-auto">
        {/* Success header */}
        <div className="text-center mb-8 animate-slide-up">
          <div
            className="w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4"
            style={{
              background: "oklch(0.72 0.14 175 / 15%)",
              border: "2px solid oklch(0.72 0.14 175 / 40%)",
              boxShadow: "0 0 32px oklch(0.72 0.14 175 / 20%)",
            }}
          >
            <CheckCircle
              size={28}
              style={{ color: "oklch(0.72 0.14 175)" }}
            />
          </div>
          <h1
            className="text-2xl font-bold mb-2"
            style={{ fontFamily: "'Space Grotesk', sans-serif" }}
          >
            Request Submitted
          </h1>
          <p className="text-sm text-muted-foreground max-w-sm mx-auto leading-relaxed">
            Your private lesson request has been sent to the academy for review.
            You'll hear back within 1–2 business days.
          </p>
        </div>

        {/* Status badge */}
        <div
          className="flex items-center justify-center gap-2 px-4 py-2.5 rounded-full mx-auto w-fit mb-8 animate-slide-up delay-1"
          style={{
            background: "oklch(0.72 0.16 60 / 12%)",
            border: "1px solid oklch(0.72 0.16 60 / 30%)",
            color: "oklch(0.72 0.16 60)",
          }}
        >
          <Clock size={14} />
          <span className="text-sm font-medium">
            Request sent for academy review
          </span>
        </div>

        {/* Summary card */}
        <div
          className="rounded-2xl p-5 mb-5 animate-slide-up delay-2"
          style={{
            background: "oklch(0.14 0.007 220)",
            border: "1px solid oklch(1 0 0 / 8%)",
          }}
        >
          <p
            className="text-xs font-semibold uppercase tracking-wider mb-4 text-muted-foreground"
          >
            Request Summary
          </p>

          {[
            { label: "Player", value: player.name },
            { label: "Coach Requested", value: coach.name },
            { label: "Coach Role", value: coach.role },
            {
              label: "Development Focus",
              value: player.currentFocus,
            },
            { label: "Lesson Type", value: "Technical" },
            { label: "Preferred Day", value: "Any day" },
            { label: "Preferred Time", value: "Any time" },
          ].map((row) => (
            <div
              key={row.label}
              className="flex items-start justify-between py-2.5 border-b last:border-0"
              style={{ borderColor: "oklch(1 0 0 / 6%)" }}
            >
              <span
                className="text-xs"
                style={{ color: "oklch(0.58 0.01 220)" }}
              >
                {row.label}
              </span>
              <span className="text-xs font-medium text-right max-w-[55%]">
                {row.value}
              </span>
            </div>
          ))}
        </div>

        {/* Important note */}
        <div
          className="rounded-xl p-4 mb-6 flex items-start gap-2.5 animate-slide-up delay-3"
          style={{
            background: "oklch(0.72 0.16 60 / 8%)",
            border: "1px solid oklch(0.72 0.16 60 / 20%)",
          }}
        >
          <Clock
            size={14}
            className="shrink-0 mt-0.5"
            style={{ color: "oklch(0.72 0.16 60)" }}
          />
          <p className="text-xs leading-relaxed" style={{ color: "oklch(0.85 0.005 220)" }}>
            <span
              className="font-semibold"
              style={{ color: "oklch(0.72 0.16 60)" }}
            >
              Please note:{" "}
            </span>
            This is a request, not a confirmed booking. The academy team will
            review availability and contact you to confirm the lesson details.
          </p>
        </div>

        {/* Actions */}
        <div className="flex flex-col gap-3 animate-slide-up delay-4">
          <Link href="/message">
            <button
              className="w-full py-3 rounded-xl text-sm font-medium flex items-center justify-center gap-2 transition-all"
              style={{
                background: "oklch(1 0 0 / 6%)",
                border: "1px solid oklch(1 0 0 / 10%)",
                color: "oklch(0.85 0.005 220)",
              }}
            >
              <MessageSquare size={14} />
              Send a Message to the Academy
            </button>
          </Link>
          <Link href="/">
            <button className="btn-aqua w-full py-3 rounded-xl text-sm font-semibold flex items-center justify-center gap-2">
              <Home size={14} />
              Back to Home
            </button>
          </Link>
        </div>
      </div>
    </PortalLayout>
  );
}
