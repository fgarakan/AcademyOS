/*
 * AcademyOS Parent Portal — Screen 7: Private Lesson Request
 * "Midnight Court" design: clean form, pre-filled from player data, easy CTA
 */
import { useState } from "react";
import { Link, useLocation } from "wouter";
import PortalLayout from "@/components/PortalLayout";
import { ChevronLeft, Calendar, ChevronDown } from "lucide-react";
import { player, lessonTypes, coaches } from "@/lib/data";

export default function RequestLesson() {
  const [, navigate] = useLocation();
  const [form, setForm] = useState({
    player: player.name,
    developmentFocus: player.currentFocus,
    preferredCoach: "",
    preferredDay: "",
    preferredTime: "",
    lessonType: "",
    notes: "",
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    navigate("/coach-selection");
  };

  const inputStyle = {
    background: "oklch(1 0 0 / 6%)",
    border: "1px solid oklch(1 0 0 / 10%)",
    color: "oklch(0.95 0.005 220)",
    borderRadius: "0.625rem",
    padding: "0.625rem 0.875rem",
    fontSize: "0.875rem",
    outline: "none",
    width: "100%",
    transition: "border-color 150ms",
  };

  const labelStyle = {
    display: "block",
    fontSize: "0.75rem",
    fontWeight: 500,
    color: "oklch(0.58 0.01 220)",
    marginBottom: "0.375rem",
    textTransform: "uppercase" as const,
    letterSpacing: "0.05em",
  };

  return (
    <PortalLayout>
      <div className="p-5 lg:p-8 max-w-2xl mx-auto">
        <Link href="/">
          <div className="flex items-center gap-1.5 text-sm text-muted-foreground mb-6 hover:text-foreground transition-colors cursor-pointer w-fit">
            <ChevronLeft size={16} />
            Back to Home
          </div>
        </Link>

        <div className="mb-6 animate-slide-up">
          <div className="flex items-center gap-2 mb-1">
            <Calendar size={16} style={{ color: "oklch(0.72 0.14 175)" }} />
            <p
              className="text-xs font-medium uppercase tracking-widest"
              style={{ color: "oklch(0.72 0.14 175)" }}
            >
              Private Lesson Request
            </p>
          </div>
          <h1
            className="text-2xl font-bold"
            style={{ fontFamily: "'Space Grotesk', sans-serif" }}
          >
            Request a Private Lesson
          </h1>
          <p className="text-sm text-muted-foreground mt-1">
            Tell us what you want help with. AcademyOS will suggest the best
            coach options.
          </p>
        </div>

        <form onSubmit={handleSubmit}>
          <div
            className="rounded-2xl p-5 mb-4 animate-slide-up delay-1"
            style={{
              background: "oklch(0.14 0.007 220)",
              border: "1px solid oklch(1 0 0 / 8%)",
            }}
          >
            {/* Player */}
            <div className="mb-4">
              <label style={labelStyle}>Player</label>
              <input
                type="text"
                value={form.player}
                readOnly
                style={{ ...inputStyle, opacity: 0.7 }}
              />
            </div>

            {/* Development focus (pre-filled) */}
            <div className="mb-4">
              <label style={labelStyle}>Development Focus</label>
              <div className="relative">
                <textarea
                  value={form.developmentFocus}
                  onChange={(e) =>
                    setForm({ ...form, developmentFocus: e.target.value })
                  }
                  rows={2}
                  style={{ ...inputStyle, resize: "none" }}
                  placeholder="What would you like to focus on?"
                />
              </div>
              <p
                className="text-xs mt-1"
                style={{ color: "oklch(0.58 0.01 220)" }}
              >
                Pre-filled from {player.name}'s current development priorities.
              </p>
            </div>

            {/* Lesson type */}
            <div className="mb-4">
              <label style={labelStyle}>Lesson Type</label>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                {lessonTypes.map((type) => (
                  <button
                    key={type}
                    type="button"
                    onClick={() => setForm({ ...form, lessonType: type })}
                    className="px-3 py-2 rounded-lg text-xs font-medium text-left transition-all"
                    style={
                      form.lessonType === type
                        ? {
                            background: "oklch(0.72 0.14 175 / 15%)",
                            border: "1px solid oklch(0.72 0.14 175 / 40%)",
                            color: "oklch(0.72 0.14 175)",
                          }
                        : {
                            background: "oklch(1 0 0 / 4%)",
                            border: "1px solid oklch(1 0 0 / 8%)",
                            color: "oklch(0.75 0.005 220)",
                          }
                    }
                  >
                    {type}
                  </button>
                ))}
              </div>
            </div>

            {/* Preferred coach */}
            <div className="mb-4">
              <label style={labelStyle}>Preferred Coach (optional)</label>
              <div className="relative">
                <select
                  value={form.preferredCoach}
                  onChange={(e) =>
                    setForm({ ...form, preferredCoach: e.target.value })
                  }
                  style={{
                    ...inputStyle,
                    appearance: "none",
                    paddingRight: "2.5rem",
                  }}
                >
                  <option value="">No preference — let AcademyOS suggest</option>
                  {coaches.map((c) => (
                    <option key={c.id} value={c.id}>
                      {c.name} — {c.specialty}
                    </option>
                  ))}
                </select>
                <ChevronDown
                  size={14}
                  className="absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none"
                  style={{ color: "oklch(0.58 0.01 220)" }}
                />
              </div>
            </div>

            {/* Day / time */}
            <div className="grid grid-cols-2 gap-3 mb-4">
              <div>
                <label style={labelStyle}>Preferred Day</label>
                <div className="relative">
                  <select
                    value={form.preferredDay}
                    onChange={(e) =>
                      setForm({ ...form, preferredDay: e.target.value })
                    }
                    style={{
                      ...inputStyle,
                      appearance: "none",
                      paddingRight: "2.5rem",
                    }}
                  >
                    <option value="">Any day</option>
                    {[
                      "Monday",
                      "Tuesday",
                      "Wednesday",
                      "Thursday",
                      "Friday",
                      "Saturday",
                      "Sunday",
                    ].map((d) => (
                      <option key={d} value={d}>
                        {d}
                      </option>
                    ))}
                  </select>
                  <ChevronDown
                    size={14}
                    className="absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none"
                    style={{ color: "oklch(0.58 0.01 220)" }}
                  />
                </div>
              </div>
              <div>
                <label style={labelStyle}>Preferred Time</label>
                <div className="relative">
                  <select
                    value={form.preferredTime}
                    onChange={(e) =>
                      setForm({ ...form, preferredTime: e.target.value })
                    }
                    style={{
                      ...inputStyle,
                      appearance: "none",
                      paddingRight: "2.5rem",
                    }}
                  >
                    <option value="">Any time</option>
                    {[
                      "Morning (8am–12pm)",
                      "Afternoon (12pm–4pm)",
                      "Evening (4pm–7pm)",
                    ].map((t) => (
                      <option key={t} value={t}>
                        {t}
                      </option>
                    ))}
                  </select>
                  <ChevronDown
                    size={14}
                    className="absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none"
                    style={{ color: "oklch(0.58 0.01 220)" }}
                  />
                </div>
              </div>
            </div>

            {/* Notes */}
            <div>
              <label style={labelStyle}>Notes for Academy (optional)</label>
              <textarea
                value={form.notes}
                onChange={(e) => setForm({ ...form, notes: e.target.value })}
                rows={3}
                placeholder="Any additional context for the coaching team…"
                style={{ ...inputStyle, resize: "none" }}
              />
            </div>
          </div>

          <button
            type="submit"
            className="btn-aqua w-full py-3.5 rounded-xl text-sm font-semibold animate-slide-up delay-2"
          >
            View Coach Options
          </button>
        </form>
      </div>
    </PortalLayout>
  );
}
