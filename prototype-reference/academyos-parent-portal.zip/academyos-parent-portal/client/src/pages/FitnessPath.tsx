/*
 * AcademyOS Parent Portal — Screen 5: Fitness Path View
 * "Midnight Court" design: movement focus, at-home support, readiness note
 */
import { Link } from "wouter";
import PortalLayout from "@/components/PortalLayout";
import {
  ChevronLeft,
  Activity,
  Zap,
  ArrowRight as Transfer,
  Home,
  Battery,
  ChevronRight,
} from "lucide-react";
import { fitnessPath, player } from "@/lib/data";

export default function FitnessPath() {
  return (
    <PortalLayout>
      <div className="p-5 lg:p-8 max-w-3xl mx-auto">
        <Link href="/">
          <div className="flex items-center gap-1.5 text-sm text-muted-foreground mb-6 hover:text-foreground transition-colors cursor-pointer w-fit">
            <ChevronLeft size={16} />
            Back to Home
          </div>
        </Link>

        <div className="mb-6 animate-slide-up">
          <div className="flex items-center gap-2 mb-1">
            <Activity size={16} style={{ color: "oklch(0.65 0.18 300)" }} />
            <p
              className="text-xs font-medium uppercase tracking-widest"
              style={{ color: "oklch(0.65 0.18 300)" }}
            >
              Fitness Path
            </p>
          </div>
          <h1
            className="text-2xl font-bold"
            style={{ fontFamily: "'Space Grotesk', sans-serif" }}
          >
            Movement & Fitness
          </h1>
          <p className="text-sm text-muted-foreground mt-1">
            How {player.name} is developing physically and how you can support.
          </p>
        </div>

        {/* Movement focus */}
        <div
          className="rounded-2xl p-5 mb-4 animate-slide-up delay-1"
          style={{
            background:
              "linear-gradient(135deg, oklch(0.14 0.007 220) 0%, oklch(0.16 0.014 300) 100%)",
            borderLeft: "3px solid oklch(0.65 0.18 300)",
          }}
        >
          <p className="text-xs text-muted-foreground uppercase tracking-wider mb-1">
            Current Movement Focus
          </p>
          <p
            className="text-xl font-bold mb-3"
            style={{
              fontFamily: "'Space Grotesk', sans-serif",
              color: "oklch(0.65 0.18 300)",
            }}
          >
            {fitnessPath.movementFocus}
          </p>
          <p className="text-sm text-muted-foreground leading-relaxed italic">
            "Current movement focus: recovering to balance after wide balls."
          </p>
        </div>

        {/* Info cards */}
        {[
          {
            icon: Zap,
            color: "oklch(0.65 0.18 300)",
            bg: "oklch(0.65 0.18 300 / 8%)",
            border: "oklch(0.65 0.18 300 / 20%)",
            title: "Mobility & Coordination Focus",
            content: fitnessPath.mobilityFocus,
          },
          {
            icon: Transfer,
            color: "oklch(0.72 0.14 175)",
            bg: "oklch(0.72 0.14 175 / 8%)",
            border: "oklch(0.72 0.14 175 / 20%)",
            title: "Tennis Transfer",
            content: fitnessPath.tennisTranfer,
          },
          {
            icon: Home,
            color: "oklch(0.72 0.16 60)",
            bg: "oklch(0.72 0.16 60 / 8%)",
            border: "oklch(0.72 0.16 60 / 20%)",
            title: "At-Home Support Suggestion",
            content: fitnessPath.atHomeSuggestion,
          },
          {
            icon: Battery,
            color: "oklch(0.70 0.16 240)",
            bg: "oklch(0.70 0.16 240 / 8%)",
            border: "oklch(0.70 0.16 240 / 20%)",
            title: "Readiness & Load Note",
            content: fitnessPath.readinessNote,
          },
        ].map((card, i) => {
          const Icon = card.icon;
          return (
            <div
              key={card.title}
              className={`rounded-xl p-4 mb-4 animate-slide-up delay-${i + 2}`}
              style={{
                background: card.bg,
                border: `1px solid ${card.border}`,
              }}
            >
              <div className="flex items-center gap-2 mb-2">
                <Icon size={14} style={{ color: card.color }} />
                <p
                  className="text-xs font-semibold uppercase tracking-wider"
                  style={{ color: card.color }}
                >
                  {card.title}
                </p>
              </div>
              <p className="text-sm leading-relaxed">{card.content}</p>
            </div>
          );
        })}

        <div className="flex gap-3 mt-2 animate-slide-up delay-6">
          <Link href="/next-steps" className="flex-1">
            <button
              className="w-full py-3 rounded-xl text-sm font-medium flex items-center justify-center gap-2 transition-all"
              style={{
                background: "oklch(1 0 0 / 6%)",
                border: "1px solid oklch(1 0 0 / 10%)",
                color: "oklch(0.85 0.005 220)",
              }}
            >
              Next Steps
              <ChevronRight size={14} />
            </button>
          </Link>
          <Link href="/request-lesson" className="flex-1">
            <button className="btn-aqua w-full py-3 rounded-xl text-sm font-semibold">
              Request Lesson
            </button>
          </Link>
        </div>
      </div>
    </PortalLayout>
  );
}
