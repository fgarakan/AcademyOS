/*
 * AcademyOS Parent Portal — Screen 10: Message / Question to Academy
 * "Midnight Court" design: DONNA-assisted drafting, academy-approved label
 */
import { useState } from "react";
import { Link } from "wouter";
import PortalLayout from "@/components/PortalLayout";
import {
  ChevronLeft,
  MessageSquare,
  Bot,
  Send,
  CheckCircle,
  Sparkles,
} from "lucide-react";
import { player } from "@/lib/data";

const suggestedQuestions = [
  "What should my child work on?",
  "Are they ready for the next level?",
  "Should we play more tournaments?",
  "Should we request a private lesson?",
  "How can we support at home?",
];

const donnaResponses: Record<string, string> = {
  "What should my child work on?": `Based on ${player.name}'s current development plan, the primary focus is **earlier forehand preparation** and **recovery movement after wide balls**. These are the skills her coaches have identified as the highest-leverage areas right now.`,
  "Are they ready for the next level?":
    `${player.name} is making solid progress toward ${player.nextLevel}. Her coaches are tracking the key indicators — consistent forehand preparation in live-ball situations and improved recovery movement. The timing for level progression will be guided by the coaching team.`,
  "Should we play more tournaments?":
    `At this stage, ${player.name}'s development plan focuses on building the technical and tactical foundation for competition. Her coaches will recommend the right time for external tournaments. Internal match-play is already part of her program.`,
  "Should we request a private lesson?":
    `A private lesson is a great option if ${player.name} wants more focused one-on-one time. Based on her current focus, **Coach Farshad** would be an excellent match for a technical forehand session. You can request a lesson directly from the portal.`,
  "How can we support at home?":
    `The most impactful support is **consistent attendance** and a **calm, encouraging environment**. Optional: 5–10 minutes of shadow forehand practice a few times a week. Ask ${player.name} what she worked on after training — not how she performed.`,
};

export default function Message() {
  const [selectedQuestion, setSelectedQuestion] = useState<string | null>(null);
  const [customMessage, setCustomMessage] = useState("");
  const [donnaResponse, setDonnaResponse] = useState<string | null>(null);
  const [sent, setSent] = useState(false);

  const handleQuestionSelect = (q: string) => {
    setSelectedQuestion(q);
    setCustomMessage(q);
    setDonnaResponse(donnaResponses[q] || null);
    setSent(false);
  };

  const handleSend = (e: React.FormEvent) => {
    e.preventDefault();
    if (!customMessage.trim()) return;
    setSent(true);
  };

  return (
    <PortalLayout>
      <div className="p-5 lg:p-8 max-w-2xl mx-auto">
        <Link href="/">
          <div className="flex items-center gap-1.5 text-sm text-muted-foreground mb-6 hover:text-foreground transition-colors cursor-pointer w-fit">
            <ChevronLeft size={16} />
            Back to Home
          </div>
        </Link>

        <div className="mb-6 animate-slide-up">
          <div className="flex items-center gap-2 mb-1">
            <MessageSquare
              size={16}
              style={{ color: "oklch(0.70 0.16 240)" }}
            />
            <p
              className="text-xs font-medium uppercase tracking-widest"
              style={{ color: "oklch(0.70 0.16 240)" }}
            >
              Message Academy
            </p>
          </div>
          <h1
            className="text-2xl font-bold"
            style={{ fontFamily: "'Space Grotesk', sans-serif" }}
          >
            Ask the Academy
          </h1>
          <p className="text-sm text-muted-foreground mt-1">
            Ask a question about {player.name}'s development. DONNA can help
            draft a response, which will be reviewed by the academy team.
          </p>
        </div>

        {/* Suggested questions */}
        <div className="mb-5 animate-slide-up delay-1">
          <p
            className="text-xs font-semibold uppercase tracking-wider mb-3"
            style={{ color: "oklch(0.58 0.01 220)" }}
          >
            Common Questions
          </p>
          <div className="flex flex-col gap-2">
            {suggestedQuestions.map((q) => (
              <button
                key={q}
                onClick={() => handleQuestionSelect(q)}
                className="w-full text-left px-4 py-3 rounded-xl text-sm transition-all duration-150"
                style={
                  selectedQuestion === q
                    ? {
                        background: "oklch(0.70 0.16 240 / 12%)",
                        border: "1px solid oklch(0.70 0.16 240 / 35%)",
                        color: "oklch(0.88 0.005 220)",
                      }
                    : {
                        background: "oklch(1 0 0 / 4%)",
                        border: "1px solid oklch(1 0 0 / 8%)",
                        color: "oklch(0.75 0.005 220)",
                      }
                }
              >
                {q}
              </button>
            ))}
          </div>
        </div>

        {/* DONNA draft response */}
        {donnaResponse && !sent && (
          <div
            className="rounded-xl p-4 mb-5 animate-slide-up"
            style={{
              background: "oklch(0.72 0.14 175 / 8%)",
              border: "1px solid oklch(0.72 0.14 175 / 20%)",
            }}
          >
            <div className="flex items-center gap-2 mb-2">
              <Bot size={14} style={{ color: "oklch(0.72 0.14 175)" }} />
              <p
                className="text-xs font-semibold"
                style={{ color: "oklch(0.72 0.14 175)" }}
              >
                DONNA Draft Response
              </p>
              <div
                className="flex items-center gap-1 px-2 py-0.5 rounded-full text-xs ml-auto"
                style={{
                  background: "oklch(0.72 0.16 60 / 12%)",
                  color: "oklch(0.72 0.16 60)",
                  border: "1px solid oklch(0.72 0.16 60 / 25%)",
                }}
              >
                <Sparkles size={10} />
                Academy-approved response required
              </div>
            </div>
            <p
              className="text-sm leading-relaxed"
              dangerouslySetInnerHTML={{
                __html: donnaResponse.replace(
                  /\*\*(.+?)\*\*/g,
                  '<strong style="color: oklch(0.88 0.005 220)">$1</strong>'
                ),
              }}
            />
            <p
              className="text-xs mt-3 italic"
              style={{ color: "oklch(0.58 0.01 220)" }}
            >
              This is a DONNA-generated draft. The academy team will review and
              send an approved response.
            </p>
          </div>
        )}

        {/* Success state */}
        {sent && (
          <div
            className="rounded-xl p-4 mb-5 flex items-start gap-2.5 animate-slide-up"
            style={{
              background: "oklch(0.72 0.14 175 / 8%)",
              border: "1px solid oklch(0.72 0.14 175 / 20%)",
            }}
          >
            <CheckCircle
              size={16}
              className="shrink-0 mt-0.5"
              style={{ color: "oklch(0.72 0.14 175)" }}
            />
            <div>
              <p
                className="text-sm font-medium mb-1"
                style={{ color: "oklch(0.72 0.14 175)" }}
              >
                Message sent to the academy
              </p>
              <p className="text-xs text-muted-foreground leading-relaxed">
                The academy team will review your question and send an
                approved response within 1–2 business days.
              </p>
            </div>
          </div>
        )}

        {/* Custom message form */}
        {!sent && (
          <form
            onSubmit={handleSend}
            className="animate-slide-up delay-2"
          >
            <div
              className="rounded-2xl p-4 mb-4"
              style={{
                background: "oklch(0.14 0.007 220)",
                border: "1px solid oklch(1 0 0 / 8%)",
              }}
            >
              <p
                className="text-xs font-semibold uppercase tracking-wider mb-2"
                style={{ color: "oklch(0.58 0.01 220)" }}
              >
                Your Message
              </p>
              <textarea
                value={customMessage}
                onChange={(e) => {
                  setCustomMessage(e.target.value);
                  setSelectedQuestion(null);
                  setDonnaResponse(null);
                }}
                rows={4}
                placeholder="Type your question or message here…"
                className="w-full text-sm outline-none resize-none"
                style={{
                  background: "transparent",
                  color: "oklch(0.95 0.005 220)",
                  lineHeight: "1.6",
                }}
              />
            </div>
            <button
              type="submit"
              disabled={!customMessage.trim()}
              className="w-full py-3.5 rounded-xl text-sm font-semibold flex items-center justify-center gap-2 transition-all duration-200"
              style={
                customMessage.trim()
                  ? {
                      background: "oklch(0.72 0.14 175)",
                      color: "oklch(0.08 0.005 220)",
                      boxShadow: "0 0 20px oklch(0.72 0.14 175 / 30%)",
                    }
                  : {
                      background: "oklch(1 0 0 / 8%)",
                      color: "oklch(0.45 0.008 220)",
                      cursor: "not-allowed",
                    }
              }
            >
              <Send size={14} />
              Send to Academy
            </button>
          </form>
        )}

        {sent && (
          <Link href="/">
            <button className="btn-aqua w-full py-3 rounded-xl text-sm font-semibold mt-2 animate-slide-up">
              Back to Home
            </button>
          </Link>
        )}
      </div>
    </PortalLayout>
  );
}
