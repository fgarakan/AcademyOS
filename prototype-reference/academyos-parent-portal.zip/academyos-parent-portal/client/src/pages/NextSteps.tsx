/*
 * AcademyOS Parent Portal — Screen 6: Next Steps + How to Help
 * "Midnight Court" design: parent-safe, calm, supportive guidance
 */
import { Link } from "wouter";
import PortalLayout from "@/components/PortalLayout";
import {
  ChevronLeft,
  ArrowRight,
  Heart,
  Home,
  Calendar,
  Trophy,
  AlertCircle,
  ChevronRight,
} from "lucide-react";
import { nextSteps, player } from "@/lib/data";

export default function NextSteps() {
  return (
    <PortalLayout>
      <div className="p-5 lg:p-8 max-w-3xl mx-auto">
        <Link href="/">
          <div className="flex items-center gap-1.5 text-sm text-muted-foreground mb-6 hover:text-foreground transition-colors cursor-pointer w-fit">
            <ChevronLeft size={16} />
            Back to Home
          </div>
        </Link>

        <div className="mb-6 animate-slide-up">
          <div className="flex items-center gap-2 mb-1">
            <ArrowRight size={16} style={{ color: "oklch(0.70 0.16 240)" }} />
            <p
              className="text-xs font-medium uppercase tracking-widest"
              style={{ color: "oklch(0.70 0.16 240)" }}
            >
              Next Steps
            </p>
          </div>
          <h1
            className="text-2xl font-bold"
            style={{ fontFamily: "'Space Grotesk', sans-serif" }}
          >
            How to Help {player.name}
          </h1>
          <p className="text-sm text-muted-foreground mt-1">
            Simple, calm guidance for supporting {player.name}'s development
            this month.
          </p>
        </div>

        {/* Best support this month */}
        <div
          className="rounded-2xl p-5 mb-4 animate-slide-up delay-1"
          style={{
            background:
              "linear-gradient(135deg, oklch(0.14 0.007 220) 0%, oklch(0.16 0.014 240) 100%)",
            borderLeft: "3px solid oklch(0.70 0.16 240)",
          }}
        >
          <div className="flex items-center gap-2 mb-3">
            <Heart size={16} style={{ color: "oklch(0.70 0.16 240)" }} />
            <p
              className="text-sm font-semibold"
              style={{
                fontFamily: "'Space Grotesk', sans-serif",
                color: "oklch(0.70 0.16 240)",
              }}
            >
              Best Support This Month
            </p>
          </div>
          <div className="flex flex-col gap-2.5">
            {nextSteps.bestSupportThisMonth.map((item, i) => (
              <div key={i} className="flex items-start gap-2.5">
                <div
                  className="w-5 h-5 rounded-full flex items-center justify-center shrink-0 mt-0.5 text-xs font-bold"
                  style={{
                    background: "oklch(0.70 0.16 240 / 20%)",
                    color: "oklch(0.70 0.16 240)",
                  }}
                >
                  {i + 1}
                </div>
                <p className="text-sm leading-relaxed">{item}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Optional home practice */}
        <div
          className="rounded-xl p-4 mb-4 animate-slide-up delay-2"
          style={{
            background: "oklch(0.72 0.14 175 / 8%)",
            border: "1px solid oklch(0.72 0.14 175 / 20%)",
          }}
        >
          <div className="flex items-center gap-2 mb-2">
            <Home size={14} style={{ color: "oklch(0.72 0.14 175)" }} />
            <p
              className="text-xs font-semibold uppercase tracking-wider"
              style={{ color: "oklch(0.72 0.14 175)" }}
            >
              Optional Home Practice
            </p>
          </div>
          <p className="text-sm leading-relaxed">{nextSteps.optionalHomePractice}</p>
        </div>

        {/* When to request lesson */}
        <div
          className="rounded-xl p-4 mb-4 animate-slide-up delay-3"
          style={{
            background: "oklch(0.72 0.16 60 / 8%)",
            border: "1px solid oklch(0.72 0.16 60 / 20%)",
          }}
        >
          <div className="flex items-center gap-2 mb-2">
            <Calendar size={14} style={{ color: "oklch(0.72 0.16 60)" }} />
            <p
              className="text-xs font-semibold uppercase tracking-wider"
              style={{ color: "oklch(0.72 0.16 60)" }}
            >
              When to Request a Private Lesson
            </p>
          </div>
          <p className="text-sm leading-relaxed">{nextSteps.whenToRequestLesson}</p>
        </div>

        {/* When to play matches */}
        <div
          className="rounded-xl p-4 mb-4 animate-slide-up delay-4"
          style={{
            background: "oklch(0.65 0.18 300 / 8%)",
            border: "1px solid oklch(0.65 0.18 300 / 20%)",
          }}
        >
          <div className="flex items-center gap-2 mb-2">
            <Trophy size={14} style={{ color: "oklch(0.65 0.18 300)" }} />
            <p
              className="text-xs font-semibold uppercase tracking-wider"
              style={{ color: "oklch(0.65 0.18 300)" }}
            >
              When to Play Matches
            </p>
          </div>
          <p className="text-sm leading-relaxed">{nextSteps.whenToPlayMatches}</p>
        </div>

        {/* What not to over-focus on */}
        <div
          className="rounded-xl p-4 mb-6 animate-slide-up delay-5"
          style={{
            background: "oklch(0.14 0.007 220)",
            border: "1px solid oklch(1 0 0 / 8%)",
          }}
        >
          <div className="flex items-center gap-2 mb-2">
            <AlertCircle
              size={14}
              style={{ color: "oklch(0.58 0.01 220)" }}
            />
            <p className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">
              What Not to Over-Focus On
            </p>
          </div>
          <p className="text-sm leading-relaxed text-muted-foreground">
            {nextSteps.whatNotToOverFocus}
          </p>
        </div>

        {/* CTAs */}
        <div className="flex gap-3 animate-slide-up delay-6">
          <Link href="/message" className="flex-1">
            <button
              className="w-full py-3 rounded-xl text-sm font-medium flex items-center justify-center gap-2 transition-all"
              style={{
                background: "oklch(1 0 0 / 6%)",
                border: "1px solid oklch(1 0 0 / 10%)",
                color: "oklch(0.85 0.005 220)",
              }}
            >
              Ask the Academy
              <ChevronRight size={14} />
            </button>
          </Link>
          <Link href="/request-lesson" className="flex-1">
            <button className="btn-aqua w-full py-3 rounded-xl text-sm font-semibold">
              Request Lesson
            </button>
          </Link>
        </div>
      </div>
    </PortalLayout>
  );
}
