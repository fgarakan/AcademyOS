/*
 * AcademyOS Parent Portal — Screen 8: Coach Selection
 * "Midnight Court" design: coach cards with specialty, availability, recommended badge
 */
import { useState } from "react";
import { Link, useLocation } from "wouter";
import PortalLayout from "@/components/PortalLayout";
import {
  ChevronLeft,
  Users,
  Star,
  Clock,
  CheckCircle,
  ChevronRight,
} from "lucide-react";
import { coaches, player } from "@/lib/data";

export default function CoachSelection() {
  const [, navigate] = useLocation();
  const [selected, setSelected] = useState<string | null>(null);

  const handleSelect = (coachId: string) => {
    setSelected(coachId);
  };

  const handleRequest = () => {
    if (selected) navigate("/confirmation");
  };

  return (
    <PortalLayout>
      <div className="p-5 lg:p-8 max-w-2xl mx-auto">
        <Link href="/request-lesson">
          <div className="flex items-center gap-1.5 text-sm text-muted-foreground mb-6 hover:text-foreground transition-colors cursor-pointer w-fit">
            <ChevronLeft size={16} />
            Back to Request
          </div>
        </Link>

        <div className="mb-6 animate-slide-up">
          <div className="flex items-center gap-2 mb-1">
            <Users size={16} style={{ color: "oklch(0.72 0.14 175)" }} />
            <p
              className="text-xs font-medium uppercase tracking-widest"
              style={{ color: "oklch(0.72 0.14 175)" }}
            >
              Coach Selection
            </p>
          </div>
          <h1
            className="text-2xl font-bold"
            style={{ fontFamily: "'Space Grotesk', sans-serif" }}
          >
            Choose a Coach
          </h1>
          <p className="text-sm text-muted-foreground mt-1">
            Select the coach that best fits {player.name}'s current development
            focus.
          </p>
        </div>

        {/* Coach cards */}
        <div className="flex flex-col gap-4 mb-6">
          {coaches.map((coach, i) => {
            const isSelected = selected === coach.id;
            return (
              <button
                key={coach.id}
                onClick={() => handleSelect(coach.id)}
                className={`w-full text-left rounded-2xl p-4 transition-all duration-200 animate-slide-up delay-${i + 1}`}
                style={
                  isSelected
                    ? {
                        background: "oklch(0.72 0.14 175 / 10%)",
                        border: "2px solid oklch(0.72 0.14 175 / 60%)",
                        boxShadow: "0 0 24px oklch(0.72 0.14 175 / 20%)",
                      }
                    : {
                        background: "oklch(0.14 0.007 220)",
                        border: "1px solid oklch(1 0 0 / 8%)",
                      }
                }
              >
                <div className="flex items-start gap-3">
                  {/* Avatar */}
                  <div
                    className="w-10 h-10 rounded-full flex items-center justify-center text-sm font-bold shrink-0"
                    style={{
                      background: `${coach.avatarColor.replace(")", " / 20%)")}`,
                      color: coach.avatarColor,
                      border: `1px solid ${coach.avatarColor.replace(")", " / 30%)")}`,
                    }}
                  >
                    {coach.avatarInitials}
                  </div>

                  {/* Info */}
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-0.5 flex-wrap">
                      <p
                        className="text-sm font-semibold"
                        style={{ fontFamily: "'Space Grotesk', sans-serif" }}
                      >
                        {coach.name}
                      </p>
                      {coach.recommended && (
                        <div
                          className="flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-medium"
                          style={{
                            background: "oklch(0.72 0.14 175 / 15%)",
                            color: "oklch(0.72 0.14 175)",
                            border: "1px solid oklch(0.72 0.14 175 / 30%)",
                          }}
                        >
                          <Star size={10} fill="currentColor" />
                          Recommended
                        </div>
                      )}
                      {isSelected && (
                        <CheckCircle
                          size={14}
                          style={{ color: "oklch(0.72 0.14 175)" }}
                        />
                      )}
                    </div>
                    <p
                      className="text-xs mb-1"
                      style={{ color: "oklch(0.58 0.01 220)" }}
                    >
                      {coach.role}
                    </p>
                    <p className="text-xs text-muted-foreground mb-2">
                      {coach.specialty}
                    </p>

                    {/* Best fit reason */}
                    <p
                      className="text-xs leading-relaxed mb-2 italic"
                      style={{ color: "oklch(0.72 0.14 175)" }}
                    >
                      {coach.bestFitReason}
                    </p>

                    {/* Lesson types + availability */}
                    <div className="flex flex-wrap gap-1.5 mb-2">
                      {coach.availableLessonTypes.map((type) => (
                        <span
                          key={type}
                          className="px-2 py-0.5 rounded-full text-xs"
                          style={{
                            background: "oklch(1 0 0 / 6%)",
                            border: "1px solid oklch(1 0 0 / 10%)",
                            color: "oklch(0.75 0.005 220)",
                          }}
                        >
                          {type}
                        </span>
                      ))}
                    </div>

                    <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
                      <Clock size={11} />
                      Available: {coach.availability}
                    </div>
                  </div>
                </div>
              </button>
            );
          })}
        </div>

        {/* CTA */}
        <button
          onClick={handleRequest}
          disabled={!selected}
          className="w-full py-3.5 rounded-xl text-sm font-semibold transition-all duration-200 animate-slide-up delay-6"
          style={
            selected
              ? {
                  background: "oklch(0.72 0.14 175)",
                  color: "oklch(0.08 0.005 220)",
                  boxShadow: "0 0 20px oklch(0.72 0.14 175 / 30%)",
                }
              : {
                  background: "oklch(1 0 0 / 8%)",
                  color: "oklch(0.45 0.008 220)",
                  cursor: "not-allowed",
                }
          }
        >
          {selected
            ? `Request Lesson with ${coaches.find((c) => c.id === selected)?.name}`
            : "Select a Coach to Continue"}
        </button>

        {selected && (
          <p
            className="text-xs text-center mt-3 text-muted-foreground animate-slide-up"
          >
            Your request will be sent to the academy for review. No booking is
            confirmed until the academy responds.
          </p>
        )}
      </div>
    </PortalLayout>
  );
}
