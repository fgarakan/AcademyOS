// AcademyOS Parent Portal — Prototype Data
// All data is illustrative and parent-safe (no raw coach notes, no rankings, no pressure language)

export const player = {
  name: "Sarah",
  age: 13,
  level: "Orange 3",
  nextLevel: "Green 1",
  currentFocus: "Forehand preparation & recovery after wide balls",
  coachApprovedSummary:
    "Sarah is currently working on earlier forehand preparation and recovering after wide balls. Her next goal is to show this consistently in live-ball rally situations.",
  nextRecommendedAction: "Request a private lesson focused on forehand mechanics",
  lastAssessment: "May 6, 2026",
  attendanceRate: "92%",
  sessionsThisMonth: 8,
  progressNote:
    "Sarah has shown clear improvement in her court positioning over the last three weeks. Her coaches have noted more consistent footwork patterns.",
  mainPriority: "Forehand preparation",
  secondaryPriority: "Recovery movement after wide balls",
  evidenceSummary:
    "Observed in group sessions and noted during two supervised match-play situations. Consistent pattern across different court surfaces.",
};

export const skillPath = {
  currentFocus: "Earlier forehand preparation",
  whatImproving:
    "Sarah is learning to start her racket take-back earlier, giving her more time to set up and strike with control.",
  whyItMatters:
    "Earlier preparation helps handle faster balls, reduces errors under pressure, and creates better recovery time after each shot.",
  evidenceCollected:
    "Coaches have observed this in three group training sessions. Sarah is showing awareness of the pattern in slower-paced rallies.",
  practiceRecommendation:
    "Short, focused shadow swings at home (5–10 minutes) focusing on the take-back motion — no ball needed.",
  whatParentsShouldNotice:
    "Watch for Sarah starting her swing preparation before the ball crosses the net. That's the target habit.",
};

export const competitionPath = {
  currentFocus: "Choosing safer crosscourt targets under pressure",
  situationalAwareness:
    "Sarah is learning to recognise when she is under pressure and choose a higher-percentage shot rather than going for a winner.",
  decisionMakingTheme: "Safety-first shot selection when out of position",
  matchBehaviorFocus:
    "Staying calm after errors and resetting quickly for the next point.",
  recentCompetitionNote:
    "Sarah competed in two internal match-play sessions this month. Coaches noted improved composure after losing a point.",
  nextReadinessGuidance:
    "Sarah is building the tactical foundation needed for external competition. Her coaches will guide the right timing for her first tournament.",
};

export const fitnessPath = {
  movementFocus: "Recovering to balance after wide balls",
  mobilityFocus: "Hip mobility and lateral movement patterns",
  tennisTranfer:
    "Better lateral recovery means Sarah can set up for the next shot instead of scrambling — directly supporting her forehand work.",
  atHomeSuggestion:
    "Gentle lateral shuffle steps or skipping rope (5–10 minutes) on non-training days. Keep it fun, not intense.",
  readinessNote:
    "Sarah's training load is well-managed. No concerns about fatigue or overtraining at this stage.",
};

export const nextSteps = {
  bestSupportThisMonth: [
    "Encourage consistent attendance — routine is the most powerful development tool.",
    "Ask Sarah what she worked on after training, not how she performed.",
    "Celebrate effort and awareness, not outcomes.",
  ],
  optionalHomePractice:
    "Shadow forehand take-back (5–10 min, 3x per week). No ball needed. Keep it relaxed.",
  whenToRequestLesson:
    "If Sarah mentions wanting more one-on-one time with a coach, or if you'd like a focused check-in on her progress, a private lesson is a great option.",
  whenToPlayMatches:
    "Her coaches will recommend the right time for external competition. Internal match-play is already part of her program.",
  whatNotToOverFocus:
    "Avoid focusing on match results or comparing to other players. Her development plan is individual and on track.",
};

export const coaches = [
  {
    id: "brian",
    name: "Coach Brian",
    role: "High Performance Director",
    specialty: "Tactical development & competitive strategy",
    availableLessonTypes: ["Competition / tactics", "Assessment / check-in"],
    bestFitReason:
      "Recommended because Coach Brian specialises in tactical decision-making — directly aligned with Sarah's current competition focus.",
    availability: "Tue, Thu, Sat",
    avatarInitials: "CB",
    avatarColor: "oklch(0.55 0.18 260)",
  },
  {
    id: "farshad",
    name: "Coach Farshad",
    role: "Technical Specialist",
    specialty: "Forehand mechanics, angles training, early development",
    availableLessonTypes: ["Technical", "Assessment / check-in"],
    bestFitReason:
      "Recommended because Coach Farshad's forehand mechanics expertise directly matches Sarah's current skill focus.",
    availability: "Mon, Wed, Fri",
    avatarInitials: "CF",
    avatarColor: "oklch(0.62 0.16 175)",
    recommended: true,
  },
  {
    id: "maria",
    name: "Coach Maria",
    role: "Junior Development Coach",
    specialty: "Red/Orange Ball development, foundational skills",
    availableLessonTypes: ["Technical", "Serve"],
    bestFitReason:
      "Recommended for foundational skill reinforcement in a supportive, low-pressure environment.",
    availability: "Mon, Tue, Thu",
    avatarInitials: "CM",
    avatarColor: "oklch(0.62 0.18 340)",
  },
  {
    id: "alex",
    name: "Coach Alex",
    role: "Fitness & Movement Coach",
    specialty: "Fitness, movement patterns, speed & agility",
    availableLessonTypes: ["Fitness / movement"],
    bestFitReason:
      "Recommended because Sarah's fitness path focuses on lateral recovery — Coach Alex's core specialty.",
    availability: "Wed, Fri, Sat",
    avatarInitials: "CA",
    avatarColor: "oklch(0.65 0.18 60)",
  },
  {
    id: "daniel",
    name: "Coach Daniel",
    role: "Match Play Specialist",
    specialty: "Serve development, match play scenarios",
    availableLessonTypes: ["Serve", "Competition / tactics"],
    bestFitReason:
      "Recommended for serve development and match-play preparation as Sarah advances toward competition.",
    availability: "Tue, Thu, Sun",
    avatarInitials: "CD",
    avatarColor: "oklch(0.60 0.16 300)",
  },
];

export const lessonTypes = [
  "Technical",
  "Competition / tactics",
  "Serve",
  "Fitness / movement",
  "Assessment / check-in",
];

export const donnaQuickActions = [
  "Explain current focus",
  "What should we support at home?",
  "Should we request a private lesson?",
  "What does the next level require?",
  "Ask a question for the academy",
];

export const donnaResponses: Record<string, string> = {
  "Explain current focus":
    "Sarah is currently focused on **earlier forehand preparation**. This means she's learning to start her swing before the ball arrives, giving her more time and control. It's a foundational habit that will help her handle faster balls as she progresses.",
  "What should we support at home?":
    "The best support at home is **consistency and calm**. Encourage Sarah to attend training regularly, ask her what she worked on (not how she did), and celebrate effort over results. Optional: 5–10 minutes of shadow forehand practice a few times a week.",
  "Should we request a private lesson?":
    "A private lesson is a great option if Sarah wants more focused one-on-one time, or if you'd like a dedicated progress check-in. Based on her current focus, **Coach Farshad** would be an excellent match for a technical forehand session.",
  "What does the next level require?":
    "Moving from **Orange 3 to Green 1** requires Sarah to demonstrate consistent forehand preparation in live-ball situations, improved recovery movement, and basic tactical awareness in rally patterns. Her coaches are actively building these skills.",
  "Ask a question for the academy":
    "I can help you draft a question for the academy team. What would you like to ask? Note: all responses will be reviewed and approved by the academy before being sent.",
};
