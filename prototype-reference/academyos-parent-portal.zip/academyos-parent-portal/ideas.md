# AcademyOS Parent Portal — Design Brainstorm

<response>
<text>
**Approach A — "Midnight Court" (Dark Precision Athletic)**

- **Design Movement**: Dark-mode premium SaaS meets sports analytics dashboard
- **Core Principles**: High contrast, data clarity, trust through restraint, zero noise
- **Color Philosophy**: Near-black (#0D0F10) base, deep charcoal cards (#161A1D), aqua/teal (#00C9A7) as the sole accent. White for primary text, muted slate for secondary. The aqua evokes court lines under stadium lights — precision, energy, clarity.
- **Layout Paradigm**: Left sidebar navigation (persistent), main content area with a fixed right DONNA panel on desktop. Mobile collapses to bottom tab bar + drawer for DONNA.
- **Signature Elements**: Thin aqua left-border on active cards; pill badges with subtle glow; progress bars in aqua with dark track
- **Interaction Philosophy**: Every tap/click has a 150ms scale(0.97) press response. Card hover lifts with a soft shadow bloom. DONNA responses animate in word-by-word.
- **Animation**: Staggered card entrance (40ms delay each), slide-in from left for sidebar, fade+scale for modals
- **Typography System**: "DM Sans" for body (clean, humanist), "Space Grotesk" for headings (geometric, athletic). Bold 700 for titles, 400 for body, 500 for labels.
</text>
<probability>0.08</probability>
</response>

<response>
<text>
**Approach B — "Soft Signal" (Calm Parental Trust)**

- **Design Movement**: Warm minimalism meets health-app clarity
- **Core Principles**: Warmth, approachability, zero intimidation, breathing room
- **Color Philosophy**: Off-white (#F8F9FA) background, warm card surfaces, teal accent only for CTAs. Designed to feel like a trusted school portal, not a performance dashboard.
- **Layout Paradigm**: Single-column mobile-first with generous padding. Cards stack vertically. No sidebar.
- **Signature Elements**: Rounded 20px cards with subtle drop shadows; illustrated avatar for child; soft teal progress rings
- **Interaction Philosophy**: Gentle, no pressure. Taps feel soft. No dense data.
- **Animation**: Fade-in only, no transforms. Calm and still.
- **Typography System**: "Nunito" for everything — rounded, friendly, approachable.
</text>
<probability>0.04</probability>
</response>

<response>
<text>
**Approach C — "Signal & Silence" (Editorial Dark with Structural Asymmetry)**

- **Design Movement**: Editorial sports journalism meets SaaS dashboard
- **Core Principles**: Asymmetric structure, typographic hierarchy, signal over noise, premium restraint
- **Color Philosophy**: True black (#080A0C) background, single-pixel aqua dividers, white headlines, 60% opacity body text. Accent used ONLY for actionable elements — never decorative.
- **Layout Paradigm**: Two-column asymmetric: 65% content / 35% DONNA sidebar. On mobile, DONNA becomes a floating FAB that opens a bottom sheet.
- **Signature Elements**: Full-bleed section headers with aqua underline; coach avatar with aqua ring; step-indicator dots for multi-screen flows
- **Interaction Philosophy**: Keyboard-navigable, screen-reader friendly. Every interactive element has a clear affordance. No hidden gestures.
- **Animation**: Entrance from bottom (translateY 16px → 0) with opacity, 200ms ease-out. Active nav item slides aqua indicator bar.
- **Typography System**: "Syne" for display headings (bold, distinctive), "Inter" for data/body (readable at small sizes). Strict size scale: 32/24/18/14/12.
</text>
<probability>0.06</probability>
</response>

---

## Selected Approach: **A — "Midnight Court"**

This approach best matches the existing AcademyOS brand (dark premium athletic SaaS, aqua accent, DONNA assistant). It maintains visual family consistency with the Curriculum Builder and Templates screens while keeping a calm, high-trust tone appropriate for parents.
