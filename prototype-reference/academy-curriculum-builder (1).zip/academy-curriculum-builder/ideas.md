# AcademyOS Curriculum Builder — Design Brainstorm

<response>
<text>
## Idea A — "Dark Court" Athletic Command Center

**Design Movement:** Premium Athletic SaaS / Nike Digital × WHOOP Dashboard

**Core Principles:**
1. Pitch-black (#0A0A0A) canvas with charcoal card surfaces (#141414, #1A1A1A) — zero white, zero grey washes
2. Lime-green (#CAFF00 / #B8F400) as the singular accent — used sparingly for CTAs, status indicators, and active states
3. Tight typographic hierarchy: Bebas Neue for display headers, DM Sans for body — weight contrast creates athletic energy
4. Every card has a micro-border of 1px rgba(255,255,255,0.07) — barely visible but adds depth

**Color Philosophy:**
- Background: #0A0A0A (pitch black)
- Card surface: #141414 / #1C1C1C
- Elevated card: #222222
- Lime accent: #CAFF00 — used for CTAs, active level glow, DONNA highlights
- Muted text: #888888
- Danger/incomplete: #FF4444
- Warning/needs review: #FF9900
- Success/ready: #CAFF00

**Layout Paradigm:**
- Two-column split: 70% main content area (scrollable) + 30% fixed DONNA panel (right rail)
- Curriculum Map uses a horizontal pathway row layout — each pathway is a horizontal strip of level cards
- No centered hero — content starts from top-left with a persistent sidebar nav

**Signature Elements:**
1. Lime glow ring on selected/active level cards (`box-shadow: 0 0 0 1px #CAFF00, 0 0 20px rgba(202,255,0,0.15)`)
2. DONNA panel with a subtle lime top-border and "D" avatar in lime
3. Progress rail: horizontal dot-connected timeline with lime fill for completed steps

**Interaction Philosophy:**
- Cards scale up 1.02 on hover with a 160ms ease-out
- DONNA panel slides in from right with 250ms cubic-bezier(0.23,1,0.32,1)
- Impact cards stagger-animate in with 50ms delay each
- Relationship map nodes pulse with a 3s infinite lime glow keyframe

**Animation:**
- Card hover: `transform: scale(1.02); box-shadow: 0 8px 32px rgba(0,0,0,0.4)` — 160ms ease-out
- DONNA panel entrance: `translateX(100%) → translateX(0)` — 250ms cubic-bezier(0.23,1,0.32,1)
- Level selection glow: `box-shadow` transition 200ms
- Progress rail fill: width transition 400ms ease-in-out
- Impact cards: stagger `opacity 0→1 + translateY 8px→0` with 50ms per card
- Relationship map: `@keyframes pulse` — scale 1→1.05→1 over 3s infinite

**Typography System:**
- Display/Headers: Bebas Neue (uppercase, tracking 0.05em)
- UI Labels/Body: DM Sans (400/500/600 weights)
- Monospace/Data: JetBrains Mono (for percentages, counts)
- Scale: 11px label → 13px body → 15px card title → 20px section → 28px page title → 48px hero
</text>
<probability>0.08</probability>
</response>

<response>
<text>
## Idea B — "Terminal Court" Hacker-Athletic Hybrid

Design Movement: Cyberpunk Athletic × Vercel Dark
Core Principles: Green-on-black terminal aesthetic meets sports data dashboard
Color Philosophy: True black + terminal green (#00FF41) + amber warnings
Layout Paradigm: Full-width data table rows, command palette navigation
</text>
<probability>0.04</probability>
</response>

<response>
<text>
## Idea C — "Slate Precision" Minimal Dark Professional

Design Movement: Linear.app × Figma Dark
Core Principles: Deep slate (#0F1117) + electric blue accent, ultra-minimal
Color Philosophy: Slate grays with a single electric blue (#4F8EF7) accent
Layout Paradigm: Three-panel layout with collapsible sidebar
</text>
<probability>0.06</probability>
</response>

---

## Selected Design: **Idea A — "Dark Court" Athletic Command Center**

This is the clear winner for AcademyOS. The pitch-black canvas with lime accent perfectly captures the Nike/WHOOP premium athletic aesthetic requested. Bebas Neue headers give the interface an authoritative, athletic energy while DM Sans keeps the UI readable and modern.
