// AcademyOS — Curriculum Builder shared data & types

export type LevelStatus = "ready" | "needs-review" | "incomplete" | "custom";

export interface CurriculumLevel {
  id: string;
  pathway: string;
  pathwayColor: string;
  name: string;
  shortName: string;
  completion: number;
  skills: number;
  drills: number;
  assessmentGates: number;
  missingItems: number;
  lastUpdated: string;
  status: LevelStatus;
  goal: string;
  skillFocus: string;
  competitionFocus: string;
  fitnessSupport: string;
}

export interface Pathway {
  id: string;
  name: string;
  color: string;
  dotColor: string;
  levels: CurriculumLevel[];
}

export const PATHWAYS: Pathway[] = [
  {
    id: "red",
    name: "Red Ball",
    color: "#e05252",
    dotColor: "#ff6b6b",
    levels: [
      { id: "red-1", pathway: "Red Ball", pathwayColor: "#e05252", name: "Red Ball 1", shortName: "R1", completion: 100, skills: 8, drills: 12, assessmentGates: 3, missingItems: 0, lastUpdated: "2d ago", status: "ready", goal: "Introduce racket control and basic rally", skillFocus: "Grip, swing path, contact point", competitionFocus: "Mini-court rallies", fitnessSupport: "Coordination & balance" },
      { id: "red-2", pathway: "Red Ball", pathwayColor: "#e05252", name: "Red Ball 2", shortName: "R2", completion: 87, skills: 10, drills: 14, assessmentGates: 3, missingItems: 1, lastUpdated: "5d ago", status: "needs-review", goal: "Build consistency in groundstrokes", skillFocus: "Forehand & backhand baseline", competitionFocus: "Crosscourt patterns", fitnessSupport: "Footwork ladders" },
      { id: "red-3", pathway: "Red Ball", pathwayColor: "#e05252", name: "Red Ball 3", shortName: "R3", completion: 62, skills: 11, drills: 10, assessmentGates: 4, missingItems: 3, lastUpdated: "1w ago", status: "incomplete", goal: "Introduce serve and volley basics", skillFocus: "Serve mechanics, net approach", competitionFocus: "Serve + 1 patterns", fitnessSupport: "Core stability" },
    ],
  },
  {
    id: "orange",
    name: "Orange Ball",
    color: "#ff9500",
    dotColor: "#ffb340",
    levels: [
      { id: "orange-1", pathway: "Orange Ball", pathwayColor: "#ff9500", name: "Orange Ball 1", shortName: "O1", completion: 95, skills: 14, drills: 18, assessmentGates: 4, missingItems: 0, lastUpdated: "3d ago", status: "ready", goal: "Develop directional control", skillFocus: "Inside-out forehand, slice backhand", competitionFocus: "Pattern play", fitnessSupport: "Speed & agility" },
      { id: "orange-2", pathway: "Orange Ball", pathwayColor: "#ff9500", name: "Orange Ball 2", shortName: "O2", completion: 74, skills: 16, drills: 20, assessmentGates: 5, missingItems: 2, lastUpdated: "2d ago", status: "needs-review", goal: "Build tactical awareness", skillFocus: "Recovery movement, wide ball", competitionFocus: "Open court patterns", fitnessSupport: "Low contact mobility" },
      { id: "orange-3", pathway: "Orange Ball", pathwayColor: "#ff9500", name: "Orange Ball 3", shortName: "O3", completion: 45, skills: 18, drills: 16, assessmentGates: 5, missingItems: 5, lastUpdated: "2w ago", status: "incomplete", goal: "Introduce match-play strategy", skillFocus: "Approach shots, passing shots", competitionFocus: "Net vs. baseline decisions", fitnessSupport: "Reactive agility" },
    ],
  },
  {
    id: "green",
    name: "Green Ball",
    color: "#34c759",
    dotColor: "#4cd964",
    levels: [
      { id: "green-1", pathway: "Green Ball", pathwayColor: "#34c759", name: "Green Ball 1", shortName: "G1", completion: 100, skills: 20, drills: 24, assessmentGates: 5, missingItems: 0, lastUpdated: "1d ago", status: "ready", goal: "Full court consistency", skillFocus: "Topspin, depth control", competitionFocus: "Baseline rallies", fitnessSupport: "Endurance base" },
      { id: "green-2", pathway: "Green Ball", pathwayColor: "#34c759", name: "Green Ball 2", shortName: "G2", completion: 88, skills: 22, drills: 26, assessmentGates: 6, missingItems: 1, lastUpdated: "4d ago", status: "custom", goal: "Develop net game", skillFocus: "Volleys, overheads", competitionFocus: "Serve & volley", fitnessSupport: "Explosive first step" },
      { id: "green-3", pathway: "Green Ball", pathwayColor: "#34c759", name: "Green Ball 3", shortName: "G3", completion: 71, skills: 24, drills: 22, assessmentGates: 6, missingItems: 2, lastUpdated: "1w ago", status: "needs-review", goal: "Competitive match preparation", skillFocus: "Second serve, return patterns", competitionFocus: "Match-play scenarios", fitnessSupport: "Match fitness" },
    ],
  },
  {
    id: "yellow",
    name: "Yellow Ball",
    color: "#ffd60a",
    dotColor: "#ffe234",
    levels: [
      { id: "yellow-1", pathway: "Yellow Ball", pathwayColor: "#ffd60a", name: "Yellow Ball 1", shortName: "Y1", completion: 92, skills: 26, drills: 30, assessmentGates: 7, missingItems: 0, lastUpdated: "6h ago", status: "ready", goal: "Advanced baseline patterns", skillFocus: "Heavy topspin, flat drive", competitionFocus: "3-ball patterns", fitnessSupport: "Strength & power" },
      { id: "yellow-2", pathway: "Yellow Ball", pathwayColor: "#ffd60a", name: "Yellow Ball 2", shortName: "Y2", completion: 80, skills: 28, drills: 32, assessmentGates: 7, missingItems: 2, lastUpdated: "3d ago", status: "needs-review", goal: "Tactical serve patterns", skillFocus: "Kick serve, slice serve", competitionFocus: "Serve + pattern combos", fitnessSupport: "Shoulder & rotational" },
      { id: "yellow-3", pathway: "Yellow Ball", pathwayColor: "#ffd60a", name: "Yellow Ball 3", shortName: "Y3", completion: 55, skills: 30, drills: 28, assessmentGates: 8, missingItems: 4, lastUpdated: "1w ago", status: "incomplete", goal: "Tournament preparation", skillFocus: "Mental toughness, pressure points", competitionFocus: "Tiebreak & clutch scenarios", fitnessSupport: "Peak performance" },
    ],
  },
  {
    id: "hp",
    name: "High Performance",
    color: "#00c9a7",
    dotColor: "#00e5c4",
    levels: [
      { id: "hp-1", pathway: "High Performance", pathwayColor: "#00c9a7", name: "High Performance 1", shortName: "HP1", completion: 98, skills: 35, drills: 40, assessmentGates: 10, missingItems: 0, lastUpdated: "1d ago", status: "ready", goal: "Elite baseline dominance", skillFocus: "Weapons development", competitionFocus: "Pattern mastery", fitnessSupport: "Athletic profiling" },
      { id: "hp-2", pathway: "High Performance", pathwayColor: "#00c9a7", name: "High Performance 2", shortName: "HP2", completion: 85, skills: 38, drills: 44, assessmentGates: 10, missingItems: 1, lastUpdated: "2d ago", status: "custom", goal: "Tour-level tactical systems", skillFocus: "Situational decision-making", competitionFocus: "Scouting & game plans", fitnessSupport: "Periodization" },
      { id: "hp-3", pathway: "High Performance", pathwayColor: "#00c9a7", name: "High Performance 3", shortName: "HP3", completion: 60, skills: 40, drills: 48, assessmentGates: 12, missingItems: 3, lastUpdated: "5d ago", status: "needs-review", goal: "Professional transition readiness", skillFocus: "Full game system", competitionFocus: "Pro circuit preparation", fitnessSupport: "Elite S&C" },
    ],
  },
];

export const ALL_LEVELS: CurriculumLevel[] = PATHWAYS.flatMap(p => p.levels);

export const LEVEL_ORDER = ALL_LEVELS.map(l => l.id);

export function getNextLevel(id: string): CurriculumLevel | null {
  const idx = LEVEL_ORDER.indexOf(id);
  if (idx === -1 || idx === LEVEL_ORDER.length - 1) return null;
  return ALL_LEVELS[idx + 1];
}

export function getPrevLevel(id: string): CurriculumLevel | null {
  const idx = LEVEL_ORDER.indexOf(id);
  if (idx <= 0) return null;
  return ALL_LEVELS[idx - 1];
}

export function getLevelById(id: string): CurriculumLevel | null {
  return ALL_LEVELS.find(l => l.id === id) ?? null;
}

export const STATUS_LABEL: Record<LevelStatus, string> = {
  ready: "Ready",
  "needs-review": "Needs Review",
  incomplete: "Incomplete",
  custom: "Custom",
};
