/*
 * DonnaPanel — AnglesOS brand
 * Reusable DONNA AI assistant right panel
 */
import { useState } from "react";
import { Sparkles, Send, ChevronRight } from "lucide-react";
import { cn } from "@/lib/utils";

interface DonnaOption {
  label: string;
  onClick?: () => void;
  highlight?: boolean;
}

interface Props {
  greeting: string;
  subtext?: string;
  options?: DonnaOption[];
  inputPlaceholder?: string;
  onSend?: (val: string) => void;
  children?: React.ReactNode;
  badge?: string;
}

export default function DonnaPanel({
  greeting,
  subtext,
  options = [],
  inputPlaceholder = "Ask DONNA anything...",
  onSend,
  children,
  badge,
}: Props) {
  const [input, setInput] = useState("");
  const [sent, setSent] = useState(false);

  const handleSend = () => {
    if (!input.trim()) return;
    onSend?.(input);
    setSent(true);
    setTimeout(() => setSent(false), 2000);
    setInput("");
  };

  return (
    <div className="flex flex-col h-full">
      {/* Header */}
      <div
        className="px-4 py-4 shrink-0"
        style={{ borderBottom: "1px solid rgba(0,201,167,0.08)" }}
      >
        <div className="flex items-center gap-2.5 mb-3">
          <div
            className="w-8 h-8 rounded-full flex items-center justify-center font-bold text-sm shrink-0 animate-donna-blink"
            style={{
              background: "linear-gradient(135deg,#00c9a7,#00a88a)",
              color: "#050d0b",
            }}
          >
            D
          </div>
          <div>
            <div className="text-xs font-bold" style={{ color: "#00c9a7" }}>
              DONNA
            </div>
            <div className="text-[10px]" style={{ color: "#3a6660" }}>
              AI Curriculum Assistant
            </div>
          </div>
          {badge && (
            <span
              className="ml-auto text-[10px] font-semibold px-2 py-0.5 rounded-full"
              style={{ background: "rgba(0,201,167,0.12)", color: "#00c9a7", border: "1px solid rgba(0,201,167,0.2)" }}
            >
              {badge}
            </span>
          )}
        </div>

        {/* Greeting bubble */}
        <div
          className="rounded-xl px-3.5 py-3 text-sm leading-relaxed animate-stagger-in"
          style={{
            background: "rgba(0,201,167,0.07)",
            border: "1px solid rgba(0,201,167,0.15)",
            color: "#c8e0dc",
          }}
        >
          <Sparkles size={12} className="inline mr-1.5 mb-0.5" style={{ color: "#00c9a7" }} />
          {greeting}
          {subtext && (
            <p className="mt-1.5 text-xs" style={{ color: "#5a7a76" }}>
              {subtext}
            </p>
          )}
        </div>
      </div>

      {/* Options */}
      {options.length > 0 && (
        <div
          className="px-4 py-3 space-y-1.5 shrink-0"
          style={{ borderBottom: "1px solid rgba(0,201,167,0.06)" }}
        >
          {options.map((opt, i) => (
            <button
              key={i}
              onClick={opt.onClick}
              className={cn(
                "w-full flex items-center gap-2 px-3 py-2.5 rounded-lg text-left text-xs font-medium transition-all duration-150 animate-stagger-in",
                `delay-${Math.min(i * 50, 300)}`
              )}
              style={
                opt.highlight
                  ? {
                      background: "rgba(0,201,167,0.12)",
                      color: "#00c9a7",
                      border: "1px solid rgba(0,201,167,0.25)",
                    }
                  : {
                      background: "rgba(255,255,255,0.03)",
                      color: "#a0b8b4",
                      border: "1px solid rgba(255,255,255,0.06)",
                    }
              }
              onMouseEnter={(e) => {
                (e.currentTarget as HTMLElement).style.background = "rgba(0,201,167,0.1)";
                (e.currentTarget as HTMLElement).style.color = "#00c9a7";
                (e.currentTarget as HTMLElement).style.borderColor = "rgba(0,201,167,0.2)";
              }}
              onMouseLeave={(e) => {
                if (opt.highlight) {
                  (e.currentTarget as HTMLElement).style.background = "rgba(0,201,167,0.12)";
                  (e.currentTarget as HTMLElement).style.color = "#00c9a7";
                  (e.currentTarget as HTMLElement).style.borderColor = "rgba(0,201,167,0.25)";
                } else {
                  (e.currentTarget as HTMLElement).style.background = "rgba(255,255,255,0.03)";
                  (e.currentTarget as HTMLElement).style.color = "#a0b8b4";
                  (e.currentTarget as HTMLElement).style.borderColor = "rgba(255,255,255,0.06)";
                }
              }}
            >
              <ChevronRight size={11} className="shrink-0 opacity-60" />
              {opt.label}
            </button>
          ))}
        </div>
      )}

      {/* Extra content slot */}
      {children && (
        <div className="px-4 py-3 flex-1 overflow-y-auto">{children}</div>
      )}

      {/* Input */}
      <div
        className="px-4 py-3 shrink-0 mt-auto"
        style={{ borderTop: "1px solid rgba(0,201,167,0.08)" }}
      >
        <div
          className="flex items-center gap-2 rounded-lg px-3 py-2"
          style={{
            background: "rgba(0,201,167,0.05)",
            border: "1px solid rgba(0,201,167,0.15)",
          }}
        >
          <input
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && handleSend()}
            placeholder={inputPlaceholder}
            className="flex-1 bg-transparent text-xs outline-none placeholder:opacity-40"
            style={{ color: "#c8e0dc" }}
          />
          <button
            onClick={handleSend}
            className="shrink-0 transition-all duration-150"
            style={{ color: input.trim() ? "#00c9a7" : "#2a4a46" }}
          >
            <Send size={13} />
          </button>
        </div>
        {sent && (
          <p className="text-[10px] mt-1.5 text-center animate-fade-in" style={{ color: "#00c9a7" }}>
            ✓ DONNA received your message
          </p>
        )}
      </div>
    </div>
  );
}
