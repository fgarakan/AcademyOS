/*
 * AppLayout — AnglesOS Brand
 * Dark forest-green bg, teal accent, Inter font
 * Persistent sidebar + scrollable main + optional DONNA right panel
 */
import { useLocation } from "wouter";
import { cn } from "@/lib/utils";
import {
  LayoutGrid, Layers, Zap, Dumbbell, Activity,
  AlertTriangle, GitBranch, ClipboardCheck, Search,
  Sparkles, ChevronRight
} from "lucide-react";

const NAV = [
  { icon: LayoutGrid,     label: "Curriculum Map",   path: "/" },
  { icon: Layers,         label: "Guided Review",    path: "/guided-review" },
  { icon: Zap,            label: "Level Builder",    path: "/level-builder" },
  { icon: Dumbbell,       label: "Add Drill",        path: "/add-drill" },
  { icon: Activity,       label: "Add Fitness",      path: "/add-fitness" },
  { icon: AlertTriangle,  label: "Impact Preview",   path: "/impact-preview" },
  { icon: GitBranch,      label: "Relationship Map", path: "/relationship-map" },
  { icon: ClipboardCheck, label: "Change Queue",     path: "/change-queue" },
  { icon: Search,         label: "Jump to Level",    path: "/jump-to-level" },
  { icon: Sparkles,       label: "First-Time Setup", path: "/empty-state" },
];

interface Props {
  children: React.ReactNode;
  donnaPanel?: React.ReactNode;
  title?: string;
  subtitle?: string;
  headerRight?: React.ReactNode;
}

export default function AppLayout({ children, donnaPanel, title, subtitle, headerRight }: Props) {
  const [location, navigate] = useLocation();

  return (
    <div className="flex h-screen overflow-hidden" style={{ background: "#0a0f0e" }}>
      {/* ── Sidebar ── */}
      <aside
        className="flex flex-col w-[220px] shrink-0"
        style={{
          background: "#0d1614",
          borderRight: "1px solid rgba(0,201,167,0.08)",
        }}
      >
        {/* Logo */}
        <div
          className="px-5 py-4 flex items-center gap-3"
          style={{ borderBottom: "1px solid rgba(0,201,167,0.08)" }}
        >
          <div
            className="w-8 h-8 rounded-lg flex items-center justify-center text-xs font-bold tracking-wider shrink-0"
            style={{ background: "linear-gradient(135deg,#00c9a7,#00a88a)", color: "#050d0b" }}
          >
            A
          </div>
          <div>
            <div
              className="text-xs font-bold tracking-[0.18em] uppercase"
              style={{ color: "#e8f0ee", letterSpacing: "0.18em" }}
            >
              AnglesOS
            </div>
            <div className="text-[10px] mt-0.5" style={{ color: "#3a6660" }}>
              Curriculum Builder
            </div>
          </div>
        </div>

        {/* Nav */}
        <nav className="flex-1 overflow-y-auto py-3 px-2 space-y-0.5">
          <div className="px-3 mb-2">
            <span
              className="text-[10px] font-semibold uppercase tracking-[0.14em]"
              style={{ color: "#2a4a46" }}
            >
              Screens
            </span>
          </div>
          {NAV.map((item) => {
            const active = location === item.path;
            return (
              <button
                key={item.path}
                onClick={() => navigate(item.path)}
                className="w-full flex items-center gap-2.5 px-3 py-2 rounded-md text-left transition-all duration-150 group"
                style={
                  active
                    ? {
                        background: "rgba(0,201,167,0.12)",
                        color: "#00c9a7",
                        borderLeft: "2px solid #00c9a7",
                      }
                    : {
                        color: "#5a7a76",
                        borderLeft: "2px solid transparent",
                      }
                }
                onMouseEnter={(e) => {
                  if (!active) {
                    (e.currentTarget as HTMLElement).style.background = "rgba(0,201,167,0.05)";
                    (e.currentTarget as HTMLElement).style.color = "#a0c8c4";
                  }
                }}
                onMouseLeave={(e) => {
                  if (!active) {
                    (e.currentTarget as HTMLElement).style.background = "transparent";
                    (e.currentTarget as HTMLElement).style.color = "#5a7a76";
                  }
                }}
              >
                <item.icon size={13} className="shrink-0" />
                <span className="text-xs font-medium truncate">{item.label}</span>
                {active && <ChevronRight size={11} className="ml-auto opacity-60" />}
              </button>
            );
          })}
        </nav>

        {/* DONNA badge */}
        <div
          className="px-3 py-4"
          style={{ borderTop: "1px solid rgba(0,201,167,0.08)" }}
        >
          <div
            className="flex items-center gap-2.5 px-3 py-2.5 rounded-lg"
            style={{
              background: "rgba(0,201,167,0.07)",
              border: "1px solid rgba(0,201,167,0.15)",
            }}
          >
            <div
              className="w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold shrink-0 animate-donna-blink"
              style={{
                background: "linear-gradient(135deg,#00c9a7,#00a88a)",
                color: "#050d0b",
                fontSize: "10px",
              }}
            >
              D
            </div>
            <div className="flex-1 min-w-0">
              <div className="text-xs font-semibold" style={{ color: "#00c9a7" }}>
                DONNA
              </div>
              <div className="text-[10px]" style={{ color: "#3a6660" }}>
                AI Assistant · Active
              </div>
            </div>
            <div
              className="w-1.5 h-1.5 rounded-full shrink-0"
              style={{
                background: "#00c9a7",
                boxShadow: "0 0 6px #00c9a7",
              }}
            />
          </div>
        </div>
      </aside>

      {/* ── Main area ── */}
      <div className="flex flex-1 overflow-hidden">
        <main className="flex-1 flex flex-col overflow-hidden">
          {/* Top bar */}
          {(title || headerRight) && (
            <div
              className="shrink-0 px-6 py-4 flex items-center justify-between"
              style={{
                background: "rgba(10,15,14,0.95)",
                borderBottom: "1px solid rgba(0,201,167,0.08)",
                backdropFilter: "blur(12px)",
              }}
            >
              <div>
                {title && (
                  <h1
                    className="text-lg font-bold tracking-tight"
                    style={{ color: "#e8f0ee" }}
                  >
                    {title}
                  </h1>
                )}
                {subtitle && (
                  <p className="text-xs mt-0.5" style={{ color: "#3a6660" }}>
                    {subtitle}
                  </p>
                )}
              </div>
              {headerRight && <div>{headerRight}</div>}
            </div>
          )}
          <div className="flex-1 overflow-y-auto p-6">{children}</div>
        </main>

        {/* ── DONNA Panel ── */}
        {donnaPanel && (
          <aside
            className="w-[280px] shrink-0 overflow-y-auto donna-panel animate-slide-in-right"
            style={{
              background: "#0d1614",
              borderLeft: "1px solid rgba(0,201,167,0.08)",
              borderTop: "2px solid #00c9a7",
            }}
          >
            {donnaPanel}
          </aside>
        )}
      </div>
    </div>
  );
}
