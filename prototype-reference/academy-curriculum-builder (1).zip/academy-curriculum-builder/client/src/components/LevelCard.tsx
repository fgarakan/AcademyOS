/*
 * LevelCard — AnglesOS brand
 * Animated level card with progress bar, status chip, and hover glow
 */
import { useState, useEffect } from "react";
import { cn } from "@/lib/utils";
import { type CurriculumLevel, STATUS_LABEL } from "@/lib/curriculumData";
import { AlertCircle, Clock, Target, Layers, CheckSquare } from "lucide-react";

interface Props {
  level: CurriculumLevel;
  selected?: boolean;
  onClick?: () => void;
  animDelay?: number;
  compact?: boolean;
}

const STATUS_STYLE: Record<string, { bg: string; color: string; border: string }> = {
  ready:          { bg: "rgba(0,201,167,0.1)",   color: "#00c9a7", border: "rgba(0,201,167,0.25)" },
  "needs-review": { bg: "rgba(255,170,0,0.1)",   color: "#ffaa00", border: "rgba(255,170,0,0.25)" },
  incomplete:     { bg: "rgba(224,82,82,0.1)",   color: "#e05252", border: "rgba(224,82,82,0.25)" },
  custom:         { bg: "rgba(130,100,220,0.1)", color: "#a07de0", border: "rgba(130,100,220,0.25)" },
};

export default function LevelCard({ level, selected, onClick, animDelay = 0, compact = false }: Props) {
  const [barWidth, setBarWidth] = useState(0);
  const statusStyle = STATUS_STYLE[level.status];

  // Animate progress bar on mount
  useEffect(() => {
    const t = setTimeout(() => setBarWidth(level.completion), animDelay + 200);
    return () => clearTimeout(t);
  }, [level.completion, animDelay]);

  return (
    <div
      onClick={onClick}
      className={cn(
        "rounded-xl cursor-pointer transition-all duration-200 animate-stagger-in",
        compact ? "p-3" : "p-4"
      )}
      style={{
        animationDelay: `${animDelay}ms`,
        background: selected ? "rgba(0,201,167,0.08)" : "#111a18",
        border: selected
          ? "1px solid rgba(0,201,167,0.4)"
          : "1px solid rgba(0,201,167,0.08)",
        boxShadow: selected
          ? "0 0 0 1px rgba(0,201,167,0.3), 0 0 24px rgba(0,201,167,0.12)"
          : "none",
      }}
      onMouseEnter={(e) => {
        if (!selected) {
          (e.currentTarget as HTMLElement).style.transform = "translateY(-2px)";
          (e.currentTarget as HTMLElement).style.borderColor = "rgba(0,201,167,0.2)";
          (e.currentTarget as HTMLElement).style.boxShadow =
            "0 8px 32px rgba(0,0,0,0.4), 0 0 0 1px rgba(0,201,167,0.15)";
        }
      }}
      onMouseLeave={(e) => {
        if (!selected) {
          (e.currentTarget as HTMLElement).style.transform = "translateY(0)";
          (e.currentTarget as HTMLElement).style.borderColor = "rgba(0,201,167,0.08)";
          (e.currentTarget as HTMLElement).style.boxShadow = "none";
        }
      }}
    >
      {/* Header row */}
      <div className="flex items-start justify-between mb-3">
        <div className="flex items-center gap-2">
          <div
            className="w-2 h-2 rounded-full shrink-0"
            style={{ background: level.pathwayColor, boxShadow: `0 0 6px ${level.pathwayColor}60` }}
          />
          <span className="text-sm font-semibold" style={{ color: "#e8f0ee" }}>
            {level.name}
          </span>
        </div>
        <span
          className="text-[10px] font-semibold px-2 py-0.5 rounded"
          style={{
            background: statusStyle.bg,
            color: statusStyle.color,
            border: `1px solid ${statusStyle.border}`,
            letterSpacing: "0.04em",
            textTransform: "uppercase",
          }}
        >
          {STATUS_LABEL[level.status]}
        </span>
      </div>

      {/* Progress bar */}
      <div className="mb-3">
        <div className="flex items-center justify-between mb-1">
          <span className="text-[10px] font-medium" style={{ color: "#3a6660" }}>
            Readiness
          </span>
          <span
            className="text-[11px] font-bold"
            style={{ color: level.completion >= 90 ? "#00c9a7" : level.completion >= 60 ? "#ffaa00" : "#e05252", fontFamily: "monospace" }}
          >
            {level.completion}%
          </span>
        </div>
        <div
          className="h-1.5 rounded-full overflow-hidden"
          style={{ background: "rgba(255,255,255,0.05)" }}
        >
          <div
            className="h-full rounded-full rail-fill"
            style={{
              width: `${barWidth}%`,
              background:
                level.completion >= 90
                  ? "linear-gradient(90deg,#00c9a7,#00e5c4)"
                  : level.completion >= 60
                  ? "linear-gradient(90deg,#ff9500,#ffb340)"
                  : "linear-gradient(90deg,#e05252,#ff6b6b)",
            }}
          />
        </div>
      </div>

      {/* Stats row */}
      {!compact && (
        <div className="grid grid-cols-3 gap-2 mb-3">
          {[
            { icon: Target, val: level.skills, label: "Skills" },
            { icon: Layers, val: level.drills, label: "Drills" },
            { icon: CheckSquare, val: level.assessmentGates, label: "Gates" },
          ].map(({ icon: Icon, val, label }) => (
            <div
              key={label}
              className="rounded-lg px-2 py-1.5 text-center"
              style={{ background: "rgba(255,255,255,0.03)" }}
            >
              <div className="text-sm font-bold" style={{ color: "#e8f0ee", fontFamily: "monospace" }}>
                {val}
              </div>
              <div className="text-[9px] uppercase tracking-wider" style={{ color: "#3a6660" }}>
                {label}
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Footer */}
      <div className="flex items-center justify-between">
        {level.missingItems > 0 ? (
          <div className="flex items-center gap-1">
            <AlertCircle size={10} style={{ color: "#e05252" }} />
            <span className="text-[10px]" style={{ color: "#e05252" }}>
              {level.missingItems} missing
            </span>
          </div>
        ) : (
          <span className="text-[10px]" style={{ color: "#3a6660" }}>
            Complete
          </span>
        )}
        <div className="flex items-center gap-1">
          <Clock size={9} style={{ color: "#3a6660" }} />
          <span className="text-[10px]" style={{ color: "#3a6660" }}>
            {level.lastUpdated}
          </span>
        </div>
      </div>
    </div>
  );
}
