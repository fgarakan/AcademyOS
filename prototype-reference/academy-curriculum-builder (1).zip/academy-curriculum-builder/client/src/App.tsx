import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import CurriculumMap from "./pages/CurriculumMap";
import GuidedReview from "./pages/GuidedReview";
import LevelBuilder from "./pages/LevelBuilder";
import AddDrill from "./pages/AddDrill";
import AddFitness from "./pages/AddFitness";
import ImpactPreview from "./pages/ImpactPreview";
import RelationshipMap from "./pages/RelationshipMap";
import ChangeQueue from "./pages/ChangeQueue";
import JumpToLevel from "./pages/JumpToLevel";
import EmptyState from "./pages/EmptyState";
import NotFound from "./pages/NotFound";

function Router() {
  return (
    <Switch>
      <Route path="/" component={CurriculumMap} />
      <Route path="/guided-review" component={GuidedReview} />
      <Route path="/level-builder" component={LevelBuilder} />
      <Route path="/add-drill" component={AddDrill} />
      <Route path="/add-fitness" component={AddFitness} />
      <Route path="/impact-preview" component={ImpactPreview} />
      <Route path="/relationship-map" component={RelationshipMap} />
      <Route path="/change-queue" component={ChangeQueue} />
      <Route path="/jump-to-level" component={JumpToLevel} />
      <Route path="/empty-state" component={EmptyState} />
      <Route component={NotFound} />
    </Switch>
  );
}

export default function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider defaultTheme="dark">
        <TooltipProvider>
          <Toaster />
          <Router />
        </TooltipProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}
