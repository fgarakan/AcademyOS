/*
 * Screen 3 — Level Builder Detail (Orange Ball 2 example)
 * AnglesOS brand: full level editing view with DONNA panel
 */
import { useState } from "react";
import { useLocation } from "wouter";
import AppLayout from "@/components/AppLayout";
import DonnaPanel from "@/components/DonnaPanel";
import { Plus, Edit3, ArrowUpDown, Sparkles, ChevronRight, Target, Dumbbell, Activity, CheckSquare, Flag } from "lucide-react";
import { toast } from "sonner";

interface SectionItem {
  id: string;
  title: string;
  desc: string;
  tag?: string;
}

const SKILL_PATH: SectionItem[] = [
  { id: "s1", title: "Forehand Spacing", desc: "Contact point control on wide balls", tag: "Core" },
  { id: "s2", title: "Recovery Movement", desc: "Split-step timing after wide ball", tag: "Movement" },
  { id: "s3", title: "Crosscourt Pattern", desc: "Directional control under pressure", tag: "Tactical" },
  { id: "s4", title: "Balance After Contact", desc: "Stable base through the swing", tag: "Technical" },
];

const COMPETITION_PATH: SectionItem[] = [
  { id: "c1", title: "Open Court Pattern", desc: "Create and attack open court", tag: "Pattern" },
  { id: "c2", title: "Wide Ball Rally", desc: "Sustain rally after being pulled wide", tag: "Rally" },
];

const FITNESS: SectionItem[] = [
  { id: "f1", title: "Low Contact Mobility Prep", desc: "Hip & ankle mobility for low forehands", tag: "Mobility" },
  { id: "f2", title: "Lateral Speed Ladder", desc: "First-step quickness for wide balls", tag: "Speed" },
];

const ASSESSMENTS: SectionItem[] = [
  { id: "a1", title: "Wide Ball Recovery Gate", desc: "Player recovers to neutral after wide ball 8/10 times", tag: "Gate 1" },
  { id: "a2", title: "Crosscourt Rally Gate", desc: "Sustain 10-ball crosscourt rally", tag: "Gate 2" },
];

const MISSIONS: SectionItem[] = [
  { id: "m1", title: "Crosscourt Builder", desc: "Complete 5 sessions focusing on crosscourt patterns", tag: "Mission" },
  { id: "m2", title: "Wide Ball Warrior", desc: "Demonstrate recovery in match-play 3 times", tag: "Mission" },
];

function SectionBlock({
  title,
  icon: Icon,
  items,
  color,
  onAdd,
  onAskDonna,
  animBase = 0,
}: {
  title: string;
  icon: React.ElementType;
  items: SectionItem[];
  color: string;
  onAdd: () => void;
  onAskDonna: () => void;
  animBase?: number;
}) {
  return (
    <div
      className="rounded-xl overflow-hidden animate-stagger-in"
      style={{
        background: "#111a18",
        border: "1px solid rgba(0,201,167,0.08)",
        animationDelay: `${animBase}ms`,
      }}
    >
      {/* Section header */}
      <div
        className="px-4 py-3 flex items-center justify-between"
        style={{ borderBottom: "1px solid rgba(255,255,255,0.04)" }}
      >
        <div className="flex items-center gap-2">
          <Icon size={13} style={{ color }} />
          <span className="text-xs font-bold uppercase tracking-widest" style={{ color: "#e8f0ee" }}>
            {title}
          </span>
          <span
            className="text-[10px] font-semibold px-1.5 py-0.5 rounded"
            style={{ background: "rgba(255,255,255,0.05)", color: "#5a7a76" }}
          >
            {items.length}
          </span>
        </div>
        <div className="flex items-center gap-1.5">
          <button
            onClick={onAskDonna}
            className="flex items-center gap-1 px-2 py-1 rounded text-[10px] font-medium transition-all duration-150"
            style={{ background: "rgba(0,201,167,0.07)", color: "#00c9a7", border: "1px solid rgba(0,201,167,0.15)" }}
            onMouseEnter={e => { (e.currentTarget as HTMLElement).style.background = "rgba(0,201,167,0.14)"; }}
            onMouseLeave={e => { (e.currentTarget as HTMLElement).style.background = "rgba(0,201,167,0.07)"; }}
          >
            <Sparkles size={9} /> Ask DONNA
          </button>
          <button
            onClick={onAdd}
            className="flex items-center gap-1 px-2 py-1 rounded text-[10px] font-medium transition-all duration-150"
            style={{ background: "rgba(255,255,255,0.04)", color: "#a0b8b4", border: "1px solid rgba(255,255,255,0.06)" }}
            onMouseEnter={e => { (e.currentTarget as HTMLElement).style.background = "rgba(255,255,255,0.08)"; (e.currentTarget as HTMLElement).style.color = "#e8f0ee"; }}
            onMouseLeave={e => { (e.currentTarget as HTMLElement).style.background = "rgba(255,255,255,0.04)"; (e.currentTarget as HTMLElement).style.color = "#a0b8b4"; }}
          >
            <Plus size={9} /> Add
          </button>
        </div>
      </div>

      {/* Items */}
      <div className="divide-y" style={{ borderColor: "rgba(255,255,255,0.03)" }}>
        {items.map((item, i) => (
          <div
            key={item.id}
            className="px-4 py-3 flex items-center gap-3 group transition-all duration-150 animate-stagger-in"
            style={{
              animationDelay: `${animBase + i * 50}ms`,
            }}
            onMouseEnter={e => { (e.currentTarget as HTMLElement).style.background = "rgba(255,255,255,0.02)"; }}
            onMouseLeave={e => { (e.currentTarget as HTMLElement).style.background = "transparent"; }}
          >
            <div
              className="w-1.5 h-1.5 rounded-full shrink-0"
              style={{ background: color, opacity: 0.7 }}
            />
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2">
                <span className="text-sm font-medium" style={{ color: "#e8f0ee" }}>
                  {item.title}
                </span>
                {item.tag && (
                  <span
                    className="text-[9px] font-semibold px-1.5 py-0.5 rounded"
                    style={{ background: "rgba(255,255,255,0.05)", color: "#5a7a76", textTransform: "uppercase", letterSpacing: "0.06em" }}
                  >
                    {item.tag}
                  </span>
                )}
              </div>
              <p className="text-xs mt-0.5 truncate" style={{ color: "#3a6660" }}>
                {item.desc}
              </p>
            </div>
            <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity duration-150">
              <button
                onClick={() => toast.info(`Editing: ${item.title}`)}
                className="p-1 rounded transition-all duration-150"
                style={{ color: "#5a7a76" }}
                onMouseEnter={e => { (e.currentTarget as HTMLElement).style.color = "#00c9a7"; }}
                onMouseLeave={e => { (e.currentTarget as HTMLElement).style.color = "#5a7a76"; }}
              >
                <Edit3 size={11} />
              </button>
              <button
                onClick={() => toast.info(`Reordering: ${item.title}`)}
                className="p-1 rounded transition-all duration-150"
                style={{ color: "#5a7a76" }}
                onMouseEnter={e => { (e.currentTarget as HTMLElement).style.color = "#00c9a7"; }}
                onMouseLeave={e => { (e.currentTarget as HTMLElement).style.color = "#5a7a76"; }}
              >
                <ArrowUpDown size={11} />
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

export default function LevelBuilder() {
  const [, navigate] = useLocation();

  return (
    <AppLayout
      title="Orange Ball 2"
      subtitle="Level Builder · Tactical awareness & recovery movement"
      headerRight={
        <div className="flex items-center gap-2">
          <button
            onClick={() => navigate("/impact-preview")}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium transition-all duration-150"
            style={{ background: "rgba(255,170,0,0.08)", color: "#ffaa00", border: "1px solid rgba(255,170,0,0.2)" }}
            onMouseEnter={e => { (e.currentTarget as HTMLElement).style.background = "rgba(255,170,0,0.14)"; }}
            onMouseLeave={e => { (e.currentTarget as HTMLElement).style.background = "rgba(255,170,0,0.08)"; }}
          >
            Preview Impact
          </button>
          <button
            onClick={() => navigate("/guided-review")}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all duration-150"
            style={{ background: "#00c9a7", color: "#050d0b" }}
            onMouseEnter={e => { (e.currentTarget as HTMLElement).style.background = "#00e5c4"; }}
            onMouseLeave={e => { (e.currentTarget as HTMLElement).style.background = "#00c9a7"; }}
          >
            Back to Review <ChevronRight size={12} />
          </button>
        </div>
      }
      donnaPanel={
        <DonnaPanel
          greeting="You're editing Orange Ball 2. What would you like to change?"
          subtext="Nothing is applied until you approve."
          options={[
            { label: "Add a skill", onClick: () => toast.info("Opening skill editor…"), highlight: true },
            { label: "Add a drill", onClick: () => navigate("/add-drill") },
            { label: "Add an assessment gate", onClick: () => toast.info("Opening gate editor…") },
            { label: "Add a fitness exercise", onClick: () => navigate("/add-fitness") },
            { label: "Add a player mission", onClick: () => toast.info("Opening mission editor…") },
            { label: "Rewrite this level", onClick: () => toast.info("DONNA is drafting a rewrite…") },
            { label: "Skip to another level", onClick: () => navigate("/jump-to-level") },
          ]}
        />
      }
    >
      {/* Level meta */}
      <div
        className="rounded-xl px-5 py-4 mb-5 flex items-center gap-6 animate-stagger-in"
        style={{
          background: "rgba(0,201,167,0.05)",
          border: "1px solid rgba(0,201,167,0.12)",
        }}
      >
        <div>
          <p className="text-[10px] font-semibold uppercase tracking-widest mb-1" style={{ color: "#3a6660" }}>Level Goal</p>
          <p className="text-sm font-medium" style={{ color: "#e8f0ee" }}>Build tactical awareness in open-court situations</p>
        </div>
        <div
          className="w-px h-10 shrink-0"
          style={{ background: "rgba(0,201,167,0.15)" }}
        />
        <div>
          <p className="text-[10px] font-semibold uppercase tracking-widest mb-1" style={{ color: "#3a6660" }}>Development Intent</p>
          <p className="text-sm" style={{ color: "#c8e0dc" }}>Players learn to recover and redirect after being pulled wide</p>
        </div>
        <div
          className="w-px h-10 shrink-0"
          style={{ background: "rgba(0,201,167,0.15)" }}
        />
        <div>
          <p className="text-[10px] font-semibold uppercase tracking-widest mb-1" style={{ color: "#3a6660" }}>Evidence for Level-Up</p>
          <p className="text-sm" style={{ color: "#c8e0dc" }}>Pass 2 assessment gates + complete 1 player mission</p>
        </div>
      </div>

      {/* Sections grid */}
      <div className="grid grid-cols-2 gap-4">
        <SectionBlock
          title="Skill Path"
          icon={Target}
          items={SKILL_PATH}
          color="#00c9a7"
          onAdd={() => toast.info("Add a new skill")}
          onAskDonna={() => navigate("/add-drill")}
          animBase={100}
        />
        <SectionBlock
          title="Competition Path"
          icon={Flag}
          items={COMPETITION_PATH}
          color="#ff9500"
          onAdd={() => toast.info("Add a competition drill")}
          onAskDonna={() => navigate("/add-drill")}
          animBase={150}
        />
        <SectionBlock
          title="Fitness Support"
          icon={Activity}
          items={FITNESS}
          color="#a07de0"
          onAdd={() => navigate("/add-fitness")}
          onAskDonna={() => navigate("/add-fitness")}
          animBase={200}
        />
        <SectionBlock
          title="Assessment Gates"
          icon={CheckSquare}
          items={ASSESSMENTS}
          color="#ffaa00"
          onAdd={() => toast.info("Add an assessment gate")}
          onAskDonna={() => toast.info("DONNA is suggesting assessment criteria…")}
          animBase={250}
        />
      </div>

      {/* Player Missions */}
      <div className="mt-4">
        <SectionBlock
          title="Player Missions"
          icon={Dumbbell}
          items={MISSIONS}
          color="#e05252"
          onAdd={() => toast.info("Add a player mission")}
          onAskDonna={() => toast.info("DONNA is creating a mission…")}
          animBase={300}
        />
      </div>
    </AppLayout>
  );
}
