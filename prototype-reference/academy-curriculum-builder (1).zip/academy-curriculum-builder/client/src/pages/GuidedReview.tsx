/*
 * Screen 2 — Guided Review Mode
 * AnglesOS brand: DONNA walks user through levels one at a time
 * Animated progress rail, level summary, skip/jump controls
 */
import { useState } from "react";
import { useLocation } from "wouter";
import AppLayout from "@/components/AppLayout";
import DonnaPanel from "@/components/DonnaPanel";
import { ALL_LEVELS, LEVEL_ORDER, getLevelById, getNextLevel, getPrevLevel } from "@/lib/curriculumData";
import { ChevronRight, ChevronLeft, SkipForward, Zap, CheckCircle, Edit3, ArrowRight } from "lucide-react";
import { toast } from "sonner";

const SECTION_LABELS = [
  { key: "goal", label: "Level Goal" },
  { key: "skillFocus", label: "Skill Focus" },
  { key: "competitionFocus", label: "Competition Focus" },
  { key: "fitnessSupport", label: "Fitness Support" },
];

export default function GuidedReview() {
  const [, navigate] = useLocation();
  const [currentId, setCurrentId] = useState("red-1");
  const [animKey, setAnimKey] = useState(0);
  const [action, setAction] = useState<string | null>(null);

  const level = getLevelById(currentId)!;
  const next = getNextLevel(currentId);
  const prev = getPrevLevel(currentId);
  const currentIdx = LEVEL_ORDER.indexOf(currentId);

  const goTo = (id: string) => {
    setAction(null);
    setCurrentId(id);
    setAnimKey(k => k + 1);
  };

  const handleAction = (act: string) => {
    setAction(act);
    if (act === "modify") {
      setTimeout(() => navigate("/level-builder"), 400);
    } else if (act === "keep" || act === "skip") {
      if (next) goTo(next.id);
      else toast.success("Curriculum review complete!");
    }
  };

  return (
    <AppLayout
      title="Guided Review"
      subtitle={`Reviewing ${level.name} · ${currentIdx + 1} of ${LEVEL_ORDER.length}`}
      headerRight={
        <button
          onClick={() => navigate("/jump-to-level")}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium transition-all duration-150"
          style={{ background: "rgba(0,201,167,0.08)", color: "#00c9a7", border: "1px solid rgba(0,201,167,0.2)" }}
          onMouseEnter={e => { (e.currentTarget as HTMLElement).style.background = "rgba(0,201,167,0.14)"; }}
          onMouseLeave={e => { (e.currentTarget as HTMLElement).style.background = "rgba(0,201,167,0.08)"; }}
        >
          <Zap size={12} /> Jump to Level
        </button>
      }
      donnaPanel={
        <DonnaPanel
          greeting={`You're reviewing ${level.name}. What would you like to do?`}
          subtext="You can keep it, modify it, or skip to the next level. Nothing changes until you approve."
          options={[
            { label: "Keep as-is & continue", onClick: () => handleAction("keep"), highlight: true },
            { label: "Modify this level", onClick: () => handleAction("modify") },
            { label: "Skip this level", onClick: () => handleAction("skip") },
            { label: "Ask DONNA to improve it", onClick: () => toast.info("DONNA is analyzing this level…") },
          ]}
        />
      }
    >
      {/* Progress Rail */}
      <div
        className="mb-6 rounded-xl px-4 py-3 overflow-x-auto animate-stagger-in"
        style={{ background: "#111a18", border: "1px solid rgba(0,201,167,0.08)" }}
      >
        <div className="flex items-center gap-1 min-w-max">
          {ALL_LEVELS.map((lvl, i) => {
            const isCurrent = lvl.id === currentId;
            const isPast = i < currentIdx;
            return (
              <div key={lvl.id} className="flex items-center">
                <button
                  onClick={() => goTo(lvl.id)}
                  className="flex flex-col items-center gap-1 transition-all duration-200"
                  title={lvl.name}
                >
                  <div
                    className="w-7 h-7 rounded-full flex items-center justify-center text-[9px] font-bold transition-all duration-200"
                    style={{
                      background: isCurrent
                        ? "#00c9a7"
                        : isPast
                        ? "rgba(0,201,167,0.2)"
                        : "rgba(255,255,255,0.05)",
                      color: isCurrent ? "#050d0b" : isPast ? "#00c9a7" : "#3a6660",
                      boxShadow: isCurrent ? "0 0 12px rgba(0,201,167,0.5)" : "none",
                      transform: isCurrent ? "scale(1.15)" : "scale(1)",
                    }}
                  >
                    {lvl.shortName}
                  </div>
                </button>
                {i < ALL_LEVELS.length - 1 && (
                  <div
                    className="w-4 h-px mx-0.5"
                    style={{
                      background: isPast ? "rgba(0,201,167,0.4)" : "rgba(255,255,255,0.06)",
                    }}
                  />
                )}
              </div>
            );
          })}
        </div>
      </div>

      {/* Level content card */}
      <div
        key={animKey}
        className="rounded-xl overflow-hidden animate-scale-in"
        style={{ background: "#111a18", border: "1px solid rgba(0,201,167,0.1)" }}
      >
        {/* Level header */}
        <div
          className="px-6 py-5 flex items-center justify-between"
          style={{
            background: "rgba(0,201,167,0.05)",
            borderBottom: "1px solid rgba(0,201,167,0.1)",
          }}
        >
          <div className="flex items-center gap-3">
            <div
              className="w-3 h-3 rounded-full"
              style={{
                background: level.pathwayColor,
                boxShadow: `0 0 8px ${level.pathwayColor}80`,
              }}
            />
            <div>
              <h2 className="text-xl font-bold" style={{ color: "#e8f0ee" }}>
                {level.name}
              </h2>
              <p className="text-xs mt-0.5" style={{ color: "#3a6660" }}>
                {level.pathway} · {level.completion}% complete
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <div
              className="text-xs font-semibold px-2.5 py-1 rounded"
              style={{
                background:
                  level.status === "ready"
                    ? "rgba(0,201,167,0.1)"
                    : level.status === "needs-review"
                    ? "rgba(255,170,0,0.1)"
                    : "rgba(224,82,82,0.1)",
                color:
                  level.status === "ready"
                    ? "#00c9a7"
                    : level.status === "needs-review"
                    ? "#ffaa00"
                    : "#e05252",
                border: `1px solid ${
                  level.status === "ready"
                    ? "rgba(0,201,167,0.25)"
                    : level.status === "needs-review"
                    ? "rgba(255,170,0,0.25)"
                    : "rgba(224,82,82,0.25)"
                }`,
                textTransform: "uppercase",
                letterSpacing: "0.04em",
              }}
            >
              {level.status === "ready" ? "Ready" : level.status === "needs-review" ? "Needs Review" : "Incomplete"}
            </div>
          </div>
        </div>

        {/* Level summary sections */}
        <div className="p-6 grid grid-cols-2 gap-4">
          {SECTION_LABELS.map(({ key, label }, i) => (
            <div
              key={key}
              className="rounded-lg px-4 py-3 animate-stagger-in"
              style={{
                background: "rgba(255,255,255,0.02)",
                border: "1px solid rgba(255,255,255,0.05)",
                animationDelay: `${i * 60}ms`,
              }}
            >
              <p className="text-[10px] font-semibold uppercase tracking-widest mb-1" style={{ color: "#3a6660" }}>
                {label}
              </p>
              <p className="text-sm" style={{ color: "#c8e0dc" }}>
                {(level as unknown as Record<string, string>)[key]}
              </p>
            </div>
          ))}

          {/* Assessment gates */}
          <div
            className="rounded-lg px-4 py-3 animate-stagger-in"
            style={{
              background: "rgba(255,255,255,0.02)",
              border: "1px solid rgba(255,255,255,0.05)",
              animationDelay: "240ms",
            }}
          >
            <p className="text-[10px] font-semibold uppercase tracking-widest mb-1" style={{ color: "#3a6660" }}>
              Assessment Gates
            </p>
            <p className="text-sm font-bold" style={{ color: "#00c9a7", fontFamily: "monospace" }}>
              {level.assessmentGates} gates
            </p>
          </div>

          {/* Player missions */}
          <div
            className="rounded-lg px-4 py-3 animate-stagger-in"
            style={{
              background: "rgba(255,255,255,0.02)",
              border: "1px solid rgba(255,255,255,0.05)",
              animationDelay: "300ms",
            }}
          >
            <p className="text-[10px] font-semibold uppercase tracking-widest mb-1" style={{ color: "#3a6660" }}>
              Player Missions
            </p>
            <p className="text-sm" style={{ color: "#c8e0dc" }}>
              {level.skills} skill missions assigned
            </p>
          </div>
        </div>

        {/* Action buttons */}
        <div
          className="px-6 py-4 flex items-center gap-2 flex-wrap"
          style={{ borderTop: "1px solid rgba(255,255,255,0.04)" }}
        >
          <button
            onClick={() => handleAction("keep")}
            className="flex items-center gap-1.5 px-4 py-2 rounded-lg text-sm font-semibold transition-all duration-150"
            style={{
              background: action === "keep" ? "#00c9a7" : "rgba(0,201,167,0.1)",
              color: action === "keep" ? "#050d0b" : "#00c9a7",
              border: "1px solid rgba(0,201,167,0.25)",
            }}
            onMouseEnter={e => { (e.currentTarget as HTMLElement).style.background = "#00c9a7"; (e.currentTarget as HTMLElement).style.color = "#050d0b"; }}
            onMouseLeave={e => {
              if (action !== "keep") {
                (e.currentTarget as HTMLElement).style.background = "rgba(0,201,167,0.1)";
                (e.currentTarget as HTMLElement).style.color = "#00c9a7";
              }
            }}
          >
            <CheckCircle size={14} /> Keep as-is
          </button>
          <button
            onClick={() => handleAction("modify")}
            className="flex items-center gap-1.5 px-4 py-2 rounded-lg text-sm font-medium transition-all duration-150"
            style={{ background: "rgba(255,255,255,0.04)", color: "#a0b8b4", border: "1px solid rgba(255,255,255,0.08)" }}
            onMouseEnter={e => { (e.currentTarget as HTMLElement).style.background = "rgba(255,255,255,0.08)"; (e.currentTarget as HTMLElement).style.color = "#e8f0ee"; }}
            onMouseLeave={e => { (e.currentTarget as HTMLElement).style.background = "rgba(255,255,255,0.04)"; (e.currentTarget as HTMLElement).style.color = "#a0b8b4"; }}
          >
            <Edit3 size={14} /> Modify this level
          </button>
          <button
            onClick={() => handleAction("skip")}
            className="flex items-center gap-1.5 px-4 py-2 rounded-lg text-sm font-medium transition-all duration-150"
            style={{ background: "rgba(255,255,255,0.04)", color: "#a0b8b4", border: "1px solid rgba(255,255,255,0.08)" }}
            onMouseEnter={e => { (e.currentTarget as HTMLElement).style.background = "rgba(255,255,255,0.08)"; (e.currentTarget as HTMLElement).style.color = "#e8f0ee"; }}
            onMouseLeave={e => { (e.currentTarget as HTMLElement).style.background = "rgba(255,255,255,0.04)"; (e.currentTarget as HTMLElement).style.color = "#a0b8b4"; }}
          >
            <SkipForward size={14} /> Skip this level
          </button>
          <button
            onClick={() => navigate("/jump-to-level")}
            className="flex items-center gap-1.5 px-4 py-2 rounded-lg text-sm font-medium transition-all duration-150"
            style={{ background: "rgba(255,255,255,0.04)", color: "#a0b8b4", border: "1px solid rgba(255,255,255,0.08)" }}
            onMouseEnter={e => { (e.currentTarget as HTMLElement).style.background = "rgba(255,255,255,0.08)"; (e.currentTarget as HTMLElement).style.color = "#e8f0ee"; }}
            onMouseLeave={e => { (e.currentTarget as HTMLElement).style.background = "rgba(255,255,255,0.04)"; (e.currentTarget as HTMLElement).style.color = "#a0b8b4"; }}
          >
            <Zap size={14} /> Jump to another level
          </button>
          <button
            onClick={() => toast.info("DONNA is analyzing this level for improvements…")}
            className="flex items-center gap-1.5 px-4 py-2 rounded-lg text-sm font-medium transition-all duration-150 ml-auto"
            style={{ background: "rgba(0,201,167,0.06)", color: "#00c9a7", border: "1px solid rgba(0,201,167,0.15)" }}
            onMouseEnter={e => { (e.currentTarget as HTMLElement).style.background = "rgba(0,201,167,0.12)"; }}
            onMouseLeave={e => { (e.currentTarget as HTMLElement).style.background = "rgba(0,201,167,0.06)"; }}
          >
            Ask DONNA to improve it
          </button>
        </div>
      </div>

      {/* Prev / Next nav */}
      <div className="flex items-center justify-between mt-4">
        <button
          onClick={() => prev && goTo(prev.id)}
          disabled={!prev}
          className="flex items-center gap-1.5 px-3 py-2 rounded-lg text-xs font-medium transition-all duration-150 disabled:opacity-30"
          style={{ background: "rgba(255,255,255,0.04)", color: "#a0b8b4", border: "1px solid rgba(255,255,255,0.06)" }}
          onMouseEnter={e => { if (prev) (e.currentTarget as HTMLElement).style.background = "rgba(255,255,255,0.08)"; }}
          onMouseLeave={e => { (e.currentTarget as HTMLElement).style.background = "rgba(255,255,255,0.04)"; }}
        >
          <ChevronLeft size={13} /> {prev?.name ?? "Start"}
        </button>
        <span className="text-xs" style={{ color: "#3a6660" }}>
          {currentIdx + 1} / {LEVEL_ORDER.length}
        </span>
        <button
          onClick={() => next && goTo(next.id)}
          disabled={!next}
          className="flex items-center gap-1.5 px-3 py-2 rounded-lg text-xs font-medium transition-all duration-150 disabled:opacity-30"
          style={{ background: "rgba(0,201,167,0.08)", color: "#00c9a7", border: "1px solid rgba(0,201,167,0.2)" }}
          onMouseEnter={e => { if (next) (e.currentTarget as HTMLElement).style.background = "rgba(0,201,167,0.14)"; }}
          onMouseLeave={e => { (e.currentTarget as HTMLElement).style.background = "rgba(0,201,167,0.08)"; }}
        >
          {next?.name ?? "Finish"} <ArrowRight size={13} />
        </button>
      </div>
    </AppLayout>
  );
}
