/*
 * Screen 9 — Search / Jump to Level
 * AnglesOS brand: command palette with animated search results
 */
import { useState, useRef, useEffect } from "react";
import { useLocation } from "wouter";
import AppLayout from "@/components/AppLayout";
import { PATHWAYS, ALL_LEVELS } from "@/lib/curriculumData";
import { Search, Zap, ArrowRight, Target, Dumbbell, CheckSquare, Activity } from "lucide-react";

const QUICK_RESULTS = [
  { label: "Orange Ball 2", sub: "Needs 2 assessment gates", type: "level", color: "#ff9500", path: "/level-builder" },
  { label: "Green Ball 1", sub: "14 drills · Ready", type: "level", color: "#34c759", path: "/level-builder" },
  { label: "Forehand Preparation", sub: "Appears in 5 levels", type: "skill", color: "#00c9a7", path: "/level-builder" },
  { label: "Low Contact Mobility", sub: "Fitness support exercise · Orange 2, 3", type: "fitness", color: "#a07de0", path: "/add-fitness" },
  { label: "Wide Ball Recovery Builder", sub: "Draft drill · Pending approval", type: "drill", color: "#ffaa00", path: "/add-drill" },
  { label: "Rally Tolerance Gate", sub: "Assessment gate · Orange Ball 2", type: "assessment", color: "#e05252", path: "/level-builder" },
];

const TYPE_ICON: Record<string, React.ElementType> = {
  level: Zap,
  skill: Target,
  drill: Dumbbell,
  fitness: Activity,
  assessment: CheckSquare,
};

export default function JumpToLevel() {
  const [, navigate] = useLocation();
  const [query, setQuery] = useState("");
  const [focused, setFocused] = useState<number | null>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    inputRef.current?.focus();
  }, []);

  const filtered = query.trim()
    ? QUICK_RESULTS.filter(r =>
        r.label.toLowerCase().includes(query.toLowerCase()) ||
        r.sub.toLowerCase().includes(query.toLowerCase())
      )
    : QUICK_RESULTS;

  return (
    <AppLayout
      title="Jump to Level"
      subtitle="Search levels, skills, drills, gates, or exercises"
    >
      {/* Search input */}
      <div
        className="rounded-xl px-4 py-3 mb-5 flex items-center gap-3 animate-scale-in"
        style={{
          background: "#111a18",
          border: "1px solid rgba(0,201,167,0.2)",
          boxShadow: "0 0 32px rgba(0,201,167,0.06)",
        }}
      >
        <Search size={18} style={{ color: "#00c9a7", flexShrink: 0 }} />
        <input
          ref={inputRef}
          value={query}
          onChange={e => setQuery(e.target.value)}
          placeholder="Search levels, skills, drills, gates, or exercises…"
          className="flex-1 bg-transparent text-base outline-none placeholder:opacity-30"
          style={{ color: "#e8f0ee" }}
        />
        {query && (
          <button
            onClick={() => setQuery("")}
            className="text-xs px-2 py-1 rounded transition-all duration-150"
            style={{ color: "#5a7a76" }}
            onMouseEnter={e => { (e.currentTarget as HTMLElement).style.color = "#e8f0ee"; }}
            onMouseLeave={e => { (e.currentTarget as HTMLElement).style.color = "#5a7a76"; }}
          >
            Clear
          </button>
        )}
      </div>

      <div className="grid grid-cols-3 gap-5">
        {/* Left: Pathway quick-jump */}
        <div>
          <p className="text-[10px] font-semibold uppercase tracking-widest mb-3" style={{ color: "#3a6660" }}>
            Jump to Pathway
          </p>
          <div className="space-y-2">
            {PATHWAYS.map((pathway, i) => (
              <button
                key={pathway.id}
                onClick={() => navigate("/")}
                className="w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-left transition-all duration-150 animate-stagger-in"
                style={{
                  background: "#111a18",
                  border: "1px solid rgba(0,201,167,0.08)",
                  animationDelay: `${i * 50}ms`,
                }}
                onMouseEnter={e => {
                  (e.currentTarget as HTMLElement).style.background = "rgba(0,201,167,0.06)";
                  (e.currentTarget as HTMLElement).style.borderColor = "rgba(0,201,167,0.2)";
                }}
                onMouseLeave={e => {
                  (e.currentTarget as HTMLElement).style.background = "#111a18";
                  (e.currentTarget as HTMLElement).style.borderColor = "rgba(0,201,167,0.08)";
                }}
              >
                <div
                  className="w-2.5 h-2.5 rounded-full shrink-0"
                  style={{ background: pathway.color, boxShadow: `0 0 6px ${pathway.color}60` }}
                />
                <div className="flex-1 min-w-0">
                  <div className="text-sm font-medium" style={{ color: "#e8f0ee" }}>{pathway.name}</div>
                  <div className="text-[10px]" style={{ color: "#3a6660" }}>
                    {pathway.levels.length} levels
                  </div>
                </div>
                <ArrowRight size={12} style={{ color: "#3a6660" }} />
              </button>
            ))}
          </div>
        </div>

        {/* Right: Search results */}
        <div className="col-span-2">
          <p className="text-[10px] font-semibold uppercase tracking-widest mb-3" style={{ color: "#3a6660" }}>
            {query ? `Results for "${query}"` : "Quick Access"}
          </p>
          {filtered.length === 0 ? (
            <div
              className="rounded-xl px-5 py-8 text-center animate-scale-in"
              style={{ background: "#111a18", border: "1px solid rgba(0,201,167,0.08)" }}
            >
              <Search size={24} className="mx-auto mb-2" style={{ color: "#2a4a46" }} />
              <p className="text-sm" style={{ color: "#3a6660" }}>No results for "{query}"</p>
            </div>
          ) : (
            <div className="space-y-2">
              {filtered.map((result, i) => {
                const Icon = TYPE_ICON[result.type] ?? Zap;
                const isHovered = focused === i;
                return (
                  <button
                    key={result.label}
                    onClick={() => navigate(result.path)}
                    onMouseEnter={() => setFocused(i)}
                    onMouseLeave={() => setFocused(null)}
                    className="w-full flex items-center gap-3 px-4 py-3 rounded-xl text-left transition-all duration-150 animate-stagger-in"
                    style={{
                      background: isHovered ? "rgba(0,201,167,0.07)" : "#111a18",
                      border: isHovered ? "1px solid rgba(0,201,167,0.2)" : "1px solid rgba(0,201,167,0.06)",
                      animationDelay: `${i * 50}ms`,
                      transform: isHovered ? "translateX(4px)" : "translateX(0)",
                    }}
                  >
                    <div
                      className="w-8 h-8 rounded-lg flex items-center justify-center shrink-0"
                      style={{ background: `${result.color}15`, border: `1px solid ${result.color}30` }}
                    >
                      <Icon size={14} style={{ color: result.color }} />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="text-sm font-semibold" style={{ color: "#e8f0ee" }}>
                        {result.label}
                      </div>
                      <div className="text-xs mt-0.5" style={{ color: "#3a6660" }}>
                        {result.sub}
                      </div>
                    </div>
                    <div className="flex items-center gap-1.5">
                      <span
                        className="text-[9px] font-semibold px-1.5 py-0.5 rounded uppercase tracking-wider"
                        style={{ background: `${result.color}15`, color: result.color, border: `1px solid ${result.color}25` }}
                      >
                        {result.type}
                      </span>
                      <ArrowRight size={12} style={{ color: isHovered ? "#00c9a7" : "#3a6660", transition: "color 150ms" }} />
                    </div>
                  </button>
                );
              })}
            </div>
          )}

          {/* All levels grid */}
          {!query && (
            <div className="mt-5">
              <p className="text-[10px] font-semibold uppercase tracking-widest mb-3" style={{ color: "#3a6660" }}>
                All Levels
              </p>
              <div className="flex flex-wrap gap-2">
                {ALL_LEVELS.map((level, i) => (
                  <button
                    key={level.id}
                    onClick={() => navigate("/level-builder")}
                    className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-xs font-medium transition-all duration-150 animate-stagger-in"
                    style={{
                      background: "#111a18",
                      border: "1px solid rgba(0,201,167,0.08)",
                      color: "#a0b8b4",
                      animationDelay: `${i * 30}ms`,
                    }}
                    onMouseEnter={e => {
                      (e.currentTarget as HTMLElement).style.background = `${level.pathwayColor}15`;
                      (e.currentTarget as HTMLElement).style.borderColor = `${level.pathwayColor}30`;
                      (e.currentTarget as HTMLElement).style.color = level.pathwayColor;
                    }}
                    onMouseLeave={e => {
                      (e.currentTarget as HTMLElement).style.background = "#111a18";
                      (e.currentTarget as HTMLElement).style.borderColor = "rgba(0,201,167,0.08)";
                      (e.currentTarget as HTMLElement).style.color = "#a0b8b4";
                    }}
                  >
                    <div
                      className="w-1.5 h-1.5 rounded-full"
                      style={{ background: level.pathwayColor }}
                    />
                    {level.shortName}
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </AppLayout>
  );
}
