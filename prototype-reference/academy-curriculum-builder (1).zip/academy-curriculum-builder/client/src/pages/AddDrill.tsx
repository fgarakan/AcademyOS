/*
 * Screen 4 — Add Drill with DONNA
 * AnglesOS brand: DONNA creates a draft drill card, user approves
 */
import { useState } from "react";
import { useLocation } from "wouter";
import AppLayout from "@/components/AppLayout";
import DonnaPanel from "@/components/DonnaPanel";
import { Sparkles, CheckCircle, Edit3, Layers, X, AlertTriangle, Send } from "lucide-react";
import { toast } from "sonner";

export default function AddDrill() {
  const [, navigate] = useLocation();
  const [prompt, setPrompt] = useState("Add a drill for forehand recovery after wide balls.");
  const [showDraft, setShowDraft] = useState(true);
  const [approved, setApproved] = useState(false);

  const handleApprove = () => {
    setApproved(true);
    setTimeout(() => navigate("/impact-preview"), 600);
  };

  return (
    <AppLayout
      title="Add Drill"
      subtitle="DONNA will create a draft — nothing is applied until you approve"
      donnaPanel={
        <DonnaPanel
          greeting="Tell me what drill you need and I'll create a draft for your review."
          subtext="Be specific about the skill, movement, or situation you want to target."
          options={[
            { label: "Forehand recovery drill", onClick: () => setShowDraft(true), highlight: true },
            { label: "Backhand approach drill", onClick: () => setShowDraft(true) },
            { label: "Serve + 1 pattern drill", onClick: () => setShowDraft(true) },
            { label: "Net approach drill", onClick: () => setShowDraft(true) },
          ]}
        />
      }
    >
      {/* Prompt input */}
      <div
        className="rounded-xl px-5 py-4 mb-5 animate-stagger-in"
        style={{ background: "#111a18", border: "1px solid rgba(0,201,167,0.1)" }}
      >
        <p className="text-[10px] font-semibold uppercase tracking-widest mb-2" style={{ color: "#3a6660" }}>
          Your Request to DONNA
        </p>
        <div
          className="flex items-center gap-3 rounded-lg px-3 py-2.5"
          style={{ background: "rgba(0,201,167,0.05)", border: "1px solid rgba(0,201,167,0.15)" }}
        >
          <Sparkles size={14} style={{ color: "#00c9a7", flexShrink: 0 }} />
          <input
            value={prompt}
            onChange={e => setPrompt(e.target.value)}
            className="flex-1 bg-transparent text-sm outline-none"
            style={{ color: "#e8f0ee" }}
          />
          <button
            onClick={() => setShowDraft(true)}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all duration-150 shrink-0"
            style={{ background: "#00c9a7", color: "#050d0b" }}
            onMouseEnter={e => { (e.currentTarget as HTMLElement).style.background = "#00e5c4"; }}
            onMouseLeave={e => { (e.currentTarget as HTMLElement).style.background = "#00c9a7"; }}
          >
            <Send size={11} /> Generate
          </button>
        </div>
      </div>

      {showDraft && (
        <div className="animate-scale-in">
          {/* DONNA draft label */}
          <div className="flex items-center gap-2 mb-3">
            <div
              className="w-5 h-5 rounded-full flex items-center justify-center text-xs font-bold"
              style={{ background: "linear-gradient(135deg,#00c9a7,#00a88a)", color: "#050d0b" }}
            >
              D
            </div>
            <span className="text-xs font-semibold" style={{ color: "#00c9a7" }}>DONNA Draft</span>
            <span
              className="text-[10px] px-2 py-0.5 rounded-full"
              style={{ background: "rgba(255,170,0,0.1)", color: "#ffaa00", border: "1px solid rgba(255,170,0,0.2)" }}
            >
              Pending Approval
            </span>
          </div>

          {/* Draft card */}
          <div
            className="rounded-xl overflow-hidden mb-4"
            style={{
              background: "#111a18",
              border: "1px solid rgba(0,201,167,0.15)",
              boxShadow: "0 0 32px rgba(0,201,167,0.06)",
            }}
          >
            {/* Card header */}
            <div
              className="px-5 py-4"
              style={{
                background: "rgba(0,201,167,0.05)",
                borderBottom: "1px solid rgba(0,201,167,0.1)",
              }}
            >
              <div className="flex items-start justify-between">
                <div>
                  <h2 className="text-lg font-bold" style={{ color: "#e8f0ee" }}>
                    Wide Ball Recovery Builder
                  </h2>
                  <p className="text-xs mt-1" style={{ color: "#3a6660" }}>
                    DONNA-generated drill · Orange Ball 2
                  </p>
                </div>
                <span
                  className="text-[10px] font-semibold px-2 py-1 rounded"
                  style={{ background: "rgba(255,170,0,0.1)", color: "#ffaa00", border: "1px solid rgba(255,170,0,0.2)", textTransform: "uppercase", letterSpacing: "0.04em" }}
                >
                  Draft
                </span>
              </div>
            </div>

            {/* Card body */}
            <div className="p-5 grid grid-cols-2 gap-4">
              {[
                { label: "Development Intent", val: "Train players to recover after being pulled off court. Focus on split-step timing and neutral position recovery." },
                { label: "Recommended Level", val: "Orange Ball 2" },
                { label: "Pathways", val: "Skill Path · Movement · Competition Transfer" },
                { label: "Duration", val: "15–20 minutes per session" },
              ].map(({ label, val }, i) => (
                <div
                  key={label}
                  className="rounded-lg px-4 py-3 animate-stagger-in"
                  style={{
                    background: "rgba(255,255,255,0.02)",
                    border: "1px solid rgba(255,255,255,0.04)",
                    animationDelay: `${i * 60}ms`,
                  }}
                >
                  <p className="text-[10px] font-semibold uppercase tracking-widest mb-1" style={{ color: "#3a6660" }}>
                    {label}
                  </p>
                  <p className="text-sm" style={{ color: "#c8e0dc" }}>{val}</p>
                </div>
              ))}

              {/* Connected skills */}
              <div
                className="rounded-lg px-4 py-3 animate-stagger-in col-span-2"
                style={{
                  background: "rgba(255,255,255,0.02)",
                  border: "1px solid rgba(255,255,255,0.04)",
                  animationDelay: "240ms",
                }}
              >
                <p className="text-[10px] font-semibold uppercase tracking-widest mb-2" style={{ color: "#3a6660" }}>
                  Connected Skills
                </p>
                <div className="flex flex-wrap gap-2">
                  {["Forehand Spacing", "Recovery Movement", "Balance After Contact"].map((skill) => (
                    <span
                      key={skill}
                      className="text-xs px-2.5 py-1 rounded-full"
                      style={{ background: "rgba(0,201,167,0.1)", color: "#00c9a7", border: "1px solid rgba(0,201,167,0.2)" }}
                    >
                      {skill}
                    </span>
                  ))}
                </div>
              </div>

              {/* Assessment evidence */}
              <div
                className="rounded-lg px-4 py-3 animate-stagger-in col-span-2"
                style={{
                  background: "rgba(255,255,255,0.02)",
                  border: "1px solid rgba(255,255,255,0.04)",
                  animationDelay: "300ms",
                }}
              >
                <p className="text-[10px] font-semibold uppercase tracking-widest mb-2" style={{ color: "#3a6660" }}>
                  Assessment Evidence
                </p>
                <ul className="space-y-1.5">
                  {[
                    "Player recovers to neutral position after wide ball",
                    "Player can rally crosscourt after recovery",
                  ].map((ev) => (
                    <li key={ev} className="flex items-start gap-2">
                      <CheckCircle size={12} className="mt-0.5 shrink-0" style={{ color: "#00c9a7" }} />
                      <span className="text-xs" style={{ color: "#c8e0dc" }}>{ev}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>

            {/* Impact notice */}
            <div
              className="px-5 py-3 flex items-start gap-2.5"
              style={{
                background: "rgba(255,170,0,0.05)",
                borderTop: "1px solid rgba(255,170,0,0.1)",
              }}
            >
              <AlertTriangle size={13} style={{ color: "#ffaa00", flexShrink: 0, marginTop: 1 }} />
              <p className="text-xs" style={{ color: "#a08040" }}>
                <span className="font-semibold" style={{ color: "#ffaa00" }}>Impact preview: </span>
                This will affect Orange Ball 2 lesson plans, player missions, and future assessment evidence.
              </p>
            </div>

            {/* Action buttons */}
            <div
              className="px-5 py-4 flex items-center gap-2 flex-wrap"
              style={{ borderTop: "1px solid rgba(255,255,255,0.04)" }}
            >
              <button
                onClick={handleApprove}
                className="flex items-center gap-1.5 px-4 py-2 rounded-lg text-sm font-semibold transition-all duration-200"
                style={{
                  background: approved ? "#00e5c4" : "#00c9a7",
                  color: "#050d0b",
                  transform: approved ? "scale(0.97)" : "scale(1)",
                }}
                onMouseEnter={e => { if (!approved) (e.currentTarget as HTMLElement).style.background = "#00e5c4"; }}
                onMouseLeave={e => { if (!approved) (e.currentTarget as HTMLElement).style.background = "#00c9a7"; }}
              >
                <CheckCircle size={14} />
                {approved ? "Approved! Redirecting…" : "Approve and Add"}
              </button>
              <button
                onClick={() => toast.info("Opening draft editor…")}
                className="flex items-center gap-1.5 px-4 py-2 rounded-lg text-sm font-medium transition-all duration-150"
                style={{ background: "rgba(255,255,255,0.04)", color: "#a0b8b4", border: "1px solid rgba(255,255,255,0.08)" }}
                onMouseEnter={e => { (e.currentTarget as HTMLElement).style.background = "rgba(255,255,255,0.08)"; (e.currentTarget as HTMLElement).style.color = "#e8f0ee"; }}
                onMouseLeave={e => { (e.currentTarget as HTMLElement).style.background = "rgba(255,255,255,0.04)"; (e.currentTarget as HTMLElement).style.color = "#a0b8b4"; }}
              >
                <Edit3 size={14} /> Edit Draft
              </button>
              <button
                onClick={() => toast.info("Select a different level…")}
                className="flex items-center gap-1.5 px-4 py-2 rounded-lg text-sm font-medium transition-all duration-150"
                style={{ background: "rgba(255,255,255,0.04)", color: "#a0b8b4", border: "1px solid rgba(255,255,255,0.08)" }}
                onMouseEnter={e => { (e.currentTarget as HTMLElement).style.background = "rgba(255,255,255,0.08)"; (e.currentTarget as HTMLElement).style.color = "#e8f0ee"; }}
                onMouseLeave={e => { (e.currentTarget as HTMLElement).style.background = "rgba(255,255,255,0.04)"; (e.currentTarget as HTMLElement).style.color = "#a0b8b4"; }}
              >
                <Layers size={14} /> Change Level
              </button>
              <button
                onClick={() => setShowDraft(false)}
                className="flex items-center gap-1.5 px-4 py-2 rounded-lg text-sm font-medium transition-all duration-150 ml-auto"
                style={{ background: "rgba(224,82,82,0.08)", color: "#e05252", border: "1px solid rgba(224,82,82,0.15)" }}
                onMouseEnter={e => { (e.currentTarget as HTMLElement).style.background = "rgba(224,82,82,0.15)"; }}
                onMouseLeave={e => { (e.currentTarget as HTMLElement).style.background = "rgba(224,82,82,0.08)"; }}
              >
                <X size={14} /> Cancel
              </button>
            </div>
          </div>

          {/* Nothing changes notice */}
          <div
            className="rounded-lg px-4 py-3 flex items-center gap-2 animate-fade-in"
            style={{
              background: "rgba(0,201,167,0.04)",
              border: "1px solid rgba(0,201,167,0.1)",
            }}
          >
            <div
              className="w-4 h-4 rounded-full flex items-center justify-center text-[9px] font-bold shrink-0"
              style={{ background: "rgba(0,201,167,0.2)", color: "#00c9a7" }}
            >
              D
            </div>
            <p className="text-xs" style={{ color: "#5a7a76" }}>
              <span className="font-semibold" style={{ color: "#00c9a7" }}>DONNA proposes. Directors approve. </span>
              Nothing changes until approved.
            </p>
          </div>
        </div>
      )}
    </AppLayout>
  );
}
