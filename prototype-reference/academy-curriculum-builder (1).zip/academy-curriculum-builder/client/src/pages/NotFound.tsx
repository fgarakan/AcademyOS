import { useLocation } from "wouter";

export default function NotFound() {
  const [, navigate] = useLocation();
  return (
    <div
      className="min-h-screen flex items-center justify-center"
      style={{ background: "#0a0f0e" }}
    >
      <div className="text-center">
        <div className="text-6xl font-bold mb-4" style={{ color: "#00c9a7" }}>404</div>
        <p className="text-lg mb-6" style={{ color: "#5a7a76" }}>Page not found</p>
        <button
          onClick={() => navigate("/")}
          className="px-5 py-2.5 rounded-xl text-sm font-semibold transition-all duration-150"
          style={{ background: "#00c9a7", color: "#050d0b" }}
          onMouseEnter={e => { (e.currentTarget as HTMLElement).style.background = "#00e5c4"; }}
          onMouseLeave={e => { (e.currentTarget as HTMLElement).style.background = "#00c9a7"; }}
        >
          Back to Curriculum Map
        </button>
      </div>
    </div>
  );
}
