/*
 * Screen 1 — Curriculum Map
 * AnglesOS brand: dark forest-green bg, teal accent
 * Visual map of all pathways and levels with animated cards
 */
import { useState } from "react";
import { useLocation } from "wouter";
import AppLayout from "@/components/AppLayout";
import DonnaPanel from "@/components/DonnaPanel";
import LevelCard from "@/components/LevelCard";
import { PATHWAYS, ALL_LEVELS, type CurriculumLevel } from "@/lib/curriculumData";
import { Play, Zap, Eye, Clock, AlertCircle, ChevronRight } from "lucide-react";
import { toast } from "sonner";

export default function CurriculumMap() {
  const [, navigate] = useLocation();
  const [selectedLevel, setSelectedLevel] = useState<CurriculumLevel | null>(null);

  const incompleteCount = ALL_LEVELS.filter(l => l.status === "incomplete" || l.status === "needs-review").length;
  const readyCount = ALL_LEVELS.filter(l => l.status === "ready").length;
  const totalLevels = ALL_LEVELS.length;

  const donnaOptions = [
    { label: "Start from Red Ball 1", onClick: () => navigate("/guided-review"), highlight: true },
    { label: "Jump to Orange Ball 2", onClick: () => navigate("/level-builder") },
    { label: "Review only incomplete levels", onClick: () => navigate("/guided-review") },
    { label: "Help me customize this curriculum", onClick: () => navigate("/level-builder") },
  ];

  return (
    <AppLayout
      title="Curriculum Map"
      subtitle={`${totalLevels} levels across 5 pathways · ${incompleteCount} need attention`}
      headerRight={
        <div className="flex items-center gap-2">
          <button
            onClick={() => navigate("/jump-to-level")}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium transition-all duration-150"
            style={{
              background: "rgba(0,201,167,0.08)",
              color: "#00c9a7",
              border: "1px solid rgba(0,201,167,0.2)",
            }}
            onMouseEnter={e => { (e.currentTarget as HTMLElement).style.background = "rgba(0,201,167,0.14)"; }}
            onMouseLeave={e => { (e.currentTarget as HTMLElement).style.background = "rgba(0,201,167,0.08)"; }}
          >
            <Zap size={12} /> Jump to Level
          </button>
          <button
            onClick={() => navigate("/guided-review")}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all duration-150"
            style={{
              background: "#00c9a7",
              color: "#050d0b",
            }}
            onMouseEnter={e => { (e.currentTarget as HTMLElement).style.background = "#00e5c4"; }}
            onMouseLeave={e => { (e.currentTarget as HTMLElement).style.background = "#00c9a7"; }}
          >
            <Play size={12} /> Start Guided Review
          </button>
        </div>
      }
      donnaPanel={
        <DonnaPanel
          greeting="Where would you like to start today?"
          subtext="I can guide you level by level, or jump straight to what needs attention."
          options={donnaOptions}
          badge="Active"
        >
          {/* Quick stats in DONNA panel */}
          <div className="space-y-2 mt-2">
            <p className="text-[10px] font-semibold uppercase tracking-widest mb-2" style={{ color: "#2a4a46" }}>
              Curriculum Health
            </p>
            {[
              { label: "Ready", val: readyCount, color: "#00c9a7" },
              { label: "Needs Review", val: ALL_LEVELS.filter(l => l.status === "needs-review").length, color: "#ffaa00" },
              { label: "Incomplete", val: ALL_LEVELS.filter(l => l.status === "incomplete").length, color: "#e05252" },
              { label: "Custom", val: ALL_LEVELS.filter(l => l.status === "custom").length, color: "#a07de0" },
            ].map(({ label, val, color }) => (
              <div key={label} className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className="w-1.5 h-1.5 rounded-full" style={{ background: color }} />
                  <span className="text-xs" style={{ color: "#5a7a76" }}>{label}</span>
                </div>
                <span className="text-xs font-bold" style={{ color, fontFamily: "monospace" }}>{val}</span>
              </div>
            ))}
          </div>
        </DonnaPanel>
      }
    >
      {/* Summary bar */}
      <div
        className="grid grid-cols-4 gap-3 mb-6 animate-stagger-in"
        style={{ animationDelay: "0ms" }}
      >
        {[
          { label: "Total Levels", val: totalLevels, icon: Eye, color: "#e8f0ee" },
          { label: "Ready", val: readyCount, icon: Play, color: "#00c9a7" },
          { label: "Need Attention", val: incompleteCount, icon: AlertCircle, color: "#ffaa00" },
          { label: "Last Updated", val: "2h ago", icon: Clock, color: "#5a7a76" },
        ].map(({ label, val, icon: Icon, color }, i) => (
          <div
            key={label}
            className="rounded-xl px-4 py-3 flex items-center gap-3 animate-stagger-in"
            style={{
              background: "#111a18",
              border: "1px solid rgba(0,201,167,0.08)",
              animationDelay: `${i * 60}ms`,
            }}
          >
            <Icon size={16} style={{ color }} />
            <div>
              <div className="text-lg font-bold" style={{ color, fontFamily: "monospace" }}>{val}</div>
              <div className="text-[10px] uppercase tracking-wider" style={{ color: "#3a6660" }}>{label}</div>
            </div>
          </div>
        ))}
      </div>

      {/* Pathway rows */}
      <div className="space-y-6">
        {PATHWAYS.map((pathway, pi) => (
          <div
            key={pathway.id}
            className="animate-stagger-in"
            style={{ animationDelay: `${pi * 80 + 100}ms` }}
          >
            {/* Pathway header */}
            <div className="flex items-center gap-3 mb-3">
              <div
                className="w-3 h-3 rounded-full"
                style={{ background: pathway.color, boxShadow: `0 0 8px ${pathway.color}60` }}
              />
              <h2 className="text-sm font-bold uppercase tracking-widest" style={{ color: "#e8f0ee" }}>
                {pathway.name}
              </h2>
              <div
                className="h-px flex-1"
                style={{ background: `linear-gradient(90deg, ${pathway.color}30, transparent)` }}
              />
              <span className="text-[10px]" style={{ color: "#3a6660" }}>
                {pathway.levels.filter(l => l.status === "ready").length}/{pathway.levels.length} ready
              </span>
            </div>

            {/* Level cards */}
            <div className="grid grid-cols-3 gap-3">
              {pathway.levels.map((level, li) => (
                <LevelCard
                  key={level.id}
                  level={level}
                  selected={selectedLevel?.id === level.id}
                  onClick={() => {
                    setSelectedLevel(level);
                    setTimeout(() => navigate("/level-builder"), 300);
                  }}
                  animDelay={pi * 80 + li * 60 + 150}
                />
              ))}
            </div>
          </div>
        ))}
      </div>

      {/* Bottom action bar */}
      <div
        className="mt-6 rounded-xl px-5 py-4 flex items-center justify-between animate-stagger-in"
        style={{
          background: "rgba(0,201,167,0.05)",
          border: "1px solid rgba(0,201,167,0.12)",
          animationDelay: "600ms",
        }}
      >
        <div>
          <p className="text-sm font-semibold" style={{ color: "#e8f0ee" }}>
            Ready to review your curriculum?
          </p>
          <p className="text-xs mt-0.5" style={{ color: "#3a6660" }}>
            DONNA will guide you one level at a time. Skip anything and come back later.
          </p>
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={() => navigate("/change-queue")}
            className="flex items-center gap-1.5 px-3 py-2 rounded-lg text-xs font-medium transition-all duration-150"
            style={{
              background: "rgba(255,255,255,0.04)",
              color: "#a0b8b4",
              border: "1px solid rgba(255,255,255,0.06)",
            }}
            onMouseEnter={e => { (e.currentTarget as HTMLElement).style.background = "rgba(255,255,255,0.07)"; }}
            onMouseLeave={e => { (e.currentTarget as HTMLElement).style.background = "rgba(255,255,255,0.04)"; }}
          >
            <Clock size={12} /> View Recent Changes
          </button>
          <button
            onClick={() => navigate("/guided-review")}
            className="flex items-center gap-1.5 px-4 py-2 rounded-lg text-xs font-semibold transition-all duration-150"
            style={{ background: "#00c9a7", color: "#050d0b" }}
            onMouseEnter={e => { (e.currentTarget as HTMLElement).style.background = "#00e5c4"; }}
            onMouseLeave={e => { (e.currentTarget as HTMLElement).style.background = "#00c9a7"; }}
          >
            Start Guided Review <ChevronRight size={12} />
          </button>
        </div>
      </div>
    </AppLayout>
  );
}
