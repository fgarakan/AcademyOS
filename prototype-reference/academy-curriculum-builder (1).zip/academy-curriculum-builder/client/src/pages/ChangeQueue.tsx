/*
 * Screen 8 — DONNA Change Review Queue
 * AnglesOS brand: pending changes waiting for director approval
 */
import { useState } from "react";
import { useLocation } from "wouter";
import AppLayout from "@/components/AppLayout";
import DonnaPanel from "@/components/DonnaPanel";
import { CheckCircle, X, Edit3, AlertTriangle, Zap, Clock, User, Sparkles } from "lucide-react";
import { toast } from "sonner";

type RiskLevel = "low" | "medium" | "high";
type ChangeSource = "DONNA" | "Director" | "Coach";

interface ChangeItem {
  id: string;
  title: string;
  type: string;
  source: ChangeSource;
  level: string;
  pathways: string[];
  downstreamImpact: string;
  risk: RiskLevel;
  time: string;
}

const CHANGES: ChangeItem[] = [
  {
    id: "c1",
    title: "Wide Ball Recovery Builder",
    type: "Added drill draft",
    source: "DONNA",
    level: "Orange Ball 2",
    pathways: ["Skill Path", "Movement", "Competition Transfer"],
    downstreamImpact: "Affects 3 session templates, 2 lesson plans, 1 player mission",
    risk: "low",
    time: "2 min ago",
  },
  {
    id: "c2",
    title: "Low Contact Mobility Prep",
    type: "Added fitness exercise draft",
    source: "DONNA",
    level: "Orange Ball 2 · Orange Ball 3",
    pathways: ["Fitness Support"],
    downstreamImpact: "Affects 2 levels, 4 session templates",
    risk: "medium",
    time: "8 min ago",
  },
  {
    id: "c3",
    title: "Rally Tolerance Assessment Gate",
    type: "Modified level gate",
    source: "Director",
    level: "Orange Ball 2",
    pathways: ["Assessment"],
    downstreamImpact: "Affects player level-up criteria for 12 players",
    risk: "high",
    time: "1h ago",
  },
  {
    id: "c4",
    title: "Crosscourt Pattern Evidence",
    type: "Added assessment requirement",
    source: "Coach",
    level: "Green Ball 1",
    pathways: ["Assessment", "Skill Path"],
    downstreamImpact: "Affects 8 player profiles, 1 parent summary",
    risk: "medium",
    time: "3h ago",
  },
];

const RISK_CONFIG: Record<RiskLevel, { color: string; bg: string; border: string; label: string }> = {
  low:    { color: "#00c9a7", bg: "rgba(0,201,167,0.08)",   border: "rgba(0,201,167,0.2)",   label: "Low Risk" },
  medium: { color: "#ffaa00", bg: "rgba(255,170,0,0.08)",   border: "rgba(255,170,0,0.2)",   label: "Med Risk" },
  high:   { color: "#e05252", bg: "rgba(224,82,82,0.08)",   border: "rgba(224,82,82,0.2)",   label: "High Risk" },
};

const SOURCE_ICON: Record<ChangeSource, React.ElementType> = {
  DONNA: Sparkles,
  Director: User,
  Coach: User,
};

export default function ChangeQueue() {
  const [, navigate] = useLocation();
  const [dismissed, setDismissed] = useState<Set<string>>(new Set());

  const visible = CHANGES.filter(c => !dismissed.has(c.id));

  const dismiss = (id: string) => setDismissed(prev => { const next = new Set(Array.from(prev)); next.add(id); return next; });

  return (
    <AppLayout
      title="Change Queue"
      subtitle={`${visible.length} changes pending approval`}
      headerRight={
        <button
          onClick={() => navigate("/")}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium transition-all duration-150"
          style={{ background: "rgba(0,201,167,0.08)", color: "#00c9a7", border: "1px solid rgba(0,201,167,0.2)" }}
          onMouseEnter={e => { (e.currentTarget as HTMLElement).style.background = "rgba(0,201,167,0.14)"; }}
          onMouseLeave={e => { (e.currentTarget as HTMLElement).style.background = "rgba(0,201,167,0.08)"; }}
        >
          Back to Map
        </button>
      }
      donnaPanel={
        <DonnaPanel
          greeting="These changes are waiting for your approval. Review each one carefully."
          subtext="DONNA proposes. Directors approve. Nothing changes until approved."
          badge={`${visible.length} pending`}
          options={[
            { label: "Approve all low-risk changes", onClick: () => { CHANGES.filter(c => c.risk === "low").forEach(c => dismiss(c.id)); toast.success("Low-risk changes approved"); }, highlight: true },
            { label: "Review high-risk changes first", onClick: () => toast.info("Filtering to high-risk…") },
            { label: "Export change log", onClick: () => toast.info("Exporting change log…") },
          ]}
        />
      }
    >
      {/* DONNA principle banner */}
      <div
        className="rounded-xl px-5 py-3 mb-5 flex items-center gap-3 animate-stagger-in"
        style={{
          background: "rgba(0,201,167,0.05)",
          border: "1px solid rgba(0,201,167,0.12)",
        }}
      >
        <div
          className="w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold shrink-0"
          style={{ background: "linear-gradient(135deg,#00c9a7,#00a88a)", color: "#050d0b" }}
        >
          D
        </div>
        <p className="text-sm" style={{ color: "#c8e0dc" }}>
          <span className="font-semibold" style={{ color: "#00c9a7" }}>DONNA proposes. Directors approve. </span>
          Nothing changes until approved.
        </p>
      </div>

      {/* Change cards */}
      {visible.length === 0 ? (
        <div
          className="rounded-xl px-6 py-12 text-center animate-scale-in"
          style={{ background: "#111a18", border: "1px solid rgba(0,201,167,0.08)" }}
        >
          <CheckCircle size={32} className="mx-auto mb-3" style={{ color: "#00c9a7" }} />
          <p className="text-lg font-semibold" style={{ color: "#e8f0ee" }}>All caught up!</p>
          <p className="text-sm mt-1" style={{ color: "#3a6660" }}>No pending changes in the queue.</p>
        </div>
      ) : (
        <div className="space-y-3">
          {visible.map((change, i) => {
            const riskCfg = RISK_CONFIG[change.risk];
            const SourceIcon = SOURCE_ICON[change.source];
            return (
              <div
                key={change.id}
                className="rounded-xl overflow-hidden animate-stagger-in"
                style={{
                  background: "#111a18",
                  border: "1px solid rgba(0,201,167,0.08)",
                  animationDelay: `${i * 80}ms`,
                }}
              >
                {/* Card header */}
                <div
                  className="px-5 py-4 flex items-start justify-between"
                  style={{ borderBottom: "1px solid rgba(255,255,255,0.04)" }}
                >
                  <div className="flex items-start gap-3">
                    <div
                      className="w-8 h-8 rounded-lg flex items-center justify-center shrink-0"
                      style={{ background: "rgba(0,201,167,0.1)", border: "1px solid rgba(0,201,167,0.2)" }}
                    >
                      <SourceIcon size={14} style={{ color: "#00c9a7" }} />
                    </div>
                    <div>
                      <div className="flex items-center gap-2 mb-0.5">
                        <span className="text-sm font-bold" style={{ color: "#e8f0ee" }}>
                          {change.title}
                        </span>
                        <span
                          className="text-[10px] font-semibold px-1.5 py-0.5 rounded"
                          style={{
                            background: riskCfg.bg,
                            color: riskCfg.color,
                            border: `1px solid ${riskCfg.border}`,
                            textTransform: "uppercase",
                            letterSpacing: "0.04em",
                          }}
                        >
                          {riskCfg.label}
                        </span>
                      </div>
                      <p className="text-xs" style={{ color: "#3a6660" }}>
                        {change.type} · {change.source} · {change.level}
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <Clock size={11} style={{ color: "#3a6660" }} />
                    <span className="text-[10px]" style={{ color: "#3a6660" }}>{change.time}</span>
                  </div>
                </div>

                {/* Card body */}
                <div className="px-5 py-3 grid grid-cols-2 gap-4">
                  <div>
                    <p className="text-[10px] font-semibold uppercase tracking-widest mb-1" style={{ color: "#2a4a46" }}>
                      Affected Pathways
                    </p>
                    <div className="flex flex-wrap gap-1.5">
                      {change.pathways.map(p => (
                        <span
                          key={p}
                          className="text-[10px] px-2 py-0.5 rounded"
                          style={{ background: "rgba(0,201,167,0.08)", color: "#00c9a7", border: "1px solid rgba(0,201,167,0.15)" }}
                        >
                          {p}
                        </span>
                      ))}
                    </div>
                  </div>
                  <div>
                    <p className="text-[10px] font-semibold uppercase tracking-widest mb-1" style={{ color: "#2a4a46" }}>
                      Downstream Impact
                    </p>
                    <p className="text-xs" style={{ color: "#5a7a76" }}>{change.downstreamImpact}</p>
                  </div>
                </div>

                {/* Actions */}
                <div
                  className="px-5 py-3 flex items-center gap-2"
                  style={{ borderTop: "1px solid rgba(255,255,255,0.04)" }}
                >
                  <button
                    onClick={() => { dismiss(change.id); toast.success(`Approved: ${change.title}`); }}
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all duration-150"
                    style={{ background: "#00c9a7", color: "#050d0b" }}
                    onMouseEnter={e => { (e.currentTarget as HTMLElement).style.background = "#00e5c4"; }}
                    onMouseLeave={e => { (e.currentTarget as HTMLElement).style.background = "#00c9a7"; }}
                  >
                    <CheckCircle size={12} /> Approve
                  </button>
                  <button
                    onClick={() => navigate("/impact-preview")}
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium transition-all duration-150"
                    style={{ background: "rgba(255,255,255,0.04)", color: "#a0b8b4", border: "1px solid rgba(255,255,255,0.08)" }}
                    onMouseEnter={e => { (e.currentTarget as HTMLElement).style.background = "rgba(255,255,255,0.08)"; (e.currentTarget as HTMLElement).style.color = "#e8f0ee"; }}
                    onMouseLeave={e => { (e.currentTarget as HTMLElement).style.background = "rgba(255,255,255,0.04)"; (e.currentTarget as HTMLElement).style.color = "#a0b8b4"; }}
                  >
                    <Edit3 size={12} /> Edit
                  </button>
                  <button
                    onClick={() => { dismiss(change.id); toast.error(`Rejected: ${change.title}`); }}
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium transition-all duration-150"
                    style={{ background: "rgba(224,82,82,0.08)", color: "#e05252", border: "1px solid rgba(224,82,82,0.15)" }}
                    onMouseEnter={e => { (e.currentTarget as HTMLElement).style.background = "rgba(224,82,82,0.15)"; }}
                    onMouseLeave={e => { (e.currentTarget as HTMLElement).style.background = "rgba(224,82,82,0.08)"; }}
                  >
                    <X size={12} /> Reject
                  </button>
                  {change.risk === "high" && (
                    <div className="flex items-center gap-1.5 ml-auto">
                      <AlertTriangle size={12} style={{ color: "#e05252" }} />
                      <span className="text-[10px]" style={{ color: "#e05252" }}>
                        High impact — review carefully
                      </span>
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}
    </AppLayout>
  );
}
