/*
 * Screen 5 — Add Fitness Exercise with DONNA
 * AnglesOS brand: visual connection chain, draft fitness card
 */
import { useState } from "react";
import { useLocation } from "wouter";
import AppLayout from "@/components/AppLayout";
import DonnaPanel from "@/components/DonnaPanel";
import { Sparkles, CheckCircle, Edit3, X, ArrowRight, Activity, Send } from "lucide-react";
import { toast } from "sonner";

export default function AddFitness() {
  const [, navigate] = useLocation();
  const [prompt, setPrompt] = useState("Add a mobility exercise for Orange 2 players who struggle with low contact.");
  const [showDraft, setShowDraft] = useState(true);
  const [approved, setApproved] = useState(false);

  const handleApprove = () => {
    setApproved(true);
    setTimeout(() => navigate("/impact-preview"), 600);
  };

  return (
    <AppLayout
      title="Add Fitness Exercise"
      subtitle="DONNA will create a draft — nothing is applied until you approve"
      donnaPanel={
        <DonnaPanel
          greeting="Describe the fitness need and I'll design an exercise that connects to your curriculum."
          subtext="I'll link it to the right skill needs and levels automatically."
          options={[
            { label: "Low contact mobility exercise", onClick: () => setShowDraft(true), highlight: true },
            { label: "Lateral speed & agility", onClick: () => setShowDraft(true) },
            { label: "Core stability for serve", onClick: () => setShowDraft(true) },
            { label: "Explosive first-step drill", onClick: () => setShowDraft(true) },
          ]}
        />
      }
    >
      {/* Prompt */}
      <div
        className="rounded-xl px-5 py-4 mb-5 animate-stagger-in"
        style={{ background: "#111a18", border: "1px solid rgba(0,201,167,0.1)" }}
      >
        <p className="text-[10px] font-semibold uppercase tracking-widest mb-2" style={{ color: "#3a6660" }}>
          Your Request to DONNA
        </p>
        <div
          className="flex items-center gap-3 rounded-lg px-3 py-2.5"
          style={{ background: "rgba(0,201,167,0.05)", border: "1px solid rgba(0,201,167,0.15)" }}
        >
          <Sparkles size={14} style={{ color: "#00c9a7", flexShrink: 0 }} />
          <input
            value={prompt}
            onChange={e => setPrompt(e.target.value)}
            className="flex-1 bg-transparent text-sm outline-none"
            style={{ color: "#e8f0ee" }}
          />
          <button
            onClick={() => setShowDraft(true)}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all duration-150 shrink-0"
            style={{ background: "#00c9a7", color: "#050d0b" }}
            onMouseEnter={e => { (e.currentTarget as HTMLElement).style.background = "#00e5c4"; }}
            onMouseLeave={e => { (e.currentTarget as HTMLElement).style.background = "#00c9a7"; }}
          >
            <Send size={11} /> Generate
          </button>
        </div>
      </div>

      {showDraft && (
        <div className="animate-scale-in">
          {/* DONNA label */}
          <div className="flex items-center gap-2 mb-3">
            <div
              className="w-5 h-5 rounded-full flex items-center justify-center text-xs font-bold"
              style={{ background: "linear-gradient(135deg,#00c9a7,#00a88a)", color: "#050d0b" }}
            >
              D
            </div>
            <span className="text-xs font-semibold" style={{ color: "#00c9a7" }}>DONNA Draft</span>
            <span
              className="text-[10px] px-2 py-0.5 rounded-full"
              style={{ background: "rgba(255,170,0,0.1)", color: "#ffaa00", border: "1px solid rgba(255,170,0,0.2)" }}
            >
              Pending Approval
            </span>
          </div>

          {/* Draft card */}
          <div
            className="rounded-xl overflow-hidden mb-4"
            style={{
              background: "#111a18",
              border: "1px solid rgba(160,125,224,0.2)",
              boxShadow: "0 0 32px rgba(160,125,224,0.06)",
            }}
          >
            {/* Header */}
            <div
              className="px-5 py-4"
              style={{
                background: "rgba(160,125,224,0.05)",
                borderBottom: "1px solid rgba(160,125,224,0.1)",
              }}
            >
              <div className="flex items-start justify-between">
                <div className="flex items-center gap-3">
                  <Activity size={18} style={{ color: "#a07de0" }} />
                  <div>
                    <h2 className="text-lg font-bold" style={{ color: "#e8f0ee" }}>
                      Low Contact Mobility Prep
                    </h2>
                    <p className="text-xs mt-1" style={{ color: "#3a6660" }}>
                      Fitness Support · DONNA-generated
                    </p>
                  </div>
                </div>
                <span
                  className="text-[10px] font-semibold px-2 py-1 rounded"
                  style={{ background: "rgba(160,125,224,0.1)", color: "#a07de0", border: "1px solid rgba(160,125,224,0.2)", textTransform: "uppercase", letterSpacing: "0.04em" }}
                >
                  Draft
                </span>
              </div>
            </div>

            {/* Body */}
            <div className="p-5 grid grid-cols-2 gap-4">
              {[
                { label: "Pathway", val: "Fitness Support" },
                { label: "Tennis Transfer", val: "Helps players stay balanced on low forehands and backhands" },
                { label: "Recommended Levels", val: "Orange Ball 2 · Orange Ball 3" },
                { label: "Use Before", val: "Forehand spacing block · Low ball rally block" },
              ].map(({ label, val }, i) => (
                <div
                  key={label}
                  className="rounded-lg px-4 py-3 animate-stagger-in"
                  style={{
                    background: "rgba(255,255,255,0.02)",
                    border: "1px solid rgba(255,255,255,0.04)",
                    animationDelay: `${i * 60}ms`,
                  }}
                >
                  <p className="text-[10px] font-semibold uppercase tracking-widest mb-1" style={{ color: "#3a6660" }}>
                    {label}
                  </p>
                  <p className="text-sm" style={{ color: "#c8e0dc" }}>{val}</p>
                </div>
              ))}
            </div>

            {/* Visual connection chain */}
            <div
              className="px-5 py-4"
              style={{ borderTop: "1px solid rgba(255,255,255,0.04)" }}
            >
              <p className="text-[10px] font-semibold uppercase tracking-widest mb-3" style={{ color: "#3a6660" }}>
                Curriculum Connection
              </p>
              <div className="flex items-center gap-2 flex-wrap">
                {[
                  { label: "Fitness Exercise", color: "#a07de0" },
                  { label: "Skill Need", color: "#00c9a7" },
                  { label: "Curriculum Level", color: "#ff9500" },
                  { label: "Player Mission", color: "#e05252" },
                ].map(({ label, color }, i, arr) => (
                  <div key={label} className="flex items-center gap-2">
                    <div
                      className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium animate-stagger-in"
                      style={{
                        background: `${color}15`,
                        color,
                        border: `1px solid ${color}30`,
                        animationDelay: `${i * 80}ms`,
                      }}
                    >
                      <div className="w-1.5 h-1.5 rounded-full" style={{ background: color }} />
                      {label}
                    </div>
                    {i < arr.length - 1 && (
                      <ArrowRight size={12} style={{ color: "#2a4a46" }} />
                    )}
                  </div>
                ))}
              </div>
            </div>

            {/* Action buttons */}
            <div
              className="px-5 py-4 flex items-center gap-2 flex-wrap"
              style={{ borderTop: "1px solid rgba(255,255,255,0.04)" }}
            >
              <button
                onClick={handleApprove}
                className="flex items-center gap-1.5 px-4 py-2 rounded-lg text-sm font-semibold transition-all duration-200"
                style={{
                  background: approved ? "#00e5c4" : "#00c9a7",
                  color: "#050d0b",
                }}
                onMouseEnter={e => { if (!approved) (e.currentTarget as HTMLElement).style.background = "#00e5c4"; }}
                onMouseLeave={e => { if (!approved) (e.currentTarget as HTMLElement).style.background = "#00c9a7"; }}
              >
                <CheckCircle size={14} />
                {approved ? "Approved! Redirecting…" : "Approve and Add"}
              </button>
              <button
                onClick={() => toast.info("Opening draft editor…")}
                className="flex items-center gap-1.5 px-4 py-2 rounded-lg text-sm font-medium transition-all duration-150"
                style={{ background: "rgba(255,255,255,0.04)", color: "#a0b8b4", border: "1px solid rgba(255,255,255,0.08)" }}
                onMouseEnter={e => { (e.currentTarget as HTMLElement).style.background = "rgba(255,255,255,0.08)"; (e.currentTarget as HTMLElement).style.color = "#e8f0ee"; }}
                onMouseLeave={e => { (e.currentTarget as HTMLElement).style.background = "rgba(255,255,255,0.04)"; (e.currentTarget as HTMLElement).style.color = "#a0b8b4"; }}
              >
                <Edit3 size={14} /> Edit Draft
              </button>
              <button
                onClick={() => toast.info("Select another level…")}
                className="flex items-center gap-1.5 px-4 py-2 rounded-lg text-sm font-medium transition-all duration-150"
                style={{ background: "rgba(255,255,255,0.04)", color: "#a0b8b4", border: "1px solid rgba(255,255,255,0.08)" }}
                onMouseEnter={e => { (e.currentTarget as HTMLElement).style.background = "rgba(255,255,255,0.08)"; (e.currentTarget as HTMLElement).style.color = "#e8f0ee"; }}
                onMouseLeave={e => { (e.currentTarget as HTMLElement).style.background = "rgba(255,255,255,0.04)"; (e.currentTarget as HTMLElement).style.color = "#a0b8b4"; }}
              >
                Add to Another Level
              </button>
              <button
                onClick={() => setShowDraft(false)}
                className="flex items-center gap-1.5 px-4 py-2 rounded-lg text-sm font-medium transition-all duration-150 ml-auto"
                style={{ background: "rgba(224,82,82,0.08)", color: "#e05252", border: "1px solid rgba(224,82,82,0.15)" }}
                onMouseEnter={e => { (e.currentTarget as HTMLElement).style.background = "rgba(224,82,82,0.15)"; }}
                onMouseLeave={e => { (e.currentTarget as HTMLElement).style.background = "rgba(224,82,82,0.08)"; }}
              >
                <X size={14} /> Cancel
              </button>
            </div>
          </div>

          {/* Nothing changes notice */}
          <div
            className="rounded-lg px-4 py-3 flex items-center gap-2 animate-fade-in"
            style={{ background: "rgba(0,201,167,0.04)", border: "1px solid rgba(0,201,167,0.1)" }}
          >
            <div
              className="w-4 h-4 rounded-full flex items-center justify-center text-[9px] font-bold shrink-0"
              style={{ background: "rgba(0,201,167,0.2)", color: "#00c9a7" }}
            >
              D
            </div>
            <p className="text-xs" style={{ color: "#5a7a76" }}>
              <span className="font-semibold" style={{ color: "#00c9a7" }}>DONNA proposes. Directors approve. </span>
              Nothing changes until approved.
            </p>
          </div>
        </div>
      )}
    </AppLayout>
  );
}
