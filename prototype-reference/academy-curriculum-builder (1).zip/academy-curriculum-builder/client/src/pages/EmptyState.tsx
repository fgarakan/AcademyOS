/*
 * Screen 10 — Empty State / First-Time Setup
 * AnglesOS brand: DONNA onboarding, no blank workspace
 */
import { useLocation } from "wouter";
import AppLayout from "@/components/AppLayout";
import { Play, Eye, Zap, Sparkles, ChevronRight, CheckCircle } from "lucide-react";
import { toast } from "sonner";

const STEPS = [
  { num: 1, label: "Review your master curriculum", desc: "DONNA has pre-loaded the standard curriculum for your academy type." },
  { num: 2, label: "Customize each level", desc: "Add your academy's drills, exercises, and assessment criteria." },
  { num: 3, label: "Approve changes", desc: "Nothing goes live until you review and approve every change." },
];

export default function EmptyState() {
  const [, navigate] = useLocation();

  return (
    <AppLayout
      title="Welcome to Curriculum Builder"
      subtitle="Powered by DONNA · Your academy starts with the master curriculum"
    >
      <div className="max-w-3xl mx-auto">
        {/* DONNA welcome card */}
        <div
          className="rounded-2xl overflow-hidden mb-6 animate-scale-in"
          style={{
            background: "linear-gradient(135deg, rgba(0,201,167,0.08) 0%, rgba(0,201,167,0.03) 100%)",
            border: "1px solid rgba(0,201,167,0.2)",
          }}
        >
          <div className="px-8 py-8">
            <div className="flex items-center gap-3 mb-5">
              <div
                className="w-12 h-12 rounded-full flex items-center justify-center text-lg font-bold animate-donna-blink"
                style={{
                  background: "linear-gradient(135deg,#00c9a7,#00a88a)",
                  color: "#050d0b",
                  boxShadow: "0 0 24px rgba(0,201,167,0.3)",
                }}
              >
                D
              </div>
              <div>
                <div className="text-base font-bold" style={{ color: "#00c9a7" }}>DONNA</div>
                <div className="text-xs" style={{ color: "#3a6660" }}>AI Curriculum Assistant · Ready</div>
              </div>
              <div
                className="ml-auto px-3 py-1 rounded-full text-xs font-semibold"
                style={{ background: "rgba(0,201,167,0.12)", color: "#00c9a7", border: "1px solid rgba(0,201,167,0.25)" }}
              >
                <Sparkles size={10} className="inline mr-1" />
                AI-Powered
              </div>
            </div>

            <h2
              className="text-2xl font-bold mb-2 leading-snug"
              style={{ color: "#e8f0ee" }}
            >
              Your academy starts with the master curriculum.
              <br />
              <span style={{ color: "#00c9a7" }}>DONNA will help you review and customize it.</span>
            </h2>
            <p className="text-sm mb-6" style={{ color: "#5a7a76" }}>
              I'll guide you one level at a time. You can skip anything and come back later.
              Nothing changes until you approve.
            </p>

            {/* CTA buttons */}
            <div className="flex items-center gap-3 flex-wrap">
              <button
                onClick={() => navigate("/guided-review")}
                className="flex items-center gap-2 px-5 py-2.5 rounded-xl text-sm font-semibold transition-all duration-150"
                style={{ background: "#00c9a7", color: "#050d0b" }}
                onMouseEnter={e => { (e.currentTarget as HTMLElement).style.background = "#00e5c4"; (e.currentTarget as HTMLElement).style.transform = "translateY(-1px)"; (e.currentTarget as HTMLElement).style.boxShadow = "0 8px 24px rgba(0,201,167,0.3)"; }}
                onMouseLeave={e => { (e.currentTarget as HTMLElement).style.background = "#00c9a7"; (e.currentTarget as HTMLElement).style.transform = "translateY(0)"; (e.currentTarget as HTMLElement).style.boxShadow = "none"; }}
              >
                <Play size={14} /> Start Guided Review <ChevronRight size={14} />
              </button>
              <button
                onClick={() => navigate("/guided-review")}
                className="flex items-center gap-2 px-5 py-2.5 rounded-xl text-sm font-medium transition-all duration-150"
                style={{ background: "rgba(255,255,255,0.05)", color: "#a0b8b4", border: "1px solid rgba(255,255,255,0.1)" }}
                onMouseEnter={e => { (e.currentTarget as HTMLElement).style.background = "rgba(255,255,255,0.09)"; (e.currentTarget as HTMLElement).style.color = "#e8f0ee"; }}
                onMouseLeave={e => { (e.currentTarget as HTMLElement).style.background = "rgba(255,255,255,0.05)"; (e.currentTarget as HTMLElement).style.color = "#a0b8b4"; }}
              >
                <Eye size={14} /> Review Incomplete Levels
              </button>
              <button
                onClick={() => navigate("/jump-to-level")}
                className="flex items-center gap-2 px-5 py-2.5 rounded-xl text-sm font-medium transition-all duration-150"
                style={{ background: "rgba(255,255,255,0.05)", color: "#a0b8b4", border: "1px solid rgba(255,255,255,0.1)" }}
                onMouseEnter={e => { (e.currentTarget as HTMLElement).style.background = "rgba(255,255,255,0.09)"; (e.currentTarget as HTMLElement).style.color = "#e8f0ee"; }}
                onMouseLeave={e => { (e.currentTarget as HTMLElement).style.background = "rgba(255,255,255,0.05)"; (e.currentTarget as HTMLElement).style.color = "#a0b8b4"; }}
              >
                <Zap size={14} /> Jump to a Level
              </button>
              <button
                onClick={() => toast.info("DONNA is analyzing your curriculum for priorities…")}
                className="flex items-center gap-2 px-5 py-2.5 rounded-xl text-sm font-medium transition-all duration-150"
                style={{ background: "rgba(0,201,167,0.06)", color: "#00c9a7", border: "1px solid rgba(0,201,167,0.15)" }}
                onMouseEnter={e => { (e.currentTarget as HTMLElement).style.background = "rgba(0,201,167,0.12)"; }}
                onMouseLeave={e => { (e.currentTarget as HTMLElement).style.background = "rgba(0,201,167,0.06)"; }}
              >
                <Sparkles size={14} /> Ask DONNA to Suggest Priorities
              </button>
            </div>
          </div>
        </div>

        {/* How it works */}
        <div className="mb-6">
          <p className="text-[10px] font-semibold uppercase tracking-widest mb-4" style={{ color: "#3a6660" }}>
            How it works
          </p>
          <div className="grid grid-cols-3 gap-4">
            {STEPS.map((step, i) => (
              <div
                key={step.num}
                className="rounded-xl px-5 py-4 animate-stagger-in"
                style={{
                  background: "#111a18",
                  border: "1px solid rgba(0,201,167,0.08)",
                  animationDelay: `${i * 100}ms`,
                }}
              >
                <div
                  className="w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold mb-3"
                  style={{ background: "rgba(0,201,167,0.12)", color: "#00c9a7", border: "1px solid rgba(0,201,167,0.2)" }}
                >
                  {step.num}
                </div>
                <p className="text-sm font-semibold mb-1" style={{ color: "#e8f0ee" }}>{step.label}</p>
                <p className="text-xs" style={{ color: "#3a6660" }}>{step.desc}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Curriculum overview teaser */}
        <div
          className="rounded-xl px-5 py-4 animate-stagger-in"
          style={{
            background: "#111a18",
            border: "1px solid rgba(0,201,167,0.08)",
            animationDelay: "400ms",
          }}
        >
          <div className="flex items-center justify-between mb-4">
            <p className="text-sm font-semibold" style={{ color: "#e8f0ee" }}>
              Master Curriculum Overview
            </p>
            <button
              onClick={() => navigate("/")}
              className="flex items-center gap-1 text-xs transition-all duration-150"
              style={{ color: "#00c9a7" }}
              onMouseEnter={e => { (e.currentTarget as HTMLElement).style.color = "#00e5c4"; }}
              onMouseLeave={e => { (e.currentTarget as HTMLElement).style.color = "#00c9a7"; }}
            >
              View full map <ChevronRight size={12} />
            </button>
          </div>
          <div className="grid grid-cols-5 gap-3">
            {[
              { name: "Red Ball", levels: 3, color: "#e05252" },
              { name: "Orange Ball", levels: 3, color: "#ff9500" },
              { name: "Green Ball", levels: 3, color: "#34c759" },
              { name: "Yellow Ball", levels: 3, color: "#ffd60a" },
              { name: "High Performance", levels: 3, color: "#00c9a7" },
            ].map(({ name, levels, color }, i) => (
              <button
                key={name}
                onClick={() => navigate("/")}
                className="rounded-lg px-3 py-3 text-center transition-all duration-150 animate-stagger-in"
                style={{
                  background: `${color}10`,
                  border: `1px solid ${color}25`,
                  animationDelay: `${500 + i * 60}ms`,
                }}
                onMouseEnter={e => {
                  (e.currentTarget as HTMLElement).style.background = `${color}18`;
                  (e.currentTarget as HTMLElement).style.borderColor = `${color}40`;
                  (e.currentTarget as HTMLElement).style.transform = "translateY(-2px)";
                }}
                onMouseLeave={e => {
                  (e.currentTarget as HTMLElement).style.background = `${color}10`;
                  (e.currentTarget as HTMLElement).style.borderColor = `${color}25`;
                  (e.currentTarget as HTMLElement).style.transform = "translateY(0)";
                }}
              >
                <div
                  className="w-3 h-3 rounded-full mx-auto mb-2"
                  style={{ background: color, boxShadow: `0 0 8px ${color}60` }}
                />
                <div className="text-xs font-semibold" style={{ color: "#e8f0ee" }}>{name}</div>
                <div className="text-[10px] mt-0.5" style={{ color: "#3a6660" }}>{levels} levels</div>
              </button>
            ))}
          </div>
        </div>

        {/* Bottom reassurance */}
        <div className="flex items-center justify-center gap-2 mt-6 animate-fade-in" style={{ animationDelay: "700ms" }}>
          <CheckCircle size={13} style={{ color: "#00c9a7" }} />
          <p className="text-xs" style={{ color: "#3a6660" }}>
            Nothing changes until you review and approve. Your curriculum is safe.
          </p>
        </div>
      </div>
    </AppLayout>
  );
}
