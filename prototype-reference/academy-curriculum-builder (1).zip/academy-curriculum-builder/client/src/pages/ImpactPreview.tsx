/*
 * Screen 6 — Curriculum Impact Preview
 * AnglesOS brand: staggered animated impact cards, approval actions
 */
import { useState } from "react";
import { useLocation } from "wouter";
import AppLayout from "@/components/AppLayout";
import DonnaPanel from "@/components/DonnaPanel";
import { CheckCircle, AlertTriangle, Minus, Clock, ChevronRight, Layers } from "lucide-react";
import { toast } from "sonner";

type ImpactStatus = "will-update" | "needs-review" | "not-affected" | "future";

interface ImpactItem {
  area: string;
  desc: string;
  status: ImpactStatus;
}

const IMPACT_ITEMS: ImpactItem[] = [
  { area: "Orange Ball 2 Curriculum", desc: "Drill added to skill path and competition path", status: "will-update" },
  { area: "Session Templates", desc: "3 session templates reference this skill block", status: "will-update" },
  { area: "Lesson Plans", desc: "2 lesson plans will include the new drill", status: "will-update" },
  { area: "Coach Session Context", desc: "Coach briefing notes will reference this drill", status: "needs-review" },
  { area: "Player Profile Requirements", desc: "Level-up criteria may be affected", status: "needs-review" },
  { area: "Assessment Gates", desc: "Gate 1 evidence criteria updated", status: "will-update" },
  { area: "Player Missions", desc: "Crosscourt Builder mission references this drill", status: "will-update" },
  { area: "Parent/Player Summaries", desc: "No direct connection at this time", status: "not-affected" },
  { area: "Orange Ball 3 Curriculum", desc: "May benefit from this drill in future review", status: "future" },
];

const STATUS_CONFIG: Record<ImpactStatus, { label: string; color: string; bg: string; border: string; icon: React.ElementType }> = {
  "will-update": { label: "Will Update", color: "#00c9a7", bg: "rgba(0,201,167,0.08)", border: "rgba(0,201,167,0.2)", icon: CheckCircle },
  "needs-review": { label: "Needs Review", color: "#ffaa00", bg: "rgba(255,170,0,0.08)", border: "rgba(255,170,0,0.2)", icon: AlertTriangle },
  "not-affected": { label: "Not Affected", color: "#5a7a76", bg: "rgba(255,255,255,0.03)", border: "rgba(255,255,255,0.06)", icon: Minus },
  "future": { label: "Future Connection", color: "#a07de0", bg: "rgba(160,125,224,0.08)", border: "rgba(160,125,224,0.2)", icon: Clock },
};

export default function ImpactPreview() {
  const [, navigate] = useLocation();
  const [applied, setApplied] = useState(false);

  const handleApply = (scope: string) => {
    setApplied(true);
    toast.success(`Applied to ${scope}`);
    setTimeout(() => navigate("/"), 1200);
  };

  const willUpdateCount = IMPACT_ITEMS.filter(i => i.status === "will-update").length;
  const needsReviewCount = IMPACT_ITEMS.filter(i => i.status === "needs-review").length;

  return (
    <AppLayout
      title="Impact Preview"
      subtitle="Review what will change before anything is applied"
      donnaPanel={
        <DonnaPanel
          greeting="Here's everything this change will touch. Review carefully before applying."
          subtext={`${willUpdateCount} areas will update automatically. ${needsReviewCount} need your review.`}
          options={[
            { label: "Apply to this level only", onClick: () => handleApply("Orange Ball 2"), highlight: true },
            { label: "Apply to all Orange Ball 2 groups", onClick: () => handleApply("all Orange Ball 2 groups") },
            { label: "Apply academy-wide", onClick: () => handleApply("entire academy") },
            { label: "Save as draft", onClick: () => { toast.info("Saved as draft"); navigate("/change-queue"); } },
          ]}
        />
      }
    >
      {/* Change summary */}
      <div
        className="rounded-xl px-5 py-4 mb-5 flex items-center gap-6 animate-stagger-in"
        style={{ background: "rgba(0,201,167,0.05)", border: "1px solid rgba(0,201,167,0.12)" }}
      >
        <div>
          <p className="text-[10px] font-semibold uppercase tracking-widest mb-1" style={{ color: "#3a6660" }}>Change</p>
          <p className="text-sm font-semibold" style={{ color: "#e8f0ee" }}>Wide Ball Recovery Builder</p>
          <p className="text-xs mt-0.5" style={{ color: "#3a6660" }}>New drill · Orange Ball 2</p>
        </div>
        <div className="w-px h-10 shrink-0" style={{ background: "rgba(0,201,167,0.15)" }} />
        <div className="flex items-center gap-4">
          {[
            { val: willUpdateCount, label: "Will Update", color: "#00c9a7" },
            { val: needsReviewCount, label: "Needs Review", color: "#ffaa00" },
            { val: IMPACT_ITEMS.filter(i => i.status === "not-affected").length, label: "Not Affected", color: "#5a7a76" },
            { val: IMPACT_ITEMS.filter(i => i.status === "future").length, label: "Future", color: "#a07de0" },
          ].map(({ val, label, color }) => (
            <div key={label} className="text-center">
              <div className="text-xl font-bold" style={{ color, fontFamily: "monospace" }}>{val}</div>
              <div className="text-[10px] uppercase tracking-wider" style={{ color: "#3a6660" }}>{label}</div>
            </div>
          ))}
        </div>
      </div>

      {/* Impact cards grid */}
      <div className="grid grid-cols-2 gap-3 mb-5">
        {IMPACT_ITEMS.map((item, i) => {
          const cfg = STATUS_CONFIG[item.status];
          const Icon = cfg.icon;
          return (
            <div
              key={item.area}
              className="rounded-xl px-4 py-3 flex items-start gap-3 animate-stagger-in"
              style={{
                background: cfg.bg,
                border: `1px solid ${cfg.border}`,
                animationDelay: `${i * 55}ms`,
              }}
            >
              <Icon size={14} style={{ color: cfg.color, flexShrink: 0, marginTop: 2 }} />
              <div className="flex-1 min-w-0">
                <div className="flex items-center justify-between gap-2 mb-0.5">
                  <span className="text-sm font-semibold truncate" style={{ color: "#e8f0ee" }}>
                    {item.area}
                  </span>
                  <span
                    className="text-[9px] font-semibold px-1.5 py-0.5 rounded shrink-0"
                    style={{
                      background: `${cfg.color}20`,
                      color: cfg.color,
                      border: `1px solid ${cfg.color}30`,
                      textTransform: "uppercase",
                      letterSpacing: "0.05em",
                    }}
                  >
                    {cfg.label}
                  </span>
                </div>
                <p className="text-xs" style={{ color: "#5a7a76" }}>{item.desc}</p>
              </div>
            </div>
          );
        })}
      </div>

      {/* Action buttons */}
      <div
        className="rounded-xl px-5 py-4 flex items-center gap-2 flex-wrap animate-stagger-in"
        style={{
          background: "#111a18",
          border: "1px solid rgba(0,201,167,0.08)",
          animationDelay: "550ms",
        }}
      >
        <button
          onClick={() => handleApply("Orange Ball 2")}
          className="flex items-center gap-1.5 px-4 py-2 rounded-lg text-sm font-semibold transition-all duration-150"
          style={{ background: "#00c9a7", color: "#050d0b" }}
          onMouseEnter={e => { (e.currentTarget as HTMLElement).style.background = "#00e5c4"; }}
          onMouseLeave={e => { (e.currentTarget as HTMLElement).style.background = "#00c9a7"; }}
        >
          <CheckCircle size={14} /> Apply to this level only
        </button>
        <button
          onClick={() => handleApply("all Orange Ball 2 groups")}
          className="flex items-center gap-1.5 px-4 py-2 rounded-lg text-sm font-medium transition-all duration-150"
          style={{ background: "rgba(255,255,255,0.04)", color: "#a0b8b4", border: "1px solid rgba(255,255,255,0.08)" }}
          onMouseEnter={e => { (e.currentTarget as HTMLElement).style.background = "rgba(255,255,255,0.08)"; (e.currentTarget as HTMLElement).style.color = "#e8f0ee"; }}
          onMouseLeave={e => { (e.currentTarget as HTMLElement).style.background = "rgba(255,255,255,0.04)"; (e.currentTarget as HTMLElement).style.color = "#a0b8b4"; }}
        >
          <Layers size={14} /> Apply to all Orange Ball 2 groups
        </button>
        <button
          onClick={() => handleApply("entire academy")}
          className="flex items-center gap-1.5 px-4 py-2 rounded-lg text-sm font-medium transition-all duration-150"
          style={{ background: "rgba(255,255,255,0.04)", color: "#a0b8b4", border: "1px solid rgba(255,255,255,0.08)" }}
          onMouseEnter={e => { (e.currentTarget as HTMLElement).style.background = "rgba(255,255,255,0.08)"; (e.currentTarget as HTMLElement).style.color = "#e8f0ee"; }}
          onMouseLeave={e => { (e.currentTarget as HTMLElement).style.background = "rgba(255,255,255,0.04)"; (e.currentTarget as HTMLElement).style.color = "#a0b8b4"; }}
        >
          Apply academy-wide
        </button>
        <button
          onClick={() => { toast.info("Saved as draft"); navigate("/change-queue"); }}
          className="flex items-center gap-1.5 px-4 py-2 rounded-lg text-sm font-medium transition-all duration-150"
          style={{ background: "rgba(255,255,255,0.04)", color: "#a0b8b4", border: "1px solid rgba(255,255,255,0.08)" }}
          onMouseEnter={e => { (e.currentTarget as HTMLElement).style.background = "rgba(255,255,255,0.08)"; (e.currentTarget as HTMLElement).style.color = "#e8f0ee"; }}
          onMouseLeave={e => { (e.currentTarget as HTMLElement).style.background = "rgba(255,255,255,0.04)"; (e.currentTarget as HTMLElement).style.color = "#a0b8b4"; }}
        >
          Save as Draft
        </button>
        <button
          onClick={() => navigate("/level-builder")}
          className="flex items-center gap-1.5 px-4 py-2 rounded-lg text-sm font-medium transition-all duration-150 ml-auto"
          style={{ background: "rgba(224,82,82,0.08)", color: "#e05252", border: "1px solid rgba(224,82,82,0.15)" }}
          onMouseEnter={e => { (e.currentTarget as HTMLElement).style.background = "rgba(224,82,82,0.15)"; }}
          onMouseLeave={e => { (e.currentTarget as HTMLElement).style.background = "rgba(224,82,82,0.08)"; }}
        >
          Cancel
        </button>
      </div>
    </AppLayout>
  );
}
