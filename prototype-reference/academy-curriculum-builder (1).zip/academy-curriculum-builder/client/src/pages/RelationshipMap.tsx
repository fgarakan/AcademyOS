/*
 * Screen 7 — Visual Curriculum Relationship Map
 * AnglesOS brand: graph-style view with pulsing nodes and animated connections
 */
import { useState } from "react";
import { useLocation } from "wouter";
import AppLayout from "@/components/AppLayout";
import DonnaPanel from "@/components/DonnaPanel";
import { toast } from "sonner";

interface Node {
  id: string;
  label: string;
  sublabel?: string;
  type: "center" | "skill" | "fitness" | "assessment" | "mission" | "parent";
  x: number;
  y: number;
  color: string;
}

const NODES: Node[] = [
  { id: "center", label: "Orange Ball 2", sublabel: "74% complete", type: "center", x: 50, y: 50, color: "#ff9500" },
  { id: "fh", label: "Forehand Preparation", sublabel: "Skill", type: "skill", x: 18, y: 20, color: "#00c9a7" },
  { id: "bh", label: "Backhand Spacing", sublabel: "Skill", type: "skill", x: 80, y: 18, color: "#00c9a7" },
  { id: "rec", label: "Recovery Movement", sublabel: "Skill", type: "skill", x: 14, y: 55, color: "#00c9a7" },
  { id: "cross", label: "Crosscourt Pattern", sublabel: "Skill", type: "skill", x: 82, y: 52, color: "#00c9a7" },
  { id: "mob", label: "Low Contact Mobility", sublabel: "Fitness", type: "fitness", x: 22, y: 82, color: "#a07de0" },
  { id: "rally", label: "Rally Tolerance Gate", sublabel: "Assessment", type: "assessment", x: 78, y: 82, color: "#ffaa00" },
  { id: "mission", label: "Crosscourt Builder", sublabel: "Player Mission", type: "mission", x: 50, y: 88, color: "#e05252" },
  { id: "parent", label: "Parent Summary", sublabel: "What your child is working on", type: "parent", x: 50, y: 14, color: "#5a7a76" },
];

const EDGES: [string, string][] = [
  ["center", "fh"],
  ["center", "bh"],
  ["center", "rec"],
  ["center", "cross"],
  ["center", "mob"],
  ["center", "rally"],
  ["center", "mission"],
  ["center", "parent"],
  ["fh", "rec"],
  ["rec", "mob"],
  ["cross", "rally"],
  ["rally", "mission"],
];

const TYPE_LABELS: Record<string, string> = {
  center: "Level",
  skill: "Skill",
  fitness: "Fitness",
  assessment: "Assessment",
  mission: "Mission",
  parent: "Summary",
};

export default function RelationshipMap() {
  const [, navigate] = useLocation();
  const [hoveredNode, setHoveredNode] = useState<string | null>(null);

  const getNode = (id: string) => NODES.find(n => n.id === id)!;

  return (
    <AppLayout
      title="Relationship Map"
      subtitle="Orange Ball 2 — how everything connects"
      donnaPanel={
        <DonnaPanel
          greeting="This map shows how Orange Ball 2 connects to every part of your curriculum."
          subtext="Click any node to explore its connections. Pulsing nodes have recent changes."
          options={[
            { label: "View Forehand Preparation", onClick: () => toast.info("Opening Forehand Preparation…") },
            { label: "View Assessment Gates", onClick: () => toast.info("Opening Assessment Gates…") },
            { label: "Add a connection", onClick: () => toast.info("Select two nodes to connect…") },
            { label: "Export this map", onClick: () => toast.info("Exporting relationship map…") },
          ]}
        >
          {/* Node legend */}
          <div className="mt-3 space-y-1.5">
            <p className="text-[10px] font-semibold uppercase tracking-widest mb-2" style={{ color: "#2a4a46" }}>
              Node Types
            </p>
            {[
              { label: "Level", color: "#ff9500" },
              { label: "Skill", color: "#00c9a7" },
              { label: "Fitness", color: "#a07de0" },
              { label: "Assessment", color: "#ffaa00" },
              { label: "Mission", color: "#e05252" },
              { label: "Summary", color: "#5a7a76" },
            ].map(({ label, color }) => (
              <div key={label} className="flex items-center gap-2">
                <div className="w-2 h-2 rounded-full" style={{ background: color }} />
                <span className="text-xs" style={{ color: "#5a7a76" }}>{label}</span>
              </div>
            ))}
          </div>
        </DonnaPanel>
      }
    >
      {/* SVG relationship map */}
      <div
        className="rounded-xl overflow-hidden animate-fade-in"
        style={{
          background: "#0d1614",
          border: "1px solid rgba(0,201,167,0.08)",
          position: "relative",
          height: "580px",
        }}
      >
        <svg
          width="100%"
          height="100%"
          viewBox="0 0 100 100"
          preserveAspectRatio="xMidYMid meet"
          style={{ position: "absolute", inset: 0 }}
        >
          {/* Grid dots */}
          {Array.from({ length: 10 }).map((_, row) =>
            Array.from({ length: 10 }).map((_, col) => (
              <circle
                key={`${row}-${col}`}
                cx={col * 11 + 5}
                cy={row * 11 + 5}
                r="0.3"
                fill="rgba(0,201,167,0.08)"
              />
            ))
          )}

          {/* Edges */}
          {EDGES.map(([fromId, toId]) => {
            const from = getNode(fromId);
            const to = getNode(toId);
            const isHovered = hoveredNode === fromId || hoveredNode === toId;
            return (
              <line
                key={`${fromId}-${toId}`}
                x1={from.x}
                y1={from.y}
                x2={to.x}
                y2={to.y}
                stroke={isHovered ? "rgba(0,201,167,0.4)" : "rgba(0,201,167,0.12)"}
                strokeWidth={isHovered ? "0.5" : "0.3"}
                strokeDasharray={fromId === "center" || toId === "center" ? "none" : "1,1"}
                style={{ transition: "stroke 200ms, stroke-width 200ms" }}
              />
            );
          })}

          {/* Nodes */}
          {NODES.map((node, i) => {
            const isCenter = node.type === "center";
            const isHovered = hoveredNode === node.id;
            const r = isCenter ? 6 : 4;
            return (
              <g
                key={node.id}
                style={{ cursor: "pointer" }}
                onMouseEnter={() => setHoveredNode(node.id)}
                onMouseLeave={() => setHoveredNode(null)}
                onClick={() => toast.info(`${node.label} — ${node.sublabel}`)}
              >
                {/* Pulse ring for center and hovered */}
                {(isCenter || isHovered) && (
                  <circle
                    cx={node.x}
                    cy={node.y}
                    r={r + 2}
                    fill="none"
                    stroke={node.color}
                    strokeWidth="0.4"
                    opacity={isHovered ? 0.6 : 0.3}
                    style={{
                      animation: "node-pulse 2.5s ease-in-out infinite",
                    }}
                  />
                )}
                {/* Node circle */}
                <circle
                  cx={node.x}
                  cy={node.y}
                  r={r}
                  fill={isCenter ? node.color : `${node.color}20`}
                  stroke={node.color}
                  strokeWidth={isCenter ? "0" : isHovered ? "0.8" : "0.5"}
                  style={{
                    transition: "all 200ms",
                    filter: isHovered ? `drop-shadow(0 0 4px ${node.color}80)` : "none",
                  }}
                />
                {/* Center label inside */}
                {isCenter && (
                  <text
                    x={node.x}
                    y={node.y + 0.5}
                    textAnchor="middle"
                    dominantBaseline="middle"
                    fontSize="1.8"
                    fontWeight="bold"
                    fill="#050d0b"
                    style={{ fontFamily: "Inter, sans-serif" }}
                  >
                    O2
                  </text>
                )}
                {/* Outer label */}
                <text
                  x={node.x}
                  y={node.y + r + 2.5}
                  textAnchor="middle"
                  fontSize="2"
                  fontWeight={isHovered ? "600" : "400"}
                  fill={isHovered ? node.color : "#a0b8b4"}
                  style={{
                    fontFamily: "Inter, sans-serif",
                    transition: "fill 200ms",
                  }}
                >
                  {node.label}
                </text>
                {node.sublabel && (
                  <text
                    x={node.x}
                    y={node.y + r + 4.5}
                    textAnchor="middle"
                    fontSize="1.6"
                    fill={isHovered ? `${node.color}90` : "#3a6660"}
                    style={{ fontFamily: "Inter, sans-serif" }}
                  >
                    {node.sublabel}
                  </text>
                )}
              </g>
            );
          })}
        </svg>

        {/* Hover tooltip */}
        {hoveredNode && hoveredNode !== "center" && (
          <div
            className="absolute bottom-4 left-4 rounded-xl px-4 py-3 animate-scale-in"
            style={{
              background: "#111a18",
              border: `1px solid ${getNode(hoveredNode).color}40`,
              minWidth: "200px",
            }}
          >
            <div className="flex items-center gap-2 mb-1">
              <div
                className="w-2 h-2 rounded-full"
                style={{ background: getNode(hoveredNode).color }}
              />
              <span className="text-xs font-bold" style={{ color: "#e8f0ee" }}>
                {getNode(hoveredNode).label}
              </span>
            </div>
            <p className="text-[10px]" style={{ color: "#5a7a76" }}>
              {TYPE_LABELS[getNode(hoveredNode).type]} · Click to explore
            </p>
          </div>
        )}
      </div>
    </AppLayout>
  );
}
